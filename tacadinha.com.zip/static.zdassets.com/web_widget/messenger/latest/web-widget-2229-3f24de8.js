"use strict";
(globalThis.webpackChunk_zendesk_web_widget_messenger = globalThis.webpackChunk_zendesk_web_widget_messenger || []).push([
    [2229], {
        7087: (e, t, n) => {
            n.d(t, {
                vV: () => c,
                G1: () => u,
                yT: () => a,
                fb: () => i,
                CH: () => d,
                T7: () => o,
                xY: () => l,
                og: () => s,
                Uc: () => p
            });
            var r = n(26436);
            const s = "0px 20px 30px rgba(23, 73, 77, 0.15)",
                i = "ZD-campaigns",
                o = 280,
                a = 40,
                d = 40,
                l = "20px",
                c = [{
                    opacity: 0
                }, {
                    opacity: 1
                }],
                u = {
                    duration: 300,
                    fill: "forwards",
                    easing: "ease-in-out"
                },
                p = e => r.x5 + r._k + e
        },
        43229: (e, t, n) => {
            n.d(t, {
                Ay: () => g
            });
            var r = n(85991),
                s = n(69911),
                i = n(88910),
                o = n(48559);
            const a = !1,
                d = i.createContext(null);
            var l = n(69825),
                c = "unmounted",
                u = "exited",
                p = "entering",
                h = "entered",
                m = "exiting",
                f = function(e) {
                    function t(t, n) {
                        var r;
                        r = e.call(this, t, n) || this;
                        var s, i = n && !n.isMounting ? t.enter : t.appear;
                        return r.appearStatus = null, t.in ? i ? (s = u, r.appearStatus = p) : s = h : s = t.unmountOnExit || t.mountOnEnter ? c : u, r.state = {
                            status: s
                        }, r.nextCallback = null, r
                    }(0, s.A)(t, e), t.getDerivedStateFromProps = function(e, t) {
                        return e.in && t.status === c ? {
                            status: u
                        } : null
                    };
                    var n = t.prototype;
                    return n.componentDidMount = function() {
                        this.updateStatus(!0, this.appearStatus)
                    }, n.componentDidUpdate = function(e) {
                        var t = null;
                        if (e !== this.props) {
                            var n = this.state.status;
                            this.props.in ? n !== p && n !== h && (t = p) : n !== p && n !== h || (t = m)
                        }
                        this.updateStatus(!1, t)
                    }, n.componentWillUnmount = function() {
                        this.cancelNextCallback()
                    }, n.getTimeouts = function() {
                        var e, t, n, r = this.props.timeout;
                        return e = t = n = r, null != r && "number" != typeof r && (e = r.exit, t = r.enter, n = void 0 !== r.appear ? r.appear : t), {
                            exit: e,
                            enter: t,
                            appear: n
                        }
                    }, n.updateStatus = function(e, t) {
                        if (void 0 === e && (e = !1), null !== t)
                            if (this.cancelNextCallback(), t === p) {
                                if (this.props.unmountOnExit || this.props.mountOnEnter) {
                                    var n = this.props.nodeRef ? this.props.nodeRef.current : o.findDOMNode(this);
                                    n && (0, l.F)(n)
                                }
                                this.performEnter(e)
                            } else this.performExit();
                        else this.props.unmountOnExit && this.state.status === u && this.setState({
                            status: c
                        })
                    }, n.performEnter = function(e) {
                        var t = this,
                            n = this.props.enter,
                            r = this.context ? this.context.isMounting : e,
                            s = this.props.nodeRef ? [r] : [o.findDOMNode(this), r],
                            i = s[0],
                            d = s[1],
                            l = this.getTimeouts(),
                            c = r ? l.appear : l.enter;
                        !e && !n || a ? this.safeSetState({
                            status: h
                        }, (function() {
                            t.props.onEntered(i)
                        })) : (this.props.onEnter(i, d), this.safeSetState({
                            status: p
                        }, (function() {
                            t.props.onEntering(i, d), t.onTransitionEnd(c, (function() {
                                t.safeSetState({
                                    status: h
                                }, (function() {
                                    t.props.onEntered(i, d)
                                }))
                            }))
                        })))
                    }, n.performExit = function() {
                        var e = this,
                            t = this.props.exit,
                            n = this.getTimeouts(),
                            r = this.props.nodeRef ? void 0 : o.findDOMNode(this);
                        t && !a ? (this.props.onExit(r), this.safeSetState({
                            status: m
                        }, (function() {
                            e.props.onExiting(r), e.onTransitionEnd(n.exit, (function() {
                                e.safeSetState({
                                    status: u
                                }, (function() {
                                    e.props.onExited(r)
                                }))
                            }))
                        }))) : this.safeSetState({
                            status: u
                        }, (function() {
                            e.props.onExited(r)
                        }))
                    }, n.cancelNextCallback = function() {
                        null !== this.nextCallback && (this.nextCallback.cancel(), this.nextCallback = null)
                    }, n.safeSetState = function(e, t) {
                        t = this.setNextCallback(t), this.setState(e, t)
                    }, n.setNextCallback = function(e) {
                        var t = this,
                            n = !0;
                        return this.nextCallback = function(r) {
                            n && (n = !1, t.nextCallback = null, e(r))
                        }, this.nextCallback.cancel = function() {
                            n = !1
                        }, this.nextCallback
                    }, n.onTransitionEnd = function(e, t) {
                        this.setNextCallback(t);
                        var n = this.props.nodeRef ? this.props.nodeRef.current : o.findDOMNode(this),
                            r = null == e && !this.props.addEndListener;
                        if (n && !r) {
                            if (this.props.addEndListener) {
                                var s = this.props.nodeRef ? [this.nextCallback] : [n, this.nextCallback],
                                    i = s[0],
                                    a = s[1];
                                this.props.addEndListener(i, a)
                            }
                            null != e && setTimeout(this.nextCallback, e)
                        } else setTimeout(this.nextCallback, 0)
                    }, n.render = function() {
                        var e = this.state.status;
                        if (e === c) return null;
                        var t = this.props,
                            n = t.children,
                            s = (t.in, t.mountOnEnter, t.unmountOnExit, t.appear, t.enter, t.exit, t.timeout, t.addEndListener, t.onEnter, t.onEntering, t.onEntered, t.onExit, t.onExiting, t.onExited, t.nodeRef, (0, r.A)(t, ["children", "in", "mountOnEnter", "unmountOnExit", "appear", "enter", "exit", "timeout", "addEndListener", "onEnter", "onEntering", "onEntered", "onExit", "onExiting", "onExited", "nodeRef"]));
                        return i.createElement(d.Provider, {
                            value: null
                        }, "function" == typeof n ? n(e, s) : i.cloneElement(i.Children.only(n), s))
                    }, t
                }(i.Component);

            function x() {}
            f.contextType = d, f.propTypes = {}, f.defaultProps = { in: !1,
                mountOnEnter: !1,
                unmountOnExit: !1,
                appear: !1,
                enter: !0,
                exit: !0,
                onEnter: x,
                onEntering: x,
                onEntered: x,
                onExit: x,
                onExiting: x,
                onExited: x
            }, f.UNMOUNTED = c, f.EXITED = u, f.ENTERING = p, f.ENTERED = h, f.EXITING = m;
            const g = f
        },
        50915: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => Le
            });
            var r = n(48559),
                s = n(20912),
                i = n(88910),
                o = n(24726),
                a = n.n(o),
                d = n(70069),
                l = n(54899),
                c = n(43229),
                u = n(12826),
                p = n(94998);
            const h = u.Ay.div.withConfig({
                componentId: "sc-1q9fwvy-0"
            })(["position:absolute;left:0px;display:flex;align-items:center;justify-content:center;height:100%;width:100%;transition:top ", "s ", ";", ""], .5, p.rN, (e => "entering" === e.state || "entered" === e.state ? (0, u.AH)(["top:0;"]) : (0, u.AH)(["top:", ";"], e.hiddenPosition)));
            var m = n(86222);
            const f = ({
                isVisible: e,
                hiddenPosition: t,
                children: n
            }) => (0, m.jsx)(c.Ay, { in: e,
                timeout: 500,
                children: e => (0, m.jsx)(h, {
                    state: e,
                    hiddenPosition: t,
                    "aria-hidden": "true",
                    children: n
                })
            });
            f.propTypes = {
                isVisible: a().bool,
                hiddenPosition: a().string,
                children: a().node
            };
            const x = f;
            var g = function(e) {
                return (0, m.jsx)("svg", { ...e,
                    children: (0, m.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        fill: "currentColor",
                        d: "M20.1005 2.7169L10.9931 11.8244C10.4724 12.3451 9.62815 12.3451 9.10745 11.8244L-8.00829e-06 2.7169L1.88561 0.831278L10.0503 8.99593L18.2149 0.831278L20.1005 2.7169Z"
                    })
                })
            };
            g.defaultProps = {
                xmlns: "http://www.w3.org/2000/svg",
                width: "21",
                height: "13",
                viewBox: "0 0 21 13",
                focusable: "false",
                role: "presentation",
                "aria-hidden": "true"
            };
            var b = function(e) {
                return (0, m.jsx)("svg", { ...e,
                    children: (0, m.jsx)("path", {
                        d: "M10,18 L6,22 L6,18 L10,18 Z M17,6 C19.7614237,6 22,8.23857625 22,11 C22,13.7614237 19.7614237,16 17,16 L17,16 L7,16 C4.23857625,16 2,13.7614237 2,11 C2,8.23857625 4.23857625,6 7,6 L7,6 Z",
                        transform: "translate(12.000000, 14.000000) scale(-1, 1) translate(-12.000000, -14.000000) "
                    })
                })
            };
            b.defaultProps = {
                width: "24px",
                height: "24px",
                viewBox: "0 0 24 24",
                version: "1.1",
                xmlns: "http://www.w3.org/2000/svg",
                xmlnsXlink: "http://www.w3.org/1999/xlink",
                "aria-hidden": "true"
            };
            const y = (0, u.Ay)(g).withConfig({
                    componentId: "sc-1k07fow-0"
                })(["path{fill:", ";}"], (e => e.theme.messenger.colors.primaryForegroundColor)),
                w = (0, u.Ay)(b).withConfig({
                    componentId: "sc-1k07fow-1"
                })(["width:60% !important;height:60% !important;path{fill:", ";}", ""], (e => e.theme.messenger.colors.primaryForegroundColor), (e => "left" === e.position && "\n    transform: scaleX(-1);\n  ")),
                E = ({
                    isOpen: e,
                    position: t
                }) => (0, m.jsxs)(m.Fragment, {
                    children: [(0, m.jsx)(x, {
                        isVisible: !e,
                        hiddenPosition: "-100%",
                        children: (0, m.jsx)(w, {
                            position: t
                        })
                    }), (0, m.jsx)(x, {
                        isVisible: e,
                        hiddenPosition: "100%",
                        children: (0, m.jsx)(y, {})
                    })]
                });
            E.propTypes = {
                isOpen: a().bool,
                position: a().oneOf(["left", "right"])
            };
            const k = E;
            var v = n(36913);
            const C = u.Ay.div.withConfig({
                    componentId: "sc-1w3tvxe-0"
                })(["width:", ";height:", ";border-radius:", ";box-shadow:rgb(36,36,36,0.15) 0px 20px 30px 0px;display:flex;align-items:center;justify-content:center;background-color:", " !important;"], (({
                    size: e
                }) => e ? ? "100%"), (({
                    size: e
                }) => e ? ? "100%"), (({
                    shape: e,
                    shapeSettings: t
                }) => A(e, t)), (({
                    theme: e
                }) => e.messenger.colors.primaryBackgroundColor)),
                j = (0, u.Ay)(v.K).withConfig({
                    componentId: "sc-1w3tvxe-1"
                })(["&&&{position:relative;overflow:hidden;border-radius:", ";width:100%;height:100%;background-color:", ";border:", ";&:active{box-shadow:none;}&:focus{box-shadow:none;}&[data-garden-focus-visible]{box-shadow:inset ", ";}}"], (({
                    shape: e,
                    shapeSettings: t
                }) => A(e, t)), (({
                    theme: e
                }) => e.messenger.colors.primaryBackgroundColor), (({
                    theme: e
                }) => `${e.shadowWidths.sm} solid ${e.messenger.colors.primaryBackgroundColor}`), (({
                    theme: e
                }) => e.shadows.sm(e.messenger.colors.primaryForegroundColor))),
                A = (e, t) => {
                    switch (e) {
                        case d.Fe.circle:
                            return d.mi.circle;
                        case d.Fe.square:
                            return t ? .borderRadius ? `${t.borderRadius}px` : d.mi.square;
                        default:
                            return "0"
                    }
                },
                S = (0, i.forwardRef)((({
                    shape: e,
                    shapeSettings: t,
                    isOpen: n,
                    onClick: r,
                    position: s,
                    size: i,
                    unreadCount: o
                }, a) => {
                    const {
                        launcher: {
                            openWindowAriaLabel: d,
                            closeWindowAriaLabel: c
                        },
                        ariaLabels: {
                            unreadMessagesCount: {
                                oneUnreadMessage: u,
                                moreThanOneUnreadMessage: p
                            }
                        }
                    } = (0, l.A)();
                    let h;
                    h = 1 === o ? `, ${u}` : o > 1 ? `, ${p(o)}` : "";
                    const f = n ? c : `${d}${h}`;
                    return (0, m.jsx)(C, {
                        ref: a,
                        size: i,
                        shape: e,
                        shapeSettings: t,
                        children: (0, m.jsx)(j, {
                            shape: e,
                            shapeSettings: t,
                            onClick: r,
                            "aria-label": f,
                            isPill: !1,
                            onKeyDown: () => {},
                            children: (0, m.jsx)(k, {
                                isOpen: n,
                                position: s
                            })
                        })
                    })
                }));
            S.propTypes = {
                shape: a().oneOf(Object.keys(d.Fe)),
                shapeSettings: a().shape({
                    borderRadius: a().string
                }),
                isOpen: a().bool,
                onClick: a().func,
                position: a().oneOf(Object.keys(d.x8)),
                size: a().string,
                unreadCount: a().number
            }, S.defaultProps = {
                size: "64px"
            };
            const _ = S;
            var O = n(26436),
                T = n(55265),
                L = n(88083),
                Y = n(84234),
                R = n(874),
                $ = n(79733),
                N = n(97813),
                F = n(21521);
            const I = () => {
                const e = (0, s.d4)(F.l$),
                    t = (0, s.d4)(N.a7),
                    n = (0, s.d4)(N.zS),
                    [r, o] = (0, i.useState)(0);
                return (0, i.useEffect)((() => {
                    "number" == typeof n && "number" == typeof t && (e === F.h_.SingleConversation ? o(t) : o(n))
                }), [e, t, n]), r
            };
            var D = n(45812),
                M = n(27186),
                z = n(52859),
                P = n(42350),
                H = n(99028),
                W = n(82665),
                U = n(30339),
                B = n(87944),
                G = n(18333),
                Z = n(70609),
                X = n(48167),
                K = n(33402);
            const V = `ww-${(0,n(84858).A)()}`,
                q = `${V}-launcherOnOpen`,
                J = `${V}-widgetOnLoad`,
                Q = `\n        @-webkit-keyframes ${q} {\n          0% {\n            -webkit-transform: translateY(0px) rotate(0deg);\n                    transform: translateY(0px) rotate(0deg);\n          }\n\n          30% {\n            -webkit-transform: translateY(-5px) rotate(2deg);\n                    transform: translateY(-5px) rotate(2deg);\n          }\n\n          60% {\n            -webkit-transform: translateY(0px) rotate(0deg);\n                    transform: translateY(0px) rotate(0deg);\n          }\n\n\n          90% {\n            -webkit-transform: translateY(-1px) rotate(0deg);\n                    transform: translateY(-1px) rotate(0deg);\n\n          }\n\n          100% {\n            -webkit-transform: translateY(-0px) rotate(0deg);\n                    transform: translateY(-0px) rotate(0deg);\n          }\n        }\n        @keyframes ${q} {\n          0% {\n            -webkit-transform: translateY(0px) rotate(0deg);\n                    transform: translateY(0px) rotate(0deg);\n          }\n\n          30% {\n            -webkit-transform: translateY(-5px) rotate(2deg);\n                    transform: translateY(-5px) rotate(2deg);\n          }\n\n          60% {\n            -webkit-transform: translateY(0px) rotate(0deg);\n                    transform: translateY(0px) rotate(0deg);\n          }\n\n\n          90% {\n            -webkit-transform: translateY(-1px) rotate(0deg);\n                    transform: translateY(-1px) rotate(0deg);\n\n          }\n\n          100% {\n            -webkit-transform: translateY(-0px) rotate(0deg);\n                    transform: translateY(-0px) rotate(0deg);\n          }\n        }\n\n        @keyframes ${J} {\n          0% {\n            opacity: 0;\n          }\n          100% {\n            opacity: 1;\n          }\n        }\n\n        @-webkit-keyframes ${J} {\n          0% {\n            opacity: 0;\n          }\n          100% {\n            opacity: 1;\n          }\n        }\n      `,
                ee = ({
                    children: e
                }) => {
                    const t = (0, s.d4)(Y.xD),
                        n = (0, s.d4)(B._),
                        r = (0, s.d4)(B.d),
                        o = (0, s.d4)($.E9),
                        a = (0, s.d4)(T.rU),
                        l = (0, s.d4)($.fl),
                        c = (0, s.d4)(T.iG),
                        u = (0, s.d4)(T.dA),
                        {
                            horizontal: p,
                            vertical: h
                        } = (0, s.d4)($.XI),
                        f = h > O.G1,
                        x = I(),
                        g = (0, s.d4)(Z.rX),
                        b = (0, U.A)(),
                        {
                            isZoomedIn: y
                        } = (0, W.A)(),
                        w = !n && !r,
                        E = A(c, u),
                        k = (0, s.Pj)(),
                        v = (0, i.useCallback)((() => {
                            let e = b("embeddable_framework.messenger.launcher.frame.title");
                            return g === K.v.Successful && (e = 0 === x ? b("embeddable_framework.messenger.launcher.frame.no_new_messages_title") : 1 === x ? b("embeddable_framework.messenger.launcher.frame.one_new_message_title") : b("embeddable_framework.messenger.launcher.frame.new_messages_title", {
                                count: x
                            })), e
                        }), [g, x]);
                    let C = [];
                    return a && C.push(`${J} 0.2s ease-in ${G.X}s forwards`), t && w && C.push(`${q} ${d.tV}s ${O.rN}`), (0, m.jsxs)(m.Fragment, {
                        children: [(0, m.jsx)("style", {
                            dangerouslySetInnerHTML: {
                                __html: Q
                            }
                        }), (0, m.jsx)(H.Ay, {
                            title: v(),
                            hidden: !a,
                            id: "launcher",
                            style: {
                                height: O._k,
                                width: O._k,
                                position: "fixed",
                                bottom: y && f ? O.G1 : h,
                                [o]: p,
                                border: 0,
                                marginTop: 0,
                                opacity: 0,
                                boxShadow: O.RD,
                                animation: C.join(", "),
                                zIndex: l,
                                borderRadius: E
                            },
                            onKeyDown: e => {
                                (0, M.tE)(e, k)
                            },
                            children: (0, m.jsx)(X.A, {
                                setBackgroundColor: !0,
                                children: e
                            })
                        })]
                    })
                };
            ee.propTypes = {
                children: a().node
            };
            const te = ee,
                ne = () => {
                    const e = (0, s.wA)(),
                        t = (0, s.d4)(Y.xD),
                        n = (0, s.d4)($.E9),
                        r = (0, s.d4)(T.iG),
                        o = (0, s.d4)(T.dA),
                        a = (0, s.d4)(D.B1),
                        d = (0, i.useRef)(null),
                        l = I(),
                        c = (0, s.d4)(P.HA);
                    return (0, i.useEffect)((() => {
                        const e = d.current ? .querySelector("button");
                        c || !e || t || e.focus()
                    }), [c, t]), (0, i.useEffect)((() => {
                        z.A.markOnce("launcher_rendered")
                    }), []), (0, i.useEffect)((() => ((0, M.kT)("refLauncher", d), L.W(d.current), () => {
                        L.T(d.current)
                    })), [d]), a ? (0, m.jsx)(te, {
                        children: (0, m.jsx)(_, {
                            ref: d,
                            isOpen: t,
                            onClick: () => {
                                z.A.markOnce("launcher_clicked"), e((0, R.fH)())
                            },
                            position: n,
                            shape: r,
                            shapeSettings: o,
                            size: `${O._k}px`,
                            unreadCount: l
                        })
                    }) : null
                };
            var re = n(32583),
                se = n(91857),
                ie = n(188),
                oe = n(61688),
                ae = n(99317),
                de = n(39453),
                le = n(31650),
                ce = n(44025),
                ue = n(83268),
                pe = n(47386),
                he = n(79390),
                me = n(93901),
                fe = n(97247),
                xe = n(77315);
            const ge = () => {
                const e = (0, s.wA)(),
                    t = (0, s.d4)(Y.xD),
                    n = (0, s.d4)(P.HA),
                    r = (0, s.d4)(oe._6),
                    o = (0, s.d4)(D.B1),
                    a = (0, i.useRef)(n),
                    d = (0, s.d4)(me.WP),
                    l = (0, ie.rr)(),
                    c = (0, s.d4)(oe.oP),
                    [u, p] = (0, i.useState)(!1);
                n && (a.current = !0), (0, i.useLayoutEffect)((() => {
                    t && a.current && e((0, P.LT)())
                }), [t]), (0, i.useEffect)((() => {
                    d && !u && p(!0)
                }), [d]);
                const h = (0, U.A)(),
                    f = h("embeddable_framework.messenger.launcher_label.close_v2"),
                    x = h("embeddable_framework.messenger.launcher_label.close_v3"),
                    g = h("embeddable_framework.messenger.launcher_label.frame.title"),
                    b = n && o && !u && (!l || c),
                    y = (0, i.useRef)({}),
                    {
                        onClickAnimate: w,
                        animateHide: E
                    } = (0, pe.A)({
                        isLabelVisible: b,
                        refs: y
                    }),
                    {
                        maxWidth: k,
                        messageContainerHeight: v,
                        messageFrameHeight: C,
                        messageFrameWidth: j,
                        setFrameDimensions: A
                    } = (0, he.A)({
                        refs: y,
                        isIconNextToMessage: !0
                    });
                return b ? (0, m.jsx)(ae.A, {
                    children: (0, m.jsxs)(de.A, {
                        children: [(0, m.jsx)(le.A, {
                            title: f,
                            ref: e => y.current.closeFrame = e,
                            children: (0, m.jsx)(re.A, {
                                ariaLabel: x,
                                onClick: () => {
                                    E((() => {
                                        e((0, P.LT)())
                                    }))
                                }
                            })
                        }), (0, m.jsx)(ce.A, {
                            ref: e => y.current.messageFrame = e,
                            title: g,
                            maxWidth: k,
                            messageFrameWidth: j,
                            messageFrameHeight: C,
                            children: (0, m.jsx)(ue.N, {
                                maxMessageContainerHeight: v,
                                children: (0, m.jsx)(se.A, {
                                    message: r,
                                    maxWidth: k,
                                    onClick: () => {
                                        w((() => {
                                            e((0, R.Gi)())
                                        })), (0, fe.U)(fe.o.OPEN, {
                                            source: xe.HU.GreetingMessage
                                        })
                                    },
                                    onRender: A
                                })
                            })
                        })]
                    })
                }) : null
            };
            var be = n(26277);
            const ye = (0, i.lazy)((() => n.e(6209).then(n.bind(n, 66209)))),
                we = () => {
                    const [e, t] = (0, i.useState)(!1), n = (0, s.d4)(be.BH);
                    return (0, i.useEffect)((() => {
                        n && t(!0)
                    }), [n]), (0, m.jsx)(i.Suspense, {
                        fallback: null,
                        children: e && (0, m.jsx)(ye, {})
                    })
                },
                Ee = u.Ay.div.withConfig({
                    componentId: "sc-1o8glcn-0"
                })(["height:", "px;min-width:", "px;color:", ";background-color:", ";border-radius:", "px;display:flex;justify-content:center;align-items:center;font-size:14px;padding:0 6px;", ""], 20, 20, (e => e.theme.messenger.colors.notifyForegroundColor), (e => e.theme.messenger.colors.notifyBackgroundColor), 20, (({
                    position: e
                }) => `margin-${"right"===e?"left":"right"}: auto`)),
                ke = u.Ay.div.withConfig({
                    componentId: "sc-1o8glcn-1"
                })(["font-size:12px;"]),
                ve = ({
                    unreadCount: e = 0
                }) => {
                    const t = (0, s.wA)(),
                        n = Math.min(e, 99),
                        r = (0, s.d4)($.E9);
                    return (0, m.jsx)("div", {
                        onClick: () => {
                            t((0, R.fH)())
                        },
                        "aria-hidden": "true",
                        style: {
                            cursor: "pointer",
                            width: O.Kr + 20,
                            display: "flex"
                        },
                        children: (0, m.jsxs)(Ee, {
                            position: r,
                            "data-testid": "unread-indicator-container",
                            children: [n, e > 99 && (0, m.jsx)(ke, {
                                children: "+"
                            })]
                        })
                    })
                };
            ve.propTypes = {
                unreadCount: a().number
            };
            const Ce = ve,
                je = (0, u.DU)(["html{background-color:transparent;}"]),
                Ae = ({
                    children: e
                }) => {
                    const t = (0, s.d4)(T.rU),
                        n = (0, s.d4)($.E9),
                        r = (0, s.d4)($.fl),
                        i = (0, U.A)(),
                        {
                            vertical: o,
                            horizontal: a
                        } = (0, s.d4)($.XI),
                        d = o > O.G1,
                        {
                            isZoomedIn: l
                        } = (0, W.A)();
                    return (0, m.jsx)(H.Ay, {
                        tabIndex: "-1",
                        title: i("embeddable_framework.messenger.unread_indicator.frame.title"),
                        hidden: !t,
                        style: {
                            zIndex: r,
                            height: O.Kr,
                            width: O.Kr + 20,
                            position: "fixed",
                            bottom: l && d ? O.ZY.bottom(O.G1) : O.ZY.bottom(o),
                            [n]: "right" === n ? O.ZY.right(a) : O.ZY.left(a),
                            border: 0,
                            marginTop: 0
                        },
                        children: (0, m.jsx)(X.A, {
                            children: (0, m.jsxs)(m.Fragment, {
                                children: [(0, m.jsx)(je, {}), e]
                            })
                        })
                    })
                };
            Ae.propTypes = {
                children: a().node
            };
            const Se = Ae,
                _e = ({
                    unreadCount: e,
                    isWidgetOpen: t
                }) => t || 0 === e ? null : (0, m.jsx)(Se, {
                    children: (0, m.jsx)(Ce, {
                        unreadCount: e
                    })
                });
            _e.propTypes = {
                unreadCount: a().number,
                isWidgetOpen: a().bool
            };
            const Oe = _e,
                Te = () => {
                    const e = I(),
                        t = (0, s.d4)(Y.xD);
                    return (0, m.jsx)(Oe, {
                        unreadCount: e,
                        isWidgetOpen: t
                    })
                },
                Le = ({
                    store: e,
                    container: t,
                    callback: n = null
                }) => {
                    r.render((0, m.jsxs)(s.Kq, {
                        store: e,
                        children: [(0, m.jsx)(we, {}), (0, m.jsx)(ge, {}), (0, m.jsx)(ne, {}), (0, m.jsx)(Te, {})]
                    }), t, n)
                }
        },
        69825: (e, t, n) => {
            n.d(t, {
                F: () => r
            });
            var r = function(e) {
                return e.scrollTop
            }
        },
        88083: (e, t, n) => {
            n.d(t, {
                T: () => i,
                W: () => s
            });
            var r = n(35423);
            const s = e => {
                    try {
                        e.addEventListener("click", (() => {
                            (0, r.gb)()
                        }), {
                            once: !0
                        }), e.addEventListener("input", (() => {
                            (0, r.gb)()
                        }), {
                            once: !0
                        })
                    } catch {}
                },
                i = e => {
                    try {
                        e.removeEventListener("click", (() => {
                            (0, r.gb)()
                        })), e.removeEventListener("input", (() => {
                            (0, r.gb)()
                        }))
                    } catch {}
                }
        },
        94998: (e, t, n) => {
            n.d(t, {
                Ay: () => C,
                kY: () => k,
                lY: () => v,
                rN: () => s
            });
            var r = n(12826);
            const s = "cubic-bezier(0.66, 0, 0.12, 1)",
                i = (e = {}) => ({
                    duration: .3,
                    delay: 0,
                    timing: "linear",
                    ...e
                });
            let o = 0;
            const a = i({
                    delay: o,
                    timing: s,
                    duration: .15
                }),
                d = i({
                    delay: o,
                    timing: "ease"
                }),
                l = i({
                    delay: o,
                    duration: 0
                }),
                c = i({
                    delay: o,
                    duration: 0
                }),
                u = i({
                    delay: o,
                    duration: 0
                }),
                p = i({
                    delay: o
                }),
                h = i({
                    delay: o,
                    duration: .2,
                    timing: "linear"
                });
            o = .15;
            const m = i({
                delay: o,
                duration: .15
            });
            o = .3;
            const f = i({
                    delay: o,
                    duration: .5,
                    fill: "both"
                }),
                x = i({
                    delay: o,
                    duration: .3
                }),
                g = i({
                    delay: o,
                    duration: .3
                }),
                b = i({
                    delay: o,
                    duration: 0
                });
            o = .6;
            const y = i({
                delay: o,
                timing: s
            });
            o = .7;
            const w = i({
                delay: o,
                duration: 0
            });
            o = .9;
            const E = i({
                    delay: o,
                    timing: "ease"
                }),
                k = (e, ...t) => t.map((t => `${t} ${e.duration}s ${e.timing} ${e.delay}s`)).join(", "),
                v = (e, t) => (0, r.AH)(["", " ", "s ", " ", "s ", ""], t, e.duration, e.timing, e.delay, e.fill),
                C = {
                    tailEnter: y,
                    tailExit: a,
                    textEnter: E,
                    textExit: d,
                    messageBorder: m,
                    messageEnter: f,
                    messageStatusOpacity: p,
                    messageColor: h,
                    existingRepliesEnter: l,
                    freshRepliesEnter: w,
                    repliesExit: c,
                    repliesFadeIn: x,
                    receiptEnter: u,
                    receiptReenter: g,
                    receiptExit: b
                }
        }
    }
]);