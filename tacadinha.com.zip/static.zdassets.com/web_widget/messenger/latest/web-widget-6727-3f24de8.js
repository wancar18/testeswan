"use strict";
(globalThis.webpackChunk_zendesk_web_widget_messenger = globalThis.webpackChunk_zendesk_web_widget_messenger || []).push([
    [6727], {
        6917: (e, t, r) => {
            r.d(t, {
                T: () => s,
                k: () => n
            });
            var o = r(12826);
            const n = (0, o.DU)(["html{background-color:transparent;}"]),
                s = (0, o.DU)(["body{opacity:0;}"])
        },
        31650: (e, t, r) => {
            r.d(t, {
                A: () => g
            });
            var o = r(88910),
                n = r(20912),
                s = r(99028),
                i = r(26436),
                a = r(7087),
                l = r(87944),
                c = r(48167),
                d = r(23112),
                m = r(6917),
                h = r(86222);
            const g = (0, o.forwardRef)((({
                children: e,
                title: t
            }, r) => {
                const g = (0, n.d4)(l._) ? i.xm : i.Ez,
                    {
                        height: u,
                        width: p
                    } = (0, o.useMemo)((() => ({
                        height: (0, d.A)(a.CH, g),
                        width: (0, d.A)(a.CH, g)
                    })), [g]);
                return (0, h.jsx)(s.Ay, {
                    title: t,
                    style: {
                        height: u,
                        width: p,
                        border: 0,
                        backgroundColor: "transparent",
                        boxShadow: a.og,
                        borderRadius: "100%",
                        verticalAlign: "unset",
                        opacity: 0,
                        alignSelf: "end"
                    },
                    ref: r,
                    children: (0, h.jsxs)(c.A, {
                        children: [(0, h.jsx)(m.k, {}), e]
                    })
                })
            }))
        },
        32583: (e, t, r) => {
            r.d(t, {
                A: () => h
            });
            var o = r(24726),
                n = r.n(o),
                s = r(12826),
                i = (r(88910), r(40577)),
                a = r(86222),
                l = function(e) {
                    return (0, a.jsx)("svg", { ...e,
                        children: (0, a.jsx)("path", {
                            stroke: "currentColor",
                            strokeLinecap: "round",
                            d: "M3 13L13 3m0 10L3 3"
                        })
                    })
                };
            l.defaultProps = {
                xmlns: "http://www.w3.org/2000/svg",
                width: "16",
                height: "16",
                focusable: "false",
                viewBox: "0 0 16 16"
            };
            const c = s.Ay.button.withConfig({
                    componentId: "sc-1uf0igr-0"
                })(["border:0;background:", ";color:", ";border-radius:", ";display:flex;align-items:center;justify-content:center;width:", ";height:", ";transform-origin:bottom;&:focus,&:active,&:hover{opacity:1;}&[data-garden-focus-visible]{box-shadow:inset ", ";outline:none;}"], (e => e.theme.messenger.colors.proactiveMessageBackgroundColor), (e => e.theme.palette.black), (e => e.theme.messenger.borderRadii.textMessage), (e => e.theme.messenger.iconSizes.xxl), (e => e.theme.messenger.iconSizes.xxl), (e => e.theme.shadows.md(e.theme.messenger.colors.actionBackgroundColor))),
                d = (0, s.Ay)(l).attrs({
                    "aria-hidden": !0
                }).withConfig({
                    componentId: "sc-1uf0igr-1"
                })(["width:", ";height:", ";"], (e => (0, i.D0)(16, e.theme.messenger.baseFontSize)), (e => (0, i.D0)(16, e.theme.messenger.baseFontSize))),
                m = ({
                    onClick: e,
                    ariaLabel: t
                }) => (0, a.jsx)(c, {
                    onClick: e,
                    "aria-label": t,
                    children: (0, a.jsx)(d, {})
                });
            m.propTypes = {
                onClick: n().func,
                ariaLabel: n().string
            };
            const h = (0, s.Ay)(m).withConfig({
                componentId: "sc-1xsbl6q-0"
            })([""])
        },
        39453: (e, t, r) => {
            r.d(t, {
                A: () => s
            });
            var o = r(26436),
                n = r(86222);
            const s = ({
                children: e
            }) => (0, n.jsx)("div", {
                style: {
                    display: "flex",
                    gap: o.x5
                },
                children: e
            })
        },
        44025: (e, t, r) => {
            r.d(t, {
                A: () => u
            });
            var o = r(88910),
                n = r(20912),
                s = r(99028),
                i = r(26436),
                a = r(7087),
                l = r(87944),
                c = r(48167),
                d = r(79733),
                m = r(23112),
                h = r(6917),
                g = r(86222);
            const u = (0, o.forwardRef)((({
                children: e,
                title: t,
                messageFrameWidth: r,
                maxWidth: u,
                messageFrameHeight: p
            }, f) => {
                const b = (0, n.d4)(l._) ? i.xm : i.Ez,
                    y = (0, n.d4)(d.E9),
                    {
                        borderRadius: x
                    } = (0, o.useMemo)((() => ({
                        borderRadius: (0, m.A)(a.xY, b)
                    })), [b]);
                return (0, g.jsx)(s.Ay, {
                    ref: f,
                    title: t,
                    style: {
                        width: r,
                        height: p,
                        maxWidth: u,
                        overflow: "auto",
                        border: 0,
                        backgroundColor: "transparent",
                        boxShadow: a.og,
                        borderRadius: x,
                        display: "inline-block",
                        verticalAlign: "unset",
                        transformOrigin: `bottom ${String(y)}`
                    },
                    children: (0, g.jsxs)(c.A, {
                        children: [(0, g.jsx)(h.k, {}), (0, g.jsx)(h.T, {}), e]
                    })
                })
            }))
        },
        47386: (e, t, r) => {
            r.d(t, {
                A: () => c
            });
            var o = r(88910),
                n = r(20912),
                s = r(7087),
                i = r(18333),
                a = r(84234);
            const l = 1e3 * i.X + 50,
                c = ({
                    isLabelVisible: e,
                    refs: t
                }) => {
                    const r = (0, n.d4)(a.xD),
                        i = (0, o.useRef)(0);
                    (0, o.useLayoutEffect)((() => {
                        i.current = Date.now()
                    }), [r]);
                    const c = (0, o.useCallback)((e => {
                        const {
                            closeFrame: r,
                            messageFrame: o,
                            avatarFrame: n
                        } = t.current;
                        if (!o ? .animate) return;
                        o.style.opacity = "0", o.style.transform = "scale(0)", r && (r.style.opacity = "0"), n && (n.style.opacity = "0");
                        o.animate([{
                            transform: "scale(0)",
                            opacity: 0
                        }, {
                            transform: "scale(1)",
                            opacity: 1
                        }], { ...s.G1,
                            delay: e ? 750 : 0
                        }).onfinish = () => {
                            o && o.contentDocument && (o.contentDocument.body.animate(s.vV, s.G1), t.current.avatarFrame && (t.current.avatarFrame.style.opacity = "1", t.current.avatarFrame.animate(s.vV, s.G1)), t.current.closeFrame && (t.current.closeFrame.style.opacity = "1", t.current.closeFrame.animate(s.vV, s.G1)), o.contentDocument.body.style.opacity = "1")
                        }
                    }), [t]);
                    (0, o.useLayoutEffect)((() => {
                        const {
                            messageFrame: r
                        } = t.current;
                        if (e) {
                            if (e) {
                                const e = Date.now() - i.current < l;
                                c(e)
                            }
                        } else r ? .contentDocument && (r.contentDocument.body.style.opacity = "0")
                    }), [e]);
                    return {
                        onClickAnimate: e => {
                            const {
                                messageFrame: r,
                                avatarFrame: o
                            } = t.current;
                            if (!r ? .animate) return void e();
                            o ? .animate([{
                                opacity: 0
                            }], {
                                delay: 100,
                                fill: "forwards"
                            });
                            r.animate([{
                                transform: "scale(1)"
                            }, {
                                transform: "scale(0.95)",
                                opacity: 1
                            }, {
                                transform: "scale(1)",
                                opacity: 0
                            }], 200).onfinish = e
                        },
                        animateHide: e => {
                            const {
                                closeFrame: r,
                                messageFrame: o,
                                avatarFrame: n
                            } = t.current;
                            if (!o ? .animate) return void e();
                            r ? .animate([{
                                opacity: 0
                            }], 200), n ? .animate([{
                                opacity: 0
                            }], 200);
                            o.animate([{
                                opacity: 0
                            }], 200).onfinish = e
                        }
                    }
                }
        },
        49376: (e, t, r) => {
            r.d(t, {
                Y: () => c
            });
            var o = r(97519),
                n = r(88910),
                s = r(78428);
            const i = {
                ALLOWED_TAGS: ["p", "br", "pre", "span", "strong", "b", "em", "i", "u", "ins", "s", "del", "a", "ol", "ul", "li", "h1", "h2", "h3", "h4", "h5", "h6", "code", "mark", "q", "#text"],
                KEEP_CONTENT: !1,
                ALLOWED_URI_REGEXP: /^(?:(?:https?|mailto|tel):|[^a-z]|[a-z+.-]+(?:[^a-z+.\-:]|$))/i,
                ALLOWED_ATTR: ["target", "href", "style"],
                ALLOWED_STYLES: {
                    "*": {
                        color: [/^#(0x)?[0-9a-f]{3,6}$/i, /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/, ...["black", "silver", "gray", "white", "maroon", "red", "purple", "fuchsia", "green", "lime", "olive", "yellow", "navy", "blue", "teal", "aqua", "aliceblue", "antiquewhite", "aqua", "aquamarine", "azure", "beige", "bisque", "black", "blanchedalmond", "blue", "blueviolet", "brown", "burlywood", "cadetblue", "chartreuse", "chocolate", "coral", "cornflowerblue", "cornsilk", "crimson", "cyan", "darkblue", "darkcyan", "darkgoldenrod", "darkgray", "darkgreen", "darkgrey", "darkkhaki", "darkmagenta", "darkolivegreen", "darkorange", "darkorchid", "darkred", "darksalmon", "darkseagreen", "darkslateblue", "darkslategray", "darkslategrey", "darkturquoise", "darkviolet", "deeppink", "deepskyblue", "dimgray", "dimgrey", "dodgerblue", "firebrick", "floralwhite", "forestgreen", "fuchsia", "gainsboro", "ghostwhite", "gold", "goldenrod", "gray", "green", "greenyellow", "grey", "honeydew", "hotpink", "indianred", "indigo", "ivory", "khaki", "lavender", "lavenderblush", "lawngreen", "lemonchiffon", "lightblue", "lightcoral", "lightcyan", "lightgoldenrodyellow", "lightgray", "lightgreen", "lightgrey", "lightpink", "lightsalmon", "lightseagreen", "lightskyblue", "lightslategray", "lightslategrey", "lightsteelblue", "lightyellow", "lime", "limegreen", "linen", "magenta", "maroon", "mediumaquamarine", "mediumblue", "mediumorchid", "mediumpurple", "mediumseagreen", "mediumslateblue", "mediumspringgreen", "mediumturquoise", "mediumvioletred", "midnightblue", "mintcream", "mistyrose", "moccasin", "navajowhite", "navy", "oldlace", "olive", "olivedrab", "orange", "orangered", "orchid", "palegoldenrod", "palegreen", "paleturquoise", "palevioletred", "papayawhip", "peachpuff", "peru", "pink", "plum", "powderblue", "purple", "rebeccapurple", "red", "rosybrown", "royalblue", "saddlebrown", "salmon", "sandybrown", "seagreen", "seashell", "sienna", "silver", "skyblue", "slateblue", "slategray", "slategrey", "snow", "springgreen", "steelblue", "tan", "teal", "thistle", "tomato", "turquoise", "violet", "wheat", "white", "whitesmoke", "yellow", "yellowgreen"].map((e => new RegExp(`^${e}$`)))]
                    }
                }
            };
            var a = r(76535),
                l = r(86222);
            const c = e => (e => {
                const t = (new DOMParser).parseFromString(e, "text/html"),
                    r = (e, t) => {
                        if (e.nodeType === Node.TEXT_NODE) return (0, a.Sp)(e.textContent || "", t);
                        if (e.nodeType !== Node.ELEMENT_NODE) return null;
                        const o = e,
                            i = o.nodeName.toLowerCase(),
                            c = Array.from(o.childNodes).map(((e, t) => r(e, t))),
                            d = {},
                            m = o.getAttribute("style");
                        switch (m && (d.style = (0, a.It)(m)), i) {
                            case "code":
                                {
                                    const e = o.textContent ? .trim();
                                    if (e) return (0, l.jsx)(a.c3, {
                                        codeContent: e,
                                        index: t,
                                        codeNode: o
                                    }, `code-${t}`);
                                    break
                                }
                            case "a":
                                {
                                    const e = o.getAttribute("href") || "",
                                        r = o.textContent || "",
                                        n = e => {
                                            e.stopPropagation()
                                        };
                                    return (0, l.jsx)(s.A, {
                                        onClick: n,
                                        href: e,
                                        text: r
                                    }, `link-${t}`)
                                }
                            case "br":
                                return (0, l.jsx)("br", {}, `br-${t}`);
                            default:
                                return (0, n.createElement)(i, {
                                    key: `${i}-${t}`,
                                    ...d
                                }, c)
                        }
                    };
                return Array.from(t.body.childNodes).map(((e, t) => r(e, t)))
            })(o.A.sanitize(e, i))
        },
        54899: (e, t, r) => {
            r.d(t, {
                A: () => s
            });
            var o = r(88910),
                n = r(12826);
            const s = () => (0, o.useContext)(n.Dx).messenger.labels
        },
        76535: (e, t, r) => {
            r.d(t, {
                It: () => u,
                Sp: () => g,
                aw: () => m,
                c3: () => h,
                vt: () => d
            });
            var o = r(88910),
                n = r(1637),
                s = r(36913),
                i = r(80869),
                a = r(54899),
                l = r(86222),
                c = function(e) {
                    return (0, l.jsx)("svg", { ...e,
                        children: (0, l.jsx)("path", {
                            fill: "currentColor",
                            d: "M3.5 10a.5.5 0 110 1H1a1 1 0 01-1-1V1a1 1 0 011-1h9a1 1 0 011 1v2.5a.5.5 0 11-1 0V1H1v9h2.5zM6 6v9h9V6H6zm0-1h9a1 1 0 011 1v9a1 1 0 01-1 1H6a1 1 0 01-1-1V6a1 1 0 011-1z"
                        })
                    })
                };
            c.defaultProps = {
                xmlns: "http://www.w3.org/2000/svg",
                width: "16",
                height: "16",
                focusable: "false",
                viewBox: "0 0 16 16"
            };
            const d = ["p", "br", "pre", "span", "strong", "b", "em", "i", "u", "ins", "s", "del", "a", "ol", "ul", "li", "h1", "h2", "h3", "h4", "h5", "h6", "code", "mark", "q", "#text"],
                m = ["target", "href"],
                h = ({
                    codeContent: e,
                    codeNode: t,
                    index: r
                }) => {
                    const d = "string" == typeof e ? e : e ? .toString() || "",
                        m = g(d, r),
                        h = (0, a.A)(),
                        u = h.htmlTextMessage.tooltipCopyCode,
                        p = h.htmlTextMessage.tooltipCodeCopied,
                        [f, b] = (0, o.useState)(u),
                        y = () => {
                            b(p)
                        };
                    return (0, l.jsxs)("pre", {
                        className: "styledPre",
                        children: [(0, l.jsx)(n.CopyToClipboard, {
                            text: t.textContent ? .trim() || "",
                            onCopy: y,
                            children: (0, l.jsx)("span", {
                                children: (0, l.jsx)(i.m, {
                                    content: f,
                                    type: "light",
                                    size: "small",
                                    children: (0, l.jsx)(s.K, {
                                        size: "small",
                                        isPill: !1,
                                        className: "code-block-copy-icon",
                                        onMouseEnter: () => {
                                            b(u)
                                        },
                                        children: (0, l.jsx)(c, {
                                            onClick: y,
                                            "aria-hidden": !0
                                        })
                                    })
                                })
                            })
                        }), (0, l.jsx)("code", {
                            children: m
                        })]
                    })
                },
                g = (e, t) => (0, l.jsx)(o.Fragment, {
                    children: e
                }, `text-${t}`),
                u = e => {
                    const t = {};
                    return e.split(";").forEach((e => {
                        const [r, o] = e.split(":");
                        if (r && o) {
                            const e = r.trim(),
                                n = o.trim();
                            "color" === e && (t[e] = n)
                        }
                    })), t
                }
        },
        78428: (e, t, r) => {
            r.d(t, {
                A: () => l
            });
            var o = r(95698),
                n = r(54899),
                s = r(12826);
            const i = s.Ay.span.withConfig({
                componentId: "sc-qlp6cz-0"
            })(["text-decoration:underline;& > a{color:", ";}:hover{opacity:0.9;}& > a[data-garden-focus-visible]{outline-color:", ";box-shadow:", ";}"], (e => (e => void 0 === e.isPrimaryParticipant ? "inherit !important" : e.isPrimaryParticipant ? `${e.theme.messenger.colors.messageForegroundColor} !important` : `${e.theme.messenger.colors.businessMessageForegroundColor} !important`)(e)), (({
                theme: e
            }) => `${e.messenger.colors.actionBackgroundColor}`), (({
                theme: e
            }) => `0 0 0 3px ${e.messenger.colors.actionBackgroundColor}33`));
            var a = r(86222);
            const l = ({
                text: e,
                href: t,
                isPrimaryParticipant: r,
                onClick: s
            }) => {
                const l = (0, n.A)().ariaLabels.linkExternalAnchor;
                return (0, a.jsx)(i, {
                    isPrimaryParticipant: r,
                    children: (0, a.jsx)(o.M, {
                        onClick: s,
                        isExternal: !0,
                        href: t,
                        externalIconLabel: l,
                        children: e
                    })
                })
            }
        },
        79390: (e, t, r) => {
            r.d(t, {
                A: () => h
            });
            var o = r(88910),
                n = r(20912),
                s = r(26436),
                i = r(7087),
                a = r(79733),
                l = r(6223);
            const c = () => {
                    const {
                        innerWidth: e,
                        innerHeight: t
                    } = l.Jc;
                    return {
                        width: e,
                        height: t
                    }
                },
                d = () => {
                    const [e, t] = (0, o.useState)(c());
                    return (0, o.useEffect)((() => {
                        const e = function(e, t) {
                            let r = 0;
                            return (...o) => {
                                const n = new Date;
                                n.getTime() - r >= t && (e(...o), r = n.getTime())
                            }
                        }((() => {
                            t(c())
                        }), 200);
                        return l.Jc.addEventListener("resize", e), () => l.Jc.removeEventListener("resize", e)
                    }), []), e
                };
            var m = r(82665);
            const h = ({
                refs: e,
                isIconNextToMessage: t
            }) => {
                const [r, l] = (0, o.useState)(0), [c, h] = (0, o.useState)(0), g = (0, m.A)(), {
                    vertical: u,
                    horizontal: p
                } = (0, n.d4)(a.XI), f = u > s.G1, b = d(), y = b.width - (t ? i.yT + s.x5 : 0) - s.pJ - (g.isZoomedIn && f ? s.G1 : p), x = Math.min(i.T7, y), w = b.height - (0, i.Uc)(g.isZoomedIn ? 0 : u) - s.x5 - (e.current ? .closeFrame ? .clientHeight ? s.x5 + e.current ? .closeFrame ? .clientHeight : 0);
                return {
                    maxWidth: x,
                    messageFrameWidth: Math.min(r, y),
                    messageFrameHeight: Math.min(c, w),
                    messageContainerHeight: b.height - (e.current ? .closeFrame ? i.CH + s.x5 : 0) - (0, i.Uc)(g.isZoomedIn ? 0 : u) - s.x5,
                    setFrameDimensions: e => {
                        if (e.current) {
                            const t = e.current.getBoundingClientRect();
                            l(t.width), h(t.height)
                        }
                    }
                }
            }
        },
        82665: (e, t, r) => {
            r.d(t, {
                A: () => n
            });
            var o = r(88910);
            const n = () => {
                const [e, t] = (0, o.useState)(Math.round(100 * window.devicePixelRatio)), r = () => {
                    t(Math.round(100 * window.devicePixelRatio))
                };
                return (0, o.useEffect)((() => (window.addEventListener("resize", r), () => {
                    window.removeEventListener("resize", r)
                })), []), {
                    scale: e >= 400 ? .5 : 1,
                    isZoomedIn: e >= 400
                }
            }
        },
        83268: (e, t, r) => {
            r.d(t, {
                N: () => o
            });
            const o = r(12826).Ay.div.withConfig({
                componentId: "sc-9qme4p-0"
            })(["text-align:center;overflow:auto;max-height:", "px;"], (e => e.maxMessageContainerHeight))
        },
        91857: (e, t, r) => {
            r.d(t, {
                A: () => u
            });
            var o = r(24726),
                n = r.n(o),
                s = r(88910),
                i = r(12826),
                a = r(93452),
                l = r(49376);
            const c = i.Ay.button.withConfig({
                    componentId: "sc-1ee9gtf-0"
                })(["padding:", ";border:0;width:max-content;max-width:", ";overflow-wrap:break-word;word-break:break-word;background:", ";color:", ";border-radius:", ";text-align:initial;&:focus,&:active{outline:0;}&:focus{outline:none;}&[data-garden-focus-visible]{box-shadow:inset ", ";}"], (e => e.isTitleVisible ? `${e.theme.messenger.space.sixteen} ${e.theme.messenger.space.sm} ${e.theme.messenger.space.sm}` : e.theme.messenger.space.sm), (e => "" + ("number" == typeof e.maxWidth ? `${e.maxWidth}px` : "auto")), (e => e.theme.messenger.colors.proactiveMessageBackgroundColor), (e => e.theme.messenger.colors.proactiveMessageForegroundColor), (e => e.theme.messenger.borderRadii.textMessage), (e => e.theme.shadows.md(e.theme.messenger.colors.actionBackgroundColor))),
                d = i.Ay.h1.withConfig({
                    componentId: "sc-1ee9gtf-1"
                })(["margin-bottom:", ";color:", ";font-size:", ";line-height:", ";opacity:0.65;"], (e => e.theme.messenger.space.xs), (e => e.theme.palette.black), (e => e.theme.messenger.fontSizes.sm), (e => e.theme.messenger.lineHeights.sm)),
                m = i.Ay.span.withConfig({
                    componentId: "sc-1ee9gtf-2"
                })(["font-size:", ";line-height:", ";"], (e => e.theme.messenger.fontSizes.md), (e => e.theme.messenger.lineHeights.md));
            var h = r(86222);
            const g = ({
                title: e,
                message: t,
                htmlMessage: r,
                ariaLabel: o,
                maxWidth: n,
                onClick: i,
                onRender: g
            }) => {
                const u = (0, s.useRef)();
                return (0, s.useLayoutEffect)((() => {
                    g ? .(u)
                })), (0, h.jsxs)(c, {
                    maxWidth: n,
                    onClick: i,
                    ref: u,
                    "aria-label": o,
                    isTitleVisible: Boolean(e),
                    children: [e && (0, h.jsx)(d, {
                        children: e
                    }), (0, h.jsx)(m, {
                        children: r ? (0, h.jsx)(a.t, {
                            children: (0, l.Y)(r)
                        }) : t
                    })]
                })
            };
            g.propTypes = {
                title: n().node,
                ariaLabel: n().string,
                message: n().node.isRequired,
                htmlMessage: n().string,
                maxWidth: n().number,
                onClick: n().func.isRequired,
                onRender: n().func
            };
            const u = (0, i.Ay)(g).withConfig({
                componentId: "sc-15hwucc-0"
            })([""])
        },
        93452: (e, t, r) => {
            r.d(t, {
                t: () => i
            });
            var o = r(40577),
                n = r(12826);
            const s = (0, n.AH)(["font-size:", ";line-height:", ";word-break:break-word;"], (({
                    theme: e
                }) => e.messenger.fontSizes.md), (({
                    theme: e
                }) => e.messenger.lineHeights.md)),
                i = n.Ay.div.withConfig({
                    componentId: "sc-h4wtel-0"
                })(["", " outline:none;border-radius:", ";padding:", ";margin:-", ";&:focus,&[data-garden-focus-visible]{outline:3px solid ", ";outline-offset:-6px;}*{", "}strong{font-weight:bold;}em{font-style:italic;}u,ins{text-decoration:underline;}h1{font-size:", ";line-height:", ";}h2{font-size:", ";line-height:", ";}h3{font-size:", ";line-height:", ";}h4{font-size:", ";}h5{font-size:", ";}h1,h2,h3,h4,h5,h6{padding-bottom:", ";}ul{list-style-type:disc;padding-left:", ";}ul:not(:nth-child(2)){margin-top:", ";}ul:not(:last-child){margin-bottom:", ";}ul ul{list-style-type:circle;padding-left:", ";margin:0 !important;}ol{list-style-type:decimal;padding-left:", ";}ol:not(:last-child){margin-bottom:", ";}pre:{margin:0;padding:0;white-space:pre-wrap;}.styledPre{padding:", " ", ";background-color:white;background-color:", ";border:1px solid '#0000001F';white-space:pre;max-width:100%;box-sizing:border-box;display:flex;flex-direction:column;margin:", " 0;& code{font-family:", ";color:", ";opacity:0.65;overflow-x:auto;::-webkit-scrollbar{width:0px;height:", ";}:hover,:active,:focus{::-webkit-scrollbar{width:", ";height:", ";}::-webkit-scrollbar-thumb{background:#d9d9d9;}outline-color:", ";}}& span:first-child{text-align:end;}svg{margin-bottom:", ";}}.code-block-copy-icon{color:", " !important;border-radius:50%;color:", ";&[data-garden-focus-visible]{outline-color:", ";box-shadow:", ";}svg{margin:0;}&:hover{background-color:", ";}&:active{background-color:", ";}}"], s, (({
                    theme: e
                }) => e.messenger.borderRadii.md), (({
                    theme: e
                }) => e.messenger.space.xs), (({
                    theme: e
                }) => e.messenger.space.xs), (({
                    theme: e
                }) => e.messenger.colors.actionBackgroundColor), s, (0, o.D0)(32), (0, o.D0)(33), (0, o.D0)(24), (0, o.D0)(25), (0, o.D0)(20), (0, o.D0)(21), (({
                    theme: e
                }) => e.messenger.fontSizes.lg), (({
                    theme: e
                }) => e.messenger.fontSizes.sixteen), (0, o.D0)(4), (0, o.D0)(14), (({
                    theme: e
                }) => e.messenger.space.xxs), (({
                    theme: e
                }) => e.messenger.space.xxs), (({
                    theme: e
                }) => e.messenger.fontSizes.sm), (({
                    theme: e
                }) => e.messenger.fontSizes.sm), (({
                    theme: e
                }) => e.messenger.space.xxs), (0, o.D0)(8), (0, o.D0)(12), (({
                    theme: e
                }) => e.messenger.colors.cardBackgroundColor), (({
                    theme: e
                }) => e.messenger.space.xxs), (({
                    theme: e
                }) => e.messenger.fontFamilies.mono), (({
                    theme: e
                }) => e.messenger.colors.cardForegroundColor), (0, o.D0)(3), (0, o.D0)(105), (0, o.D0)(3), (({
                    theme: e
                }) => e.messenger.colors.action), (({
                    theme: e
                }) => e.messenger.space.xxs), (({
                    theme: e
                }) => e.messenger.colors.cardForegroundColor), (({
                    theme: e
                }) => e.messenger.colors.cardForegroundColor), (({
                    theme: e
                }) => e.messenger.colors.action), (({
                    theme: e
                }) => `0 0 0 3px ${e.messenger.colors.action}33`), (({
                    theme: e
                }) => (0, o.B3)(e.messenger.colors.cardForegroundColor, .08)), (({
                    theme: e
                }) => (0, o.B3)(e.messenger.colors.cardForegroundColor, .2)))
        },
        99028: (e, t, r) => {
            r.d(t, {
                Ay: () => m
            });
            var o = r(24726),
                n = r.n(o),
                s = r(88910),
                i = r(48559),
                a = r(12826),
                l = r(70513),
                c = r(86222);
            const d = s.forwardRef((({
                children: e,
                rootElement: t,
                title: r,
                hidden: o,
                ...n
            }, d) => {
                const [m, h] = (e => {
                    const t = (0, s.useRef)(null),
                        r = (0, s.useCallback)((r => {
                            t.current = r, e && ("function" == typeof e ? e(t.current) : e.current = t.current)
                        }), [t, e]);
                    return [t, r]
                })(d), g = (0, s.useRef)(t), [u, p] = (0, s.useState)(!1), [f, b] = (0, s.useState)(!1);
                (0, s.useEffect)((() => {
                    const e = () => {
                        p(!0)
                    };
                    if ("complete" === m.current.contentDocument.readyState) return void e();
                    const t = m.current;
                    return t.addEventListener("load", e), () => t.removeEventListener("load", e)
                }), [m]), (0, s.useEffect)((() => {
                    if (!u) return;
                    g.current || (g.current = document.createElement("div"));
                    const e = g.current,
                        t = m.current.contentDocument.body;
                    return t.appendChild(e), b(!0), () => {
                        t.contains(e) && t.removeChild(e)
                    }
                }), [m, t, u]), (0, s.useEffect)((() => {
                    if (!f) return;
                    const e = m.current.contentDocument;
                    let t = e.querySelector("title");
                    t || (t = e.createElement("title")), t.innerHTML = "", t.appendChild(e.createTextNode(r)), e.querySelector("head").appendChild(t)
                }), [r, f, m]);
                const y = {
                    colorScheme: "light",
                    ...n.style
                };
                return u && f && !o || (y.display = "none"), (0, c.jsx)("iframe", {
                    ref: h,
                    title: r,
                    ...n,
                    style: y,
                    children: u && f && (0, c.jsx)(a.ID, {
                        target: m.current.contentDocument.querySelector("head"),
                        children: (0, c.jsx)(l.Ay, {
                            value: {
                                document: m.current.contentDocument,
                                window: m.current.contentWindow
                            },
                            children: !o && i.createPortal(e, g.current)
                        })
                    })
                })
            }));
            d.propTypes = {
                children: n().node,
                rootElement: n().instanceOf(Element),
                title: n().string.isRequired,
                hidden: n().bool,
                style: n().object
            };
            const m = d
        },
        99317: (e, t, r) => {
            r.d(t, {
                A: () => h
            });
            var o = r(20912),
                n = r(70069),
                s = r(26436),
                i = r(82665),
                a = r(7533),
                l = r(55265),
                c = r(7087),
                d = r(79733),
                m = r(86222);
            const h = ({
                children: e,
                ariaLabel: t
            }) => {
                const r = (0, o.d4)(d.E9),
                    h = (0, o.d4)(d.fl),
                    g = (0, o.d4)(l.iG),
                    {
                        vertical: u,
                        horizontal: p
                    } = (0, o.d4)(d.XI),
                    f = u > s.G1,
                    b = a.A.isRTL() ? "rtl" : "ltr",
                    {
                        isZoomedIn: y
                    } = (0, i.A)();
                return (0, m.jsx)("div", {
                    "aria-label": t,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        zIndex: h,
                        bottom: g === n.Fe.none ? u : (0, c.Uc)(Number(u)),
                        position: "fixed",
                        [r]: p,
                        direction: b,
                        alignItems: "end",
                        gap: s.x5,
                        ...y && f && {
                            bottom: (0, c.Uc)(Number(s.G1))
                        }
                    },
                    children: e
                })
            }
        }
    }
]);