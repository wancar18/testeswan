/*! Our embeddable contains third-party, open source software and/or libraries. To view them and their license terms, go to https://developer.zendesk.com/documentation/classic-web-widget-sdks/web-widget/getting-started/legal/ */
(globalThis.webpackChunk_zendesk_web_widget_messenger = globalThis.webpackChunk_zendesk_web_widget_messenger || []).push([
    [4439], {
        1637: (e, t, n) => {
            "use strict";
            var o = n(15262).CopyToClipboard;
            o.CopyToClipboard = o, e.exports = o
        },
        15262: (e, t, n) => {
            "use strict";

            function o(e) {
                return o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, o(e)
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.CopyToClipboard = void 0;
            var r = l(n(88910)),
                a = l(n(54011)),
                i = ["text", "onCopy", "options", "children"];

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function s(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(n), !0).forEach((function(t) {
                        g(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function p(e, t) {
                if (null == e) return {};
                var n, o, r = function(e, t) {
                    if (null == e) return {};
                    var n, o, r = {},
                        a = Object.keys(e);
                    for (o = 0; o < a.length; o++) n = a[o], t.indexOf(n) >= 0 || (r[n] = e[n]);
                    return r
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (o = 0; o < a.length; o++) n = a[o], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n])
                }
                return r
            }

            function u(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var o = t[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, o.key, o)
                }
            }

            function d(e, t) {
                return d = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                }, d(e, t)
            }

            function f(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = h(e);
                    if (t) {
                        var a = h(this).constructor;
                        n = Reflect.construct(r, arguments, a)
                    } else n = r.apply(this, arguments);
                    return function(e, t) {
                        if (t && ("object" === o(t) || "function" == typeof t)) return t;
                        if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                        return m(e)
                    }(this, n)
                }
            }

            function m(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e
            }

            function h(e) {
                return h = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                }, h(e)
            }

            function g(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var y = function(e) {
                ! function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }), Object.defineProperty(e, "prototype", {
                        writable: !1
                    }), t && d(e, t)
                }(s, e);
                var t, n, o, l = f(s);

                function s() {
                    var e;
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, s);
                    for (var t = arguments.length, n = new Array(t), o = 0; o < t; o++) n[o] = arguments[o];
                    return g(m(e = l.call.apply(l, [this].concat(n))), "onClick", (function(t) {
                        var n = e.props,
                            o = n.text,
                            i = n.onCopy,
                            l = n.children,
                            s = n.options,
                            c = r.default.Children.only(l),
                            p = (0, a.default)(o, s);
                        i && i(o, p), c && c.props && "function" == typeof c.props.onClick && c.props.onClick(t)
                    })), e
                }
                return t = s, (n = [{
                    key: "render",
                    value: function() {
                        var e = this.props,
                            t = (e.text, e.onCopy, e.options, e.children),
                            n = p(e, i),
                            o = r.default.Children.only(t);
                        return r.default.cloneElement(o, c(c({}, n), {}, {
                            onClick: this.onClick
                        }))
                    }
                }]) && u(t.prototype, n), o && u(t, o), Object.defineProperty(t, "prototype", {
                    writable: !1
                }), s
            }(r.default.PureComponent);
            t.CopyToClipboard = y, g(y, "defaultProps", {
                onCopy: void 0,
                options: void 0
            })
        },
        18684: e => {
            e.exports = function() {
                var e = document.getSelection();
                if (!e.rangeCount) return function() {};
                for (var t = document.activeElement, n = [], o = 0; o < e.rangeCount; o++) n.push(e.getRangeAt(o));
                switch (t.tagName.toUpperCase()) {
                    case "INPUT":
                    case "TEXTAREA":
                        t.blur();
                        break;
                    default:
                        t = null
                }
                return e.removeAllRanges(),
                    function() {
                        "Caret" === e.type && e.removeAllRanges(), e.rangeCount || n.forEach((function(t) {
                            e.addRange(t)
                        })), t && t.focus()
                    }
            }
        },
        54011: (e, t, n) => {
            "use strict";
            var o = n(18684),
                r = {
                    "text/plain": "Text",
                    "text/html": "Url",
                    default: "Text"
                };
            e.exports = function(e, t) {
                var n, a, i, l, s, c, p = !1;
                t || (t = {}), n = t.debug || !1;
                try {
                    if (i = o(), l = document.createRange(), s = document.getSelection(), (c = document.createElement("span")).textContent = e, c.ariaHidden = "true", c.style.all = "unset", c.style.position = "fixed", c.style.top = 0, c.style.clip = "rect(0, 0, 0, 0)", c.style.whiteSpace = "pre", c.style.webkitUserSelect = "text", c.style.MozUserSelect = "text", c.style.msUserSelect = "text", c.style.userSelect = "text", c.addEventListener("copy", (function(o) {
                            if (o.stopPropagation(), t.format)
                                if (o.preventDefault(), void 0 === o.clipboardData) {
                                    n && console.warn("unable to use e.clipboardData"), n && console.warn("trying IE specific stuff"), window.clipboardData.clearData();
                                    var a = r[t.format] || r.default;
                                    window.clipboardData.setData(a, e)
                                } else o.clipboardData.clearData(), o.clipboardData.setData(t.format, e);
                            t.onCopy && (o.preventDefault(), t.onCopy(o.clipboardData))
                        })), document.body.appendChild(c), l.selectNodeContents(c), s.addRange(l), !document.execCommand("copy")) throw new Error("copy command was unsuccessful");
                    p = !0
                } catch (o) {
                    n && console.error("unable to copy using execCommand: ", o), n && console.warn("trying IE specific stuff");
                    try {
                        window.clipboardData.setData(t.format || "text", e), t.onCopy && t.onCopy(window.clipboardData), p = !0
                    } catch (o) {
                        n && console.error("unable to copy using clipboardData: ", o), n && console.error("falling back to prompt"), a = function(e) {
                            var t = (/mac os x/i.test(navigator.userAgent) ? "⌘" : "Ctrl") + "+C";
                            return e.replace(/#{\s*key\s*}/g, t)
                        }("message" in t ? t.message : "Copy to clipboard: #{key}, Enter"), window.prompt(a, e)
                    }
                } finally {
                    s && ("function" == typeof s.removeRange ? s.removeRange(l) : s.removeAllRanges()), c && document.body.removeChild(c), i()
                }
                return p
            }
        },
        80869: (e, t, n) => {
            "use strict";
            n.d(t, {
                m: () => O
            });
            var o = n(88910),
                r = n(48559),
                a = n(24726),
                i = n.n(a),
                l = n(12826),
                s = n(61995),
                c = n(13961);

            function p() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return function(e) {
                    for (var n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), r = 1; r < n; r++) o[r - 1] = arguments[r];
                    return t.some((t => (t && t(e, ...o), e && e.defaultPrevented)))
                }
            }
            var u = n(65019),
                d = n(68362),
                f = n(85488);

            function m(e) {
                return {
                    auto: "auto",
                    top: "top",
                    "top-start": "top-start",
                    "top-end": "top-end",
                    bottom: "bottom",
                    "bottom-start": "bottom-start",
                    "bottom-end": "bottom-end",
                    end: "right",
                    "end-top": "right-start",
                    "end-bottom": "right-end",
                    start: "left",
                    "start-top": "left-start",
                    "start-bottom": "left-end"
                }[e]
            }
            var h = n(14685),
                g = n(54079),
                y = n(6999),
                b = n(26385),
                T = n(58492);
            const A = "tooltip.paragraph",
                E = l.Ay.p.attrs({
                    "data-garden-id": A,
                    "data-garden-version": "8.76.7"
                }).withConfig({
                    displayName: "StyledParagraph",
                    componentId: "sc-wuqkfc-0"
                })(["margin:0;", ";"], (e => (0, b.A)(A, e)));
            E.defaultProps = {
                theme: T.A
            };
            const w = "tooltip.title",
                v = l.Ay.strong.attrs({
                    "data-garden-id": w,
                    "data-garden-version": "8.76.7"
                }).withConfig({
                    displayName: "StyledTitle",
                    componentId: "sc-vnjcvz-0"
                })(["display:none;margin:0;font-weight:", ";", ";"], (e => e.theme.fontWeights.semibold), (e => (0, b.A)(w, e)));
            v.defaultProps = {
                theme: T.A
            };
            const S = "tooltip.tooltip",
                _ = l.Ay.div.attrs({
                    "data-garden-id": S,
                    "data-garden-version": "8.76.7"
                }).withConfig({
                    displayName: "StyledTooltip",
                    componentId: "sc-gzzjq4-0"
                })(["display:inline-block;box-sizing:border-box;direction:", ";text-align:", ";font-weight:", ";", ";&[aria-hidden='true']{display:none;}", ";", ";"], (e => e.theme.rtl && "rtl"), (e => e.theme.rtl ? "right" : "left"), (e => e.theme.fontWeights.regular), (e => (e => {
                    let t, n, o, r, a, i, s, {
                            theme: c,
                            size: p,
                            type: u,
                            placement: d,
                            hasArrow: f
                        } = e,
                        m = 1.5 * c.space.base + "px",
                        y = c.borderRadii.sm,
                        b = "0 1em",
                        T = "nowrap",
                        A = (0, h.A)(5 * c.space.base, c.fontSizes.sm),
                        w = c.fontSizes.sm;
                    return "small" !== p && (y = c.borderRadii.md, n = "break-word", T = "normal", a = "break-word"), "extra-large" === p ? (b = 10 * c.space.base + "px", t = "460px", A = (0, h.A)(5 * c.space.base, c.fontSizes.md), r = 2.5 * c.space.base + "px") : "large" === p ? (b = 5 * c.space.base + "px", t = "270px", A = (0, h.A)(5 * c.space.base, c.fontSizes.md), r = 2 * c.space.base + "px") : "medium" === p && (b = "1em", t = "140px", A = (0, h.A)(4 * c.space.base, c.fontSizes.sm)), "extra-large" !== p && "large" !== p || (w = c.fontSizes.md, o = "block"), f && ("small" === p || "medium" === p ? (i = m, s = "dark" === u ? "1px" : "0") : (s = "dark" === u ? "2px" : "1px", "large" === p ? (m = 2 * c.space.base + "px", i = m) : "extra-large" === p && (m = 3 * c.space.base + "px", i = 2.5 * c.space.base + "px"))), (0, l.AH)(["margin:", ";border-radius:", ";padding:", ";max-width:", ";line-height:", ";word-wrap:", ";white-space:", ";font-size:", ";overflow-wrap:", ";", ";", "{margin-top:", ";}", "{display:", ";}"], m, y, b, t, A, a, T, w, n, f && (0, g.A)({
                        top: "bottom",
                        "top-start": "bottom-left",
                        "top-end": "bottom-right",
                        right: "left",
                        "right-start": "left-top",
                        "right-end": "left-bottom",
                        bottom: "top",
                        "bottom-start": "top-left",
                        "bottom-end": "top-right",
                        left: "right",
                        "left-start": "right-top",
                        "left-end": "right-bottom"
                    }[d] || "top", {
                        size: i,
                        inset: s
                    }), E, r, v, o)
                })(e)), (e => {
                    let t, n, {
                            theme: o,
                            type: r
                        } = e,
                        a = o.shadows.lg(`${o.space.base}px`, 2 * o.space.base + "px", (0, y.A)("chromeHue", 600, o, .15)),
                        i = (0, y.A)("chromeHue", 700, o),
                        s = (0, y.A)("background", 600, o);
                    return "light" === r && (a = o.shadows.lg(3 * o.space.base + "px", 5 * o.space.base + "px", (0, y.A)("chromeHue", 600, o, .15)), t = `${o.borders.sm} ${(0,y.A)("neutralHue",300,o)}`, i = (0, y.A)("background", 600, o), s = (0, y.A)("neutralHue", 700, o), n = (0, y.A)("foreground", 600, o)), (0, l.AH)(["border:", ";box-shadow:", ";background-color:", ";color:", ";", "{color:", ";}"], t, a, i, s, v, n)
                }), (e => (0, b.A)(S, e)));
            _.defaultProps = {
                theme: T.A
            };
            const x = l.Ay.div.withConfig({
                displayName: "StyledTooltipWrapper",
                componentId: "sc-1b7q9q6-0"
            })(["transition:opacity 10ms;opacity:1;z-index:", ";&[aria-hidden='true']{visibility:hidden;opacity:0;}"], (e => e.zIndex));
            x.defaultProps = {
                theme: T.A
            };
            const N = ["auto", "top", "top-start", "top-end", "bottom", "bottom-start", "bottom-end", "end", "end-top", "end-bottom", "start", "start-top", "start-bottom"],
                O = e => {
                    let {
                        id: t,
                        delayMS: n,
                        isInitialVisible: a,
                        content: i,
                        refKey: h,
                        placement: g,
                        eventsEnabled: y,
                        popperModifiers: b,
                        children: T,
                        hasArrow: A,
                        size: E,
                        type: w,
                        appendToNode: v,
                        zIndex: S,
                        isVisible: N,
                        ...O
                    } = e;
                    const {
                        rtl: C
                    } = (0, o.useContext)(l.Dx), R = (0, o.useRef)(), {
                        isVisible: D,
                        getTooltipProps: k,
                        getTriggerProps: I,
                        openTooltip: L,
                        closeTooltip: M
                    } = (0, c.f)({
                        id: t,
                        delayMilliseconds: n,
                        isVisible: a
                    }), P = function() {
                        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                        for (const e of t)
                            if (void 0 !== e) return e
                    }(N, D);
                    (0, o.useEffect)((() => {
                        P && R.current && R.current()
                    }), [P, i]);
                    const z = C ? function(e) {
                            const t = m(e);
                            return {
                                left: "right",
                                "left-start": "right-start",
                                "left-end": "right-end",
                                "top-start": "top-end",
                                "top-end": "top-start",
                                right: "left",
                                "right-start": "left-start",
                                "right-end": "left-end",
                                "bottom-start": "bottom-end",
                                "bottom-end": "bottom-start"
                            }[t] || t
                        }(g) : m(g),
                        U = o.Children.only(T),
                        H = {
                            preventOverflow: {
                                boundariesElement: "window"
                            },
                            ...b
                        };
                    return o.createElement(u.Ay, null, o.createElement(d.A, null, (e => {
                        let {
                            ref: t
                        } = e;
                        return (0, o.cloneElement)(U, I({ ...U.props,
                            [h]: (0, s.A)([t, U.ref ? U.ref : null])
                        }))
                    })), o.createElement(f.Ay, {
                        placement: z,
                        eventsEnabled: P && y,
                        modifiers: H
                    }, (e => {
                        let {
                            ref: t,
                            style: n,
                            scheduleUpdate: a,
                            placement: l
                        } = e;
                        R.current = a;
                        const {
                            onFocus: s,
                            onBlur: c,
                            ...u
                        } = O;
                        let d = E;
                        void 0 === d && (d = "dark" === w ? "small" : "large");
                        const f = {
                                hasArrow: A,
                                placement: l,
                                size: d,
                                onFocus: p(s, (() => {
                                    L()
                                })),
                                onBlur: p(c, (() => {
                                    M(0)
                                })),
                                "aria-hidden": !P,
                                type: w,
                                ...u
                            },
                            m = o.createElement(x, {
                                ref: P ? t : null,
                                style: n,
                                zIndex: S,
                                "aria-hidden": !P
                            }, o.createElement(_, k(f), i));
                        return v ? (0, r.createPortal)(m, v) : m
                    })))
                };
            O.displayName = "Tooltip", O.propTypes = {
                appendToNode: i().any,
                hasArrow: i().bool,
                delayMS: i().number,
                eventsEnabled: i().bool,
                id: i().string,
                content: i().node.isRequired,
                placement: i().oneOf(N),
                popperModifiers: i().any,
                size: i().oneOf(["small", "medium", "large", "extra-large"]),
                type: i().oneOf(["light", "dark"]),
                zIndex: i().oneOfType([i().number, i().string]),
                isInitialVisible: i().bool,
                refKey: i().string
            }, O.defaultProps = {
                hasArrow: !0,
                eventsEnabled: !0,
                type: "dark",
                placement: "top",
                delayMS: 500,
                refKey: "ref"
            }
        },
        97519: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => le
            });
            const {
                entries: o,
                setPrototypeOf: r,
                isFrozen: a,
                getPrototypeOf: i,
                getOwnPropertyDescriptor: l
            } = Object;
            let {
                freeze: s,
                seal: c,
                create: p
            } = Object, {
                apply: u,
                construct: d
            } = "undefined" != typeof Reflect && Reflect;
            s || (s = function(e) {
                return e
            }), c || (c = function(e) {
                return e
            }), u || (u = function(e, t, n) {
                return e.apply(t, n)
            }), d || (d = function(e, t) {
                return new e(...t)
            });
            const f = O(Array.prototype.forEach),
                m = O(Array.prototype.lastIndexOf),
                h = O(Array.prototype.pop),
                g = O(Array.prototype.push),
                y = O(Array.prototype.splice),
                b = O(String.prototype.toLowerCase),
                T = O(String.prototype.toString),
                A = O(String.prototype.match),
                E = O(String.prototype.replace),
                w = O(String.prototype.indexOf),
                v = O(String.prototype.trim),
                S = O(Object.prototype.hasOwnProperty),
                _ = O(RegExp.prototype.test),
                x = (N = TypeError, function() {
                    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return d(N, t)
                });
            var N;

            function O(e) {
                return function(t) {
                    for (var n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), r = 1; r < n; r++) o[r - 1] = arguments[r];
                    return u(e, t, o)
                }
            }

            function C(e, t) {
                let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : b;
                r && r(e, null);
                let o = t.length;
                for (; o--;) {
                    let r = t[o];
                    if ("string" == typeof r) {
                        const e = n(r);
                        e !== r && (a(t) || (t[o] = e), r = e)
                    }
                    e[r] = !0
                }
                return e
            }

            function R(e) {
                for (let t = 0; t < e.length; t++) {
                    S(e, t) || (e[t] = null)
                }
                return e
            }

            function D(e) {
                const t = p(null);
                for (const [n, r] of o(e)) {
                    S(e, n) && (Array.isArray(r) ? t[n] = R(r) : r && "object" == typeof r && r.constructor === Object ? t[n] = D(r) : t[n] = r)
                }
                return t
            }

            function k(e, t) {
                for (; null !== e;) {
                    const n = l(e, t);
                    if (n) {
                        if (n.get) return O(n.get);
                        if ("function" == typeof n.value) return O(n.value)
                    }
                    e = i(e)
                }
                return function() {
                    return null
                }
            }
            const I = s(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]),
                L = s(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]),
                M = s(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]),
                P = s(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]),
                z = s(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]),
                U = s(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]),
                H = s(["#text"]),
                F = s(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]),
                j = s(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]),
                B = s(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]),
                W = s(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]),
                G = c(/\{\{[\w\W]*|[\w\W]*\}\}/gm),
                Y = c(/<%[\w\W]*|[\w\W]*%>/gm),
                q = c(/\$\{[\w\W]*/gm),
                X = c(/^data-[\-\w.\u00B7-\uFFFF]+$/),
                V = c(/^aria-[\-\w]+$/),
                $ = c(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),
                K = c(/^(?:\w+script|data):/i),
                Z = c(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),
                J = c(/^html$/i),
                Q = c(/^[a-z][.\w]*(-[.\w]+)+$/i);
            var ee = Object.freeze({
                __proto__: null,
                ARIA_ATTR: V,
                ATTR_WHITESPACE: Z,
                CUSTOM_ELEMENT: Q,
                DATA_ATTR: X,
                DOCTYPE_NAME: J,
                ERB_EXPR: Y,
                IS_ALLOWED_URI: $,
                IS_SCRIPT_OR_DATA: K,
                MUSTACHE_EXPR: G,
                TMPLIT_EXPR: q
            });
            const te = 1,
                ne = 3,
                oe = 7,
                re = 8,
                ae = 9,
                ie = function() {
                    return "undefined" == typeof window ? null : window
                };
            var le = function e() {
                let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ie();
                const n = t => e(t);
                if (n.version = "3.2.4", n.removed = [], !t || !t.document || t.document.nodeType !== ae || !t.Element) return n.isSupported = !1, n;
                let {
                    document: r
                } = t;
                const a = r,
                    i = a.currentScript,
                    {
                        DocumentFragment: l,
                        HTMLTemplateElement: c,
                        Node: u,
                        Element: d,
                        NodeFilter: N,
                        NamedNodeMap: O = t.NamedNodeMap || t.MozNamedAttrMap,
                        HTMLFormElement: R,
                        DOMParser: G,
                        trustedTypes: Y
                    } = t,
                    q = d.prototype,
                    X = k(q, "cloneNode"),
                    V = k(q, "remove"),
                    K = k(q, "nextSibling"),
                    Z = k(q, "childNodes"),
                    Q = k(q, "parentNode");
                if ("function" == typeof c) {
                    const e = r.createElement("template");
                    e.content && e.content.ownerDocument && (r = e.content.ownerDocument)
                }
                let le, se = "";
                const {
                    implementation: ce,
                    createNodeIterator: pe,
                    createDocumentFragment: ue,
                    getElementsByTagName: de
                } = r, {
                    importNode: fe
                } = a;
                let me = {
                    afterSanitizeAttributes: [],
                    afterSanitizeElements: [],
                    afterSanitizeShadowDOM: [],
                    beforeSanitizeAttributes: [],
                    beforeSanitizeElements: [],
                    beforeSanitizeShadowDOM: [],
                    uponSanitizeAttribute: [],
                    uponSanitizeElement: [],
                    uponSanitizeShadowNode: []
                };
                n.isSupported = "function" == typeof o && "function" == typeof Q && ce && void 0 !== ce.createHTMLDocument;
                const {
                    MUSTACHE_EXPR: he,
                    ERB_EXPR: ge,
                    TMPLIT_EXPR: ye,
                    DATA_ATTR: be,
                    ARIA_ATTR: Te,
                    IS_SCRIPT_OR_DATA: Ae,
                    ATTR_WHITESPACE: Ee,
                    CUSTOM_ELEMENT: we
                } = ee;
                let {
                    IS_ALLOWED_URI: ve
                } = ee, Se = null;
                const _e = C({}, [...I, ...L, ...M, ...z, ...H]);
                let xe = null;
                const Ne = C({}, [...F, ...j, ...B, ...W]);
                let Oe = Object.seal(p(null, {
                        tagNameCheck: {
                            writable: !0,
                            configurable: !1,
                            enumerable: !0,
                            value: null
                        },
                        attributeNameCheck: {
                            writable: !0,
                            configurable: !1,
                            enumerable: !0,
                            value: null
                        },
                        allowCustomizedBuiltInElements: {
                            writable: !0,
                            configurable: !1,
                            enumerable: !0,
                            value: !1
                        }
                    })),
                    Ce = null,
                    Re = null,
                    De = !0,
                    ke = !0,
                    Ie = !1,
                    Le = !0,
                    Me = !1,
                    Pe = !0,
                    ze = !1,
                    Ue = !1,
                    He = !1,
                    Fe = !1,
                    je = !1,
                    Be = !1,
                    We = !0,
                    Ge = !1,
                    Ye = !0,
                    qe = !1,
                    Xe = {},
                    Ve = null;
                const $e = C({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
                let Ke = null;
                const Ze = C({}, ["audio", "video", "img", "source", "image", "track"]);
                let Je = null;
                const Qe = C({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]),
                    et = "http://www.w3.org/1998/Math/MathML",
                    tt = "http://www.w3.org/2000/svg",
                    nt = "http://www.w3.org/1999/xhtml";
                let ot = nt,
                    rt = !1,
                    at = null;
                const it = C({}, [et, tt, nt], T);
                let lt = C({}, ["mi", "mo", "mn", "ms", "mtext"]),
                    st = C({}, ["annotation-xml"]);
                const ct = C({}, ["title", "style", "font", "a", "script"]);
                let pt = null;
                const ut = ["application/xhtml+xml", "text/html"];
                let dt = null,
                    ft = null;
                const mt = r.createElement("form"),
                    ht = function(e) {
                        return e instanceof RegExp || e instanceof Function
                    },
                    gt = function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        if (!ft || ft !== e) {
                            if (e && "object" == typeof e || (e = {}), e = D(e), pt = -1 === ut.indexOf(e.PARSER_MEDIA_TYPE) ? "text/html" : e.PARSER_MEDIA_TYPE, dt = "application/xhtml+xml" === pt ? T : b, Se = S(e, "ALLOWED_TAGS") ? C({}, e.ALLOWED_TAGS, dt) : _e, xe = S(e, "ALLOWED_ATTR") ? C({}, e.ALLOWED_ATTR, dt) : Ne, at = S(e, "ALLOWED_NAMESPACES") ? C({}, e.ALLOWED_NAMESPACES, T) : it, Je = S(e, "ADD_URI_SAFE_ATTR") ? C(D(Qe), e.ADD_URI_SAFE_ATTR, dt) : Qe, Ke = S(e, "ADD_DATA_URI_TAGS") ? C(D(Ze), e.ADD_DATA_URI_TAGS, dt) : Ze, Ve = S(e, "FORBID_CONTENTS") ? C({}, e.FORBID_CONTENTS, dt) : $e, Ce = S(e, "FORBID_TAGS") ? C({}, e.FORBID_TAGS, dt) : {}, Re = S(e, "FORBID_ATTR") ? C({}, e.FORBID_ATTR, dt) : {}, Xe = !!S(e, "USE_PROFILES") && e.USE_PROFILES, De = !1 !== e.ALLOW_ARIA_ATTR, ke = !1 !== e.ALLOW_DATA_ATTR, Ie = e.ALLOW_UNKNOWN_PROTOCOLS || !1, Le = !1 !== e.ALLOW_SELF_CLOSE_IN_ATTR, Me = e.SAFE_FOR_TEMPLATES || !1, Pe = !1 !== e.SAFE_FOR_XML, ze = e.WHOLE_DOCUMENT || !1, Fe = e.RETURN_DOM || !1, je = e.RETURN_DOM_FRAGMENT || !1, Be = e.RETURN_TRUSTED_TYPE || !1, He = e.FORCE_BODY || !1, We = !1 !== e.SANITIZE_DOM, Ge = e.SANITIZE_NAMED_PROPS || !1, Ye = !1 !== e.KEEP_CONTENT, qe = e.IN_PLACE || !1, ve = e.ALLOWED_URI_REGEXP || $, ot = e.NAMESPACE || nt, lt = e.MATHML_TEXT_INTEGRATION_POINTS || lt, st = e.HTML_INTEGRATION_POINTS || st, Oe = e.CUSTOM_ELEMENT_HANDLING || {}, e.CUSTOM_ELEMENT_HANDLING && ht(e.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (Oe.tagNameCheck = e.CUSTOM_ELEMENT_HANDLING.tagNameCheck), e.CUSTOM_ELEMENT_HANDLING && ht(e.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (Oe.attributeNameCheck = e.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), e.CUSTOM_ELEMENT_HANDLING && "boolean" == typeof e.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (Oe.allowCustomizedBuiltInElements = e.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Me && (ke = !1), je && (Fe = !0), Xe && (Se = C({}, H), xe = [], !0 === Xe.html && (C(Se, I), C(xe, F)), !0 === Xe.svg && (C(Se, L), C(xe, j), C(xe, W)), !0 === Xe.svgFilters && (C(Se, M), C(xe, j), C(xe, W)), !0 === Xe.mathMl && (C(Se, z), C(xe, B), C(xe, W))), e.ADD_TAGS && (Se === _e && (Se = D(Se)), C(Se, e.ADD_TAGS, dt)), e.ADD_ATTR && (xe === Ne && (xe = D(xe)), C(xe, e.ADD_ATTR, dt)), e.ADD_URI_SAFE_ATTR && C(Je, e.ADD_URI_SAFE_ATTR, dt), e.FORBID_CONTENTS && (Ve === $e && (Ve = D(Ve)), C(Ve, e.FORBID_CONTENTS, dt)), Ye && (Se["#text"] = !0), ze && C(Se, ["html", "head", "body"]), Se.table && (C(Se, ["tbody"]), delete Ce.tbody), e.TRUSTED_TYPES_POLICY) {
                                if ("function" != typeof e.TRUSTED_TYPES_POLICY.createHTML) throw x('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
                                if ("function" != typeof e.TRUSTED_TYPES_POLICY.createScriptURL) throw x('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
                                le = e.TRUSTED_TYPES_POLICY, se = le.createHTML("")
                            } else void 0 === le && (le = function(e, t) {
                                if ("object" != typeof e || "function" != typeof e.createPolicy) return null;
                                let n = null;
                                const o = "data-tt-policy-suffix";
                                t && t.hasAttribute(o) && (n = t.getAttribute(o));
                                const r = "dompurify" + (n ? "#" + n : "");
                                try {
                                    return e.createPolicy(r, {
                                        createHTML: e => e,
                                        createScriptURL: e => e
                                    })
                                } catch (e) {
                                    return console.warn("TrustedTypes policy " + r + " could not be created."), null
                                }
                            }(Y, i)), null !== le && "string" == typeof se && (se = le.createHTML(""));
                            s && s(e), ft = e
                        }
                    },
                    yt = C({}, [...L, ...M, ...P]),
                    bt = C({}, [...z, ...U]),
                    Tt = function(e) {
                        g(n.removed, {
                            element: e
                        });
                        try {
                            Q(e).removeChild(e)
                        } catch (t) {
                            V(e)
                        }
                    },
                    At = function(e, t) {
                        try {
                            g(n.removed, {
                                attribute: t.getAttributeNode(e),
                                from: t
                            })
                        } catch (e) {
                            g(n.removed, {
                                attribute: null,
                                from: t
                            })
                        }
                        if (t.removeAttribute(e), "is" === e)
                            if (Fe || je) try {
                                Tt(t)
                            } catch (e) {} else try {
                                t.setAttribute(e, "")
                            } catch (e) {}
                    },
                    Et = function(e) {
                        let t = null,
                            n = null;
                        if (He) e = "<remove></remove>" + e;
                        else {
                            const t = A(e, /^[\r\n\t ]+/);
                            n = t && t[0]
                        }
                        "application/xhtml+xml" === pt && ot === nt && (e = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + e + "</body></html>");
                        const o = le ? le.createHTML(e) : e;
                        if (ot === nt) try {
                            t = (new G).parseFromString(o, pt)
                        } catch (e) {}
                        if (!t || !t.documentElement) {
                            t = ce.createDocument(ot, "template", null);
                            try {
                                t.documentElement.innerHTML = rt ? se : o
                            } catch (e) {}
                        }
                        const a = t.body || t.documentElement;
                        return e && n && a.insertBefore(r.createTextNode(n), a.childNodes[0] || null), ot === nt ? de.call(t, ze ? "html" : "body")[0] : ze ? t.documentElement : a
                    },
                    wt = function(e) {
                        return pe.call(e.ownerDocument || e, e, N.SHOW_ELEMENT | N.SHOW_COMMENT | N.SHOW_TEXT | N.SHOW_PROCESSING_INSTRUCTION | N.SHOW_CDATA_SECTION, null)
                    },
                    vt = function(e) {
                        return e instanceof R && ("string" != typeof e.nodeName || "string" != typeof e.textContent || "function" != typeof e.removeChild || !(e.attributes instanceof O) || "function" != typeof e.removeAttribute || "function" != typeof e.setAttribute || "string" != typeof e.namespaceURI || "function" != typeof e.insertBefore || "function" != typeof e.hasChildNodes)
                    },
                    St = function(e) {
                        return "function" == typeof u && e instanceof u
                    };

                function _t(e, t, o) {
                    f(e, (e => {
                        e.call(n, t, o, ft)
                    }))
                }
                const xt = function(e) {
                        let t = null;
                        if (_t(me.beforeSanitizeElements, e, null), vt(e)) return Tt(e), !0;
                        const o = dt(e.nodeName);
                        if (_t(me.uponSanitizeElement, e, {
                                tagName: o,
                                allowedTags: Se
                            }), e.hasChildNodes() && !St(e.firstElementChild) && _(/<[/\w]/g, e.innerHTML) && _(/<[/\w]/g, e.textContent)) return Tt(e), !0;
                        if (e.nodeType === oe) return Tt(e), !0;
                        if (Pe && e.nodeType === re && _(/<[/\w]/g, e.data)) return Tt(e), !0;
                        if (!Se[o] || Ce[o]) {
                            if (!Ce[o] && Ot(o)) {
                                if (Oe.tagNameCheck instanceof RegExp && _(Oe.tagNameCheck, o)) return !1;
                                if (Oe.tagNameCheck instanceof Function && Oe.tagNameCheck(o)) return !1
                            }
                            if (Ye && !Ve[o]) {
                                const t = Q(e) || e.parentNode,
                                    n = Z(e) || e.childNodes;
                                if (n && t) {
                                    for (let o = n.length - 1; o >= 0; --o) {
                                        const r = X(n[o], !0);
                                        r.__removalCount = (e.__removalCount || 0) + 1, t.insertBefore(r, K(e))
                                    }
                                }
                            }
                            return Tt(e), !0
                        }
                        return e instanceof d && ! function(e) {
                            let t = Q(e);
                            t && t.tagName || (t = {
                                namespaceURI: ot,
                                tagName: "template"
                            });
                            const n = b(e.tagName),
                                o = b(t.tagName);
                            return !!at[e.namespaceURI] && (e.namespaceURI === tt ? t.namespaceURI === nt ? "svg" === n : t.namespaceURI === et ? "svg" === n && ("annotation-xml" === o || lt[o]) : Boolean(yt[n]) : e.namespaceURI === et ? t.namespaceURI === nt ? "math" === n : t.namespaceURI === tt ? "math" === n && st[o] : Boolean(bt[n]) : e.namespaceURI === nt ? !(t.namespaceURI === tt && !st[o]) && !(t.namespaceURI === et && !lt[o]) && !bt[n] && (ct[n] || !yt[n]) : !("application/xhtml+xml" !== pt || !at[e.namespaceURI]))
                        }(e) ? (Tt(e), !0) : "noscript" !== o && "noembed" !== o && "noframes" !== o || !_(/<\/no(script|embed|frames)/i, e.innerHTML) ? (Me && e.nodeType === ne && (t = e.textContent, f([he, ge, ye], (e => {
                            t = E(t, e, " ")
                        })), e.textContent !== t && (g(n.removed, {
                            element: e.cloneNode()
                        }), e.textContent = t)), _t(me.afterSanitizeElements, e, null), !1) : (Tt(e), !0)
                    },
                    Nt = function(e, t, n) {
                        if (We && ("id" === t || "name" === t) && (n in r || n in mt)) return !1;
                        if (ke && !Re[t] && _(be, t));
                        else if (De && _(Te, t));
                        else if (!xe[t] || Re[t]) {
                            if (!(Ot(e) && (Oe.tagNameCheck instanceof RegExp && _(Oe.tagNameCheck, e) || Oe.tagNameCheck instanceof Function && Oe.tagNameCheck(e)) && (Oe.attributeNameCheck instanceof RegExp && _(Oe.attributeNameCheck, t) || Oe.attributeNameCheck instanceof Function && Oe.attributeNameCheck(t)) || "is" === t && Oe.allowCustomizedBuiltInElements && (Oe.tagNameCheck instanceof RegExp && _(Oe.tagNameCheck, n) || Oe.tagNameCheck instanceof Function && Oe.tagNameCheck(n)))) return !1
                        } else if (Je[t]);
                        else if (_(ve, E(n, Ee, "")));
                        else if ("src" !== t && "xlink:href" !== t && "href" !== t || "script" === e || 0 !== w(n, "data:") || !Ke[e]) {
                            if (Ie && !_(Ae, E(n, Ee, "")));
                            else if (n) return !1
                        } else;
                        return !0
                    },
                    Ot = function(e) {
                        return "annotation-xml" !== e && A(e, we)
                    },
                    Ct = function(e) {
                        _t(me.beforeSanitizeAttributes, e, null);
                        const {
                            attributes: t
                        } = e;
                        if (!t || vt(e)) return;
                        const o = {
                            attrName: "",
                            attrValue: "",
                            keepAttr: !0,
                            allowedAttributes: xe,
                            forceKeepAttr: void 0
                        };
                        let r = t.length;
                        for (; r--;) {
                            const a = t[r],
                                {
                                    name: i,
                                    namespaceURI: l,
                                    value: s
                                } = a,
                                c = dt(i);
                            let p = "value" === i ? s : v(s);
                            if (o.attrName = c, o.attrValue = p, o.keepAttr = !0, o.forceKeepAttr = void 0, _t(me.uponSanitizeAttribute, e, o), p = o.attrValue, !Ge || "id" !== c && "name" !== c || (At(i, e), p = "user-content-" + p), Pe && _(/((--!?|])>)|<\/(style|title)/i, p)) {
                                At(i, e);
                                continue
                            }
                            if (o.forceKeepAttr) continue;
                            if (At(i, e), !o.keepAttr) continue;
                            if (!Le && _(/\/>/i, p)) {
                                At(i, e);
                                continue
                            }
                            Me && f([he, ge, ye], (e => {
                                p = E(p, e, " ")
                            }));
                            const u = dt(e.nodeName);
                            if (Nt(u, c, p)) {
                                if (le && "object" == typeof Y && "function" == typeof Y.getAttributeType)
                                    if (l);
                                    else switch (Y.getAttributeType(u, c)) {
                                        case "TrustedHTML":
                                            p = le.createHTML(p);
                                            break;
                                        case "TrustedScriptURL":
                                            p = le.createScriptURL(p)
                                    }
                                try {
                                    l ? e.setAttributeNS(l, i, p) : e.setAttribute(i, p), vt(e) ? Tt(e) : h(n.removed)
                                } catch (e) {}
                            }
                        }
                        _t(me.afterSanitizeAttributes, e, null)
                    },
                    Rt = function e(t) {
                        let n = null;
                        const o = wt(t);
                        for (_t(me.beforeSanitizeShadowDOM, t, null); n = o.nextNode();) _t(me.uponSanitizeShadowNode, n, null), xt(n), Ct(n), n.content instanceof l && e(n.content);
                        _t(me.afterSanitizeShadowDOM, t, null)
                    };
                return n.sanitize = function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        o = null,
                        r = null,
                        i = null,
                        s = null;
                    if (rt = !e, rt && (e = "\x3c!--\x3e"), "string" != typeof e && !St(e)) {
                        if ("function" != typeof e.toString) throw x("toString is not a function");
                        if ("string" != typeof(e = e.toString())) throw x("dirty is not a string, aborting")
                    }
                    if (!n.isSupported) return e;
                    if (Ue || gt(t), n.removed = [], "string" == typeof e && (qe = !1), qe) {
                        if (e.nodeName) {
                            const t = dt(e.nodeName);
                            if (!Se[t] || Ce[t]) throw x("root node is forbidden and cannot be sanitized in-place")
                        }
                    } else if (e instanceof u) o = Et("\x3c!----\x3e"), r = o.ownerDocument.importNode(e, !0), r.nodeType === te && "BODY" === r.nodeName || "HTML" === r.nodeName ? o = r : o.appendChild(r);
                    else {
                        if (!Fe && !Me && !ze && -1 === e.indexOf("<")) return le && Be ? le.createHTML(e) : e;
                        if (o = Et(e), !o) return Fe ? null : Be ? se : ""
                    }
                    o && He && Tt(o.firstChild);
                    const c = wt(qe ? e : o);
                    for (; i = c.nextNode();) xt(i), Ct(i), i.content instanceof l && Rt(i.content);
                    if (qe) return e;
                    if (Fe) {
                        if (je)
                            for (s = ue.call(o.ownerDocument); o.firstChild;) s.appendChild(o.firstChild);
                        else s = o;
                        return (xe.shadowroot || xe.shadowrootmode) && (s = fe.call(a, s, !0)), s
                    }
                    let p = ze ? o.outerHTML : o.innerHTML;
                    return ze && Se["!doctype"] && o.ownerDocument && o.ownerDocument.doctype && o.ownerDocument.doctype.name && _(J, o.ownerDocument.doctype.name) && (p = "<!DOCTYPE " + o.ownerDocument.doctype.name + ">\n" + p), Me && f([he, ge, ye], (e => {
                        p = E(p, e, " ")
                    })), le && Be ? le.createHTML(p) : p
                }, n.setConfig = function() {
                    gt(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}), Ue = !0
                }, n.clearConfig = function() {
                    ft = null, Ue = !1
                }, n.isValidAttribute = function(e, t, n) {
                    ft || gt({});
                    const o = dt(e),
                        r = dt(t);
                    return Nt(o, r, n)
                }, n.addHook = function(e, t) {
                    "function" == typeof t && g(me[e], t)
                }, n.removeHook = function(e, t) {
                    if (void 0 !== t) {
                        const n = m(me[e], t);
                        return -1 === n ? void 0 : y(me[e], n, 1)[0]
                    }
                    return h(me[e])
                }, n.removeHooks = function(e) {
                    me[e] = []
                }, n.removeAllHooks = function() {
                    me = {
                        afterSanitizeAttributes: [],
                        afterSanitizeElements: [],
                        afterSanitizeShadowDOM: [],
                        beforeSanitizeAttributes: [],
                        beforeSanitizeElements: [],
                        beforeSanitizeShadowDOM: [],
                        uponSanitizeAttribute: [],
                        uponSanitizeElement: [],
                        uponSanitizeShadowNode: []
                    }
                }, n
            }()
        }
    }
]);