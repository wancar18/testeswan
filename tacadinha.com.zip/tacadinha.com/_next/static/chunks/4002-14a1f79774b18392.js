"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4002], {
        56022: function(e, t, a) {
            a.d(t, {
                Z: function() {
                    return s
                }
            });
            var n = a(3827),
                r = a(64090);
            let o = {
                    xs: "w-6 h-6",
                    sm: "w-8 h-8",
                    md: "w-10 h-10",
                    lg: "w-12 h-12",
                    xl: "w-16 h-16"
                },
                i = {
                    xs: 24,
                    sm: 32,
                    md: 40,
                    lg: 48,
                    xl: 64
                };

            function l(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 64;
                return "https://api.dicebear.com/7.x/thumbs/svg?seed=".concat(encodeURIComponent(e), "&size=").concat(t)
            }

            function s(e) {
                let {
                    username: t,
                    name: a,
                    email: s,
                    size: d = "md",
                    src: c,
                    className: h = ""
                } = e, [u, m] = (0, r.useState)(!1), x = i[d], f = l(t || a || s || "default", x), g = l("default", x);
                return (0, n.jsx)("img", {
                    src: u ? g : c || f,
                    alt: t || a || s || "Avatar",
                    className: "".concat(o[d], " rounded-full object-cover border border-white/20 bg-pool-dark/50 ").concat(h),
                    onError: () => m(!0)
                })
            }
        },
        4002: function(e, t, a) {
            a.d(t, {
                Z: function() {
                    return y
                }
            });
            var n = a(3827),
                r = a(6739),
                o = a(47907),
                i = a(8792),
                l = a(20703),
                s = a(35005),
                d = a(66260),
                c = a(64178),
                h = a(32805),
                u = a(17252),
                m = a(23441),
                x = a(11213),
                f = a(10933),
                g = a(77326),
                p = a(81049),
                b = a(52235),
                w = a(79744),
                j = a(64090),
                v = a(56022),
                N = a(10826);

            function y() {
                let {
                    user: e,
                    logout: t,
                    isAdmin: a,
                    isAffiliateManager: y
                } = (0, r.tN)(), k = (0, o.useRouter)(), I = (0, o.usePathname)(), [C, _] = (0, j.useState)(!1), [z, L] = (0, j.useState)(!1), [A, Z] = (0, j.useState)(!0), R = (0, j.useRef)(null), B = () => {
                    t(), L(!1), k.push("/")
                };
                return (0, j.useEffect)(() => {
                    let e = async () => {
                        try {
                            let e = await N.h.getPlatformStatus();
                            e.data && Z(e.data.rankingEnabled)
                        } catch (e) {
                            console.error("Error loading platform status:", e)
                        }
                    };
                    e();
                    let t = setInterval(e, 3e4);
                    return () => clearInterval(t)
                }, []), (0, j.useEffect)(() => {
                    function e(e) {
                        R.current && !R.current.contains(e.target) && L(!1)
                    }
                    return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e)
                }, []), (0, n.jsx)("nav", {
                    className: "bg-pool-dark/80 backdrop-blur-md border-b border-white/10 sticky top-0 z-40",
                    children: (0, n.jsxs)("div", {
                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                        children: [(0, n.jsxs)("div", {
                            className: "flex items-center h-20 sm:h-24",
                            children: [(0, n.jsx)(i.default, {
                                href: "/lobby",
                                className: "flex-shrink-0",
                                children: (0, n.jsx)("div", {
                                    className: "relative w-24 h-24 sm:w-32 sm:h-32",
                                    children: (0, n.jsx)(l.default, {
                                        src: "/logos/logo-white-red.png",
                                        alt: "Tacadinha Logo",
                                        fill: !0,
                                        className: "object-contain",
                                        priority: !0
                                    })
                                })
                            }), (0, n.jsxs)("div", {
                                className: "hidden md:flex items-center gap-1 lg:gap-2 flex-1 justify-center",
                                children: [(0, n.jsxs)(i.default, {
                                    href: "/lobby",
                                    className: "transition-colors flex items-center gap-1.5 px-2.5 lg:px-3 py-2 rounded-lg ".concat("/lobby" === I ? "text-white bg-white/10" : "text-white/60 hover:text-white hover:bg-white/5"),
                                    title: "Lobby",
                                    children: [(0, n.jsx)(s.Z, {
                                        size: 18
                                    }), (0, n.jsx)("span", {
                                        className: "hidden lg:inline font-medium",
                                        children: "Lobby"
                                    })]
                                }), A && (0, n.jsxs)(i.default, {
                                    href: "/ranking",
                                    className: "transition-colors flex items-center gap-1.5 px-2.5 lg:px-3 py-2 rounded-lg ".concat("/ranking" === I ? "text-white bg-white/10" : "text-white/60 hover:text-white hover:bg-white/5"),
                                    title: "Ranking",
                                    children: [(0, n.jsxs)("span", {
                                        className: "relative",
                                        children: [(0, n.jsx)(d.Z, {
                                            size: 18
                                        }), (0, n.jsx)("span", {
                                            className: "lg:hidden absolute -top-1 -right-1.5 w-2 h-2 bg-sky-600 rounded-full"
                                        })]
                                    }), (0, n.jsx)("span", {
                                        className: "hidden lg:inline font-medium",
                                        children: "Ranking"
                                    }), (0, n.jsx)("span", {
                                        className: "hidden lg:inline text-[9px] font-bold bg-sky-600 text-white px-1.5 py-0.5 rounded-full leading-none",
                                        children: "Novo"
                                    })]
                                }), (0, n.jsxs)(i.default, {
                                    href: "/match-history",
                                    className: "transition-colors flex items-center gap-1.5 px-2.5 lg:px-3 py-2 rounded-lg ".concat("/match-history" === I ? "text-white bg-white/10" : "text-white/60 hover:text-white hover:bg-white/5"),
                                    title: "Partidas",
                                    children: [(0, n.jsxs)("span", {
                                        className: "relative",
                                        children: [(0, n.jsx)(c.Z, {
                                            size: 18
                                        }), (0, n.jsx)("span", {
                                            className: "lg:hidden absolute -top-1 -right-1.5 w-2 h-2 bg-sky-600 rounded-full"
                                        })]
                                    }), (0, n.jsx)("span", {
                                        className: "hidden lg:inline font-medium",
                                        children: "Partidas"
                                    }), (0, n.jsx)("span", {
                                        className: "hidden lg:inline text-[9px] font-bold bg-sky-600 text-white px-1.5 py-0.5 rounded-full leading-none",
                                        children: "Novo"
                                    })]
                                }), (0, n.jsxs)(i.default, {
                                    href: "/affiliate",
                                    className: "transition-colors flex items-center gap-1.5 px-2.5 lg:px-3 py-2 rounded-lg ".concat("/affiliate" === I ? "text-white bg-white/10" : "text-white/60 hover:text-white hover:bg-white/5"),
                                    title: "Indica\xe7\xe3o",
                                    children: [(0, n.jsx)(h.Z, {
                                        size: 18
                                    }), (0, n.jsx)("span", {
                                        className: "hidden lg:inline font-medium",
                                        children: "Indique e Ganhe"
                                    })]
                                })]
                            }), (0, n.jsxs)("div", {
                                className: "hidden md:flex items-center gap-3",
                                children: [(0, n.jsx)(i.default, {
                                    href: "/wallet",
                                    className: "bg-gradient-to-r from-pool-gold/20 to-pool-gold/10 border border-pool-gold/40 rounded-lg px-4 py-2 shadow-lg hover:from-pool-gold/30 hover:to-pool-gold/20 transition-all",
                                    children: (0, n.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [(0, n.jsx)("div", {
                                            className: "bg-pool-gold/20 p-1.5 rounded-lg",
                                            children: (0, n.jsx)(u.Z, {
                                                size: 18,
                                                className: "text-pool-gold"
                                            })
                                        }), (0, n.jsxs)("div", {
                                            className: "flex flex-col",
                                            children: [(0, n.jsx)("span", {
                                                className: "text-xs text-white/60 font-medium",
                                                children: "Saldo"
                                            }), (0, n.jsxs)("span", {
                                                className: "text-base font-bold text-pool-gold",
                                                children: ["R$ ", Number((null == e ? void 0 : e.balance) || 0).toFixed(2)]
                                            })]
                                        })]
                                    })
                                }), (0, n.jsxs)("div", {
                                    className: "relative",
                                    ref: R,
                                    children: [(0, n.jsxs)("button", {
                                        onClick: () => L(!z),
                                        className: "flex items-center gap-2 p-2 rounded-lg hover:bg-white/5 transition-colors",
                                        children: [(0, n.jsx)(v.Z, {
                                            username: null == e ? void 0 : e.username,
                                            name: null == e ? void 0 : e.name,
                                            size: "md",
                                            className: "border border-pool-gold/40"
                                        }), (0, n.jsx)(m.Z, {
                                            size: 16,
                                            className: "text-white/60 transition-transform duration-200 ".concat(z ? "rotate-180" : "")
                                        })]
                                    }), z && (0, n.jsxs)("div", {
                                        className: "absolute right-0 mt-2 w-48 bg-pool-dark border border-white/10 rounded-lg shadow-xl overflow-hidden z-50",
                                        children: [(0, n.jsxs)("div", {
                                            className: "px-4 py-3 border-b border-white/10",
                                            children: [(0, n.jsxs)("p", {
                                                className: "text-sm font-medium text-white truncate",
                                                children: ["@", null == e ? void 0 : e.username]
                                            }), (0, n.jsx)("p", {
                                                className: "text-xs text-white/60 truncate",
                                                children: null == e ? void 0 : e.email
                                            })]
                                        }), (0, n.jsxs)("div", {
                                            className: "py-1",
                                            children: [(0, n.jsxs)(i.default, {
                                                href: "/profile",
                                                onClick: () => L(!1),
                                                className: "flex items-center gap-3 px-4 py-2.5 text-white/80 hover:text-white hover:bg-white/5 transition-colors",
                                                children: [(0, n.jsx)(x.Z, {
                                                    size: 18
                                                }), (0, n.jsx)("span", {
                                                    children: "Perfil"
                                                })]
                                            }), y() && (0, n.jsxs)(i.default, {
                                                href: "/affiliate-manager",
                                                onClick: () => L(!1),
                                                className: "flex items-center gap-3 px-4 py-2.5 text-pool-gold/80 hover:text-pool-gold hover:bg-pool-gold/10 transition-colors",
                                                children: [(0, n.jsx)(f.Z, {
                                                    size: 18
                                                }), (0, n.jsx)("span", {
                                                    children: "Rede de Afiliados"
                                                })]
                                            }), a() && (0, n.jsxs)(i.default, {
                                                href: "/admin",
                                                onClick: () => L(!1),
                                                className: "flex items-center gap-3 px-4 py-2.5 text-pool-gold/80 hover:text-pool-gold hover:bg-pool-gold/10 transition-colors",
                                                children: [(0, n.jsx)(g.Z, {
                                                    size: 18
                                                }), (0, n.jsx)("span", {
                                                    children: "Admin"
                                                })]
                                            })]
                                        }), (0, n.jsx)("div", {
                                            className: "border-t border-white/10 py-1",
                                            children: (0, n.jsxs)("button", {
                                                onClick: B,
                                                className: "w-full flex items-center gap-3 px-4 py-2.5 text-red-400 hover:text-red-300 hover:bg-white/5 transition-colors",
                                                children: [(0, n.jsx)(p.Z, {
                                                    size: 18
                                                }), (0, n.jsx)("span", {
                                                    children: "Desconectar"
                                                })]
                                            })
                                        })]
                                    })]
                                })]
                            }), (0, n.jsxs)("div", {
                                className: "md:hidden flex items-center gap-2 ml-auto",
                                children: [(0, n.jsx)(i.default, {
                                    href: "/wallet",
                                    className: "bg-gradient-to-r from-pool-gold/20 to-pool-gold/10 border border-pool-gold/40 rounded-lg px-3 py-1.5 transition-all duration-200 hover:from-pool-gold/30 hover:to-pool-gold/20",
                                    children: (0, n.jsxs)("div", {
                                        className: "flex items-center gap-2",
                                        children: [(0, n.jsx)(u.Z, {
                                            size: 14,
                                            className: "text-pool-gold flex-shrink-0"
                                        }), (0, n.jsxs)("div", {
                                            className: "flex flex-col",
                                            children: [(0, n.jsx)("span", {
                                                className: "text-[10px] text-white/60 font-medium leading-tight",
                                                children: "Saldo"
                                            }), (0, n.jsxs)("span", {
                                                className: "text-sm font-bold text-pool-gold leading-tight",
                                                children: ["R$ ", Number((null == e ? void 0 : e.balance) || 0).toFixed(2)]
                                            })]
                                        })]
                                    })
                                }), (0, n.jsx)("button", {
                                    onClick: () => _(!C),
                                    className: "p-2 text-white/80 hover:text-white transition-colors",
                                    children: C ? (0, n.jsx)(b.Z, {
                                        size: 24
                                    }) : (0, n.jsx)(w.Z, {
                                        size: 24
                                    })
                                })]
                            })]
                        }), C && (0, n.jsxs)("div", {
                            className: "md:hidden py-4 space-y-2 border-t border-white/10",
                            children: [(0, n.jsxs)(i.default, {
                                href: "/lobby",
                                className: "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ".concat("/lobby" === I ? "text-white bg-white/10" : "text-white/80 hover:text-white hover:bg-white/5"),
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(s.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Lobby"
                                })]
                            }), A && (0, n.jsxs)(i.default, {
                                href: "/ranking",
                                className: "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ".concat("/ranking" === I ? "text-white bg-white/10" : "text-white/80 hover:text-white hover:bg-white/5"),
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(d.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Ranking"
                                }), (0, n.jsx)("span", {
                                    className: "text-[9px] font-bold bg-sky-600 text-white px-1.5 py-0.5 rounded-full leading-none",
                                    children: "Novo"
                                })]
                            }), (0, n.jsxs)(i.default, {
                                href: "/match-history",
                                className: "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ".concat("/match-history" === I ? "text-white bg-white/10" : "text-white/80 hover:text-white hover:bg-white/5"),
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(c.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Partidas"
                                }), (0, n.jsx)("span", {
                                    className: "text-[9px] font-bold bg-sky-600 text-white px-1.5 py-0.5 rounded-full leading-none",
                                    children: "Novo"
                                })]
                            }), (0, n.jsxs)(i.default, {
                                href: "/wallet",
                                className: "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ".concat("/wallet" === I ? "text-white bg-white/10" : "text-white/80 hover:text-white hover:bg-white/5"),
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(u.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Carteira"
                                })]
                            }), (0, n.jsxs)(i.default, {
                                href: "/affiliate",
                                className: "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ".concat("/affiliate" === I ? "text-white bg-white/10" : "text-white/80 hover:text-white hover:bg-white/5"),
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(h.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Indique e Ganhe"
                                })]
                            }), (0, n.jsx)("div", {
                                className: "border-t border-white/10 my-2"
                            }), (0, n.jsxs)(i.default, {
                                href: "/profile",
                                className: "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ".concat("/profile" === I ? "text-white bg-white/10" : "text-white/80 hover:text-white hover:bg-white/5"),
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(x.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Perfil"
                                })]
                            }), y() && (0, n.jsxs)(i.default, {
                                href: "/affiliate-manager",
                                className: "flex items-center gap-3 px-4 py-3 text-pool-gold/80 hover:text-pool-gold hover:bg-pool-gold/10 rounded-lg transition-colors",
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(f.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Rede de Afiliados"
                                })]
                            }), a() && (0, n.jsxs)(i.default, {
                                href: "/admin",
                                className: "flex items-center gap-3 px-4 py-3 text-pool-gold/80 hover:text-pool-gold hover:bg-pool-gold/10 rounded-lg transition-colors",
                                onClick: () => _(!1),
                                children: [(0, n.jsx)(g.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Admin"
                                })]
                            }), (0, n.jsxs)("button", {
                                onClick: () => {
                                    _(!1), B()
                                },
                                className: "w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:text-red-300 hover:bg-white/5 rounded-lg transition-colors",
                                children: [(0, n.jsx)(p.Z, {
                                    size: 20
                                }), (0, n.jsx)("span", {
                                    className: "font-medium",
                                    children: "Sair"
                                })]
                            })]
                        })]
                    })
                })
            }
        },
        54012: function(e, t, a) {
            function n(e, t) {
                window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                    event: e,
                    ...t
                }), console.log("[GTM] Event pushed: ".concat(e), t)
            }

            function r(e) {
                n("deposit_initiated", {
                    transaction_id: e.transactionId,
                    value: e.amount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function o(e) {
                n("deposit_completed", {
                    transaction_id: e.transactionId,
                    value: e.amount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function i(e) {
                n("withdrawal_requested", {
                    transaction_id: e.transactionId,
                    value: e.amount,
                    net_value: e.netAmount,
                    fee: e.fee,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function l(e) {
                n("match_created", {
                    room_id: e.roomId,
                    bet_amount: e.betAmount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function s(e) {
                n("game_started", {
                    match_id: e.matchId,
                    room_id: e.roomId,
                    bet_amount: e.betAmount,
                    player_num: e.playerNum,
                    is_break_shot: e.isBreakShot,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function d(e) {
                n("game_ended", {
                    match_id: e.matchId,
                    room_id: e.roomId,
                    won: e.won,
                    prize_amount: e.prizeAmount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function c(e) {
                n("sign_up", {
                    user_id: e.userId,
                    method: e.method || "email",
                    referral_code: e.referralCode
                })
            }
            a.d(t, {
                FA: function() {
                    return r
                },
                Jq: function() {
                    return s
                },
                Sw: function() {
                    return c
                },
                gh: function() {
                    return d
                },
                iy: function() {
                    return o
                },
                mY: function() {
                    return l
                },
                w7: function() {
                    return i
                }
            })
        },
        6739: function(e, t, a) {
            a.d(t, {
                d8: function() {
                    return i
                },
                tN: function() {
                    return d
                }
            });
            var n = a(22020),
                r = a(10826);
            let o = "undefined" != typeof document;

            function i(e, t, a) {
                if (!o) return;
                let n = new Date;
                n.setTime(n.getTime() + 864e5 * a), document.cookie = "".concat(e, "=").concat(encodeURIComponent(t), ";expires=").concat(n.toUTCString(), ";path=/")
            }

            function l(e) {
                if (!o) return null;
                let t = document.cookie.match(RegExp("(^| )" + e + "=([^;]+)"));
                if (t) try {
                    return decodeURIComponent(t[2])
                } catch (e) {
                    return t[2]
                }
                return null
            }
            var s = a(54012);
            let d = (0, n.Ue)((e, t) => ({
                user: null,
                isAuthenticated: !1,
                isLoading: !0,
                error: null,
                banInfo: null,
                login: async (t, a) => {
                    e({
                        isLoading: !0,
                        error: null,
                        banInfo: null
                    });
                    let n = await r.h.login(t, a);
                    if (n.error) return e({
                        isLoading: !1,
                        error: n.error,
                        banInfo: n.banInfo || null
                    }), !1;
                    if (n.data) {
                        r.h.setToken(n.data.token), localStorage.setItem("userId", n.data.user.id);
                        let t = n.data.user;
                        return e({
                            user: {
                                id: t.id,
                                email: t.email,
                                name: t.name,
                                username: t.username,
                                phone: t.phone,
                                cpf: t.cpf,
                                role: t.role,
                                referralCode: t.referralCode || "",
                                managerCode: t.managerCode,
                                managedById: t.managedById,
                                balance: Number(t.balance),
                                affiliateWallet: Number(t.affiliateWallet || 0)
                            },
                            isAuthenticated: !0,
                            isLoading: !1
                        }), !0
                    }
                    return !1
                },
                register: async (t, a, n, o) => {
                    e({
                        isLoading: !0,
                        error: null
                    });
                    let i = l("referralCode"),
                        d = l("managerCode"),
                        c = await r.h.register(t, a, n, o || void 0, i || void 0, d || void 0);
                    if (c.error) return e({
                        isLoading: !1,
                        error: c.error
                    }), !1;
                    if (c.data) {
                        r.h.setToken(c.data.token), localStorage.setItem("userId", c.data.user.id);
                        let t = c.data.user;
                        return e({
                            user: {
                                id: t.id,
                                email: t.email,
                                name: t.name,
                                username: t.username,
                                phone: t.phone,
                                cpf: t.cpf,
                                role: t.role,
                                referralCode: t.referralCode || "",
                                managerCode: t.managerCode,
                                managedById: t.managedById,
                                balance: Number(t.balance),
                                affiliateWallet: Number(t.affiliateWallet || 0)
                            },
                            isAuthenticated: !0,
                            isLoading: !1
                        }), (0, s.Sw)({
                            userId: t.id,
                            referralCode: i || void 0
                        }), !0
                    }
                    return !1
                },
                logout: async () => {
                    try {
                        await r.h.logout()
                    } catch (e) {}
                    r.h.setToken(null), localStorage.removeItem("userId"), e({
                        user: null,
                        isAuthenticated: !1,
                        isLoading: !1
                    })
                },
                checkAuth: async () => {
                    let a = r.h.getToken(),
                        n = t();
                    if (n.isAuthenticated && n.user) {
                        e({
                            isLoading: !1
                        }), r.h.getProfile().then(t => {
                            if (t.data) {
                                let a = t.data;
                                e({
                                    user: {
                                        id: a.id,
                                        email: a.email,
                                        name: a.name,
                                        username: a.username,
                                        phone: a.phone,
                                        cpf: a.cpf,
                                        role: a.role,
                                        referralCode: a.referralCode || "",
                                        managerCode: a.managerCode,
                                        managedById: a.managedById,
                                        balance: Number(a.balance),
                                        affiliateWallet: Number(a.affiliateWallet || 0)
                                    }
                                })
                            }
                        }).catch(() => {});
                        return
                    }
                    if (!a) {
                        e({
                            isLoading: !1,
                            isAuthenticated: !1
                        });
                        return
                    }
                    let o = await r.h.getProfile();
                    if (o.error) {
                        "N\xe3o autorizado" === o.error || o.error.includes("401") || o.error.includes("Unauthorized") ? (r.h.setToken(null), e({
                            isLoading: !1,
                            isAuthenticated: !1,
                            user: null
                        })) : e({
                            isLoading: !1
                        });
                        return
                    }
                    if (o.data) {
                        localStorage.setItem("userId", o.data.id);
                        let t = o.data;
                        e({
                            user: {
                                id: t.id,
                                email: t.email,
                                name: t.name,
                                username: t.username,
                                phone: t.phone,
                                cpf: t.cpf,
                                role: t.role,
                                referralCode: t.referralCode || "",
                                managerCode: t.managerCode,
                                managedById: t.managedById,
                                balance: Number(t.balance),
                                affiliateWallet: Number(t.affiliateWallet || 0)
                            },
                            isAuthenticated: !0,
                            isLoading: !1
                        })
                    }
                },
                updateBalance: a => {
                    let n = t().user;
                    n && e({
                        user: { ...n,
                            balance: a
                        }
                    })
                },
                updatePhone: a => {
                    let n = t().user;
                    n && e({
                        user: { ...n,
                            phone: a
                        }
                    })
                },
                clearError: () => e({
                    error: null,
                    banInfo: null
                }),
                isAdmin: () => {
                    let {
                        user: e
                    } = t();
                    return (null == e ? void 0 : e.role) === "ADMIN"
                },
                isAffiliateManager: () => {
                    let {
                        user: e
                    } = t();
                    return (null == e ? void 0 : e.role) === "AFFILIATE_MANAGER"
                }
            }))
        }
    }
]);