"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [826], {
        10826: function(t, e, a) {
            a.d(e, {
                h: function() {
                    return s
                }
            });
            class n {
                setToken(t) {
                    this.token = t, t ? localStorage.setItem("token", t) : localStorage.removeItem("token")
                }
                getToken() {
                    return this.token
                }
                async request(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        a = {
                            "Content-Type": "application/json",
                            ...e.headers
                        };
                    this.token && (a.Authorization = "Bearer ".concat(this.token));
                    try {
                        let n = await fetch("".concat(this.baseUrl, "/api").concat(t), { ...e,
                                headers: a,
                                credentials: "include"
                            }),
                            s = await n.text(),
                            r = s ? JSON.parse(s) : null;
                        if (!n.ok) {
                            if (403 === n.status && (null == r ? void 0 : r.type) && ("BANNED" === r.type || "SUSPENDED" === r.type)) return {
                                error: r.message || "Conta bloqueada",
                                banInfo: {
                                    type: r.type,
                                    reason: r.reason || null,
                                    bannedAt: r.bannedAt,
                                    suspendedUntil: r.suspendedUntil
                                }
                            };
                            return {
                                error: (null == r ? void 0 : r.message) || "Algo deu errado"
                            }
                        }
                        return {
                            data: r
                        }
                    } catch (t) {
                        return console.error("API Error:", t), {
                            error: "Erro de conex\xe3o"
                        }
                    }
                }
                async register(t, e, a, n, s, r) {
                    return this.request("/auth/register", {
                        method: "POST",
                        body: JSON.stringify({
                            email: t,
                            password: e,
                            name: a,
                            phone: n,
                            referralCode: s,
                            managerCode: r
                        })
                    })
                }
                async login(t, e) {
                    return this.request("/auth/login", {
                        method: "POST",
                        body: JSON.stringify({
                            identifier: t,
                            password: e
                        })
                    })
                }
                async logout() {
                    return this.request("/auth/logout", {
                        method: "POST"
                    })
                }
                async getProfile() {
                    return this.request("/auth/me")
                }
                async forgotPassword(t) {
                    return this.request("/auth/forgot-password", {
                        method: "POST",
                        body: JSON.stringify({
                            email: t
                        })
                    })
                }
                async validateResetToken(t) {
                    return this.request("/auth/reset-password/".concat(t))
                }
                async resetPassword(t, e, a) {
                    return this.request("/auth/reset-password", {
                        method: "POST",
                        body: JSON.stringify({
                            token: t,
                            password: e,
                            confirmPassword: a
                        })
                    })
                }
                async getBalance() {
                    return this.request("/wallet/balance")
                }
                async getTransactions() {
                    return this.request("/wallet/transactions")
                }
                async getTransactionStatus(t) {
                    return this.request("/wallet/transaction/".concat(t, "/status"))
                }
                async deposit(t, e) {
                    return this.request("/wallet/deposit", {
                        method: "POST",
                        body: JSON.stringify({
                            amount: t,
                            cpf: e
                        })
                    })
                }
                async withdraw(t) {
                    return this.request("/wallet/withdraw", {
                        method: "POST",
                        body: JSON.stringify({
                            amount: t
                        })
                    })
                }
                async getRooms() {
                    return this.request("/rooms")
                }
                async getActiveMatches() {
                    return this.request("/rooms/active")
                }
                async getRoom(t) {
                    return this.request("/rooms/".concat(t))
                }
                async getRoomStatus(t) {
                    return this.request("/rooms/".concat(t, "/status"))
                }
                async createRoom(t, e, a) {
                    return this.request("/rooms", {
                        method: "POST",
                        body: JSON.stringify({
                            betAmount: t,
                            isPrivate: e,
                            password: a
                        })
                    })
                }
                async getRoomByCode(t) {
                    return this.request("/rooms/code/".concat(t.toUpperCase()))
                }
                async joinRoomByCode(t, e) {
                    return this.request("/rooms/code/".concat(t.toUpperCase(), "/join"), {
                        method: "POST",
                        body: JSON.stringify({
                            password: e
                        })
                    })
                }
                async searchRooms(t) {
                    return this.request("/rooms/search?q=".concat(encodeURIComponent(t)))
                }
                async joinRoom(t) {
                    return this.request("/rooms/".concat(t, "/join"), {
                        method: "POST"
                    })
                }
                async cancelRoom(t) {
                    return this.request("/rooms/".concat(t), {
                        method: "DELETE"
                    })
                }
                async getMyRooms() {
                    return this.request("/rooms/my")
                }
                async getPlatformStatus() {
                    return this.request("/rooms/platform-status")
                }
                async getAllSessions() {
                    return this.request("/session/all")
                }
                async getMySession() {
                    return this.request("/session/me")
                }
                async clearMySession() {
                    return this.request("/session/me", {
                        method: "DELETE"
                    })
                }
                async clearSession(t) {
                    return this.request("/session/".concat(t), {
                        method: "DELETE"
                    })
                }
                async getAffiliateStats() {
                    return this.request("/affiliate/stats")
                }
                async getAffiliateCommissions(t) {
                    return this.request("/affiliate/commissions".concat(t ? "?limit=".concat(t) : ""))
                }
                async getAffiliateWithdrawals(t) {
                    return this.request("/affiliate/withdrawals".concat(t ? "?limit=".concat(t) : ""))
                }
                async withdrawAffiliate(t) {
                    return this.request("/affiliate/withdraw", {
                        method: "POST",
                        body: JSON.stringify({
                            amount: t
                        })
                    })
                }
                async getManagerStats() {
                    return this.request("/affiliate-manager/stats")
                }
                async getManagerAffiliates(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.search) && e.append("search", t.search), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/affiliate-manager/affiliates?".concat(e.toString()))
                }
                async getManagerAffiliateDetails(t) {
                    return this.request("/affiliate-manager/affiliates/".concat(t))
                }
                async getManagerCommissions(t) {
                    return this.request("/affiliate-manager/commissions".concat(t ? "?limit=".concat(t) : ""))
                }
                async getManagerLink() {
                    return this.request("/affiliate-manager/link")
                }
                async getUserProfile() {
                    return this.request("/users/profile")
                }
                async updateProfile(t) {
                    return this.request("/users/profile", {
                        method: "PATCH",
                        body: JSON.stringify(t)
                    })
                }
                async getGameStats() {
                    return this.request("/users/stats")
                }
                async checkUsername(t) {
                    return this.request("/users/check-username/".concat(encodeURIComponent(t)))
                }
                async getUsernameChangeInfo() {
                    return this.request("/users/username-change-info")
                }
                async changeUsername(t) {
                    return this.request("/users/username", {
                        method: "PATCH",
                        body: JSON.stringify({
                            username: t
                        })
                    })
                }
                async completeDepositAdmin(t) {
                    return this.request("/wallet/admin/complete-deposit/".concat(t), {
                        method: "POST"
                    })
                }
                async getAdminMetrics() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    return this.request("/admin/metrics".concat(t ? "?refresh=true" : ""))
                }
                async refreshMetrics() {
                    return this.request("/admin/metrics/refresh", {
                        method: "POST"
                    })
                }
                async getChartsBatch(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), this.request("/admin/metrics/charts-batch?".concat(e.toString()))
                }
                async getRevenueChartData(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), this.request("/admin/metrics/chart/revenue?".concat(e.toString()))
                }
                async getUsersChartData(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), this.request("/admin/metrics/chart/users?".concat(e.toString()))
                }
                async getGamesChartData(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), this.request("/admin/metrics/chart/games?".concat(e.toString()))
                }
                async getDepositsWithdrawalsChartData(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), this.request("/admin/metrics/chart/deposits-withdrawals?".concat(e.toString()))
                }
                async getDepositsDetailedChartData(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), (null == t ? void 0 : t.type) && e.append("type", t.type), (null == t ? void 0 : t.depositorType) && e.append("depositorType", t.depositorType), this.request("/admin/metrics/chart/deposits-detailed?".concat(e.toString()))
                }
                async getWithdrawalsDetailedChartData(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), (null == t ? void 0 : t.type) && e.append("type", t.type), this.request("/admin/metrics/chart/withdrawals-detailed?".concat(e.toString()))
                }
                async getFeesBreakdownChartData(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.period) && e.append("period", t.period), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.groupBy) && e.append("groupBy", t.groupBy), this.request("/admin/metrics/chart/fees-breakdown?".concat(e.toString()))
                }
                async getAdminUsers(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.search) && e.append("search", t.search), (null == t ? void 0 : t.role) && e.append("role", t.role), (null == t ? void 0 : t.userType) && e.append("userType", t.userType), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/admin/users?".concat(e.toString()))
                }
                async getAdminUserDetails(t) {
                    return this.request("/admin/users/".concat(t))
                }
                async updateAdminUser(t, e) {
                    return this.request("/admin/users/".concat(t), {
                        method: "PATCH",
                        body: JSON.stringify(e)
                    })
                }
                async getAdminUserTransactions(t, e, a) {
                    let n = new URLSearchParams;
                    return e && n.append("type", e), a && n.append("limit", a.toString()), this.request("/admin/users/".concat(t, "/transactions?").concat(n.toString()))
                }
                async getAdminUserGameStats(t) {
                    return this.request("/admin/users/".concat(t, "/game-stats"))
                }
                async getAdminUserMatchHistory(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        a = new URLSearchParams;
                    return void 0 !== e.skip && a.append("skip", e.skip.toString()), void 0 !== e.take && a.append("take", e.take.toString()), this.request("/admin/users/".concat(t, "/match-history?").concat(a.toString()))
                }
                async getAdminUserUsernameHistory(t) {
                    return this.request("/admin/users/".concat(t, "/username-history"))
                }
                async getAdminUserAffiliate(t) {
                    return this.request("/admin/users/".concat(t, "/affiliate"))
                }
                async getAffiliateSettings(t) {
                    return this.request("/admin/users/".concat(t, "/affiliate-settings"))
                }
                async updateAffiliateSettings(t, e) {
                    return this.request("/admin/users/".concat(t, "/affiliate-settings"), {
                        method: "PATCH",
                        body: JSON.stringify(e)
                    })
                }
                async adjustUserBalance(t, e, a) {
                    return this.request("/admin/users/".concat(t, "/adjust-balance"), {
                        method: "POST",
                        body: JSON.stringify({
                            amount: e,
                            type: a
                        })
                    })
                }
                async adjustUserAffiliateWallet(t, e, a) {
                    return this.request("/admin/users/".concat(t, "/adjust-affiliate-wallet"), {
                        method: "POST",
                        body: JSON.stringify({
                            amount: e,
                            type: a
                        })
                    })
                }
                async getAdminManagers() {
                    return this.request("/admin/managers")
                }
                async promoteToManager(t) {
                    return this.request("/admin/users/".concat(t, "/promote-manager"), {
                        method: "POST"
                    })
                }
                async demoteFromManager(t) {
                    return this.request("/admin/users/".concat(t, "/demote-manager"), {
                        method: "POST"
                    })
                }
                async linkAffiliateToManager(t, e) {
                    return this.request("/admin/users/".concat(t, "/link-manager"), {
                        method: "POST",
                        body: JSON.stringify({
                            managerId: e
                        })
                    })
                }
                async unlinkAffiliateFromManager(t) {
                    return this.request("/admin/users/".concat(t, "/unlink-manager"), {
                        method: "POST"
                    })
                }
                async getPlatformSettings() {
                    return this.request("/admin/platform-settings")
                }
                async setRoomCreationEnabled(t) {
                    return this.request("/admin/platform-settings/room-creation", {
                        method: "POST",
                        body: JSON.stringify({
                            enabled: t
                        })
                    })
                }
                async setMaintenanceMode(t) {
                    return this.request("/admin/platform-settings/maintenance", {
                        method: "POST",
                        body: JSON.stringify({
                            enabled: t
                        })
                    })
                }
                async setRankingEnabled(t) {
                    return this.request("/admin/platform-settings/ranking", {
                        method: "POST",
                        body: JSON.stringify({
                            enabled: t
                        })
                    })
                }
                async getAdminActiveMatches() {
                    return this.request("/admin/matches/active")
                }
                async getActiveMatchCounts() {
                    return this.request("/admin/matches/counts")
                }
                async getMatchHistory() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = new URLSearchParams;
                    return t.skip && e.append("skip", t.skip.toString()), t.take && e.append("take", t.take.toString()), t.status && e.append("status", t.status), this.request("/admin/matches/history?".concat(e.toString()))
                }
                async cancelMatch(t, e) {
                    return this.request("/admin/matches/".concat(t, "/cancel"), {
                        method: "POST",
                        body: JSON.stringify({
                            reason: e
                        })
                    })
                }
                async cancelAllMatches(t) {
                    return this.request("/admin/matches/cancel-all", {
                        method: "POST",
                        body: JSON.stringify({
                            reason: t
                        })
                    })
                }
                async cleanupGhostMatches() {
                    return this.request("/admin/matches/cleanup-ghosts", {
                        method: "POST"
                    })
                }
                async forceCleanupMatch(t, e) {
                    return this.request("/admin/matches/".concat(t, "/force-cleanup"), {
                        method: "POST",
                        body: JSON.stringify({
                            reason: e
                        })
                    })
                }
                async forceCleanupAllOrphans() {
                    return this.request("/admin/matches/force-cleanup-all", {
                        method: "POST"
                    })
                }
                async getBannedUsers() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 25;
                    return this.request("/admin/users/banned?skip=".concat(t, "&take=").concat(e))
                }
                async banUser(t, e) {
                    return this.request("/admin/users/".concat(t, "/ban"), {
                        method: "POST",
                        body: JSON.stringify({
                            reason: e
                        })
                    })
                }
                async suspendUser(t, e, a) {
                    return this.request("/admin/users/".concat(t, "/suspend"), {
                        method: "POST",
                        body: JSON.stringify({
                            durationHours: e,
                            reason: a
                        })
                    })
                }
                async unbanUser(t) {
                    return this.request("/admin/users/".concat(t, "/unban"), {
                        method: "POST"
                    })
                }
                async getUserBanHistory(t) {
                    return this.request("/admin/users/".concat(t, "/ban-history"))
                }
                async getPendingWithdrawals() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 25;
                    return this.request("/admin/withdrawals/pending?skip=".concat(t, "&take=").concat(e))
                }
                async getWithdrawalStats() {
                    return this.request("/admin/withdrawals/stats")
                }
                async getWithdrawalHistory(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.status) && e.append("status", t.status), (null == t ? void 0 : t.type) && e.append("type", t.type), (null == t ? void 0 : t.userId) && e.append("userId", t.userId), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/admin/withdrawals/history?".concat(e.toString()))
                }
                async getWithdrawalDetails(t) {
                    return this.request("/admin/withdrawals/".concat(t))
                }
                async cancelWithdrawal(t, e) {
                    return this.request("/admin/withdrawals/".concat(t, "/cancel"), {
                        method: "POST",
                        body: JSON.stringify({
                            reason: e
                        })
                    })
                }
                async getDepositStats() {
                    return this.request("/admin/deposits/stats")
                }
                async getPendingDeposits() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 25;
                    return this.request("/admin/deposits/pending?skip=".concat(t, "&take=").concat(e))
                }
                async getDepositHistory(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.status) && e.append("status", t.status), (null == t ? void 0 : t.userId) && e.append("userId", t.userId), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/admin/deposits/history?".concat(e.toString()))
                }
                async cancelDeposit(t, e) {
                    return this.request("/admin/deposits/".concat(t, "/cancel"), {
                        method: "POST",
                        body: JSON.stringify({
                            reason: e
                        })
                    })
                }
                async getAllTransactions(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.type) && e.append("type", t.type), (null == t ? void 0 : t.status) && e.append("status", t.status), (null == t ? void 0 : t.walletType) && e.append("walletType", t.walletType), (null == t ? void 0 : t.userId) && e.append("userId", t.userId), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/admin/transactions?".concat(e.toString()))
                }
                async getActivityLogs(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.userId) && e.append("userId", t.userId), (null == t ? void 0 : t.action) && e.append("action", t.action), (null == t ? void 0 : t.category) && e.append("category", t.category), (null == t ? void 0 : t.startDate) && e.append("startDate", t.startDate), (null == t ? void 0 : t.endDate) && e.append("endDate", t.endDate), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/admin/activity-logs?".concat(e.toString()))
                }
                async getActivityStats(t, e) {
                    let a = new URLSearchParams;
                    return t && a.append("startDate", t), e && a.append("endDate", e), this.request("/admin/activity-logs/stats?".concat(a.toString()))
                }
                async getUserActivityLogs(t, e) {
                    let a = new URLSearchParams;
                    return e && a.append("limit", e.toString()), this.request("/admin/activity-logs/user/".concat(t, "?").concat(a.toString()))
                }
                async getAffiliateNetworkStats() {
                    return this.request("/admin/affiliate-network/stats")
                }
                async getAffiliateNetworkTree() {
                    return this.request("/admin/affiliate-network/tree")
                }
                async getAffiliateNodeDetails(t) {
                    return this.request("/admin/affiliate-network/node/".concat(t))
                }
                async getIndependentAffiliates() {
                    return this.request("/admin/affiliate-network/independent")
                }
                async getDailyTopPerformers() {
                    return this.request("/admin/affiliate-network/daily-performers")
                }
                async createCampaign(t, e) {
                    return this.request("/admin/users/".concat(t, "/campaigns"), {
                        method: "POST",
                        body: JSON.stringify(e)
                    })
                }
                async deactivateCampaign(t) {
                    return this.request("/admin/users/".concat(t, "/campaigns/deactivate"), {
                        method: "POST"
                    })
                }
                async updateActiveCampaign(t, e) {
                    return this.request("/admin/users/".concat(t, "/campaigns/active"), {
                        method: "PATCH",
                        body: JSON.stringify(e)
                    })
                }
                async listAffiliateCampaigns(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    return this.request("/admin/users/".concat(t, "/campaigns?includeUsers=").concat(e))
                }
                async getActiveCampaign(t) {
                    return this.request("/admin/users/".concat(t, "/campaigns/active"))
                }
                async getCampaignDetails(t) {
                    return this.request("/admin/campaigns/".concat(t))
                }
                async getCurrentRanking() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 50;
                    return this.request("/ranking/current?limit=".concat(t))
                }
                async getMyRanking() {
                    return this.request("/ranking/me")
                }
                async getSeasonsList() {
                    return this.request("/ranking/seasons")
                }
                async getSeasonRanking(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 50;
                    return this.request("/ranking/seasons/".concat(t, "?limit=").concat(e))
                }
                async getAdminSeasons() {
                    return this.request("/admin/seasons")
                }
                async getAdminSeasonDetails(t) {
                    return this.request("/admin/seasons/".concat(t))
                }
                async createSeason(t) {
                    return this.request("/admin/seasons", {
                        method: "POST",
                        body: JSON.stringify(t)
                    })
                }
                async updateSeason(t, e) {
                    return this.request("/admin/seasons/".concat(t), {
                        method: "PATCH",
                        body: JSON.stringify(e)
                    })
                }
                async activateSeason(t) {
                    return this.request("/admin/seasons/".concat(t, "/activate"), {
                        method: "POST"
                    })
                }
                async finalizeSeason(t) {
                    let e = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
                    return this.request("/admin/seasons/".concat(t, "/finalize"), {
                        method: "POST",
                        body: JSON.stringify({
                            payPrizes: e
                        })
                    })
                }
                async paySeasonPrizes(t) {
                    return this.request("/admin/seasons/".concat(t, "/pay-prizes"), {
                        method: "POST"
                    })
                }
                async deleteSeason(t) {
                    return this.request("/admin/seasons/".concat(t), {
                        method: "DELETE"
                    })
                }
                async getSeasonStats(t) {
                    return this.request("/admin/seasons/".concat(t, "/stats"))
                }
                async getInstancesOverview() {
                    return this.request("/admin/instances")
                }
                async getAllActiveInstanceMatches() {
                    return this.request("/admin/instances/matches")
                }
                async getInstanceDetails(t) {
                    return this.request("/admin/instances/".concat(t))
                }
                async refreshInstanceHealth() {
                    return this.request("/admin/instances/refresh-health", {
                        method: "POST"
                    })
                }
                async getMatchCentralHistory() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = new URLSearchParams;
                    return t.playerSearch && e.append("playerSearch", t.playerSearch), t.dateFrom && e.append("dateFrom", t.dateFrom), t.dateTo && e.append("dateTo", t.dateTo), void 0 !== t.betAmountMin && e.append("betAmountMin", t.betAmountMin.toString()), void 0 !== t.betAmountMax && e.append("betAmountMax", t.betAmountMax.toString()), t.status && e.append("status", t.status), t.endReason && e.append("endReason", t.endReason), void 0 !== t.skip && e.append("skip", t.skip.toString()), void 0 !== t.take && e.append("take", t.take.toString()), this.request("/admin/match-central/history?".concat(e.toString()))
                }
                async getMatchCentralDetail(t) {
                    return this.request("/admin/match-central/".concat(t))
                }
                async createReport(t) {
                    return this.request("/reports", {
                        method: "POST",
                        body: JSON.stringify(t)
                    })
                }
                async checkReport(t) {
                    return this.request("/reports/check/".concat(t))
                }
                async checkReportsBatch(t) {
                    return this.request("/reports/check-batch", {
                        method: "POST",
                        body: JSON.stringify({
                            matchIds: t
                        })
                    })
                }
                async getReportedUsers(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.search) && e.append("search", t.search), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/admin/player-reports/users?".concat(e.toString()))
                }
                async getReportedUserDetails(t) {
                    return this.request("/admin/player-reports/users/".concat(t))
                }
                async getUserReports(t, e) {
                    let a = new URLSearchParams;
                    return (null == e ? void 0 : e.category) && a.append("category", e.category), (null == e ? void 0 : e.sortOrder) && a.append("sortOrder", e.sortOrder), (null == e ? void 0 : e.skip) !== void 0 && a.append("skip", e.skip.toString()), (null == e ? void 0 : e.take) !== void 0 && a.append("take", e.take.toString()), this.request("/admin/player-reports/users/".concat(t, "/reports?").concat(a.toString()))
                }
                async getUserReportedMatches(t, e) {
                    let a = new URLSearchParams;
                    return (null == e ? void 0 : e.skip) !== void 0 && a.append("skip", e.skip.toString()), (null == e ? void 0 : e.take) !== void 0 && a.append("take", e.take.toString()), this.request("/admin/player-reports/users/".concat(t, "/matches?").concat(a.toString()))
                }
                async getReportedUsersCount() {
                    return this.request("/admin/player-reports/count")
                }
                async getMyMatchHistory() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = new URLSearchParams;
                    return void 0 !== t.skip && e.append("skip", t.skip.toString()), void 0 !== t.take && e.append("take", t.take.toString()), this.request("/users/match-history?".concat(e.toString()))
                }
                async getAdminUserIpHistory(t) {
                    return this.request("/admin/ip/user/".concat(t))
                }
                async getAdminLinkedAccounts(t) {
                    return this.request("/admin/ip/user/".concat(t, "/linked-accounts"))
                }
                async getAdminUsersByIp(t) {
                    return this.request("/admin/ip/address/".concat(encodeURIComponent(t)))
                }
                async getAdminIpFlags(t) {
                    let e = new URLSearchParams;
                    return (null == t ? void 0 : t.status) && e.append("status", t.status), (null == t ? void 0 : t.severity) && e.append("severity", t.severity), (null == t ? void 0 : t.skip) !== void 0 && e.append("skip", t.skip.toString()), (null == t ? void 0 : t.take) !== void 0 && e.append("take", t.take.toString()), this.request("/admin/ip/flags?".concat(e.toString()))
                }
                async getAdminIpFlagCount() {
                    return this.request("/admin/ip/flags/count")
                }
                async reviewAdminIpFlag(t, e, a) {
                    return this.request("/admin/ip/flags/".concat(encodeURIComponent(t), "/review"), {
                        method: "POST",
                        body: JSON.stringify({
                            action: e,
                            notes: a
                        })
                    })
                }
                async searchAdminIp(t) {
                    return this.request("/admin/ip/search?q=".concat(encodeURIComponent(t)))
                }
                async getAdminIpStats() {
                    return this.request("/admin/ip/stats")
                }
                async post(t, e) {
                    return this.request(t, {
                        method: "POST",
                        body: e ? JSON.stringify(e) : void 0
                    })
                }
                async get(t) {
                    return this.request(t)
                }
                constructor(t) {
                    this.token = null, this.baseUrl = t, this.token = localStorage.getItem("token")
                }
            }
            let s = new n("https://tacadinha.com")
        }
    }
]);