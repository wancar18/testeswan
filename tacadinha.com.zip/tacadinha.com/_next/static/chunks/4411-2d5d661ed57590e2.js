"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4411], {
        52681: function(e, t) {
            t.discordURLBuilder = function(e) {
                var t;
                let r = (null === (t = null == window ? void 0 : window.location) || void 0 === t ? void 0 : t.hostname) || "localhost",
                    n = e.hostname.split("."),
                    o = e.hostname.includes("trycloudflare.com") || e.hostname.includes("discordsays.com") || !(n.length > 2) ? "" : "/".concat(n[0]);
                return e.pathname.startsWith("/.proxy") ? "".concat(e.protocol, "//").concat(r).concat(o).concat(e.pathname).concat(e.search) : "".concat(e.protocol, "//").concat(r, "/.proxy/colyseus").concat(o).concat(e.pathname).concat(e.search)
            }
        },
        55651: function(e, t, r) {
            var n, o, i, s, a = r(69703),
                c = r(71746),
                l = r(62537);
            class u {
                set token(e) {
                    this.http.authToken = e
                }
                get token() {
                    return this.http.authToken
                }
                onChange(e) {
                    let t = a.__classPrivateFieldGet(this, s, "f").on("change", e);
                    return a.__classPrivateFieldGet(this, n, "f") || a.__classPrivateFieldSet(this, o, new Promise((e, t) => {
                        this.getUserData().then(e => {
                            this.emitChange(Object.assign(Object.assign({}, e), {
                                token: this.token
                            }))
                        }).catch(e => {
                            this.emitChange({
                                user: null,
                                token: void 0
                            })
                        }).finally(() => {
                            e()
                        })
                    }), "f"), a.__classPrivateFieldSet(this, n, !0, "f"), t
                }
                getUserData() {
                    return a.__awaiter(this, void 0, void 0, function*() {
                        if (this.token) return (yield this.http.get("".concat(this.settings.path, "/userdata"))).data;
                        throw Error("missing auth.token")
                    })
                }
                registerWithEmailAndPassword(e, t, r) {
                    return a.__awaiter(this, void 0, void 0, function*() {
                        let n = (yield this.http.post("".concat(this.settings.path, "/register"), {
                            body: {
                                email: e,
                                password: t,
                                options: r
                            }
                        })).data;
                        return this.emitChange(n), n
                    })
                }
                signInWithEmailAndPassword(e, t) {
                    return a.__awaiter(this, void 0, void 0, function*() {
                        let r = (yield this.http.post("".concat(this.settings.path, "/login"), {
                            body: {
                                email: e,
                                password: t
                            }
                        })).data;
                        return this.emitChange(r), r
                    })
                }
                signInAnonymously(e) {
                    return a.__awaiter(this, void 0, void 0, function*() {
                        let t = (yield this.http.post("".concat(this.settings.path, "/anonymous"), {
                            body: {
                                options: e
                            }
                        })).data;
                        return this.emitChange(t), t
                    })
                }
                sendPasswordResetEmail(e) {
                    return a.__awaiter(this, void 0, void 0, function*() {
                        return (yield this.http.post("".concat(this.settings.path, "/forgot-password"), {
                            body: {
                                email: e
                            }
                        })).data
                    })
                }
                signInWithProvider(e) {
                    return a.__awaiter(this, arguments, void 0, function*(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        return new Promise((r, n) => {
                            let o = t.width || 480,
                                s = t.height || 768,
                                c = this.token ? "?token=".concat(this.token) : "",
                                l = "Login with ".concat(e[0].toUpperCase() + e.substring(1)),
                                u = this.http.client.getHttpEndpoint("".concat(t.prefix || "".concat(this.settings.path, "/provider"), "/").concat(e).concat(c)),
                                f = screen.width / 2 - o / 2,
                                h = screen.height / 2 - s / 2;
                            a.__classPrivateFieldSet(this, i, window.open(u, l, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=" + o + ", height=" + s + ", top=" + h + ", left=" + f), "f");
                            let d = e => {
                                    (void 0 !== e.data.user || void 0 !== e.data.token) && (clearInterval(p), a.__classPrivateFieldGet(this, i, "f").close(), a.__classPrivateFieldSet(this, i, void 0, "f"), window.removeEventListener("message", d), void 0 !== e.data.error ? n(e.data.error) : (r(e.data), this.emitChange(e.data)))
                                },
                                p = setInterval(() => {
                                    (!a.__classPrivateFieldGet(this, i, "f") || a.__classPrivateFieldGet(this, i, "f").closed) && (a.__classPrivateFieldSet(this, i, void 0, "f"), n("cancelled"), window.removeEventListener("message", d))
                                }, 200);
                            window.addEventListener("message", d)
                        })
                    })
                }
                signOut() {
                    return a.__awaiter(this, void 0, void 0, function*() {
                        this.emitChange({
                            user: null,
                            token: null
                        })
                    })
                }
                emitChange(e) {
                    void 0 !== e.token && (this.token = e.token, null === e.token ? c.removeItem(this.settings.key) : c.setItem(this.settings.key, e.token)), a.__classPrivateFieldGet(this, s, "f").emit("change", e)
                }
                constructor(e) {
                    this.http = e, this.settings = {
                        path: "/auth",
                        key: "colyseus-auth-token"
                    }, n.set(this, !1), o.set(this, void 0), i.set(this, void 0), s.set(this, l.createNanoEvents()), c.getItem(this.settings.key, e => this.token = e)
                }
            }
            n = new WeakMap, o = new WeakMap, i = new WeakMap, s = new WeakMap, t.Auth = u
        },
        43443: function(e, t, r) {
            var n, o = r(69703),
                i = r(72771),
                s = r(80692),
                a = r(16789),
                c = r(55651),
                l = r(52681);
            class u extends Error {
                constructor(e, t) {
                    super(e), this.code = t, this.name = "MatchMakeError", Object.setPrototypeOf(this, u.prototype)
                }
            }
            let f = "undefined" != typeof window && void 0 !== (null === (n = null == window ? void 0 : window.location) || void 0 === n ? void 0 : n.hostname) ? "".concat(window.location.protocol.replace("http", "ws"), "//").concat(window.location.hostname).concat(window.location.port && ":".concat(window.location.port)) : "ws://127.0.0.1:2567";
            class h {
                joinOrCreate(e) {
                    return o.__awaiter(this, arguments, void 0, function*(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = arguments.length > 2 ? arguments[2] : void 0;
                        return yield this.createMatchMakeRequest("joinOrCreate", e, t, r)
                    })
                }
                create(e) {
                    return o.__awaiter(this, arguments, void 0, function*(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = arguments.length > 2 ? arguments[2] : void 0;
                        return yield this.createMatchMakeRequest("create", e, t, r)
                    })
                }
                join(e) {
                    return o.__awaiter(this, arguments, void 0, function*(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = arguments.length > 2 ? arguments[2] : void 0;
                        return yield this.createMatchMakeRequest("join", e, t, r)
                    })
                }
                joinById(e) {
                    return o.__awaiter(this, arguments, void 0, function*(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = arguments.length > 2 ? arguments[2] : void 0;
                        return yield this.createMatchMakeRequest("joinById", e, t, r)
                    })
                }
                reconnect(e, t) {
                    return o.__awaiter(this, void 0, void 0, function*() {
                        if ("string" == typeof e && "string" == typeof t) throw Error("DEPRECATED: .reconnect() now only accepts 'reconnectionToken' as argument.\nYou can get this token from previously connected `room.reconnectionToken`");
                        let [r, n] = e.split(":");
                        if (!r || !n) throw Error("Invalid reconnection token format.\nThe format should be roomId:reconnectionToken");
                        return yield this.createMatchMakeRequest("reconnect", r, {
                            reconnectionToken: n
                        }, t)
                    })
                }
                consumeSeatReservation(e, t, r) {
                    return o.__awaiter(this, void 0, void 0, function*() {
                        let n = this.createRoom(e.room.name, t);
                        n.roomId = e.room.roomId, n.sessionId = e.sessionId;
                        let s = {
                            sessionId: n.sessionId
                        };
                        e.reconnectionToken && (s.reconnectionToken = e.reconnectionToken);
                        let a = r || n;
                        return n.connect(this.buildEndpoint(e.room, s, e.protocol), e.devMode && (() => o.__awaiter(this, void 0, void 0, function*() {
                            console.info("[Colyseus devMode]: ".concat(String.fromCodePoint(128260), " Re-establishing connection with room id '").concat(n.roomId, "'..."));
                            let r = 0,
                                i = () => o.__awaiter(this, void 0, void 0, function*() {
                                    r++;
                                    try {
                                        yield this.consumeSeatReservation(e, t, a), console.info("[Colyseus devMode]: ".concat(String.fromCodePoint(9989), " Successfully re-established connection with room '").concat(n.roomId, "'"))
                                    } catch (e) {
                                        r < 8 ? (console.info("[Colyseus devMode]: ".concat(String.fromCodePoint(128260), " retrying... (").concat(r, " out of ").concat(8, ")")), setTimeout(i, 2e3)) : console.info("[Colyseus devMode]: ".concat(String.fromCodePoint(10060), " Failed to reconnect. Is your server running? Please check server logs."))
                                    }
                                });
                            setTimeout(i, 2e3)
                        })), a, e, this.http.headers), new Promise((e, t) => {
                            let r = (e, r) => t(new i.ServerError(e, r));
                            a.onError.once(r), a.onJoin.once(() => {
                                a.onError.remove(r), e(a)
                            })
                        })
                    })
                }
                createMatchMakeRequest(e, t) {
                    return o.__awaiter(this, arguments, void 0, function*(e, t) {
                        let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                            n = arguments.length > 3 ? arguments[3] : void 0,
                            o = arguments.length > 4 ? arguments[4] : void 0,
                            i = (yield this.http.post("matchmake/".concat(e, "/").concat(t), {
                                headers: {
                                    Accept: "application/json",
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify(r)
                            })).data;
                        if (i.error) throw new u(i.error, i.code);
                        return "reconnect" === e && (i.reconnectionToken = r.reconnectionToken), yield this.consumeSeatReservation(i, n, o)
                    })
                }
                createRoom(e, t) {
                    return new s.Room(e, t)
                }
                buildEndpoint(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "ws",
                        n = this.settings.searchParams || "";
                    for (let e in this.http.authToken && (t._authToken = this.http.authToken), t) t.hasOwnProperty(e) && (n += (n ? "&" : "") + "".concat(e, "=").concat(t[e]));
                    "h3" === r && (r = "http");
                    let o = this.settings.secure ? "".concat(r, "s://") : "".concat(r, "://");
                    e.publicAddress ? o += "".concat(e.publicAddress) : o += "".concat(this.settings.hostname).concat(this.getEndpointPort()).concat(this.settings.pathname);
                    let i = "".concat(o, "/").concat(e.processId, "/").concat(e.roomId, "?").concat(n);
                    return this.urlBuilder ? this.urlBuilder(new URL(i)) : i
                }
                getHttpEndpoint() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        t = e.startsWith("/") ? e : "/".concat(e),
                        r = "".concat(this.settings.secure ? "https" : "http", "://").concat(this.settings.hostname).concat(this.getEndpointPort()).concat(this.settings.pathname).concat(t);
                    return this.settings.searchParams && (r += "?".concat(this.settings.searchParams)), this.urlBuilder ? this.urlBuilder(new URL(r)) : r
                }
                getEndpointPort() {
                    return 80 !== this.settings.port && 443 !== this.settings.port ? ":".concat(this.settings.port) : ""
                }
                constructor(e = f, t) {
                    var r, n;
                    if ("string" == typeof e) {
                        let t = e.startsWith("/") ? new URL(e, f) : new URL(e),
                            r = "https:" === t.protocol || "wss:" === t.protocol,
                            n = Number(t.port || (r ? 443 : 80));
                        this.settings = {
                            hostname: t.hostname,
                            pathname: t.pathname,
                            port: n,
                            secure: r,
                            searchParams: t.searchParams.toString() || void 0
                        }
                    } else void 0 === e.port && (e.port = e.secure ? 443 : 80), void 0 === e.pathname && (e.pathname = ""), this.settings = e;
                    this.settings.pathname.endsWith("/") && (this.settings.pathname = this.settings.pathname.slice(0, -1)), this.http = new a.HTTP(this, (null == t ? void 0 : t.headers) || {}), this.auth = new c.Auth(this.http), this.urlBuilder = null == t ? void 0 : t.urlBuilder, !this.urlBuilder && "undefined" != typeof window && (null === (n = null === (r = null == window ? void 0 : window.location) || void 0 === r ? void 0 : r.hostname) || void 0 === n ? void 0 : n.includes("discordsays.com")) && (this.urlBuilder = l.discordURLBuilder, console.log("Colyseus SDK: Discord Embedded SDK detected. Using custom URL builder."))
                }
            }
            h.VERSION = "0.16.22", t.Client = h, t.MatchMakeError = u
        },
        54530: function(e, t, r) {
            var n = r(50704),
                o = r(58033);
            class i {
                connect(e, t) {
                    this.transport.connect.call(this.transport, e, t)
                }
                send(e) {
                    this.transport.send(e)
                }
                sendUnreliable(e) {
                    this.transport.sendUnreliable(e)
                }
                close(e, t) {
                    this.transport.close(e, t)
                }
                get isOpen() {
                    return this.transport.isOpen
                }
                constructor(e) {
                    (this.events = {}, "h3" === e) ? this.transport = new n.H3TransportTransport(this.events): this.transport = new o.WebSocketTransport(this.events)
                }
            }
            t.Connection = i
        },
        16789: function(e, t, r) {
            var n, o = r(72771),
                i = r(13260),
                s = (n = Object.create(null), i && Object.keys(i).forEach(function(e) {
                    if ("default" !== e) {
                        var t = Object.getOwnPropertyDescriptor(i, e);
                        Object.defineProperty(n, e, t.get ? t : {
                            enumerable: !0,
                            get: function() {
                                return i[e]
                            }
                        })
                    }
                }), n.default = i, Object.freeze(n));
            class a {
                get(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return this.request("get", e, t)
                }
                post(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return this.request("post", e, t)
                }
                del(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return this.request("del", e, t)
                }
                put(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return this.request("put", e, t)
                }
                request(e, t) {
                    let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                    return s[e](this.client.getHttpEndpoint(t), this.getOptions(r)).catch(e => {
                        var t;
                        if (e.aborted) throw new o.AbortError("Request aborted");
                        let r = e.statusCode,
                            n = (null === (t = e.data) || void 0 === t ? void 0 : t.error) || e.statusMessage || e.message;
                        if (!r && !n) throw e;
                        throw new o.ServerError(r, n)
                    })
                }
                getOptions(e) {
                    return e.headers = Object.assign({}, this.headers, e.headers), this.authToken && (e.headers.Authorization = "Bearer ".concat(this.authToken)), "undefined" != typeof cc && cc.sys && cc.sys.isNative || (e.withCredentials = !0), e
                }
                constructor(e, t = {}) {
                    this.client = e, this.headers = t
                }
            }
            t.HTTP = a
        },
        42395: function(e, t) {
            var r, n;
            t.Protocol = void 0, (r = t.Protocol || (t.Protocol = {}))[r.HANDSHAKE = 9] = "HANDSHAKE", r[r.JOIN_ROOM = 10] = "JOIN_ROOM", r[r.ERROR = 11] = "ERROR", r[r.LEAVE_ROOM = 12] = "LEAVE_ROOM", r[r.ROOM_DATA = 13] = "ROOM_DATA", r[r.ROOM_STATE = 14] = "ROOM_STATE", r[r.ROOM_STATE_PATCH = 15] = "ROOM_STATE_PATCH", r[r.ROOM_DATA_SCHEMA = 16] = "ROOM_DATA_SCHEMA", r[r.ROOM_DATA_BYTES = 17] = "ROOM_DATA_BYTES", t.ErrorCode = void 0, (n = t.ErrorCode || (t.ErrorCode = {}))[n.MATCHMAKE_NO_HANDLER = 4210] = "MATCHMAKE_NO_HANDLER", n[n.MATCHMAKE_INVALID_CRITERIA = 4211] = "MATCHMAKE_INVALID_CRITERIA", n[n.MATCHMAKE_INVALID_ROOM_ID = 4212] = "MATCHMAKE_INVALID_ROOM_ID", n[n.MATCHMAKE_UNHANDLED = 4213] = "MATCHMAKE_UNHANDLED", n[n.MATCHMAKE_EXPIRED = 4214] = "MATCHMAKE_EXPIRED", n[n.AUTH_FAILED = 4215] = "AUTH_FAILED", n[n.APPLICATION_ERROR = 4216] = "APPLICATION_ERROR"
        },
        80692: function(e, t, r) {
            var n = r(54530),
                o = r(42395),
                i = r(78411),
                s = r(62537),
                a = r(19862),
                c = r(64800),
                l = r(69842),
                u = r(72771),
                f = r(40314);
            class h {
                connect(e, t) {
                    let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this,
                        o = arguments.length > 3 ? arguments[3] : void 0,
                        i = arguments.length > 4 ? arguments[4] : void 0,
                        s = new n.Connection(o.protocol);
                    if (r.connection = s, s.events.onmessage = h.prototype.onMessageCallback.bind(r), s.events.onclose = function(e) {
                            var n;
                            if (!r.hasJoined) {
                                null === (n = console.warn) || void 0 === n || n.call(console, "Room connection was closed unexpectedly (".concat(e.code, "): ").concat(e.reason)), r.onError.invoke(e.code, e.reason);
                                return
                            }
                            e.code === u.CloseCode.DEVMODE_RESTART && t ? t() : (r.onLeave.invoke(e.code, e.reason), r.destroy())
                        }, s.events.onerror = function(e) {
                            var t;
                            null === (t = console.warn) || void 0 === t || t.call(console, "Room, onError (".concat(e.code, "): ").concat(e.reason)), r.onError.invoke(e.code, e.reason)
                        }, "h3" === o.protocol) {
                        let t = new URL(e);
                        s.connect(t.origin, o)
                    } else s.connect(e, i)
                }
                leave() {
                    let e = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0];
                    return new Promise(t => {
                        this.onLeave(e => t(e)), this.connection ? e ? (this.packr.buffer[0] = o.Protocol.LEAVE_ROOM, this.connection.send(this.packr.buffer.subarray(0, 1))) : this.connection.close() : this.onLeave.invoke(u.CloseCode.CONSENTED)
                    })
                }
                onMessage(e, t) {
                    return this.onMessageHandlers.on(this.getMessageHandlerKey(e), t)
                }
                send(e, t) {
                    let r = {
                        offset: 1
                    };
                    this.packr.buffer[0] = o.Protocol.ROOM_DATA, "string" == typeof e ? c.encode.string(this.packr.buffer, e, r) : c.encode.number(this.packr.buffer, e, r), this.packr.position = 0;
                    let n = void 0 !== t ? this.packr.pack(t, 2048 + r.offset) : this.packr.buffer.subarray(0, r.offset);
                    this.connection.send(n)
                }
                sendUnreliable(e, t) {
                    let r = {
                        offset: 1
                    };
                    this.packr.buffer[0] = o.Protocol.ROOM_DATA, "string" == typeof e ? c.encode.string(this.packr.buffer, e, r) : c.encode.number(this.packr.buffer, e, r), this.packr.position = 0;
                    let n = void 0 !== t ? this.packr.pack(t, 2048 + r.offset) : this.packr.buffer.subarray(0, r.offset);
                    this.connection.sendUnreliable(n)
                }
                sendBytes(e, t) {
                    let r = {
                        offset: 1
                    };
                    if (this.packr.buffer[0] = o.Protocol.ROOM_DATA_BYTES, "string" == typeof e ? c.encode.string(this.packr.buffer, e, r) : c.encode.number(this.packr.buffer, e, r), t.byteLength + r.offset > this.packr.buffer.byteLength) {
                        let e = new Uint8Array(r.offset + t.byteLength);
                        e.set(this.packr.buffer), this.packr.useBuffer(e)
                    }
                    this.packr.buffer.set(t, r.offset), this.connection.send(this.packr.buffer.subarray(0, r.offset + t.byteLength))
                }
                get state() {
                    return this.serializer.getState()
                }
                removeAllListeners() {
                    this.onJoin.clear(), this.onStateChange.clear(), this.onError.clear(), this.onLeave.clear(), this.onMessageHandlers.events = {}, this.serializer instanceof l.SchemaSerializer && (this.serializer.decoder.root.callbacks = {})
                }
                onMessageCallback(e) {
                    let t = new Uint8Array(e.data),
                        r = {
                            offset: 1
                        },
                        n = t[0];
                    if (n === o.Protocol.JOIN_ROOM) {
                        let e = c.decode.utf8Read(t, r, t[r.offset++]);
                        if (this.serializerId = c.decode.utf8Read(t, r, t[r.offset++]), !this.serializer) {
                            let e = i.getSerializer(this.serializerId);
                            this.serializer = new e
                        }
                        t.byteLength > r.offset && this.serializer.handshake && this.serializer.handshake(t, r), this.reconnectionToken = "".concat(this.roomId, ":").concat(e), this.hasJoined = !0, this.onJoin.invoke(), this.packr.buffer[0] = o.Protocol.JOIN_ROOM, this.connection.send(this.packr.buffer.subarray(0, 1))
                    } else if (n === o.Protocol.ERROR) {
                        let e = c.decode.number(t, r),
                            n = c.decode.string(t, r);
                        this.onError.invoke(e, n)
                    } else if (n === o.Protocol.LEAVE_ROOM) this.leave();
                    else if (n === o.Protocol.ROOM_STATE) this.serializer.setState(t, r), this.onStateChange.invoke(this.serializer.getState());
                    else if (n === o.Protocol.ROOM_STATE_PATCH) this.serializer.patch(t, r), this.onStateChange.invoke(this.serializer.getState());
                    else if (n === o.Protocol.ROOM_DATA) {
                        let e = c.decode.stringCheck(t, r) ? c.decode.string(t, r) : c.decode.number(t, r),
                            n = t.byteLength > r.offset ? f.unpack(t, {
                                start: r.offset
                            }) : void 0;
                        this.dispatchMessage(e, n)
                    } else if (n === o.Protocol.ROOM_DATA_BYTES) {
                        let e = c.decode.stringCheck(t, r) ? c.decode.string(t, r) : c.decode.number(t, r);
                        this.dispatchMessage(e, t.subarray(r.offset))
                    }
                }
                dispatchMessage(e, t) {
                    var r;
                    let n = this.getMessageHandlerKey(e);
                    this.onMessageHandlers.events[n] ? this.onMessageHandlers.emit(n, t) : this.onMessageHandlers.events["*"] ? this.onMessageHandlers.emit("*", e, t) : null === (r = console.warn) || void 0 === r || r.call(console, "colyseus.js: onMessage() not registered for type '".concat(e, "'."))
                }
                destroy() {
                    this.serializer && this.serializer.teardown()
                }
                getMessageHandlerKey(e) {
                    switch (typeof e) {
                        case "string":
                            return e;
                        case "number":
                            return "i".concat(e);
                        default:
                            throw Error("invalid message type.")
                    }
                }
                constructor(e, t) {
                    this.onStateChange = a.createSignal(), this.onError = a.createSignal(), this.onLeave = a.createSignal(), this.onJoin = a.createSignal(), this.hasJoined = !1, this.onMessageHandlers = s.createNanoEvents(), this.roomId = null, this.name = e, this.packr = new f.Packr, this.packr.encode(void 0), t && (this.serializer = new(i.getSerializer("schema")), this.rootSchema = t, this.serializer.state = new t), this.onError((e, t) => {
                        var r;
                        return null === (r = console.warn) || void 0 === r ? void 0 : r.call(console, "colyseus.js - onError => (".concat(e, ") ").concat(t))
                    }), this.onLeave(() => this.removeAllListeners())
                }
            }
            t.Room = h
        },
        71746: function(e, t, r) {
            let n;
            var o = r(69703);

            function i() {
                if (!n) try {
                    n = "undefined" != typeof cc && cc.sys && cc.sys.localStorage ? cc.sys.localStorage : window.localStorage
                } catch (e) {}
                return n || void 0 === globalThis.indexedDB || (n = new s), n || (n = {
                    cache: {},
                    setItem: function(e, t) {
                        this.cache[e] = t
                    },
                    getItem: function(e) {
                        this.cache[e]
                    },
                    removeItem: function(e) {
                        delete this.cache[e]
                    }
                }), n
            }
            class s {
                tx(e, t) {
                    return o.__awaiter(this, void 0, void 0, function*() {
                        return t((yield this.dbPromise).transaction("store", e).objectStore("store"))
                    })
                }
                setItem(e, t) {
                    return this.tx("readwrite", r => r.put(t, e)).then()
                }
                getItem(e) {
                    return o.__awaiter(this, void 0, void 0, function*() {
                        let t = yield this.tx("readonly", t => t.get(e));
                        return new Promise(e => {
                            t.onsuccess = () => e(t.result)
                        })
                    })
                }
                removeItem(e) {
                    return this.tx("readwrite", t => t.delete(e)).then()
                }
                constructor() {
                    this.dbPromise = new Promise(e => {
                        let t = indexedDB.open("_colyseus_storage", 1);
                        t.onupgradeneeded = () => t.result.createObjectStore("store"), t.onsuccess = () => e(t.result)
                    })
                }
            }
            t.getItem = function(e, t) {
                let r = i().getItem(e);
                "undefined" != typeof Promise && r instanceof Promise ? r.then(e => t(e)) : t(r)
            }, t.removeItem = function(e) {
                i().removeItem(e)
            }, t.setItem = function(e, t) {
                i().setItem(e, t)
            }
        },
        62537: function(e, t) {
            t.createNanoEvents = () => ({
                emit(e) {
                    for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
                    let o = this.events[e] || [];
                    for (let e = 0, t = o.length; e < t; e++) o[e](...r)
                },
                events: {},
                on(e, t) {
                    var r;
                    return (null === (r = this.events[e]) || void 0 === r ? void 0 : r.push(t)) || (this.events[e] = [t]), () => {
                        var r;
                        this.events[e] = null === (r = this.events[e]) || void 0 === r ? void 0 : r.filter(e => t !== e)
                    }
                }
            })
        },
        19862: function(e, t) {
            class r {
                register(e) {
                    return arguments.length > 1 && void 0 !== arguments[1] && arguments[1], this.handlers.push(e), this
                }
                invoke() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    this.handlers.forEach(e => e.apply(this, t))
                }
                invokeAsync() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    return Promise.all(this.handlers.map(e => e.apply(this, t)))
                }
                remove(e) {
                    let t = this.handlers.indexOf(e);
                    this.handlers[t] = this.handlers[this.handlers.length - 1], this.handlers.pop()
                }
                clear() {
                    this.handlers = []
                }
                constructor() {
                    this.handlers = []
                }
            }
            t.EventEmitter = r, t.createSignal = function() {
                let e = new r;

                function t(t) {
                    return e.register(t, this === null)
                }
                return t.once = t => {
                    let r = function() {
                        for (var n = arguments.length, o = Array(n), i = 0; i < n; i++) o[i] = arguments[i];
                        t.apply(this, o), e.remove(r)
                    };
                    e.register(r)
                }, t.remove = t => e.remove(t), t.invoke = function() {
                    for (var t = arguments.length, r = Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                    return e.invoke(...r)
                }, t.invokeAsync = function() {
                    for (var t = arguments.length, r = Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                    return e.invokeAsync(...r)
                }, t.clear = () => e.clear(), t
            }
        },
        72771: function(e, t) {
            var r;
            t.CloseCode = void 0, (r = t.CloseCode || (t.CloseCode = {}))[r.CONSENTED = 4e3] = "CONSENTED", r[r.DEVMODE_RESTART = 4010] = "DEVMODE_RESTART";
            class n extends Error {
                constructor(e, t) {
                    super(t), this.name = "ServerError", this.code = e
                }
            }
            class o extends Error {
                constructor(e) {
                    super(e), this.name = "AbortError"
                }
            }
            t.AbortError = o, t.ServerError = n
        },
        29533: function(e, t, r) {
            r(68599);
            var n = r(43443),
                o = (r(42395), r(80692)),
                i = r(55651),
                s = r(72771),
                a = r(69842),
                c = r(43575),
                l = r(78411);
            l.registerSerializer("schema", a.SchemaSerializer), l.registerSerializer("none", c.NoneSerializer), t.KU = n.Client, n.MatchMakeError, o.Room, i.Auth, s.ServerError, a.SchemaSerializer, a.getStateCallbacks, l.registerSerializer
        },
        68599: function() {
            ArrayBuffer.isView || (ArrayBuffer.isView = e => null !== e && "object" == typeof e && e.buffer instanceof ArrayBuffer), "undefined" == typeof globalThis && "undefined" != typeof window && (window.globalThis = window), "undefined" == typeof FormData && (globalThis.FormData = class {})
        },
        43575: function(e, t) {
            class r {
                setState(e) {}
                getState() {
                    return null
                }
                patch(e) {}
                teardown() {}
                handshake(e) {}
            }
            t.NoneSerializer = r
        },
        69842: function(e, t, r) {
            var n = r(64800);
            class o {
                setState(e, t) {
                    this.decoder.decode(e, t)
                }
                getState() {
                    return this.state
                }
                patch(e, t) {
                    return this.decoder.decode(e, t)
                }
                teardown() {
                    this.decoder.root.clearRefs()
                }
                handshake(e, t) {
                    this.state ? (n.Reflection.decode(e, t), this.decoder = new n.Decoder(this.state)) : (this.decoder = n.Reflection.decode(e, t), this.state = this.decoder.state)
                }
            }
            t.SchemaSerializer = o, t.getStateCallbacks = function(e) {
                try {
                    return n.getDecoderStateCallbacks(e.serializer.decoder)
                } catch (e) {
                    return
                }
            }
        },
        78411: function(e, t) {
            let r = {};
            t.getSerializer = function(e) {
                let t = r[e];
                if (!t) throw Error("missing serializer: " + e);
                return t
            }, t.registerSerializer = function(e, t) {
                r[e] = t
            }
        },
        50704: function(e, t, r) {
            var n = r(69703),
                o = r(64800);
            class i {
                connect(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        r = t.fingerprint && {
                            serverCertificateHashes: [{
                                algorithm: "sha-256",
                                value: new Uint8Array(t.fingerprint).buffer
                            }]
                        } || void 0;
                    this.wt = new WebTransport(e, r), this.wt.ready.then(e => {
                        console.log("WebTransport ready!", e), this.isOpen = !0, this.unreliableReader = this.wt.datagrams.readable.getReader(), this.unreliableWriter = this.wt.datagrams.writable.getWriter(), this.wt.incomingBidirectionalStreams.getReader().read().then(e => {
                            this.reader = e.value.readable.getReader(), this.writer = e.value.writable.getWriter(), this.sendSeatReservation(t.room.roomId, t.sessionId, t.reconnectionToken), this.readIncomingData(), this.readIncomingUnreliableData()
                        }).catch(e => {
                            console.error("failed to read incoming stream", e), console.error("TODO: close the connection")
                        })
                    }).catch(e => {
                        console.log("WebTransport not ready!", e), this._close()
                    }), this.wt.closed.then(e => {
                        console.log("WebTransport closed w/ success", e), this.events.onclose({
                            code: e.closeCode,
                            reason: e.reason
                        })
                    }).catch(e => {
                        console.log("WebTransport closed w/ error", e), this.events.onerror(e), this.events.onclose({
                            code: e.closeCode,
                            reason: e.reason
                        })
                    }).finally(() => {
                        this._close()
                    })
                }
                send(e) {
                    let t = o.encode.number(this.lengthPrefixBuffer, e.length, {
                            offset: 0
                        }),
                        r = new Uint8Array(t + e.length);
                    r.set(this.lengthPrefixBuffer.subarray(0, t), 0), r.set(e, t), this.writer.write(r)
                }
                sendUnreliable(e) {
                    let t = o.encode.number(this.lengthPrefixBuffer, e.length, {
                            offset: 0
                        }),
                        r = new Uint8Array(t + e.length);
                    r.set(this.lengthPrefixBuffer.subarray(0, t), 0), r.set(e, t), this.unreliableWriter.write(r)
                }
                close(e, t) {
                    try {
                        this.wt.close({
                            closeCode: e,
                            reason: t
                        })
                    } catch (e) {
                        console.error(e)
                    }
                }
                readIncomingData() {
                    return n.__awaiter(this, void 0, void 0, function*() {
                        let e;
                        for (; this.isOpen;) {
                            try {
                                let t = (e = yield this.reader.read()).value,
                                    r = {
                                        offset: 0
                                    };
                                do {
                                    let e = o.decode.number(t, r);
                                    this.events.onmessage({
                                        data: t.subarray(r.offset, r.offset + e)
                                    }), r.offset += e
                                } while (r.offset < t.length)
                            } catch (e) {
                                -1 === e.message.indexOf("session is closed") && console.error("H3Transport: failed to read incoming data", e);
                                break
                            }
                            if (e.done) break
                        }
                    })
                }
                readIncomingUnreliableData() {
                    return n.__awaiter(this, void 0, void 0, function*() {
                        let e;
                        for (; this.isOpen;) {
                            try {
                                let t = (e = yield this.unreliableReader.read()).value,
                                    r = {
                                        offset: 0
                                    };
                                do {
                                    let e = o.decode.number(t, r);
                                    this.events.onmessage({
                                        data: t.subarray(r.offset, r.offset + e)
                                    }), r.offset += e
                                } while (r.offset < t.length)
                            } catch (e) {
                                -1 === e.message.indexOf("session is closed") && console.error("H3Transport: failed to read incoming data", e);
                                break
                            }
                            if (e.done) break
                        }
                    })
                }
                sendSeatReservation(e, t, r) {
                    let n = {
                            offset: 0
                        },
                        i = [];
                    o.encode.string(i, e, n), o.encode.string(i, t, n), r && o.encode.string(i, r, n), this.writer.write(new Uint8Array(i).buffer)
                }
                _close() {
                    this.isOpen = !1
                }
                constructor(e) {
                    this.events = e, this.isOpen = !1, this.lengthPrefixBuffer = new Uint8Array(9)
                }
            }
            t.H3TransportTransport = i
        },
        58033: function(e, t, r) {
            var n = r(68212);
            let o = globalThis.WebSocket || n;
            class i {
                send(e) {
                    this.ws.send(e)
                }
                sendUnreliable(e) {
                    console.warn("colyseus.js: The WebSocket transport does not support unreliable messages")
                }
                connect(e, t) {
                    try {
                        this.ws = new o(e, {
                            headers: t,
                            protocols: this.protocols
                        })
                    } catch (t) {
                        this.ws = new o(e, this.protocols)
                    }
                    this.ws.binaryType = "arraybuffer", this.ws.onopen = this.events.onopen, this.ws.onmessage = this.events.onmessage, this.ws.onclose = this.events.onclose, this.ws.onerror = this.events.onerror
                }
                close(e, t) {
                    this.ws.close(e, t)
                }
                get isOpen() {
                    return this.ws.readyState === o.OPEN
                }
                constructor(e) {
                    this.events = e
                }
            }
            t.WebSocketTransport = i
        },
        23441: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return n
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let n = (0, r(87461).Z)("ChevronDown", [
                ["path", {
                    d: "m6 9 6 6 6-6",
                    key: "qrunsl"
                }]
            ])
        },
        26490: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return n
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let n = (0, r(87461).Z)("Clock", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["polyline", {
                    points: "12 6 12 12 16 14",
                    key: "68esgv"
                }]
            ])
        },
        35005: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return n
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let n = (0, r(87461).Z)("Home", [
                ["path", {
                    d: "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
                    key: "y5dka4"
                }],
                ["polyline", {
                    points: "9 22 9 12 15 12 15 22",
                    key: "e2us08"
                }]
            ])
        },
        18994: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return n
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let n = (0, r(87461).Z)("Loader2", [
                ["path", {
                    d: "M21 12a9 9 0 1 1-6.219-8.56",
                    key: "13zald"
                }]
            ])
        },
        66260: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return n
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let n = (0, r(87461).Z)("Trophy", [
                ["path", {
                    d: "M6 9H4.5a2.5 2.5 0 0 1 0-5H6",
                    key: "17hqa7"
                }],
                ["path", {
                    d: "M18 9h1.5a2.5 2.5 0 0 0 0-5H18",
                    key: "lmptdp"
                }],
                ["path", {
                    d: "M4 22h16",
                    key: "57wxv0"
                }],
                ["path", {
                    d: "M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",
                    key: "1nw9bq"
                }],
                ["path", {
                    d: "M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",
                    key: "1np0yb"
                }],
                ["path", {
                    d: "M18 2H6v7a6 6 0 0 0 12 0V2Z",
                    key: "u46fv3"
                }]
            ])
        },
        11213: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return n
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let n = (0, r(87461).Z)("User", [
                ["path", {
                    d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
                    key: "975kel"
                }],
                ["circle", {
                    cx: "12",
                    cy: "7",
                    r: "4",
                    key: "17ys0d"
                }]
            ])
        },
        52235: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return n
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let n = (0, r(87461).Z)("X", [
                ["path", {
                    d: "M18 6 6 18",
                    key: "1bl5f8"
                }],
                ["path", {
                    d: "m6 6 12 12",
                    key: "d8bk6v"
                }]
            ])
        },
        47907: function(e, t, r) {
            var n = r(15313);
            r.o(n, "useParams") && r.d(t, {
                useParams: function() {
                    return n.useParams
                }
            }), r.o(n, "usePathname") && r.d(t, {
                usePathname: function() {
                    return n.usePathname
                }
            }), r.o(n, "useRouter") && r.d(t, {
                useRouter: function() {
                    return n.useRouter
                }
            }), r.o(n, "useSearchParams") && r.d(t, {
                useSearchParams: function() {
                    return n.useSearchParams
                }
            })
        },
        68212: function(e) {
            e.exports = function() {
                throw Error("ws does not work in the browser. Browser clients must use the native WebSocket object")
            }
        },
        13260: function(e, t, r) {
            function n(e, t) {
                t.headers = e.headers || {}, t.statusMessage = e.statusText, t.statusCode = e.status, t.data = e.response
            }

            function o(e, t, r) {
                return new Promise(function(o, i) {
                    r = r || {};
                    var s, a, c, l = new XMLHttpRequest,
                        u = r.body,
                        f = r.headers || {};
                    for (s in r.timeout && (l.timeout = r.timeout), l.ontimeout = l.onerror = function(e) {
                            e.timeout = "timeout" == e.type, i(e)
                        }, l.onabort = function(e) {
                            e.aborted = !0, i(e)
                        }, l.open(e, t.href || t), l.onload = function() {
                            for (c = l.getAllResponseHeaders().trim().split(/[\r\n]+/), n(l, l); a = c.shift();) a = a.split(": "), l.headers[a.shift().toLowerCase()] = a.join(": ");
                            if ((a = l.headers["content-type"]) && ~a.indexOf("application/json")) try {
                                l.data = JSON.parse(l.data, r.reviver)
                            } catch (e) {
                                return n(l, e), i(e)
                            }(l.status >= 400 ? i : o)(l)
                        }, "u" > typeof FormData && u instanceof FormData || u && "object" == typeof u && (f["content-type"] = "application/json", u = JSON.stringify(u)), l.withCredentials = !!r.withCredentials, f) l.setRequestHeader(s, f[s]);
                    l.send(u), r.signal && r.signal.addEventListener("abort", function() {
                        l.abort()
                    })
                })
            }
            r.r(t), r.d(t, {
                del: function() {
                    return c
                },
                get: function() {
                    return i
                },
                patch: function() {
                    return a
                },
                post: function() {
                    return s
                },
                put: function() {
                    return l
                },
                send: function() {
                    return o
                }
            });
            var i = o.bind(o, "GET"),
                s = o.bind(o, "POST"),
                a = o.bind(o, "PATCH"),
                c = o.bind(o, "DELETE"),
                l = o.bind(o, "PUT")
        },
        40314: function(e, t, r) {
            let n, o, i, s, a, c, l, u;
            r.r(t), r.d(t, {
                ALWAYS: function() {
                    return eV
                },
                C1: function() {
                    return j
                },
                DECIMAL_FIT: function() {
                    return eK
                },
                DECIMAL_ROUND: function() {
                    return eW
                },
                Decoder: function() {
                    return eg
                },
                Encoder: function() {
                    return eH
                },
                FLOAT32_OPTIONS: function() {
                    return ew
                },
                NEVER: function() {
                    return eF
                },
                Packr: function() {
                    return ej
                },
                RESERVE_START_SPACE: function() {
                    return eZ
                },
                RESET_BUFFER_MODE: function() {
                    return eJ
                },
                REUSE_BUFFER_MODE: function() {
                    return eq
                },
                Unpackr: function() {
                    return B
                },
                addExtension: function() {
                    return ex
                },
                clearSource: function() {
                    return ed
                },
                decode: function() {
                    return em
                },
                decodeIter: function() {
                    return e$
                },
                encode: function() {
                    return ez
                },
                encodeIter: function() {
                    return eX
                },
                isNativeAccelerationEnabled: function() {
                    return Z
                },
                mapsAsObjects: function() {
                    return e0
                },
                pack: function() {
                    return eN
                },
                roundFloat32: function() {
                    return eS
                },
                unpack: function() {
                    return ev
                },
                unpackMultiple: function() {
                    return eb
                },
                useRecords: function() {
                    return eQ
                }
            });
            var f, h, d, p, g, y, v, b, m, w, _, E = r(8620).Buffer;
            try {
                f = new TextDecoder
            } catch (e) {}
            var S = 0;
            let k = [];
            var O = k,
                A = 0,
                I = {},
                T = 0,
                P = 0,
                M = [],
                R = {
                    useRecords: !1,
                    mapsAsObjects: !0
                };
            class C {}
            let j = new C;
            j.name = "MessagePack 0xC1";
            var U = !1,
                D = 2;
            try {
                Function("")
            } catch (e) {
                D = 1 / 0
            }
            class B {
                unpack(e, t) {
                    if (h) return eh(() => (ed(), this ? this.unpack(e, t) : B.prototype.unpack.call(R, e, t)));
                    e.buffer || e.constructor !== ArrayBuffer || (e = void 0 !== E ? E.from(e) : new Uint8Array(e)), "object" == typeof t ? (d = t.end || e.length, S = t.start || 0) : (S = 0, d = t > -1 ? t : e.length), A = 0, P = 0, g = null, O = k, y = null, h = e;
                    try {
                        b = e.dataView || (e.dataView = new DataView(e.buffer, e.byteOffset, e.byteLength))
                    } catch (t) {
                        if (h = null, e instanceof Uint8Array) throw t;
                        throw Error("Source must be a Uint8Array or Buffer but was a " + (e && "object" == typeof e ? e.constructor.name : typeof e))
                    }
                    return this instanceof B ? (I = this, this.structures ? p = this.structures : (!p || p.length > 0) && (p = [])) : (I = R, (!p || p.length > 0) && (p = [])), x(t)
                }
                unpackMultiple(e, t) {
                    let r, n = 0;
                    try {
                        U = !0;
                        let o = e.length,
                            i = this ? this.unpack(e, o) : ey.unpack(e, o);
                        if (t) {
                            if (!1 === t(i, n, S)) return;
                            for (; S < o;)
                                if (n = S, !1 === t(x(), n, S)) return
                        } else {
                            for (r = [i]; S < o;) n = S, r.push(x());
                            return r
                        }
                    } catch (e) {
                        throw e.lastPosition = n, e.values = r, e
                    } finally {
                        U = !1, ed()
                    }
                }
                _mergeStructures(e, t) {
                    w && (e = w.call(this, e)), Object.isFrozen(e = e || []) && (e = e.map(e => e.slice(0)));
                    for (let t = 0, r = e.length; t < r; t++) {
                        let r = e[t];
                        r && (r.isShared = !0, t >= 32 && (r.highByte = t - 32 >> 5))
                    }
                    for (let r in e.sharedLength = e.length, t || [])
                        if (r >= 0) {
                            let n = e[r],
                                o = t[r];
                            o && (n && ((e.restoreStructures || (e.restoreStructures = []))[r] = n), e[r] = o)
                        }
                    return this.structures = e
                }
                decode(e, t) {
                    return this.unpack(e, t)
                }
                constructor(e) {
                    e && (!1 === e.useRecords && void 0 === e.mapsAsObjects && (e.mapsAsObjects = !0), !e.sequential || !1 === e.trusted || (e.trusted = !0, e.structures || !1 == e.useRecords || (e.structures = [], e.maxSharedStructures || (e.maxSharedStructures = 0))), e.structures ? e.structures.sharedLength = e.structures.length : e.getStructures && ((e.structures = []).uninitialized = !0, e.structures.sharedLength = 0), e.int64AsNumber && (e.int64AsType = "number")), Object.assign(this, e)
                }
            }

            function x(e) {
                try {
                    let t;
                    if (!I.trusted && !U) {
                        let e = p.sharedLength || 0;
                        e < p.length && (p.length = e)
                    }
                    if (I.randomAccessStructure && h[S] < 64 && h[S] >= 32 && m ? (t = m(h, S, d, I), h = null, !(e && e.lazy) && t && (t = t.toJSON()), S = d) : t = N(), y && (S = y.postBundlePosition, y = null), U && (p.restoreStructures = null), S == d) p && p.restoreStructures && L(), p = null, h = null, v && (v = null);
                    else if (S > d) throw Error("Unexpected end of MessagePack data");
                    else if (!U) {
                        let e;
                        try {
                            e = JSON.stringify(t, (e, t) => "bigint" == typeof t ? "".concat(t, "n") : t).slice(0, 100)
                        } catch (t) {
                            e = "(JSON view not available " + t + ")"
                        }
                        throw Error("Data read, but end of buffer not reached " + e)
                    }
                    return t
                } catch (e) {
                    throw p && p.restoreStructures && L(), ed(), (e instanceof RangeError || e.message.startsWith("Unexpected end of buffer") || S > d) && (e.incomplete = !0), e
                }
            }

            function L() {
                for (let e in p.restoreStructures) p[e] = p.restoreStructures[e];
                p.restoreStructures = null
            }

            function N() {
                let e = h[S++];
                if (e < 160) {
                    if (e < 128) {
                        if (e < 64) return e; {
                            let t = p[63 & e] || I.getStructures && V()[63 & e];
                            return t ? (t.read || (t.read = H(t, 63 & e)), t.read()) : e
                        }
                    }
                    if (e < 144) {
                        if (e -= 128, I.mapsAsObjects) {
                            let t = {};
                            for (let r = 0; r < e; r++) {
                                let e = ei();
                                "__proto__" === e && (e = "__proto_"), t[e] = N()
                            }
                            return t
                        } {
                            let t = new Map;
                            for (let r = 0; r < e; r++) t.set(N(), N());
                            return t
                        }
                    } {
                        let t = Array(e -= 144);
                        for (let r = 0; r < e; r++) t[r] = N();
                        return I.freezeData ? Object.freeze(t) : t
                    }
                }
                if (e < 192) {
                    let t = e - 160;
                    if (P >= S) return g.slice(S - T, (S += t) - T);
                    if (0 == P && d < 140) {
                        let e = t < 16 ? ee(t) : Q(t);
                        if (null != e) return e
                    }
                    return W(t)
                } {
                    let t;
                    switch (e) {
                        case 192:
                            return null;
                        case 193:
                            if (y) {
                                if ((t = N()) > 0) return y[1].slice(y.position1, y.position1 += t);
                                return y[0].slice(y.position0, y.position0 -= t)
                            }
                            return j;
                        case 194:
                            return !1;
                        case 195:
                            return !0;
                        case 196:
                            if (void 0 === (t = h[S++])) throw Error("Unexpected end of buffer");
                            return er(t);
                        case 197:
                            return t = b.getUint16(S), S += 2, er(t);
                        case 198:
                            return t = b.getUint32(S), S += 4, er(t);
                        case 199:
                            return en(h[S++]);
                        case 200:
                            return t = b.getUint16(S), S += 2, en(t);
                        case 201:
                            return t = b.getUint32(S), S += 4, en(t);
                        case 202:
                            if (t = b.getFloat32(S), I.useFloat32 > 2) {
                                let e = ep[(127 & h[S]) << 1 | h[S + 1] >> 7];
                                return S += 4, (e * t + (t > 0 ? .5 : -.5) >> 0) / e
                            }
                            return S += 4, t;
                        case 203:
                            return t = b.getFloat64(S), S += 8, t;
                        case 204:
                            return h[S++];
                        case 205:
                            return t = b.getUint16(S), S += 2, t;
                        case 206:
                            return t = b.getUint32(S), S += 4, t;
                        case 207:
                            return "number" === I.int64AsType ? t = 4294967296 * b.getUint32(S) + b.getUint32(S + 4) : "string" === I.int64AsType ? t = b.getBigUint64(S).toString() : "auto" === I.int64AsType ? (t = b.getBigUint64(S)) <= BigInt(2) << BigInt(52) && (t = Number(t)) : t = b.getBigUint64(S), S += 8, t;
                        case 208:
                            return b.getInt8(S++);
                        case 209:
                            return t = b.getInt16(S), S += 2, t;
                        case 210:
                            return t = b.getInt32(S), S += 4, t;
                        case 211:
                            return "number" === I.int64AsType ? t = 4294967296 * b.getInt32(S) + b.getUint32(S + 4) : "string" === I.int64AsType ? t = b.getBigInt64(S).toString() : "auto" === I.int64AsType ? (t = b.getBigInt64(S)) >= BigInt(-2) << BigInt(52) && t <= BigInt(2) << BigInt(52) && (t = Number(t)) : t = b.getBigInt64(S), S += 8, t;
                        case 212:
                            if (114 == (t = h[S++])) return ea(63 & h[S++]); {
                                let e = M[t];
                                if (e) {
                                    if (e.read) return S++, e.read(N());
                                    if (e.noBuffer) return S++, e();
                                    return e(h.subarray(S, ++S))
                                }
                                throw Error("Unknown extension " + t)
                            }
                        case 213:
                            if (114 == (t = h[S])) return S++, ea(63 & h[S++], h[S++]);
                            return en(2);
                        case 214:
                            return en(4);
                        case 215:
                            return en(8);
                        case 216:
                            return en(16);
                        case 217:
                            if (t = h[S++], P >= S) return g.slice(S - T, (S += t) - T);
                            return K(t);
                        case 218:
                            if (t = b.getUint16(S), S += 2, P >= S) return g.slice(S - T, (S += t) - T);
                            return q(t);
                        case 219:
                            if (t = b.getUint32(S), S += 4, P >= S) return g.slice(S - T, (S += t) - T);
                            return J(t);
                        case 220:
                            return t = b.getUint16(S), S += 2, Y(t);
                        case 221:
                            return t = b.getUint32(S), S += 4, Y(t);
                        case 222:
                            return t = b.getUint16(S), S += 2, $(t);
                        case 223:
                            return t = b.getUint32(S), S += 4, $(t);
                        default:
                            if (e >= 224) return e - 256;
                            if (void 0 === e) {
                                let e = Error("Unexpected end of MessagePack data");
                                throw e.incomplete = !0, e
                            }
                            throw Error("Unknown MessagePack token " + e)
                    }
                }
            }
            let z = /^[a-zA-Z_$][a-zA-Z\d_$]*$/;

            function H(e, t) {
                function r() {
                    if (r.count++ > D) {
                        let r = e.read = Function("r", "return function(){return " + (I.freezeData ? "Object.freeze" : "") + "({" + e.map(e => "__proto__" === e ? "__proto_:r()" : z.test(e) ? e + ":r()" : "[" + JSON.stringify(e) + "]:r()").join(",") + "})}")(N);
                        return 0 === e.highByte && (e.read = F(t, e.read)), r()
                    }
                    let n = {};
                    for (let t = 0, r = e.length; t < r; t++) {
                        let r = e[t];
                        "__proto__" === r && (r = "__proto_"), n[r] = N()
                    }
                    return I.freezeData ? Object.freeze(n) : n
                }
                return (r.count = 0, 0 === e.highByte) ? F(t, r) : r
            }
            let F = (e, t) => function() {
                let r = h[S++];
                if (0 === r) return t();
                let n = e < 32 ? -(e + (r << 5)) : e + (r << 5),
                    o = p[n] || V()[n];
                if (!o) throw Error("Record id is not defined for " + n);
                return o.read || (o.read = H(o, e)), o.read()
            };

            function V() {
                let e = eh(() => (h = null, I.getStructures()));
                return p = I._mergeStructures(e, p)
            }
            var W = G,
                K = G,
                q = G,
                J = G;
            let Z = !1;

            function G(e) {
                let t;
                if (e < 16 && (t = ee(e))) return t;
                if (e > 64 && f) return f.decode(h.subarray(S, S += e));
                let r = S + e,
                    n = [];
                for (t = ""; S < r;) {
                    let e = h[S++];
                    if ((128 & e) == 0) n.push(e);
                    else if ((224 & e) == 192) {
                        let t = 63 & h[S++];
                        n.push((31 & e) << 6 | t)
                    } else if ((240 & e) == 224) {
                        let t = 63 & h[S++],
                            r = 63 & h[S++];
                        n.push((31 & e) << 12 | t << 6 | r)
                    } else if ((248 & e) == 240) {
                        let t = (7 & e) << 18 | (63 & h[S++]) << 12 | (63 & h[S++]) << 6 | 63 & h[S++];
                        t > 65535 && (t -= 65536, n.push(t >>> 10 & 1023 | 55296), t = 56320 | 1023 & t), n.push(t)
                    } else n.push(e);
                    n.length >= 4096 && (t += X.apply(String, n), n.length = 0)
                }
                return n.length > 0 && (t += X.apply(String, n)), t
            }

            function Y(e) {
                let t = Array(e);
                for (let r = 0; r < e; r++) t[r] = N();
                return I.freezeData ? Object.freeze(t) : t
            }

            function $(e) {
                if (I.mapsAsObjects) {
                    let t = {};
                    for (let r = 0; r < e; r++) {
                        let e = ei();
                        "__proto__" === e && (e = "__proto_"), t[e] = N()
                    }
                    return t
                } {
                    let t = new Map;
                    for (let r = 0; r < e; r++) t.set(N(), N());
                    return t
                }
            }
            var X = String.fromCharCode;

            function Q(e) {
                let t = S,
                    r = Array(e);
                for (let n = 0; n < e; n++) {
                    let e = h[S++];
                    if ((128 & e) > 0) {
                        S = t;
                        return
                    }
                    r[n] = e
                }
                return X.apply(String, r)
            }

            function ee(e) {
                if (e < 4) {
                    if (e < 2) {
                        if (0 === e) return ""; {
                            let e = h[S++];
                            if ((128 & e) > 1) {
                                S -= 1;
                                return
                            }
                            return X(e)
                        }
                    } {
                        let t = h[S++],
                            r = h[S++];
                        if ((128 & t) > 0 || (128 & r) > 0) {
                            S -= 2;
                            return
                        }
                        if (e < 3) return X(t, r);
                        let n = h[S++];
                        if ((128 & n) > 0) {
                            S -= 3;
                            return
                        }
                        return X(t, r, n)
                    }
                } {
                    let t = h[S++],
                        r = h[S++],
                        n = h[S++],
                        o = h[S++];
                    if ((128 & t) > 0 || (128 & r) > 0 || (128 & n) > 0 || (128 & o) > 0) {
                        S -= 4;
                        return
                    }
                    if (e < 6) {
                        if (4 === e) return X(t, r, n, o); {
                            let e = h[S++];
                            if ((128 & e) > 0) {
                                S -= 5;
                                return
                            }
                            return X(t, r, n, o, e)
                        }
                    }
                    if (e < 8) {
                        let i = h[S++],
                            s = h[S++];
                        if ((128 & i) > 0 || (128 & s) > 0) {
                            S -= 6;
                            return
                        }
                        if (e < 7) return X(t, r, n, o, i, s);
                        let a = h[S++];
                        if ((128 & a) > 0) {
                            S -= 7;
                            return
                        }
                        return X(t, r, n, o, i, s, a)
                    } {
                        let i = h[S++],
                            s = h[S++],
                            a = h[S++],
                            c = h[S++];
                        if ((128 & i) > 0 || (128 & s) > 0 || (128 & a) > 0 || (128 & c) > 0) {
                            S -= 8;
                            return
                        }
                        if (e < 10) {
                            if (8 === e) return X(t, r, n, o, i, s, a, c); {
                                let e = h[S++];
                                if ((128 & e) > 0) {
                                    S -= 9;
                                    return
                                }
                                return X(t, r, n, o, i, s, a, c, e)
                            }
                        }
                        if (e < 12) {
                            let l = h[S++],
                                u = h[S++];
                            if ((128 & l) > 0 || (128 & u) > 0) {
                                S -= 10;
                                return
                            }
                            if (e < 11) return X(t, r, n, o, i, s, a, c, l, u);
                            let f = h[S++];
                            if ((128 & f) > 0) {
                                S -= 11;
                                return
                            }
                            return X(t, r, n, o, i, s, a, c, l, u, f)
                        } {
                            let l = h[S++],
                                u = h[S++],
                                f = h[S++],
                                d = h[S++];
                            if ((128 & l) > 0 || (128 & u) > 0 || (128 & f) > 0 || (128 & d) > 0) {
                                S -= 12;
                                return
                            }
                            if (e < 14) {
                                if (12 === e) return X(t, r, n, o, i, s, a, c, l, u, f, d); {
                                    let e = h[S++];
                                    if ((128 & e) > 0) {
                                        S -= 13;
                                        return
                                    }
                                    return X(t, r, n, o, i, s, a, c, l, u, f, d, e)
                                }
                            } {
                                let p = h[S++],
                                    g = h[S++];
                                if ((128 & p) > 0 || (128 & g) > 0) {
                                    S -= 14;
                                    return
                                }
                                if (e < 15) return X(t, r, n, o, i, s, a, c, l, u, f, d, p, g);
                                let y = h[S++];
                                if ((128 & y) > 0) {
                                    S -= 15;
                                    return
                                }
                                return X(t, r, n, o, i, s, a, c, l, u, f, d, p, g, y)
                            }
                        }
                    }
                }
            }

            function et() {
                let e, t = h[S++];
                if (t < 192) e = t - 160;
                else switch (t) {
                    case 217:
                        e = h[S++];
                        break;
                    case 218:
                        e = b.getUint16(S), S += 2;
                        break;
                    case 219:
                        e = b.getUint32(S), S += 4;
                        break;
                    default:
                        throw Error("Expected string")
                }
                return G(e)
            }

            function er(e) {
                return I.copyBuffers ? Uint8Array.prototype.slice.call(h, S, S += e) : h.subarray(S, S += e)
            }

            function en(e) {
                let t = h[S++];
                if (M[t]) {
                    let r;
                    return M[t](h.subarray(S, r = S += e), e => {
                        S = e;
                        try {
                            return N()
                        } finally {
                            S = r
                        }
                    })
                }
                throw Error("Unknown extension type " + t)
            }
            var eo = Array(4096);

            function ei() {
                let e, t = h[S++];
                if (!(t >= 160) || !(t < 192)) return S--, es(N());
                if (t -= 160, P >= S) return g.slice(S - T, (S += t) - T);
                if (!(0 == P && d < 180)) return W(t);
                let r = (t << 5 ^ (t > 1 ? b.getUint16(S) : t > 0 ? h[S] : 0)) & 4095,
                    n = eo[r],
                    o = S,
                    i = S + t - 3,
                    s = 0;
                if (n && n.bytes == t) {
                    for (; o < i;) {
                        if ((e = b.getUint32(o)) != n[s++]) {
                            o = 1879048192;
                            break
                        }
                        o += 4
                    }
                    for (i += 3; o < i;)
                        if ((e = h[o++]) != n[s++]) {
                            o = 1879048192;
                            break
                        }
                    if (o === i) return S = o, n.string;
                    i -= 3, o = S
                }
                for (n = [], eo[r] = n, n.bytes = t; o < i;) e = b.getUint32(o), n.push(e), o += 4;
                for (i += 3; o < i;) e = h[o++], n.push(e);
                let a = t < 16 ? ee(t) : Q(t);
                return null != a ? n.string = a : n.string = W(t)
            }

            function es(e) {
                if ("string" == typeof e) return e;
                if ("number" == typeof e || "boolean" == typeof e || "bigint" == typeof e) return e.toString();
                if (null == e) return e + "";
                if (I.allowArraysInMapKeys && Array.isArray(e) && e.flat().every(e => ["string", "number", "boolean", "bigint"].includes(typeof e))) return e.flat().toString();
                throw Error("Invalid property type for record: ".concat(typeof e))
            }
            let ea = (e, t) => {
                let r = N().map(es),
                    n = e;
                void 0 !== t && (e = e < 32 ? -((t << 5) + e) : (t << 5) + e, r.highByte = t);
                let o = p[e];
                return o && (o.isShared || U) && ((p.restoreStructures || (p.restoreStructures = []))[e] = o), p[e] = r, r.read = H(r, n), r.read()
            };
            M[0] = () => {}, M[0].noBuffer = !0, M[66] = e => {
                let t = e.length,
                    r = BigInt(128 & e[0] ? e[0] - 256 : e[0]);
                for (let n = 1; n < t; n++) r <<= BigInt(8), r += BigInt(e[n]);
                return r
            };
            let ec = {
                Error,
                TypeError,
                ReferenceError
            };
            M[101] = () => {
                let e = N();
                return (ec[e[0]] || Error)(e[1], {
                    cause: e[2]
                })
            }, M[105] = e => {
                let t;
                if (!1 === I.structuredClone) throw Error("Structured clone extension is disabled");
                let r = b.getUint32(S - 4);
                v || (v = new Map);
                let n = h[S],
                    o = {
                        target: t = n >= 144 && n < 160 || 220 == n || 221 == n ? [] : {}
                    };
                v.set(r, o);
                let i = N();
                return o.used ? Object.assign(t, i) : (o.target = i, i)
            }, M[112] = e => {
                if (!1 === I.structuredClone) throw Error("Structured clone extension is disabled");
                let t = b.getUint32(S - 4),
                    r = v.get(t);
                return r.used = !0, r.target
            }, M[115] = () => new Set(N());
            let el = ["Int8", "Uint8", "Uint8Clamped", "Int16", "Uint16", "Int32", "Uint32", "Float32", "Float64", "BigInt64", "BigUint64"].map(e => e + "Array"),
                eu = "object" == typeof globalThis ? globalThis : window;
            M[116] = e => {
                let t = e[0],
                    r = el[t];
                if (!r) {
                    if (16 === t) {
                        let t = new ArrayBuffer(e.length - 1);
                        return new Uint8Array(t).set(e.subarray(1)), t
                    }
                    throw Error("Could not find typed array for code " + t)
                }
                return new eu[r](Uint8Array.prototype.slice.call(e, 1).buffer)
            }, M[120] = () => {
                let e = N();
                return new RegExp(e[0], e[1])
            };
            let ef = [];

            function eh(e) {
                _ && _();
                let t = d,
                    r = S,
                    n = A,
                    o = T,
                    i = P,
                    s = g,
                    a = O,
                    c = v,
                    l = y,
                    u = new Uint8Array(h.slice(0, d)),
                    f = p,
                    m = p.slice(0, p.length),
                    w = I,
                    E = U,
                    k = e();
                return d = t, S = r, A = n, T = o, P = i, g = s, O = a, v = c, y = l, h = u, U = E, (p = f).splice(0, p.length, ...m), I = w, b = new DataView(h.buffer, h.byteOffset, h.byteLength), k
            }

            function ed() {
                h = null, v = null, p = null
            }
            M[98] = e => {
                let t = (e[0] << 24) + (e[1] << 16) + (e[2] << 8) + e[3],
                    r = S;
                return S += t - e.length, y = ef, (y = [et(), et()]).position0 = 0, y.position1 = 0, y.postBundlePosition = S, S = r, N()
            }, M[255] = e => new Date(4 == e.length ? (16777216 * e[0] + (e[1] << 16) + (e[2] << 8) + e[3]) * 1e3 : 8 == e.length ? ((e[0] << 22) + (e[1] << 14) + (e[2] << 6) + (e[3] >> 2)) / 1e6 + ((3 & e[3]) * 4294967296 + 16777216 * e[4] + (e[5] << 16) + (e[6] << 8) + e[7]) * 1e3 : 12 == e.length ? ((e[0] << 24) + (e[1] << 16) + (e[2] << 8) + e[3]) / 1e6 + ((128 & e[4] ? -281474976710656 : 0) + 1099511627776 * e[6] + 4294967296 * e[7] + 16777216 * e[8] + (e[9] << 16) + (e[10] << 8) + e[11]) * 1e3 : "invalid");
            let ep = Array(147);
            for (let e = 0; e < 256; e++) ep[e] = +("1e" + Math.floor(45.15 - .30103 * e));
            let eg = B;
            var ey = new B({
                useRecords: !1
            });
            let ev = ey.unpack,
                eb = ey.unpackMultiple,
                em = ey.unpack,
                ew = {
                    NEVER: 0,
                    ALWAYS: 1,
                    DECIMAL_ROUND: 3,
                    DECIMAL_FIT: 4
                },
                e_ = new Float32Array(1),
                eE = new Uint8Array(e_.buffer, 0, 4);

            function eS(e) {
                e_[0] = e;
                let t = ep[(127 & eE[3]) << 1 | eE[2] >> 7];
                return (t * e + (e > 0 ? .5 : -.5) >> 0) / t
            }
            var ek = r(8620).Buffer;
            try {
                n = new TextEncoder
            } catch (e) {}
            let eO = void 0 !== ek,
                eA = eO ? function(e) {
                    return ek.allocUnsafeSlow(e)
                } : Uint8Array,
                eI = eO ? ek : Uint8Array,
                eT = eO ? 4294967296 : 2144337920,
                eP = 0,
                eM = null,
                eR = /[\u0080-\uFFFF]/,
                eC = Symbol("record-id");
            class ej extends B {
                useBuffer(e) {
                    (s = e).dataView || (s.dataView = new DataView(s.buffer, s.byteOffset, s.byteLength)), eP = 0
                }
                set position(e) {
                    eP = e
                }
                get position() {
                    return eP
                }
                set buffer(e) {
                    s = e
                }
                get buffer() {
                    return s
                }
                clearSharedData() {
                    this.structures && (this.structures = []), this.typedStructs && (this.typedStructs = [])
                }
                constructor(e) {
                    let t, r, f, h;
                    super(e), this.offset = 0;
                    let d = eI.prototype.utf8Write ? function(e, t) {
                            return s.utf8Write(e, t, s.byteLength - t)
                        } : !!n && !!n.encodeInto && function(e, t) {
                            return n.encodeInto(e, s.subarray(t)).written
                        },
                        p = this;
                    e || (e = {});
                    let g = e && e.sequential,
                        y = e.structures || e.saveStructures,
                        v = e.maxSharedStructures;
                    if (null == v && (v = y ? 32 : 0), v > 8160) throw Error("Maximum maxSharedStructure is 8160");
                    e.structuredClone && void 0 == e.moreTypes && (this.moreTypes = !0);
                    let b = e.maxOwnStructures;
                    null == b && (b = y ? 32 : 64), this.structures || !1 == e.useRecords || (this.structures = []);
                    let m = v > 32 || b + v > 64,
                        w = v + 64,
                        _ = v + b + 64;
                    if (_ > 8256) throw Error("Maximum maxSharedStructure + maxOwnStructure is 8192");
                    let E = [],
                        S = 0,
                        k = 0;
                    this.pack = this.encode = function(e, n) {
                        let o;
                        if (s || (c = (s = new eA(8192)).dataView || (s.dataView = new DataView(s.buffer, 0, 8192)), eP = 0), (l = s.length - 10) - eP < 2048 ? (c = (s = new eA(s.length)).dataView || (s.dataView = new DataView(s.buffer, 0, s.length)), l = s.length - 10, eP = 0) : eP = eP + 7 & 2147483640, t = eP, n & eZ && (eP += 255 & n), h = p.structuredClone ? new Map : null, p.bundleStrings && "string" != typeof e ? (eM = []).size = 1 / 0 : eM = null, f = p.structures) {
                            f.uninitialized && (f = p._mergeStructures(p.getStructures()));
                            let e = f.sharedLength || 0;
                            if (e > v) throw Error("Shared structures is larger than maximum shared structures, try increasing maxSharedStructures to " + f.sharedLength);
                            if (!f.transitions) {
                                f.transitions = Object.create(null);
                                for (let t = 0; t < e; t++) {
                                    let e = f[t];
                                    if (!e) continue;
                                    let r, n = f.transitions;
                                    for (let t = 0, o = e.length; t < o; t++) {
                                        let o = e[t];
                                        (r = n[o]) || (r = n[o] = Object.create(null)), n = r
                                    }
                                    n[eC] = t + 64
                                }
                                this.lastNamedStructuresLength = e
                            }
                            g || (f.nextId = e + 64)
                        }
                        r && (r = !1);
                        try {
                            p.randomAccessStructure && e && e.constructor && e.constructor === Object ? D(e) : I(e);
                            let r = eM;
                            if (eM && eB(t, I, 0), h && h.idsToInsert) {
                                let e = h.idsToInsert.sort((e, t) => e.offset > t.offset ? 1 : -1),
                                    n = e.length,
                                    o = -1;
                                for (; r && n > 0;) {
                                    let i = e[--n].offset + t;
                                    i < r.stringsPosition + t && -1 === o && (o = 0), i > r.position + t ? o >= 0 && (o += 6) : (o >= 0 && (c.setUint32(r.position + t, c.getUint32(r.position + t) + o), o = -1), r = r.previous, n++)
                                }
                                o >= 0 && r && c.setUint32(r.position + t, c.getUint32(r.position + t) + o), (eP += 6 * e.length) > l && C(eP), p.offset = eP;
                                let i = function(e, t) {
                                    let r;
                                    let n = 6 * t.length,
                                        o = e.length - n;
                                    for (; r = t.pop();) {
                                        let t = r.offset,
                                            i = r.id;
                                        e.copyWithin(t + n, t, o);
                                        let s = t + (n -= 6);
                                        e[s++] = 214, e[s++] = 105, e[s++] = i >> 24, e[s++] = i >> 16 & 255, e[s++] = i >> 8 & 255, e[s++] = 255 & i, o = t
                                    }
                                    return e
                                }(s.subarray(t, eP), e);
                                return h = null, i
                            }
                            if (p.offset = eP, n & eq) return s.start = t, s.end = eP, s;
                            return s.subarray(t, eP)
                        } catch (e) {
                            throw o = e, e
                        } finally {
                            if (f && (O(), r && p.saveStructures)) {
                                var i;
                                let r = f.sharedLength || 0,
                                    a = s.subarray(t, eP),
                                    c = ((i = f).isCompatible = e => {
                                        let t = !e || (p.lastNamedStructuresLength || 0) === e.length;
                                        return t || p._mergeStructures(e), t
                                    }, i);
                                if (!o) {
                                    if (!1 === p.saveStructures(c, c.isCompatible)) return p.pack(e, n);
                                    return p.lastNamedStructuresLength = r, s.length > 1073741824 && (s = null), a
                                }
                            }
                            s.length > 1073741824 && (s = null), n & eJ && (eP = t)
                        }
                    };
                    let O = () => {
                            k < 10 && k++;
                            let e = f.sharedLength || 0;
                            if (f.length > e && !g && (f.length = e), S > 1e4) f.transitions = null, k = 0, S = 0, E.length > 0 && (E = []);
                            else if (E.length > 0 && !g) {
                                for (let e = 0, t = E.length; e < t; e++) E[e][eC] = 0;
                                E = []
                            }
                        },
                        A = e => {
                            var t = e.length;
                            t < 16 ? s[eP++] = 144 | t : t < 65536 ? (s[eP++] = 220, s[eP++] = t >> 8, s[eP++] = 255 & t) : (s[eP++] = 221, c.setUint32(eP, t), eP += 4);
                            for (let r = 0; r < t; r++) I(e[r])
                        },
                        I = e => {
                            eP > l && (s = C(eP));
                            var r, n = typeof e;
                            if ("string" === n) {
                                let n, o = e.length;
                                if (eM && o >= 4 && o < 4096) {
                                    if ((eM.size += o) > 21760) {
                                        let e, r;
                                        let n = (eM[0] ? 3 * eM[0].length + eM[1].length : 0) + 10;
                                        eP + n > l && (s = C(eP + n)), eM.position ? (r = eM, s[eP] = 200, eP += 3, s[eP++] = 98, e = eP - t, eP += 4, eB(t, I, 0), c.setUint16(e + t - 3, eP - t - e)) : (s[eP++] = 214, s[eP++] = 98, e = eP - t, eP += 4), (eM = ["", ""]).previous = r, eM.size = 0, eM.position = e
                                    }
                                    let r = eR.test(e);
                                    eM[r ? 0 : 1] += e, s[eP++] = 193, I(r ? -o : o);
                                    return
                                }
                                n = o < 32 ? 1 : o < 256 ? 2 : o < 65536 ? 3 : 5;
                                let i = 3 * o;
                                if (eP + i > l && (s = C(eP + i)), o < 64 || !d) {
                                    let t, i, a, c = eP + n;
                                    for (t = 0; t < o; t++)(i = e.charCodeAt(t)) < 128 ? s[c++] = i : (i < 2048 ? s[c++] = i >> 6 | 192 : ((64512 & i) == 55296 && (64512 & (a = e.charCodeAt(t + 1))) == 56320 ? (i = 65536 + ((1023 & i) << 10) + (1023 & a), t++, s[c++] = i >> 18 | 240, s[c++] = i >> 12 & 63 | 128) : s[c++] = i >> 12 | 224, s[c++] = i >> 6 & 63 | 128), s[c++] = 63 & i | 128);
                                    r = c - eP - n
                                } else r = d(e, eP + n);
                                r < 32 ? s[eP++] = 160 | r : r < 256 ? (n < 2 && s.copyWithin(eP + 2, eP + 1, eP + 1 + r), s[eP++] = 217, s[eP++] = r) : r < 65536 ? (n < 3 && s.copyWithin(eP + 3, eP + 2, eP + 2 + r), s[eP++] = 218, s[eP++] = r >> 8, s[eP++] = 255 & r) : (n < 5 && s.copyWithin(eP + 5, eP + 3, eP + 3 + r), s[eP++] = 219, c.setUint32(eP, r), eP += 4), eP += r
                            } else if ("number" === n) {
                                if (e >>> 0 === e) e < 32 || e < 128 && !1 === this.useRecords || e < 64 && !this.randomAccessStructure ? s[eP++] = e : e < 256 ? (s[eP++] = 204, s[eP++] = e) : e < 65536 ? (s[eP++] = 205, s[eP++] = e >> 8, s[eP++] = 255 & e) : (s[eP++] = 206, c.setUint32(eP, e), eP += 4);
                                else if (e >> 0 === e) e >= -32 ? s[eP++] = 256 + e : e >= -128 ? (s[eP++] = 208, s[eP++] = e + 256) : e >= -32768 ? (s[eP++] = 209, c.setInt16(eP, e), eP += 2) : (s[eP++] = 210, c.setInt32(eP, e), eP += 4);
                                else {
                                    let t;
                                    if ((t = this.useFloat32) > 0 && e < 4294967296 && e >= -2147483648) {
                                        let r;
                                        if (s[eP++] = 202, c.setFloat32(eP, e), t < 4 || (r = e * ep[(127 & s[eP]) << 1 | s[eP + 1] >> 7]) >> 0 === r) {
                                            eP += 4;
                                            return
                                        }
                                        eP--
                                    }
                                    s[eP++] = 203, c.setFloat64(eP, e), eP += 8
                                }
                            } else if ("object" === n || "function" === n) {
                                if (e) {
                                    if (h) {
                                        let r = h.get(e);
                                        if (r) {
                                            if (!r.id) {
                                                let e = h.idsToInsert || (h.idsToInsert = []);
                                                r.id = e.push(r)
                                            }
                                            s[eP++] = 214, s[eP++] = 112, c.setUint32(eP, r.id), eP += 4;
                                            return
                                        }
                                        h.set(e, {
                                            offset: eP - t
                                        })
                                    }
                                    let a = e.constructor;
                                    if (a === Object) R(e);
                                    else if (a === Array) A(e);
                                    else if (a === Map) {
                                        if (this.mapAsEmptyObject) s[eP++] = 128;
                                        else
                                            for (let [t, n] of ((r = e.size) < 16 ? s[eP++] = 128 | r : r < 65536 ? (s[eP++] = 222, s[eP++] = r >> 8, s[eP++] = 255 & r) : (s[eP++] = 223, c.setUint32(eP, r), eP += 4), e)) I(t), I(n)
                                    } else {
                                        for (let t = 0, r = o.length; t < r; t++)
                                            if (e instanceof i[t]) {
                                                let r, n = o[t];
                                                if (n.write) {
                                                    n.type && (s[eP++] = 212, s[eP++] = n.type, s[eP++] = 0);
                                                    let t = n.write.call(this, e);
                                                    t === e ? Array.isArray(e) ? A(e) : R(e) : I(t);
                                                    return
                                                }
                                                let i = s,
                                                    a = c,
                                                    u = eP;
                                                s = null;
                                                try {
                                                    r = n.pack.call(this, e, e => (s = i, i = null, (eP += e) > l && C(eP), {
                                                        target: s,
                                                        targetView: c,
                                                        position: eP - e
                                                    }), I)
                                                } finally {
                                                    i && (s = i, c = a, eP = u, l = s.length - 10)
                                                }
                                                r && (r.length + eP > l && C(r.length + eP), eP = function(e, t, r, n) {
                                                    let o = e.length;
                                                    switch (o) {
                                                        case 1:
                                                            t[r++] = 212;
                                                            break;
                                                        case 2:
                                                            t[r++] = 213;
                                                            break;
                                                        case 4:
                                                            t[r++] = 214;
                                                            break;
                                                        case 8:
                                                            t[r++] = 215;
                                                            break;
                                                        case 16:
                                                            t[r++] = 216;
                                                            break;
                                                        default:
                                                            o < 256 ? (t[r++] = 199, t[r++] = o) : (o < 65536 ? (t[r++] = 200, t[r++] = o >> 8) : (t[r++] = 201, t[r++] = o >> 24, t[r++] = o >> 16 & 255, t[r++] = o >> 8 & 255), t[r++] = 255 & o)
                                                    }
                                                    return t[r++] = n, t.set(e, r), r += o
                                                }(r, s, eP, n.type));
                                                return
                                            }
                                        if (Array.isArray(e)) A(e);
                                        else {
                                            if (e.toJSON) {
                                                let t = e.toJSON();
                                                if (t !== e) return I(t)
                                            }
                                            if ("function" === n) return I(this.writeFunction && this.writeFunction(e));
                                            R(e)
                                        }
                                    }
                                } else s[eP++] = 192
                            } else if ("boolean" === n) s[eP++] = e ? 195 : 194;
                            else if ("bigint" === n) {
                                if (e < BigInt(1) << BigInt(63) && e >= -(BigInt(1) << BigInt(63))) s[eP++] = 211, c.setBigInt64(eP, e);
                                else if (e < BigInt(1) << BigInt(64) && e > 0) s[eP++] = 207, c.setBigUint64(eP, e);
                                else if (this.largeBigIntToFloat) s[eP++] = 203, c.setFloat64(eP, Number(e));
                                else if (this.largeBigIntToString) return I(e.toString());
                                else if (this.useBigIntExtension && e < BigInt(2) ** BigInt(1023) && e > -(BigInt(2) ** BigInt(1023))) {
                                    let t;
                                    s[eP++] = 199, eP++, s[eP++] = 66;
                                    let r = [];
                                    do {
                                        let n = e & BigInt(255);
                                        t = (n & BigInt(128)) === (e < BigInt(0) ? BigInt(128) : BigInt(0)), r.push(n), e >>= BigInt(8)
                                    } while (!((e === BigInt(0) || e === BigInt(-1)) && t));
                                    s[eP - 2] = r.length;
                                    for (let e = r.length; e > 0;) s[eP++] = Number(r[--e]);
                                    return
                                } else throw RangeError(e + " was too large to fit in MessagePack 64-bit integer format, use useBigIntExtension, or set largeBigIntToFloat to convert to float-64, or set largeBigIntToString to convert to string");
                                eP += 8
                            } else if ("undefined" === n) this.encodeUndefinedAsNil ? s[eP++] = 192 : (s[eP++] = 212, s[eP++] = 0, s[eP++] = 0);
                            else throw Error("Unknown type: " + n)
                        },
                        T = this.variableMapSize || this.coercibleKeyAsNumber || this.skipValues ? e => {
                            let t, r;
                            if (this.skipValues)
                                for (let r in t = [], e)("function" != typeof e.hasOwnProperty || e.hasOwnProperty(r)) && !this.skipValues.includes(e[r]) && t.push(r);
                            else t = Object.keys(e);
                            let n = t.length;
                            if (n < 16 ? s[eP++] = 128 | n : n < 65536 ? (s[eP++] = 222, s[eP++] = n >> 8, s[eP++] = 255 & n) : (s[eP++] = 223, c.setUint32(eP, n), eP += 4), this.coercibleKeyAsNumber)
                                for (let o = 0; o < n; o++) {
                                    let n = Number(r = t[o]);
                                    I(isNaN(n) ? r : n), I(e[r])
                                } else
                                    for (let o = 0; o < n; o++) I(r = t[o]), I(e[r])
                        } : e => {
                            s[eP++] = 222;
                            let r = eP - t;
                            eP += 2;
                            let n = 0;
                            for (let t in e)("function" != typeof e.hasOwnProperty || e.hasOwnProperty(t)) && (I(t), I(e[t]), n++);
                            if (n > 65535) throw Error('Object is too large to serialize with fast 16-bit map size, use the "variableMapSize" option to serialize this object');
                            s[r++ + t] = n >> 8, s[r + t] = 255 & n
                        },
                        P = !1 === this.useRecords ? T : e.progressiveRecords && !m ? e => {
                            let r, n, o = f.transitions || (f.transitions = Object.create(null)),
                                i = eP++ - t;
                            for (let s in e)
                                if ("function" != typeof e.hasOwnProperty || e.hasOwnProperty(s)) {
                                    if (n = o[s]) o = n;
                                    else {
                                        let a = Object.keys(e),
                                            c = o;
                                        o = f.transitions;
                                        let l = 0;
                                        for (let e = 0, t = a.length; e < t; e++) {
                                            let t = a[e];
                                            !(n = o[t]) && (n = o[t] = Object.create(null), l++), o = n
                                        }
                                        i + t + 1 == eP ? (eP--, j(o, a, l)) : U(o, a, i, l), r = !0, o = c[s]
                                    }
                                    I(e[s])
                                }
                            if (!r) {
                                let r = o[eC];
                                r ? s[i + t] = r : U(o, Object.keys(e), i, 0)
                            }
                        } : e => {
                            let t, r = f.transitions || (f.transitions = Object.create(null)),
                                n = 0;
                            for (let o in e)("function" != typeof e.hasOwnProperty || e.hasOwnProperty(o)) && (!(t = r[o]) && (t = r[o] = Object.create(null), n++), r = t);
                            let o = r[eC];
                            for (let t in o ? o >= 96 && m ? (s[eP++] = (31 & (o -= 96)) + 96, s[eP++] = o >> 5) : s[eP++] = o : j(r, r.__keys__ || Object.keys(e), n), e)("function" != typeof e.hasOwnProperty || e.hasOwnProperty(t)) && I(e[t])
                        },
                        M = "function" == typeof this.useRecords && this.useRecords,
                        R = M ? e => {
                            M(e) ? P(e) : T(e)
                        } : P,
                        C = e => {
                            let r;
                            if (e > 16777216) {
                                if (e - t > eT) throw Error("Packed buffer would be larger than maximum buffer size");
                                r = Math.min(eT, 4096 * Math.round(Math.max((e - t) * (e > 67108864 ? 1.25 : 2), 4194304) / 4096))
                            } else r = (Math.max(e - t << 2, s.length - 1) >> 12) + 1 << 12;
                            let n = new eA(r);
                            return c = n.dataView || (n.dataView = new DataView(n.buffer, 0, r)), e = Math.min(e, s.length), s.copy ? s.copy(n, 0, t, e) : n.set(s.slice(t, e)), eP -= t, t = 0, l = n.length - 10, s = n
                        },
                        j = (e, t, n) => {
                            let o = f.nextId;
                            o || (o = 64), o < w && this.shouldShareStructure && !this.shouldShareStructure(t) ? ((o = f.nextOwnId) < _ || (o = w), f.nextOwnId = o + 1) : (o >= _ && (o = w), f.nextId = o + 1);
                            let i = t.highByte = o >= 96 && m ? o - 96 >> 5 : -1;
                            e[eC] = o, e.__keys__ = t, f[o - 64] = t, o < w ? (t.isShared = !0, f.sharedLength = o - 63, r = !0, i >= 0 ? (s[eP++] = (31 & o) + 96, s[eP++] = i) : s[eP++] = o) : (i >= 0 ? (s[eP++] = 213, s[eP++] = 114, s[eP++] = (31 & o) + 96, s[eP++] = i) : (s[eP++] = 212, s[eP++] = 114, s[eP++] = o), n && (S += k * n), E.length >= b && (E.shift()[eC] = 0), E.push(e), I(t))
                        },
                        U = (e, r, n, o) => {
                            let i = s,
                                c = eP,
                                u = l,
                                f = t;
                            eP = 0, t = 0, (s = a) || (a = s = new eA(8192)), l = s.length - 10, j(e, r, o), a = s;
                            let h = eP;
                            if (s = i, eP = c, l = u, t = f, h > 1) {
                                let e = eP + h - 1;
                                e > l && C(e);
                                let r = n + t;
                                s.copyWithin(r + h, r + 1, eP), s.set(a.slice(0, h), r), eP = e
                            } else s[n + t] = a[0]
                        },
                        D = e => {
                            let n = u(e, s, t, eP, f, C, (e, t, n) => {
                                if (n) return r = !0;
                                eP = t;
                                let o = s;
                                return (I(e), O(), o !== s) ? {
                                    position: eP,
                                    targetView: c,
                                    target: s
                                } : eP
                            }, this);
                            if (0 === n) return R(e);
                            eP = n
                        }
                }
            }

            function eU(e, t, r, n) {
                let o = e.byteLength;
                if (o + 1 < 256) {
                    var {
                        target: i,
                        position: s
                    } = r(4 + o);
                    i[s++] = 199, i[s++] = o + 1
                } else if (o + 1 < 65536) {
                    var {
                        target: i,
                        position: s
                    } = r(5 + o);
                    i[s++] = 200, i[s++] = o + 1 >> 8, i[s++] = o + 1 & 255
                } else {
                    var {
                        target: i,
                        position: s,
                        targetView: a
                    } = r(7 + o);
                    i[s++] = 201, a.setUint32(s, o + 1), s += 4
                }
                i[s++] = 116, i[s++] = t, e.buffer || (e = new Uint8Array(e)), i.set(new Uint8Array(e.buffer, e.byteOffset, e.byteLength), s)
            }

            function eD(e, t) {
                let r = e.byteLength;
                if (r < 256) {
                    var n, o, {
                        target: n,
                        position: o
                    } = t(r + 2);
                    n[o++] = 196, n[o++] = r
                } else if (r < 65536) {
                    var {
                        target: n,
                        position: o
                    } = t(r + 3);
                    n[o++] = 197, n[o++] = r >> 8, n[o++] = 255 & r
                } else {
                    var {
                        target: n,
                        position: o,
                        targetView: i
                    } = t(r + 5);
                    n[o++] = 198, i.setUint32(o, r), o += 4
                }
                n.set(e, o)
            }

            function eB(e, t, r) {
                if (eM.length > 0) {
                    c.setUint32(eM.position + e, eP + r - eM.position - e), eM.stringsPosition = eP - e;
                    let n = eM;
                    eM = null, t(n[0]), t(n[1])
                }
            }

            function ex(e) {
                if (e.Class) {
                    if (!e.pack && !e.write) throw Error("Extension has no pack or write function");
                    if (e.pack && !e.type) throw Error("Extension has no type (numeric code to identify the extension)");
                    i.unshift(e.Class), o.unshift(e)
                }
                e.unpack ? M[e.type] = e.unpack : M[e.type] = e
            }
            i = [Date, Set, Error, RegExp, ArrayBuffer, Object.getPrototypeOf(Uint8Array.prototype).constructor, C], o = [{
                pack(e, t, r) {
                    let n = e.getTime() / 1e3;
                    if ((this.useTimestamp32 || 0 === e.getMilliseconds()) && n >= 0 && n < 4294967296) {
                        let {
                            target: e,
                            targetView: r,
                            position: o
                        } = t(6);
                        e[o++] = 214, e[o++] = 255, r.setUint32(o, n)
                    } else if (n > 0 && n < 4294967296) {
                        let {
                            target: r,
                            targetView: o,
                            position: i
                        } = t(10);
                        r[i++] = 215, r[i++] = 255, o.setUint32(i, 4e6 * e.getMilliseconds() + (n / 1e3 / 4294967296 >> 0)), o.setUint32(i + 4, n)
                    } else if (isNaN(n)) {
                        if (this.onInvalidDate) return t(0), r(this.onInvalidDate());
                        let {
                            target: e,
                            targetView: n,
                            position: o
                        } = t(3);
                        e[o++] = 212, e[o++] = 255, e[o++] = 255
                    } else {
                        let {
                            target: r,
                            targetView: o,
                            position: i
                        } = t(15);
                        r[i++] = 199, r[i++] = 12, r[i++] = 255, o.setUint32(i, 1e6 * e.getMilliseconds()), o.setBigInt64(i + 4, BigInt(Math.floor(n)))
                    }
                }
            }, {
                pack(e, t, r) {
                    if (this.setAsEmptyObject) return t(0), r({});
                    let n = Array.from(e),
                        {
                            target: o,
                            position: i
                        } = t(this.moreTypes ? 3 : 0);
                    this.moreTypes && (o[i++] = 212, o[i++] = 115, o[i++] = 0), r(n)
                }
            }, {
                pack(e, t, r) {
                    let {
                        target: n,
                        position: o
                    } = t(this.moreTypes ? 3 : 0);
                    this.moreTypes && (n[o++] = 212, n[o++] = 101, n[o++] = 0), r([e.name, e.message, e.cause])
                }
            }, {
                pack(e, t, r) {
                    let {
                        target: n,
                        position: o
                    } = t(this.moreTypes ? 3 : 0);
                    this.moreTypes && (n[o++] = 212, n[o++] = 120, n[o++] = 0), r([e.source, e.flags])
                }
            }, {
                pack(e, t) {
                    this.moreTypes ? eU(e, 16, t) : eD(eO ? ek.from(e) : new Uint8Array(e), t)
                }
            }, {
                pack(e, t) {
                    let r = e.constructor;
                    r !== eI && this.moreTypes ? eU(e, el.indexOf(r.name), t) : eD(e, t)
                }
            }, {
                pack(e, t) {
                    let {
                        target: r,
                        position: n
                    } = t(1);
                    r[n] = 193
                }
            }];
            let eL = new ej({
                    useRecords: !1
                }),
                eN = eL.pack,
                ez = eL.pack,
                eH = ej,
                {
                    NEVER: eF,
                    ALWAYS: eV,
                    DECIMAL_ROUND: eW,
                    DECIMAL_FIT: eK
                } = ew,
                eq = 512,
                eJ = 1024,
                eZ = 2048;
            var eG = r(8620).Buffer;
            async function* eY(e, t) {
                let r = new ej(t);
                for await (let t of e) yield r.pack(t)
            }
            let e$ = function(e) {
                    let t, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    if (!e || "object" != typeof e) throw Error("first argument must be an Iterable, Async Iterable, Iterator, Async Iterator, or a promise");
                    let n = new B(r),
                        o = e => {
                            let r;
                            t && (e = eG.concat([t, e]), t = void 0);
                            try {
                                r = n.unpackMultiple(e)
                            } catch (n) {
                                if (n.incomplete) t = e.slice(n.lastPosition), r = n.values;
                                else throw n
                            }
                            return r
                        };
                    return "function" == typeof e[Symbol.iterator] ? function*() {
                        for (let t of e) yield* o(t)
                    }() : "function" == typeof e[Symbol.asyncIterator] ? async function*() {
                        for await (let t of e) yield* o(t)
                    }() : void 0
                },
                eX = function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    if (e && "object" == typeof e) {
                        if ("function" == typeof e[Symbol.iterator]) return function*(e, t) {
                            let r = new ej(t);
                            for (let t of e) yield r.pack(t)
                        }(e, t);
                        if ("function" == typeof e.then || "function" == typeof e[Symbol.asyncIterator]) return eY(e, t);
                        throw Error("first argument must be an Iterable, Async Iterable, Iterator, Async Iterator, or a Promise")
                    }
                    throw Error("first argument must be an Iterable, Async Iterable, or a Promise for an Async Iterable")
                },
                eQ = !1,
                e0 = !0
        },
        69703: function(e, t, r) {
            r.r(t), r.d(t, {
                __addDisposableResource: function() {
                    return D
                },
                __assign: function() {
                    return i
                },
                __asyncDelegator: function() {
                    return O
                },
                __asyncGenerator: function() {
                    return k
                },
                __asyncValues: function() {
                    return A
                },
                __await: function() {
                    return S
                },
                __awaiter: function() {
                    return p
                },
                __classPrivateFieldGet: function() {
                    return C
                },
                __classPrivateFieldIn: function() {
                    return U
                },
                __classPrivateFieldSet: function() {
                    return j
                },
                __createBinding: function() {
                    return y
                },
                __decorate: function() {
                    return a
                },
                __disposeResources: function() {
                    return x
                },
                __esDecorate: function() {
                    return l
                },
                __exportStar: function() {
                    return v
                },
                __extends: function() {
                    return o
                },
                __generator: function() {
                    return g
                },
                __importDefault: function() {
                    return R
                },
                __importStar: function() {
                    return M
                },
                __makeTemplateObject: function() {
                    return I
                },
                __metadata: function() {
                    return d
                },
                __param: function() {
                    return c
                },
                __propKey: function() {
                    return f
                },
                __read: function() {
                    return m
                },
                __rest: function() {
                    return s
                },
                __rewriteRelativeImportExtension: function() {
                    return L
                },
                __runInitializers: function() {
                    return u
                },
                __setFunctionName: function() {
                    return h
                },
                __spread: function() {
                    return w
                },
                __spreadArray: function() {
                    return E
                },
                __spreadArrays: function() {
                    return _
                },
                __values: function() {
                    return b
                }
            });
            var n = function(e, t) {
                return (n = Object.setPrototypeOf || ({
                    __proto__: []
                }) instanceof Array && function(e, t) {
                    e.__proto__ = t
                } || function(e, t) {
                    for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                })(e, t)
            };

            function o(e, t) {
                if ("function" != typeof t && null !== t) throw TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function r() {
                    this.constructor = e
                }
                n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
            }
            var i = function() {
                return (i = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++)
                        for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            };

            function s(e, t) {
                var r = {};
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && 0 > t.indexOf(n) && (r[n] = e[n]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var o = 0, n = Object.getOwnPropertySymbols(e); o < n.length; o++) 0 > t.indexOf(n[o]) && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]]);
                return r
            }

            function a(e, t, r, n) {
                var o, i = arguments.length,
                    s = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n);
                else
                    for (var a = e.length - 1; a >= 0; a--)(o = e[a]) && (s = (i < 3 ? o(s) : i > 3 ? o(t, r, s) : o(t, r)) || s);
                return i > 3 && s && Object.defineProperty(t, r, s), s
            }

            function c(e, t) {
                return function(r, n) {
                    t(r, n, e)
                }
            }

            function l(e, t, r, n, o, i) {
                function s(e) {
                    if (void 0 !== e && "function" != typeof e) throw TypeError("Function expected");
                    return e
                }
                for (var a, c = n.kind, l = "getter" === c ? "get" : "setter" === c ? "set" : "value", u = !t && e ? n.static ? e : e.prototype : null, f = t || (u ? Object.getOwnPropertyDescriptor(u, n.name) : {}), h = !1, d = r.length - 1; d >= 0; d--) {
                    var p = {};
                    for (var g in n) p[g] = "access" === g ? {} : n[g];
                    for (var g in n.access) p.access[g] = n.access[g];
                    p.addInitializer = function(e) {
                        if (h) throw TypeError("Cannot add initializers after decoration has completed");
                        i.push(s(e || null))
                    };
                    var y = (0, r[d])("accessor" === c ? {
                        get: f.get,
                        set: f.set
                    } : f[l], p);
                    if ("accessor" === c) {
                        if (void 0 === y) continue;
                        if (null === y || "object" != typeof y) throw TypeError("Object expected");
                        (a = s(y.get)) && (f.get = a), (a = s(y.set)) && (f.set = a), (a = s(y.init)) && o.unshift(a)
                    } else(a = s(y)) && ("field" === c ? o.unshift(a) : f[l] = a)
                }
                u && Object.defineProperty(u, n.name, f), h = !0
            }

            function u(e, t, r) {
                for (var n = arguments.length > 2, o = 0; o < t.length; o++) r = n ? t[o].call(e, r) : t[o].call(e);
                return n ? r : void 0
            }

            function f(e) {
                return "symbol" == typeof e ? e : "".concat(e)
            }

            function h(e, t, r) {
                return "symbol" == typeof t && (t = t.description ? "[".concat(t.description, "]") : ""), Object.defineProperty(e, "name", {
                    configurable: !0,
                    value: r ? "".concat(r, " ", t) : t
                })
            }

            function d(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t)
            }

            function p(e, t, r, n) {
                return new(r || (r = Promise))(function(o, i) {
                    function s(e) {
                        try {
                            c(n.next(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function a(e) {
                        try {
                            c(n.throw(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function c(e) {
                        var t;
                        e.done ? o(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                            e(t)
                        })).then(s, a)
                    }
                    c((n = n.apply(e, t || [])).next())
                })
            }

            function g(e, t) {
                var r, n, o, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    },
                    s = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                return s.next = a(0), s.throw = a(1), s.return = a(2), "function" == typeof Symbol && (s[Symbol.iterator] = function() {
                    return this
                }), s;

                function a(a) {
                    return function(c) {
                        return function(a) {
                            if (r) throw TypeError("Generator is already executing.");
                            for (; s && (s = 0, a[0] && (i = 0)), i;) try {
                                if (r = 1, n && (o = 2 & a[0] ? n.return : a[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, a[1])).done) return o;
                                switch (n = 0, o && (a = [2 & a[0], o.value]), a[0]) {
                                    case 0:
                                    case 1:
                                        o = a;
                                        break;
                                    case 4:
                                        return i.label++, {
                                            value: a[1],
                                            done: !1
                                        };
                                    case 5:
                                        i.label++, n = a[1], a = [0];
                                        continue;
                                    case 7:
                                        a = i.ops.pop(), i.trys.pop();
                                        continue;
                                    default:
                                        if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === a[0] || 2 === a[0])) {
                                            i = 0;
                                            continue
                                        }
                                        if (3 === a[0] && (!o || a[1] > o[0] && a[1] < o[3])) {
                                            i.label = a[1];
                                            break
                                        }
                                        if (6 === a[0] && i.label < o[1]) {
                                            i.label = o[1], o = a;
                                            break
                                        }
                                        if (o && i.label < o[2]) {
                                            i.label = o[2], i.ops.push(a);
                                            break
                                        }
                                        o[2] && i.ops.pop(), i.trys.pop();
                                        continue
                                }
                                a = t.call(e, i)
                            } catch (e) {
                                a = [6, e], n = 0
                            } finally {
                                r = o = 0
                            }
                            if (5 & a[0]) throw a[1];
                            return {
                                value: a[0] ? a[1] : void 0,
                                done: !0
                            }
                        }([a, c])
                    }
                }
            }
            var y = Object.create ? function(e, t, r, n) {
                void 0 === n && (n = r);
                var o = Object.getOwnPropertyDescriptor(t, r);
                (!o || ("get" in o ? !t.__esModule : o.writable || o.configurable)) && (o = {
                    enumerable: !0,
                    get: function() {
                        return t[r]
                    }
                }), Object.defineProperty(e, n, o)
            } : function(e, t, r, n) {
                void 0 === n && (n = r), e[n] = t[r]
            };

            function v(e, t) {
                for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || y(t, e, r)
            }

            function b(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    r = t && e[t],
                    n = 0;
                if (r) return r.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && n >= e.length && (e = void 0), {
                            value: e && e[n++],
                            done: !e
                        }
                    }
                };
                throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }

            function m(e, t) {
                var r = "function" == typeof Symbol && e[Symbol.iterator];
                if (!r) return e;
                var n, o, i = r.call(e),
                    s = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(n = i.next()).done;) s.push(n.value)
                } catch (e) {
                    o = {
                        error: e
                    }
                } finally {
                    try {
                        n && !n.done && (r = i.return) && r.call(i)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return s
            }

            function w() {
                for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(m(arguments[t]));
                return e
            }

            function _() {
                for (var e = 0, t = 0, r = arguments.length; t < r; t++) e += arguments[t].length;
                for (var n = Array(e), o = 0, t = 0; t < r; t++)
                    for (var i = arguments[t], s = 0, a = i.length; s < a; s++, o++) n[o] = i[s];
                return n
            }

            function E(e, t, r) {
                if (r || 2 == arguments.length)
                    for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), n[o] = t[o]);
                return e.concat(n || Array.prototype.slice.call(t))
            }

            function S(e) {
                return this instanceof S ? (this.v = e, this) : new S(e)
            }

            function k(e, t, r) {
                if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
                var n, o = r.apply(e, t || []),
                    i = [];
                return n = Object.create(("function" == typeof AsyncIterator ? AsyncIterator : Object).prototype), s("next"), s("throw"), s("return", function(e) {
                    return function(t) {
                        return Promise.resolve(t).then(e, l)
                    }
                }), n[Symbol.asyncIterator] = function() {
                    return this
                }, n;

                function s(e, t) {
                    o[e] && (n[e] = function(t) {
                        return new Promise(function(r, n) {
                            i.push([e, t, r, n]) > 1 || a(e, t)
                        })
                    }, t && (n[e] = t(n[e])))
                }

                function a(e, t) {
                    try {
                        var r;
                        (r = o[e](t)).value instanceof S ? Promise.resolve(r.value.v).then(c, l) : u(i[0][2], r)
                    } catch (e) {
                        u(i[0][3], e)
                    }
                }

                function c(e) {
                    a("next", e)
                }

                function l(e) {
                    a("throw", e)
                }

                function u(e, t) {
                    e(t), i.shift(), i.length && a(i[0][0], i[0][1])
                }
            }

            function O(e) {
                var t, r;
                return t = {}, n("next"), n("throw", function(e) {
                    throw e
                }), n("return"), t[Symbol.iterator] = function() {
                    return this
                }, t;

                function n(n, o) {
                    t[n] = e[n] ? function(t) {
                        return (r = !r) ? {
                            value: S(e[n](t)),
                            done: !1
                        } : o ? o(t) : t
                    } : o
                }
            }

            function A(e) {
                if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
                var t, r = e[Symbol.asyncIterator];
                return r ? r.call(e) : (e = b(e), t = {}, n("next"), n("throw"), n("return"), t[Symbol.asyncIterator] = function() {
                    return this
                }, t);

                function n(r) {
                    t[r] = e[r] && function(t) {
                        return new Promise(function(n, o) {
                            ! function(e, t, r, n) {
                                Promise.resolve(n).then(function(t) {
                                    e({
                                        value: t,
                                        done: r
                                    })
                                }, t)
                            }(n, o, (t = e[r](t)).done, t.value)
                        })
                    }
                }
            }

            function I(e, t) {
                return Object.defineProperty ? Object.defineProperty(e, "raw", {
                    value: t
                }) : e.raw = t, e
            }
            var T = Object.create ? function(e, t) {
                    Object.defineProperty(e, "default", {
                        enumerable: !0,
                        value: t
                    })
                } : function(e, t) {
                    e.default = t
                },
                P = function(e) {
                    return (P = Object.getOwnPropertyNames || function(e) {
                        var t = [];
                        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[t.length] = r);
                        return t
                    })(e)
                };

            function M(e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e)
                    for (var r = P(e), n = 0; n < r.length; n++) "default" !== r[n] && y(t, e, r[n]);
                return T(t, e), t
            }

            function R(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function C(e, t, r, n) {
                if ("a" === r && !n) throw TypeError("Private accessor was defined without a getter");
                if ("function" == typeof t ? e !== t || !n : !t.has(e)) throw TypeError("Cannot read private member from an object whose class did not declare it");
                return "m" === r ? n : "a" === r ? n.call(e) : n ? n.value : t.get(e)
            }

            function j(e, t, r, n, o) {
                if ("m" === n) throw TypeError("Private method is not writable");
                if ("a" === n && !o) throw TypeError("Private accessor was defined without a setter");
                if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw TypeError("Cannot write private member to an object whose class did not declare it");
                return "a" === n ? o.call(e, r) : o ? o.value = r : t.set(e, r), r
            }

            function U(e, t) {
                if (null === t || "object" != typeof t && "function" != typeof t) throw TypeError("Cannot use 'in' operator on non-object");
                return "function" == typeof e ? t === e : e.has(t)
            }

            function D(e, t, r) {
                if (null != t) {
                    var n, o;
                    if ("object" != typeof t && "function" != typeof t) throw TypeError("Object expected.");
                    if (r) {
                        if (!Symbol.asyncDispose) throw TypeError("Symbol.asyncDispose is not defined.");
                        n = t[Symbol.asyncDispose]
                    }
                    if (void 0 === n) {
                        if (!Symbol.dispose) throw TypeError("Symbol.dispose is not defined.");
                        n = t[Symbol.dispose], r && (o = n)
                    }
                    if ("function" != typeof n) throw TypeError("Object not disposable.");
                    o && (n = function() {
                        try {
                            o.call(this)
                        } catch (e) {
                            return Promise.reject(e)
                        }
                    }), e.stack.push({
                        value: t,
                        dispose: n,
                        async: r
                    })
                } else r && e.stack.push({
                    async: !0
                });
                return t
            }
            var B = "function" == typeof SuppressedError ? SuppressedError : function(e, t, r) {
                var n = Error(r);
                return n.name = "SuppressedError", n.error = e, n.suppressed = t, n
            };

            function x(e) {
                function t(t) {
                    e.error = e.hasError ? new B(t, e.error, "An error was suppressed during disposal.") : t, e.hasError = !0
                }
                var r, n = 0;
                return function o() {
                    for (; r = e.stack.pop();) try {
                        if (!r.async && 1 === n) return n = 0, e.stack.push(r), Promise.resolve().then(o);
                        if (r.dispose) {
                            var i = r.dispose.call(r.value);
                            if (r.async) return n |= 2, Promise.resolve(i).then(o, function(e) {
                                return t(e), o()
                            })
                        } else n |= 1
                    } catch (e) {
                        t(e)
                    }
                    if (1 === n) return e.hasError ? Promise.reject(e.error) : Promise.resolve();
                    if (e.hasError) throw e.error
                }()
            }

            function L(e, t) {
                return "string" == typeof e && /^\.\.?\//.test(e) ? e.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function(e, r, n, o, i) {
                    return r ? t ? ".jsx" : ".js" : !n || o && i ? n + o + "." + i.toLowerCase() + "js" : e
                }) : e
            }
            t.default = {
                __extends: o,
                __assign: i,
                __rest: s,
                __decorate: a,
                __param: c,
                __esDecorate: l,
                __runInitializers: u,
                __propKey: f,
                __setFunctionName: h,
                __metadata: d,
                __awaiter: p,
                __generator: g,
                __createBinding: y,
                __exportStar: v,
                __values: b,
                __read: m,
                __spread: w,
                __spreadArrays: _,
                __spreadArray: E,
                __await: S,
                __asyncGenerator: k,
                __asyncDelegator: O,
                __asyncValues: A,
                __makeTemplateObject: I,
                __importStar: M,
                __importDefault: R,
                __classPrivateFieldGet: C,
                __classPrivateFieldSet: j,
                __classPrivateFieldIn: U,
                __addDisposableResource: D,
                __disposeResources: x,
                __rewriteRelativeImportExtension: L
            }
        },
        22020: function(e, t, r) {
            r.d(t, {
                Ue: function() {
                    return h
                }
            });
            let n = e => {
                    let t;
                    let r = new Set,
                        n = (e, n) => {
                            let o = "function" == typeof e ? e(t) : e;
                            if (!Object.is(o, t)) {
                                let e = t;
                                t = (null != n ? n : "object" != typeof o || null === o) ? o : Object.assign({}, t, o), r.forEach(r => r(t, e))
                            }
                        },
                        o = () => t,
                        i = {
                            setState: n,
                            getState: o,
                            getInitialState: () => s,
                            subscribe: e => (r.add(e), () => r.delete(e)),
                            destroy: () => {
                                console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."), r.clear()
                            }
                        },
                        s = t = e(n, o, i);
                    return i
                },
                o = e => e ? n(e) : n;
            var i = r(64090),
                s = r(29292);
            let {
                useDebugValue: a
            } = i, {
                useSyncExternalStoreWithSelector: c
            } = s, l = !1, u = e => e, f = e => {
                "function" != typeof e && console.warn("[DEPRECATED] Passing a vanilla store will be unsupported in a future version. Instead use `import { useStore } from 'zustand'`.");
                let t = "function" == typeof e ? o(e) : e,
                    r = (e, r) => (function(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : u,
                            r = arguments.length > 2 ? arguments[2] : void 0;
                        r && !l && (console.warn("[DEPRECATED] Use `createWithEqualityFn` instead of `create` or use `useStoreWithEqualityFn` instead of `useStore`. They can be imported from 'zustand/traditional'. https://github.com/pmndrs/zustand/discussions/1937"), l = !0);
                        let n = c(e.subscribe, e.getState, e.getServerState || e.getInitialState, t, r);
                        return a(n), n
                    })(t, e, r);
                return Object.assign(r, t), r
            }, h = e => e ? f(e) : f
        }
    }
]);