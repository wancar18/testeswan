"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6023], {
        76023: function(e, n, o) {
            o.d(n, {
                g: function() {
                    return f
                }
            });
            var t = o(22020),
                l = o(10826);
            let a = {
                opponent_join: "/sounds/join.mp3",
                opponent_leave: "/sounds/leave.mp3",
                countdown_start: "/sounds/countdown.mp3",
                countdown_tick: "/sounds/countdown.mp3",
                countdown_cancel: "/sounds/leave.mp3",
                player_confirmed: "/sounds/join.mp3",
                game_start: "/sounds/countdown.mp3",
                chat_message: "/sounds/chat.mp3"
            };

            function i(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .5;
                try {
                    let o = new Audio(a[e]);
                    o.volume = Math.max(0, Math.min(1, n)), o.play().catch(n => {
                        console.warn('[Sound] Failed to play sound "'.concat(e, '":'), n.message)
                    })
                } catch (n) {
                    console.error('[Sound] Error creating audio for "'.concat(e, '":'), n)
                }
            }
            var s = o(10963),
                r = o(54012),
                c = o(29533);
            let d = null;

            function u() {
                if (!d) {
                    let e = "https://tacadinha.com";
                    e.startsWith("http://") ? e = e.replace("http://", "ws://") : e.startsWith("https://") && (e = e.replace("https://", "wss://")), d = new c.KU(e)
                }
                return d
            }

            function m(e) {
                try {
                    localStorage.removeItem("colyseus_reconnect_".concat(e))
                } catch (e) {}
            }
            let p = e => {
                    try {
                        return localStorage.getItem(e)
                    } catch (e) {
                        return null
                    }
                },
                g = ["ROOM_NOT_FOUND", "ROOM_FINISHED", "ROOM_CANCELLED", "Sala n\xe3o encontrada", "Esta sala j\xe1 foi finalizada", "Esta sala foi cancelada", "Game has already ended", "Not a participant"];

            function y(e) {
                return g.some(n => e.includes(n))
            }

            function C(e) {
                return e.includes("ROOM_LOCKED")
            }
            let h = [1e3, 2e3, 4e3, 4e3, 4e3];

            function T(e, n, o, t) {
                e.postMessage({
                    type: n,
                    data: o,
                    _st: t
                }, window.location.origin)
            }
            let f = (0, t.Ue)((e, n) => ({
                room: null,
                isConnected: !1,
                roomId: null,
                matchId: null,
                playerNum: 0,
                opponentName: "",
                player1Name: "",
                player2Name: "",
                currentTurn: 1,
                isMyTurn: !1,
                phase: "waiting",
                isBreakShot: !0,
                myBallType: null,
                opponentBallType: null,
                balls: [],
                gameStarted: !1,
                gameOver: !1,
                cancelledByAdmin: !1,
                roomFinished: !1,
                winner: null,
                error: null,
                turnTimeRemaining: null,
                serverTimestamp: null,
                iframeWindow: null,
                iframeSessionToken: null,
                heartbeatInterval: null,
                pendingTimerStart: null,
                pendingExecuteShotComplete: null,
                pendingGameState: null,
                connectionLost: !1,
                reconnectAttempts: 0,
                reconnectTimeout: null,
                isConnecting: !1,
                opponentDisconnected: !1,
                opponentGraceEndTime: null,
                disconnectedPlayerName: null,
                isSyncing: !1,
                pendingShotResult: null,
                pendingGameReady: !1,
                isInitializing: !1,
                initializationTimeout: null,
                player1GameReady: !1,
                player2GameReady: !1,
                initializationFailed: !1,
                initializationFailedReason: null,
                roomStatus: null,
                confirmations: {
                    player1: !1,
                    player2: !1
                },
                countdown: null,
                chatMessages: [],
                onRoomUpdate: null,
                setOnRoomUpdate: n => e({
                    onRoomUpdate: n
                }),
                setIframeWindow: (o, t) => {
                    console.log("[Colyseus Client] setIframeWindow called, iframe:", o ? "READY" : "NULL");
                    let l = {
                        iframeWindow: o
                    };
                    t && (l.iframeSessionToken = t), e(l);
                    let a = t || n().iframeSessionToken,
                        i = n().pendingGameState,
                        s = n().pendingExecuteShotComplete;
                    if (i && o) {
                        let n = s ? { ...i,
                            pendingAnimation: !0
                        } : i;
                        console.log("[Colyseus Client] Sending pending GAME_STATE to iframe", s ? "(with pendingAnimation flag)" : ""), o.postMessage({
                            type: "GAME_STATE",
                            data: n,
                            _st: a
                        }, window.location.origin), e({
                            pendingGameState: null
                        })
                    }
                    s && o && (console.log("[Colyseus Client] Sending pending execute_shot_complete to iframe"), o.postMessage({
                        type: "EXECUTE_SHOT_COMPLETE",
                        data: s,
                        _st: a
                    }, window.location.origin), e({
                        pendingExecuteShotComplete: null
                    }));
                    let r = n().pendingTimerStart;
                    r && o && (console.log("[Colyseus Client] Sending pending timer start to iframe"), o.postMessage({
                        type: "TURN_TIMER_START",
                        data: r,
                        _st: a
                    }, window.location.origin), e({
                        pendingTimerStart: null
                    }))
                },
                connect: async o => {
                    let t = n().room,
                        a = n().roomId,
                        c = n().isConnecting,
                        d = n().gameOver,
                        g = n().roomFinished;
                    if (d || g && a === o) {
                        console.log("[Colyseus Client] Game is over or room finished, not connecting");
                        return
                    }
                    if (a !== o && e({
                            roomFinished: !1
                        }), c) {
                        console.log("[Colyseus Client] Already connecting, skipping duplicate request");
                        return
                    }
                    if (e({
                            isConnecting: !0
                        }), t && a === o) {
                        console.log("[Colyseus Client] Already connected to room", o), e({
                            isConnecting: !1
                        });
                        return
                    }
                    t && t.leave();
                    let f = l.h.getToken();
                    if (!f) {
                        e({
                            error: "N\xe3o autenticado",
                            isConnecting: !1
                        });
                        return
                    }
                    console.log("[Colyseus Client] Connecting to room", o);
                    let S = u();
                    for (let t = 0; t <= 5; t++) try {
                        let t = await S.joinOrCreate("pool_room", {
                            dbRoomId: o,
                            token: f
                        });
                        console.log("[Colyseus Client] Joined room successfully"), e({
                                room: t,
                                roomId: o,
                                isConnected: !0,
                                isConnecting: !1
                            }),
                            function e(n, o, t) {
                                n.onLeave(a => {
                                    console.log("[Colyseus Client] Left room, code:", a);
                                    let i = t().room;
                                    if (null !== i && i !== n) {
                                        console.log("[Colyseus Client] Ignoring onLeave for stale room connection");
                                        return
                                    }
                                    let r = t().heartbeatInterval;
                                    r && clearInterval(r), o({
                                        isConnected: !1,
                                        room: null,
                                        heartbeatInterval: null
                                    });
                                    let c = t();
                                    if (c.gameOver || c.roomFinished) {
                                        console.log("[Colyseus Client] Room left after game over - no reconnection needed");
                                        return
                                    }
                                    if (c.cancelledByAdmin || c.initializationFailed) {
                                        console.log("[Colyseus Client] Room left after cancellation/failure - no reconnection needed");
                                        return
                                    }
                                    if (c.gameStarted) {
                                        console.log("[Colyseus Client] Connection lost during active game"), o({
                                            connectionLost: !0,
                                            reconnectAttempts: 0
                                        }), console.log("[Colyseus Client] Starting ".concat(32e3, "ms reconnection timeout (server: ").concat(3e4, "ms + buffer: ").concat(2e3, "ms)")), o({
                                            reconnectTimeout: setTimeout(() => {
                                                let e = t();
                                                e.connectionLost && !e.isConnected && (console.log("[Colyseus Client] Reconnection timeout expired"), s.default.error("N\xe3o foi poss\xedvel reconectar. Voc\xea foi derrotado por desconex\xe3o.", {
                                                    duration: 4e3
                                                }), e.reset(), window.location.href = "/lobby")
                                            }, 32e3)
                                        });
                                        let n = c.roomId;
                                        if (n) {
                                            let a = async i => {
                                                let r = t();
                                                if (r.isConnected || !r.connectionLost || r.gameOver || r.roomFinished) {
                                                    console.log("[Colyseus Client] Stopping reconnection attempts - state changed");
                                                    return
                                                }
                                                console.log("[Colyseus Client] Reconnection attempt ".concat(i, "...")), o({
                                                    reconnectAttempts: i
                                                });
                                                try {
                                                    let a = u(),
                                                        i = l.h.getToken();
                                                    if (i) {
                                                        console.log("[Colyseus Client] Attempting reconnect via joinOrCreate");
                                                        let l = await a.joinOrCreate("pool_room", {
                                                            dbRoomId: n,
                                                            token: i
                                                        });
                                                        console.log("[Colyseus Client] Reconnected successfully!");
                                                        let r = t().reconnectTimeout;
                                                        r && clearTimeout(r), o({
                                                            room: l,
                                                            isConnected: !0,
                                                            connectionLost: !1,
                                                            reconnectAttempts: 0,
                                                            reconnectTimeout: null
                                                        }), e(l, o, t);
                                                        let c = setInterval(() => {
                                                            l.connection.isOpen && l.send("heartbeat", {
                                                                visible: "undefined" == typeof document || !document.hidden,
                                                                ts: Date.now()
                                                            })
                                                        }, 5e3);
                                                        o({
                                                            heartbeatInterval: c
                                                        }), s.default.success("Reconectado com sucesso!", {
                                                            duration: 3e3
                                                        });
                                                        return
                                                    }
                                                    console.log("[Colyseus Client] No auth token available for reconnection")
                                                } catch (l) {
                                                    let e = l instanceof Error ? l.message : "Unknown error";
                                                    if (console.log("[Colyseus Client] Reconnection attempt ".concat(i, " failed:"), e), y(e)) {
                                                        console.log("[Colyseus Client] Terminal error detected - stopping reconnection");
                                                        let e = t().reconnectTimeout;
                                                        e && clearTimeout(e), n && m(n), o({
                                                            gameOver: !0,
                                                            gameStarted: !1,
                                                            roomFinished: !0,
                                                            connectionLost: !1,
                                                            reconnectTimeout: null
                                                        }), s.default.error("A sala n\xe3o est\xe1 mais dispon\xedvel.", {
                                                            duration: 4e3
                                                        }), window.location.href = "/lobby";
                                                        return
                                                    }
                                                }
                                                let c = Math.min(1e3 * Math.pow(1.5, i - 1), 5e3);
                                                console.log("[Colyseus Client] Next reconnection attempt in ".concat(c, "ms")), setTimeout(() => {
                                                    a(i + 1)
                                                }, c)
                                            };
                                            setTimeout(() => {
                                                a(1)
                                            }, 1e3)
                                        }
                                    }
                                }), n.onError((e, l) => {
                                    let a = t().room;
                                    if (null !== a && a !== n) {
                                        console.log("[Colyseus Client] Ignoring onError for stale room connection");
                                        return
                                    }
                                    console.error("[Colyseus Client] Room error:", e, l), o({
                                        error: l || "Room error"
                                    })
                                }), n.onStateChange(e => {
                                    if (!t().playerNum) return;
                                    let n = t(),
                                        l = e.countdown;
                                    n.countdown !== (l || null) && o({
                                        countdown: l || null
                                    });
                                    let a = e.phase;
                                    a && "shooting" !== a && n.phase !== a && "shooting" !== n.phase && (console.log("[Schema Sync] Phase correction: ".concat(n.phase, " -> ").concat(a)), o({
                                        phase: a
                                    }))
                                }), n.onMessage("pong", e => {
                                    console.log("[Colyseus Client] Heartbeat OK:", e.timestamp)
                                }), n.onMessage("room_joined", e => {
                                    var n, l;
                                    console.log("[Colyseus Client] Room joined:", e);
                                    let a = {
                                        roomId: e.roomId,
                                        matchId: e.matchId,
                                        playerNum: e.playerNum,
                                        opponentName: e.opponentName
                                    };
                                    if (e.gameState) {
                                        console.log("[Colyseus Client] Applying game state from room_joined"), a.currentTurn = e.gameState.currentTurn || 1, a.phase = e.gameState.phase || "waiting", a.isBreakShot = e.gameState.isBreakShot || !1, a.myBallType = e.gameState.myBallType || null, a.opponentBallType = e.gameState.opponentBallType || null, a.balls = e.gameState.balls || [], a.isMyTurn = e.gameState.currentTurn === e.playerNum, a.turnTimeRemaining = e.gameState.turnTimeRemaining || null, a.serverTimestamp = e.gameState.serverTimestamp || Date.now(), "waiting" !== e.gameState.phase && (a.gameStarted = !0), "shooting" === e.gameState.phase && (a.isSyncing = !0), "initializing" === e.gameState.phase && (a.isInitializing = !0);
                                        let n = t().iframeWindow;
                                        if ("waiting" !== e.gameState.phase) {
                                            let l = { ...e.gameState,
                                                playerNum: e.playerNum
                                            };
                                            n ? T(n, "GAME_STATE", l, t().iframeSessionToken) : o({
                                                pendingGameState: l
                                            })
                                        }
                                    }
                                    if (e.players) {
                                        let n = e.players.find(e => 1 === e.playerNum),
                                            o = e.players.find(e => 2 === e.playerNum);
                                        n && (a.player1Name = n.username || n.name), o && (a.player2Name = o.username || o.name)
                                    }(null === (n = e.gameState) || void 0 === n ? void 0 : n.opponentConnected) === !0 && t().opponentDisconnected && (console.log("[Colyseus Client] Opponent is connected (from room_joined) - clearing disconnect overlay"), a.opponentDisconnected = !1, a.opponentGraceEndTime = null, a.disconnectedPlayerName = null), o(a), o({
                                        connectionLost: !1
                                    });
                                    let i = t().reconnectTimeout;
                                    i && (clearTimeout(i), o({
                                        reconnectTimeout: null
                                    }));
                                    let s = t().pendingShotResult,
                                        r = null === (l = e.gameState) || void 0 === l ? void 0 : l.phase;
                                    s && ("shooting" === r ? (console.log("[Colyseus Client] Server in SHOOTING phase - resending pending shot result"), setTimeout(() => {
                                        let e = t().room,
                                            n = t().pendingShotResult;
                                        e && n && e.connection && e.connection.isOpen && (console.log("[Colyseus Client] Sending queued shot result:", n), e.send("shot_result", n), o({
                                            pendingShotResult: null
                                        }))
                                    }, 200)) : (console.log("[Colyseus Client] Server phase is '".concat(r, "' (not shooting) - discarding pending shot result")), o({
                                        pendingShotResult: null
                                    })))
                                }), n.onMessage("both_players_ready", e => {
                                    var n, l, a, s, r;
                                    console.log("[Colyseus Client] Both players ready:", e);
                                    let c = t().playerNum,
                                        d = null === (n = e.players) || void 0 === n ? void 0 : n.find(e => e.playerNum !== c),
                                        u = null === (l = e.players) || void 0 === l ? void 0 : l.find(e => 1 === e.playerNum),
                                        m = null === (a = e.players) || void 0 === a ? void 0 : a.find(e => 2 === e.playerNum);
                                    o({
                                        roomStatus: "CONFIRMING",
                                        opponentName: (null == d ? void 0 : d.username) || (null == d ? void 0 : d.name) || "Oponente",
                                        player1Name: (null == u ? void 0 : u.username) || (null == u ? void 0 : u.name) || "",
                                        player2Name: (null == m ? void 0 : m.username) || (null == m ? void 0 : m.name) || ""
                                    }), i("opponent_join"), null === (s = (r = t()).onRoomUpdate) || void 0 === s || s.call(r)
                                }), n.onMessage("player_confirmed", e => {
                                    console.log("[Colyseus Client] Player confirmed:", e), o({
                                        confirmations: e.confirmations
                                    }), i("player_confirmed", .3)
                                }), n.onMessage("countdown_start", e => {
                                    console.log("[Colyseus Client] Countdown started:", e.countdown), o({
                                        roomStatus: "COUNTDOWN",
                                        countdown: e.countdown
                                    }), i("countdown_start")
                                }), n.onMessage("countdown_tick", e => {
                                    o({
                                        countdown: e.countdown
                                    }), i("countdown_tick", .4)
                                }), n.onMessage("countdown_cancelled", () => {
                                    console.log("[Colyseus Client] Countdown cancelled"), o({
                                        roomStatus: "CONFIRMING",
                                        countdown: null,
                                        confirmations: {
                                            player1: !1,
                                            player2: !1
                                        }
                                    }), i("countdown_cancel")
                                }), n.onMessage("initialization_started", e => {
                                    console.log("[Colyseus Client] Initialization started:", e), o({
                                        isInitializing: !0,
                                        initializationTimeout: e.timeout,
                                        player1GameReady: !1,
                                        player2GameReady: !1,
                                        initializationFailed: !1,
                                        initializationFailedReason: null
                                    })
                                }), n.onMessage("player_game_ready", e => {
                                    console.log("[Colyseus Client] Player game ready:", e), o({
                                        player1GameReady: e.player1Ready,
                                        player2GameReady: e.player2Ready
                                    })
                                }), n.onMessage("game_started", e => {
                                    console.log("[Colyseus Client] Game started (both players ready):", e), o({
                                        isInitializing: !1,
                                        player1GameReady: !0,
                                        player2GameReady: !0
                                    }), i("game_start")
                                }), n.onMessage("initialization_failed", e => {
                                    console.log("[Colyseus Client] Initialization failed:", e);
                                    let n = t().roomId;
                                    n && m(n);
                                    let l = t().heartbeatInterval;
                                    l && clearInterval(l);
                                    let a = t().reconnectTimeout;
                                    a && clearTimeout(a), o({
                                        isInitializing: !1,
                                        initializationFailed: !0,
                                        initializationFailedReason: e.message,
                                        gameOver: !0,
                                        gameStarted: !1,
                                        roomFinished: !0,
                                        connectionLost: !1,
                                        heartbeatInterval: null,
                                        reconnectTimeout: null
                                    }), s.default.error(e.message, {
                                        duration: 5e3
                                    }), e.refunded && e.refundAmount && e.refundAmount > 0 && setTimeout(() => {
                                        s.default.success("R$ ".concat(e.refundAmount.toFixed(2), " devolvido \xe0 sua carteira"), {
                                            duration: 4e3
                                        })
                                    }, 500), setTimeout(() => {
                                        t().reset(), window.location.href = "/lobby"
                                    }, 3e3)
                                }), n.onMessage("game_start", e => {
                                    console.log("[Colyseus Client] game_start received:", e);
                                    let n = t().iframeWindow,
                                        l = e.player1Name || "Player 1",
                                        a = e.player2Name || "Player 2",
                                        i = {
                                            matchId: e.matchId,
                                            currentTurn: e.currentTurn,
                                            isMyTurn: e.isMyTurn,
                                            phase: e.phase,
                                            isBreakShot: e.isBreakShot,
                                            myBallType: e.myBallType || null,
                                            opponentBallType: e.opponentBallType || null,
                                            balls: e.balls || [],
                                            player1Name: l,
                                            player2Name: a,
                                            gameStarted: !0,
                                            turnTimeRemaining: e.turnTimeRemaining || null,
                                            serverTimestamp: e.serverTimestamp || Date.now()
                                        };
                                    "initializing" === e.phase && (i.isInitializing = !0), o(i);
                                    let {
                                        roomId: s,
                                        playerNum: c
                                    } = t();
                                    (0, r.Jq)({
                                        matchId: e.matchId,
                                        roomId: s || "",
                                        betAmount: e.betAmount,
                                        playerNum: c,
                                        isBreakShot: e.isMyTurn && e.isBreakShot
                                    });
                                    let d = { ...e,
                                        playerNum: t().playerNum
                                    };
                                    n ? T(n, "GAME_STATE", d, t().iframeSessionToken) : o({
                                        pendingGameState: d
                                    })
                                }), n.onMessage("execute_shot", e => {
                                    console.log("[Colyseus Client] Execute shot (legacy):", e);
                                    let n = t().iframeWindow,
                                        o = t().playerNum;
                                    n && T(n, "EXECUTE_SHOT", { ...e,
                                        isMyShot: e.playerNum === o
                                    }, t().iframeSessionToken)
                                }), n.onMessage("execute_shot_complete", e => {
                                    console.log("[Colyseus Client] Execute shot complete:", e);
                                    let n = t().iframeWindow,
                                        l = t().playerNum;
                                    o({
                                        currentTurn: e.currentTurn,
                                        isMyTurn: e.isMyTurn,
                                        phase: e.newPhase,
                                        isBreakShot: e.isBreakShot,
                                        myBallType: e.myBallType || null,
                                        opponentBallType: e.opponentBallType || null,
                                        balls: e.balls || [],
                                        isSyncing: !1,
                                        pendingShotResult: null
                                    });
                                    let a = { ...e,
                                        isMyShot: e.playerNum === l,
                                        playerNum: e.playerNum
                                    };
                                    n ? T(n, "EXECUTE_SHOT_COMPLETE", a, t().iframeSessionToken) : (console.log("[Colyseus Client] Iframe not ready - queuing execute_shot_complete"), o({
                                        pendingExecuteShotComplete: a
                                    }))
                                }), n.onMessage("state_update", e => {
                                    console.log("[Colyseus Client] State update:", e), e.reconnectedDuringShooting && console.log("[Colyseus Client] Reconnected during SHOOTING phase - waiting for shot result or timeout"), e.serverSimulated && (console.log("[Colyseus Client] State was server-simulated (shot timeout recovery)"), o({
                                        pendingShotResult: null
                                    }));
                                    let n = t().iframeWindow,
                                        l = ["break_shot", "playing", "shooting", "ball_in_hand"].includes(e.phase);
                                    e.initializationComplete && console.log("[Colyseus Client] Initialization complete, game starting!");
                                    let a = !0 === e.opponentConnected && t().opponentDisconnected;
                                    a && console.log("[Colyseus Client] Opponent is connected (from state_update) - clearing disconnect overlay"), o({
                                        currentTurn: e.currentTurn,
                                        isMyTurn: e.isMyTurn,
                                        phase: e.phase,
                                        isBreakShot: e.isBreakShot,
                                        myBallType: e.myBallType || null,
                                        opponentBallType: e.opponentBallType || null,
                                        balls: e.balls || [],
                                        isSyncing: !1,
                                        isInitializing: !l && !e.initializationComplete && t().isInitializing,
                                        player1GameReady: !!e.initializationComplete || t().player1GameReady,
                                        player2GameReady: !!e.initializationComplete || t().player2GameReady,
                                        ...a ? {
                                            opponentDisconnected: !1,
                                            opponentGraceEndTime: null,
                                            disconnectedPlayerName: null
                                        } : {}
                                    }), n && T(n, "STATE_UPDATE", { ...e,
                                        playerNum: t().playerNum
                                    }, t().iframeSessionToken)
                                }), n.onMessage("turn_timer_start", e => {
                                    let n = t().iframeWindow;
                                    n ? T(n, "TURN_TIMER_START", e, t().iframeSessionToken) : o({
                                        pendingTimerStart: e
                                    })
                                }), n.onMessage("opponent_stick_update", e => {
                                    let n = t().iframeWindow;
                                    n && T(n, "OPPONENT_STICK_UPDATE", e, t().iframeSessionToken)
                                }), n.onMessage("opponent_cue_ball_moving", e => {
                                    let n = t().iframeWindow;
                                    n && T(n, "OPPONENT_CUE_BALL_MOVING", e, t().iframeSessionToken)
                                }), n.onMessage("opponent_stick_charging", e => {
                                    let n = t().iframeWindow;
                                    n && T(n, "OPPONENT_STICK_CHARGING", e, t().iframeSessionToken)
                                }), n.onMessage("cue_ball_placed", e => {
                                    let n = t().iframeWindow;
                                    n && T(n, "CUE_BALL_PLACED", e, t().iframeSessionToken)
                                }), n.onMessage("game_over", e => {
                                    console.log("[Colyseus Client] Game over:", e);
                                    let n = t().iframeWindow,
                                        l = t().roomId;
                                    l && m(l);
                                    let a = t().heartbeatInterval;
                                    a && clearInterval(a);
                                    let i = t().reconnectTimeout;
                                    i && clearTimeout(i), o({
                                        gameOver: !0,
                                        gameStarted: !1,
                                        roomFinished: !0,
                                        phase: "game_over",
                                        winner: {
                                            id: e.winnerId,
                                            name: e.winnerName,
                                            prize: e.prize,
                                            reason: e.reason,
                                            rankingUpdate: e.rankingUpdate
                                        },
                                        opponentDisconnected: !1,
                                        opponentGraceEndTime: null,
                                        disconnectedPlayerName: null,
                                        isSyncing: !1,
                                        connectionLost: !1,
                                        heartbeatInterval: null,
                                        reconnectTimeout: null
                                    });
                                    let s = p("userId");
                                    (0, r.gh)({
                                        matchId: t().matchId || "",
                                        roomId: l || "",
                                        won: e.winnerId === s,
                                        prizeAmount: e.prize,
                                        userId: s || void 0
                                    }), n && T(n, "GAME_OVER", e, t().iframeSessionToken)
                                }), n.onMessage("player_disconnect", e => {
                                    if (console.log("[Colyseus Client] Player disconnected:", {
                                            playerId: e.playerId,
                                            playerName: e.playerName,
                                            gracePeriodMs: e.gracePeriodMs,
                                            graceEndTime: e.graceEndTime,
                                            currentPhase: e.currentPhase,
                                            isOpponentTurn: e.isOpponentTurn
                                        }), "initializing" === e.currentPhase) {
                                        console.log("[Colyseus Client] Ignoring disconnect during initialization phase");
                                        return
                                    }
                                    let n = p("userId");
                                    if (e.playerId !== n) {
                                        let n = e.graceEndTime - Date.now();
                                        console.log("[Colyseus Client] Opponent has ".concat(Math.round(n / 1e3), "s to reconnect")), o({
                                            opponentDisconnected: !0,
                                            opponentGraceEndTime: e.graceEndTime,
                                            disconnectedPlayerName: e.playerName
                                        });
                                        let l = t().iframeWindow;
                                        l && T(l, "OPPONENT_DISCONNECTED", {
                                            playerName: e.playerName,
                                            graceEndTime: e.graceEndTime,
                                            gracePeriodSeconds: Math.round(n / 1e3),
                                            isOpponentTurn: e.isOpponentTurn
                                        }, t().iframeSessionToken)
                                    }
                                }), n.onMessage("opponent_reconnected", e => {
                                    console.log("[Colyseus Client] Opponent reconnected:", e), o({
                                        opponentDisconnected: !1,
                                        opponentGraceEndTime: null,
                                        disconnectedPlayerName: null,
                                        isSyncing: !1
                                    });
                                    let n = t().iframeWindow;
                                    n && T(n, "OPPONENT_RECONNECTED", {
                                        playerName: e.playerName,
                                        message: e.message
                                    }, t().iframeSessionToken), s.default.success(e.message, {
                                        duration: 3e3
                                    })
                                }), n.onMessage("disconnection_limit_exceeded", e => {
                                    console.log("[Colyseus Client] Disconnection limit exceeded:", e);
                                    let n = t().roomId;
                                    n && m(n);
                                    let l = t().heartbeatInterval;
                                    l && clearInterval(l);
                                    let a = t().reconnectTimeout;
                                    a && clearTimeout(a), o({
                                        gameOver: !0,
                                        gameStarted: !1,
                                        connectionLost: !1,
                                        roomFinished: !0,
                                        heartbeatInterval: null,
                                        reconnectTimeout: null
                                    }), s.default.error(e.message || "Voc\xea excedeu o limite de desconex\xf5es permitido", {
                                        duration: 5e3
                                    })
                                }), n.onMessage("opponent_exceeded_disconnection_limit", e => {
                                    console.log("[Colyseus Client] Opponent exceeded disconnection limit:", e), o({
                                        opponentDisconnected: !1,
                                        opponentGraceEndTime: null,
                                        disconnectedPlayerName: null,
                                        roomFinished: !0
                                    }), s.default.success("".concat(e.playerName, " excedeu o limite de desconex\xf5es. Voc\xea venceu!"), {
                                        duration: 4e3
                                    })
                                }), n.onMessage("opponent_left", e => {
                                    var n, l;
                                    console.log("[Colyseus Client] Opponent left:", e);
                                    let a = t(),
                                        i = {
                                            opponentName: "Aguardando...",
                                            roomStatus: "WAITING",
                                            confirmations: {
                                                player1: !1,
                                                player2: !1
                                            },
                                            countdown: null
                                        };
                                    1 === a.playerNum ? i.player2Name = "" : i.player1Name = "", o(i), (0, s.default)(e.message, {
                                        icon: "\uD83D\uDC4B",
                                        duration: 5e3
                                    }), null === (n = (l = t()).onRoomUpdate) || void 0 === n || n.call(l)
                                }), n.onMessage("room_cancelled", e => {
                                    console.log("[Colyseus Client] Room cancelled:", e);
                                    let l = t().roomId;
                                    l && m(l), o({
                                        roomStatus: "CANCELLED",
                                        gameOver: !0,
                                        gameStarted: !1,
                                        roomFinished: !0,
                                        connectionLost: !1,
                                        cancelledByAdmin: e.cancelledByAdmin || !1
                                    });
                                    let a = t().reconnectTimeout;
                                    a && (clearTimeout(a), o({
                                        reconnectTimeout: null
                                    })), n.leave();
                                    let i = e.message || e.reason || "Sala cancelada";
                                    s.default.error(i, {
                                        duration: 3e3
                                    }), e.cancelledByAdmin && e.refunded && e.refundAmount && e.refundAmount > 0 && setTimeout(() => {
                                        s.default.success("R$ ".concat(e.refundAmount.toFixed(2), " devolvido \xe0 sua carteira"), {
                                            duration: 4e3
                                        })
                                    }, 500);
                                    let r = e.redirectTo || "/lobby";
                                    setTimeout(() => {
                                        window.location.href = r
                                    }, 1e3)
                                }), n.onMessage("match_cancelled_by_admin", e => {
                                    console.log("[Colyseus Client] Match cancelled by admin:", e);
                                    let l = t().roomId;
                                    l && m(l), o({
                                        cancelledByAdmin: !0,
                                        gameOver: !0,
                                        gameStarted: !1,
                                        roomFinished: !0,
                                        connectionLost: !1
                                    });
                                    let a = t().reconnectTimeout;
                                    a && (clearTimeout(a), o({
                                        reconnectTimeout: null
                                    })), n.leave();
                                    let i = e.reason ? "Partida cancelada: ".concat(e.reason) : "Partida cancelada pelo administrador";
                                    s.default.error(i, {
                                        duration: 4e3
                                    }), e.refunded && e.refundAmount && e.refundAmount > 0 && setTimeout(() => {
                                        s.default.success("R$ ".concat(e.refundAmount.toFixed(2), " devolvido \xe0 sua carteira"), {
                                            duration: 4e3
                                        })
                                    }, 500);
                                    let r = e.redirectTo || "/lobby";
                                    setTimeout(() => {
                                        window.location.href = r
                                    }, 1e3)
                                }), n.onMessage("chat_message", e => {
                                    o(n => ({
                                        chatMessages: [...n.chatMessages, e]
                                    }))
                                }), n.onMessage("chat_history", e => {
                                    o({
                                        chatMessages: e.messages
                                    })
                                }), n.onMessage("error", e => {
                                    console.log("[Colyseus Client] Error:", e), o({
                                        error: e.message
                                    });
                                    let n = t().iframeWindow;
                                    n && T(n, "ERROR", {
                                        message: e.message
                                    }, t().iframeSessionToken)
                                }), n.onMessage("game_already_finished", e => {
                                    console.log("[Colyseus Client] Game already finished:", e.message), o({
                                        roomFinished: !0
                                    });
                                    let n = t();
                                    n.gameOver && n.winner ? (s.default.success("Jogo finalizado! Redirecionando...", {
                                        duration: 4e3
                                    }), setTimeout(() => {
                                        t().reset(), window.location.href = "/lobby"
                                    }, 5e3)) : (s.default.error(e.message || "Este jogo j\xe1 foi finalizado", {
                                        duration: 3e3
                                    }), setTimeout(() => {
                                        t().reset(), window.location.href = "/lobby"
                                    }, 500))
                                }), n.onMessage("redirect_to_active_game", e => {
                                    console.log("[Colyseus Client] Redirect to active game:", e), (0, s.default)(e.message, {
                                        duration: 3e3
                                    }), setTimeout(() => {
                                        window.location.href = "/game/".concat(e.activeRoomId)
                                    }, 1e3)
                                }), n.onMessage("session_takeover", () => {
                                    console.log("[Colyseus Client] Session takeover"), o({
                                        connectionLost: !1,
                                        opponentDisconnected: !1,
                                        opponentGraceEndTime: null,
                                        disconnectedPlayerName: null,
                                        isSyncing: !1
                                    }), s.default.error("Sess\xe3o transferida para outro dispositivo", {
                                        duration: 5e3
                                    }), setTimeout(() => {
                                        window.location.href = "/lobby"
                                    }, 2e3)
                                })
                            }(t, e, n), n().pendingGameReady && (console.log("[Colyseus Client] Sending queued game_ready after reconnect"), t.send("game_ready", {
                                roomId: o
                            }), e({
                                pendingGameReady: !1
                            }));
                        let a = n().heartbeatInterval;
                        a && clearInterval(a);
                        let c = setInterval(() => {
                            t.connection.isOpen && t.send("heartbeat", {
                                visible: "undefined" == typeof document || !document.hidden,
                                ts: Date.now()
                            })
                        }, 5e3);
                        e({
                            heartbeatInterval: c
                        });
                        return
                    } catch (l) {
                        let n = l instanceof Error ? l.message : "Failed to connect";
                        if (C(n) && t < 5) {
                            let e = h[t] || 4e3;
                            console.log("[Colyseus Client] Room locked, retrying in ".concat(e, "ms (attempt ").concat(t + 1, "/").concat(5, ")")), await new Promise(n => setTimeout(n, e));
                            continue
                        }
                        console.error("[Colyseus Client] Connection error:", l), y(n) ? (console.log("[Colyseus Client] Terminal error on connect - marking room as finished"), o && m(o), e({
                            error: n,
                            isConnecting: !1,
                            roomFinished: !0
                        })) : C(n) ? (console.log("[Colyseus Client] Room locked after max retries"), o && m(o), e({
                            error: "N\xe3o foi poss\xedvel conectar. Tente novamente.",
                            isConnecting: !1
                        })) : e({
                            error: n,
                            isConnecting: !1
                        });
                        return
                    }
                },
                disconnect: () => {
                    let e = n().room,
                        o = n().heartbeatInterval,
                        t = n().reconnectTimeout;
                    o && clearInterval(o), t && clearTimeout(t), e && e.leave(), n().reset()
                },
                sendShot: e => {
                    let {
                        room: o,
                        matchId: t,
                        phase: l
                    } = n();
                    if (o && t) {
                        if ("ball_in_hand" === l) {
                            console.log("[Colyseus Client] Cannot send shot during ball-in-hand phase");
                            return
                        }
                        console.log("[Colyseus Client] Sending shot to server"), o.send("shot", {
                            matchId: t,
                            ...e
                        })
                    }
                },
                sendShotResult: o => {
                    let t = n().room;
                    if (!t) {
                        console.log("[Colyseus Client] No room - queuing shot result"), e({
                            pendingShotResult: o
                        });
                        return
                    }
                    if (!t.connection || !t.connection.isOpen) {
                        console.log("[Colyseus Client] Connection not open - queuing shot result for later"), e({
                            pendingShotResult: o
                        });
                        return
                    }
                    console.log("[Colyseus Client] Sending shot result"), t.send("shot_result", o), e({
                        pendingShotResult: null
                    })
                },
                sendStickUpdate: e => {
                    let o = n().room;
                    o && o.send("stick_update", e)
                },
                sendCueBallMoving: (e, o) => {
                    let t = n().room;
                    t && t.send("cue_ball_moving", {
                        x: e,
                        y: o
                    })
                },
                sendStickCharging: e => {
                    let o = n().room;
                    o && o.send("stick_charging", e)
                },
                sendShotObservation: e => {
                    let o = n().room;
                    o && o.send("shot_observation", e)
                },
                sendForfeit: () => {
                    let e = n().room;
                    e && (console.log("[Colyseus Client] Sending forfeit"), e.send("forfeit"))
                },
                sendPlaceCueBall: (e, o) => {
                    let t = n().room;
                    t && t.send("place_cue_ball", {
                        x: e,
                        y: o
                    })
                },
                requestState: () => {
                    let e = n().room;
                    e && e.send("request_state")
                },
                confirmReady: () => {
                    let {
                        room: e,
                        roomId: o
                    } = n();
                    e && o && (console.log("[Colyseus Client] Confirming ready"), e.send("confirm_ready", {
                        roomId: o
                    }))
                },
                cancelCountdown: () => {
                    let {
                        room: e,
                        roomId: o
                    } = n();
                    e && o && (console.log("[Colyseus Client] Cancelling countdown"), e.send("cancel_countdown", {
                        roomId: o
                    }))
                },
                sendChatMessage: e => {
                    let {
                        room: o,
                        roomId: t
                    } = n();
                    o && t && e.trim() && o.send("send_chat_message", {
                        roomId: t,
                        message: e
                    })
                },
                getChatHistory: () => {
                    let {
                        room: e,
                        roomId: o
                    } = n();
                    e && o && e.send("get_chat_history", {
                        roomId: o
                    })
                },
                sendGameReady: () => {
                    let {
                        room: o,
                        roomId: t
                    } = n();
                    if (!o || !t) {
                        console.log("[Colyseus Client] No room connection - queuing game_ready for after reconnect"), e({
                            pendingGameReady: !0
                        });
                        return
                    }
                    console.log("[Colyseus Client] Sending game_ready"), o.send("game_ready", {
                        roomId: t
                    }), e({
                        pendingGameReady: !1
                    })
                },
                clearError: () => e({
                    error: null
                }),
                reset: () => {
                    let o = n().heartbeatInterval;
                    o && clearInterval(o);
                    let t = n().roomId;
                    t && m(t), e({
                        room: null,
                        isConnected: !1,
                        roomId: null,
                        matchId: null,
                        playerNum: 0,
                        opponentName: "",
                        player1Name: "",
                        player2Name: "",
                        currentTurn: 1,
                        isMyTurn: !1,
                        phase: "waiting",
                        isBreakShot: !0,
                        myBallType: null,
                        opponentBallType: null,
                        balls: [],
                        gameStarted: !1,
                        gameOver: !1,
                        cancelledByAdmin: !1,
                        roomFinished: !1,
                        winner: null,
                        error: null,
                        turnTimeRemaining: null,
                        serverTimestamp: null,
                        iframeWindow: null,
                        iframeSessionToken: null,
                        heartbeatInterval: null,
                        pendingTimerStart: null,
                        pendingExecuteShotComplete: null,
                        pendingGameState: null,
                        connectionLost: !1,
                        reconnectAttempts: 0,
                        reconnectTimeout: null,
                        isConnecting: !1,
                        opponentDisconnected: !1,
                        opponentGraceEndTime: null,
                        disconnectedPlayerName: null,
                        isSyncing: !1,
                        pendingShotResult: null,
                        pendingGameReady: !1,
                        isInitializing: !1,
                        initializationTimeout: null,
                        player1GameReady: !1,
                        player2GameReady: !1,
                        initializationFailed: !1,
                        initializationFailedReason: null,
                        roomStatus: null,
                        confirmations: {
                            player1: !1,
                            player2: !1
                        },
                        countdown: null,
                        chatMessages: []
                    })
                }
            }))
        }
    }
]);