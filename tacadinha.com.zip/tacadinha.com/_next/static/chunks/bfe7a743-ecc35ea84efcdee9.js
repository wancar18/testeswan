(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1615], {
        64800: function(e, t, i) {
            var n = i(8620).Buffer;
            ! function(e) {
                "use strict";
                var t, i, s;
                e.OPERATION = void 0, (s = e.OPERATION || (e.OPERATION = {}))[s.ADD = 128] = "ADD", s[s.REPLACE = 0] = "REPLACE", s[s.DELETE = 64] = "DELETE", s[s.DELETE_AND_MOVE = 96] = "DELETE_AND_MOVE", s[s.MOVE_AND_ADD = 160] = "MOVE_AND_ADD", s[s.DELETE_AND_ADD = 192] = "DELETE_AND_ADD", s[s.CLEAR = 10] = "CLEAR", s[s.REVERSE = 15] = "REVERSE", s[s.MOVE = 32] = "MOVE", s[s.DELETE_BY_REFID = 33] = "DELETE_BY_REFID", s[s.ADD_BY_REFID = 129] = "ADD_BY_REFID", null !== (i = (t = Symbol).metadata) && void 0 !== i || (t.metadata = Symbol.for("Symbol.metadata"));
                let r = "~track",
                    o = "~encoder",
                    a = "~decoder",
                    l = "~filter",
                    h = "~getByIndex",
                    d = "~deleteByIndex",
                    c = "~changes",
                    f = "~childType",
                    u = "~onEncodeEnd",
                    g = "~onDecodeEnd",
                    v = "~descriptors",
                    p = "~__numFields",
                    m = "~__refTypeFieldIndexes",
                    E = "~__viewFieldIndexes",
                    y = "$__fieldIndexesByViewTag";
                try {
                    new TextEncoder
                } catch (e) {}
                let b = new ArrayBuffer(8),
                    O = new Int32Array(b),
                    I = new Float32Array(b),
                    A = new Float64Array(b),
                    T = new BigInt64Array(b),
                    x = void 0 !== n && n.byteLength ? n.byteLength : function(e, t) {
                        for (var i = 0, n = 0, s = 0, r = e.length; s < r; s++)(i = e.charCodeAt(s)) < 128 ? n += 1 : i < 2048 ? n += 2 : i < 55296 || i >= 57344 ? n += 3 : (s++, n += 4);
                        return n
                    };

                function C(e, t, i) {
                    for (var n = 0, s = 0, r = t.length; s < r; s++)(n = t.charCodeAt(s)) < 128 ? e[i.offset++] = n : n < 2048 ? (e[i.offset] = 192 | n >> 6, e[i.offset + 1] = 128 | 63 & n, i.offset += 2) : n < 55296 || n >= 57344 ? (e[i.offset] = 224 | n >> 12, e[i.offset + 1] = 128 | n >> 6 & 63, e[i.offset + 2] = 128 | 63 & n, i.offset += 3) : (s++, n = 65536 + ((1023 & n) << 10 | 1023 & t.charCodeAt(s)), e[i.offset] = 240 | n >> 18, e[i.offset + 1] = 128 | n >> 12 & 63, e[i.offset + 2] = 128 | n >> 6 & 63, e[i.offset + 3] = 128 | 63 & n, i.offset += 4)
                }

                function R(e, t, i) {
                    e[i.offset++] = 255 & t
                }

                function N(e, t, i) {
                    e[i.offset++] = 255 & t, e[i.offset++] = t >> 8 & 255
                }

                function P(e, t, i) {
                    e[i.offset++] = 255 & t, e[i.offset++] = t >> 8 & 255
                }

                function D(e, t, i) {
                    e[i.offset++] = 255 & t, e[i.offset++] = t >> 8 & 255, e[i.offset++] = t >> 16 & 255, e[i.offset++] = t >> 24 & 255
                }

                function w(e, t, i) {
                    e[i.offset++] = 255 & t, e[i.offset++] = 255 & t >> 8, e[i.offset++] = 255 & t >> 16, e[i.offset++] = 255 & t >> 24
                }

                function S(e, t, i) {
                    w(e, t >>> 0, i), w(e, Math.floor(t / 4294967296), i)
                }

                function $(e, t, i) {
                    w(e, t >>> 0, i), w(e, t / 4294967296 >> 0, i)
                }

                function F(e, t, i) {
                    I[0] = t, D(e, O[0], i)
                }

                function j(e, t, i) {
                    A[0] = t, D(e, O[0], i), D(e, O[1], i)
                }
                let L = {
                        int8: R,
                        uint8: function(e, t, i) {
                            e[i.offset++] = 255 & t
                        },
                        int16: N,
                        uint16: P,
                        int32: D,
                        uint32: w,
                        int64: S,
                        uint64: $,
                        bigint64: function(e, t, i) {
                            T[0] = BigInt.asIntN(64, t), D(e, O[0], i), D(e, O[1], i)
                        },
                        biguint64: function(e, t, i) {
                            T[0] = BigInt.asIntN(64, t), D(e, O[0], i), D(e, O[1], i)
                        },
                        float32: F,
                        float64: j,
                        boolean: function(e, t, i) {
                            e[i.offset++] = t ? 1 : 0
                        },
                        string: function(e, t, i) {
                            t || (t = "");
                            let n = x(t, "utf8"),
                                s = 0;
                            if (n < 32) e[i.offset++] = 160 | n, s = 1;
                            else if (n < 256) e[i.offset++] = 217, e[i.offset++] = n % 255, s = 2;
                            else if (n < 65536) e[i.offset++] = 218, P(e, n, i), s = 3;
                            else if (n < 4294967296) e[i.offset++] = 219, w(e, n, i), s = 5;
                            else throw Error("String too long");
                            return C(e, t, i), s + n
                        },
                        number: function e(t, i, n) {
                            return isNaN(i) ? e(t, 0, n) : isFinite(i) ? i !== (0 | i) ? 34028235e31 >= Math.abs(i) && (I[0] = i, 1e-4 > Math.abs(Math.abs(I[0]) - Math.abs(i))) ? (t[n.offset++] = 202, F(t, i, n), 5) : (t[n.offset++] = 203, j(t, i, n), 9) : i >= 0 ? i < 128 ? (t[n.offset++] = 255 & i, 1) : i < 256 ? (t[n.offset++] = 204, t[n.offset++] = 255 & i, 2) : i < 65536 ? (t[n.offset++] = 205, P(t, i, n), 3) : i < 4294967296 ? (t[n.offset++] = 206, w(t, i, n), 5) : (t[n.offset++] = 207, $(t, i, n), 9) : i >= -32 ? (t[n.offset++] = 224 | i + 32, 1) : i >= -128 ? (t[n.offset++] = 208, R(t, i, n), 2) : i >= -32768 ? (t[n.offset++] = 209, N(t, i, n), 3) : i >= -2147483648 ? (t[n.offset++] = 210, D(t, i, n), 5) : (t[n.offset++] = 211, S(t, i, n), 9) : e(t, i > 0 ? Number.MAX_SAFE_INTEGER : -Number.MAX_SAFE_INTEGER, n)
                        },
                        utf8Write: C,
                        utf8Length: x
                    },
                    _ = new ArrayBuffer(8),
                    k = new Int32Array(_),
                    M = new Float32Array(_),
                    V = new Float64Array(_),
                    B = new BigUint64Array(_),
                    q = new BigInt64Array(_);

                function z(e, t, i) {
                    i > e.length - t.offset && (i = e.length - t.offset);
                    for (var n = "", s = 0, r = t.offset, o = t.offset + i; r < o; r++) {
                        var a = e[r];
                        if ((128 & a) == 0) {
                            n += String.fromCharCode(a);
                            continue
                        }
                        if ((224 & a) == 192) {
                            n += String.fromCharCode((31 & a) << 6 | 63 & e[++r]);
                            continue
                        }
                        if ((240 & a) == 224) {
                            n += String.fromCharCode((15 & a) << 12 | (63 & e[++r]) << 6 | (63 & e[++r]) << 0);
                            continue
                        }
                        if ((248 & a) == 240) {
                            (s = (7 & a) << 18 | (63 & e[++r]) << 12 | (63 & e[++r]) << 6 | (63 & e[++r]) << 0) >= 65536 ? (s -= 65536, n += String.fromCharCode((s >>> 10) + 55296, (1023 & s) + 56320)) : n += String.fromCharCode(s);
                            continue
                        }
                        console.error("decode.utf8Read(): Invalid byte " + a + " at offset " + r + ". Skip to end of string: " + (t.offset + i));
                        break
                    }
                    return t.offset += i, n
                }

                function J(e, t) {
                    return U(e, t) << 24 >> 24
                }

                function U(e, t) {
                    return e[t.offset++]
                }

                function W(e, t) {
                    return Y(e, t) << 16 >> 16
                }

                function Y(e, t) {
                    return e[t.offset++] | e[t.offset++] << 8
                }

                function Z(e, t) {
                    return e[t.offset++] | e[t.offset++] << 8 | e[t.offset++] << 16 | e[t.offset++] << 24
                }

                function G(e, t) {
                    return Z(e, t) >>> 0
                }

                function K(e, t) {
                    return k[0] = Z(e, t), M[0]
                }

                function X(e, t) {
                    return k[0] = Z(e, t), k[1] = Z(e, t), V[0]
                }

                function H(e, t) {
                    let i = G(e, t);
                    return 4294967296 * Z(e, t) + i
                }

                function Q(e, t) {
                    let i = G(e, t);
                    return 4294967296 * G(e, t) + i
                }
                let ee = {
                        utf8Read: z,
                        int8: J,
                        uint8: U,
                        int16: W,
                        uint16: Y,
                        int32: Z,
                        uint32: G,
                        float32: K,
                        float64: X,
                        int64: H,
                        uint64: Q,
                        bigint64: function(e, t) {
                            return k[0] = Z(e, t), k[1] = Z(e, t), q[0]
                        },
                        biguint64: function(e, t) {
                            return k[0] = Z(e, t), k[1] = Z(e, t), B[0]
                        },
                        boolean: function(e, t) {
                            return U(e, t) > 0
                        },
                        string: function(e, t) {
                            let i;
                            let n = e[t.offset++];
                            return n < 192 ? i = 31 & n : 217 === n ? i = U(e, t) : 218 === n ? i = Y(e, t) : 219 === n && (i = G(e, t)), z(e, t, i)
                        },
                        number: function(e, t) {
                            let i = e[t.offset++];
                            if (i < 128) return i;
                            if (202 === i) return K(e, t);
                            if (203 === i) return X(e, t);
                            if (204 === i) return U(e, t);
                            if (205 === i) return Y(e, t);
                            if (206 === i) return G(e, t);
                            if (207 === i) return Q(e, t);
                            else if (208 === i) return J(e, t);
                            else if (209 === i) return W(e, t);
                            else if (210 === i) return Z(e, t);
                            else if (211 === i) return H(e, t);
                            else if (i > 223) return -((255 - i + 1) * 1)
                        },
                        stringCheck: function(e, t) {
                            let i = e[t.offset];
                            return i < 192 && i > 160 || 217 === i || 218 === i || 219 === i
                        }
                    },
                    et = {},
                    ei = new Map;

                function en(e, t) {
                    t.constructor && (ei.set(t.constructor, e), et[e] = t), t.encode && (L[e] = t.encode), t.decode && (ee[e] = t.decode)
                }
                class es {
                    static register(e) {
                        let t = Object.getPrototypeOf(e);
                        if (t !== e_) {
                            let i = es.inheritedTypes.get(t);
                            i || (i = new Set, es.inheritedTypes.set(t, i)), i.add(e)
                        }
                    }
                    static cache(e) {
                        let t = es.cachedContexts.get(e);
                        return t || (t = new es(e), es.cachedContexts.set(e, t)), t
                    }
                    has(e) {
                        return this.schemas.has(e)
                    }
                    get(e) {
                        return this.types[e]
                    }
                    add(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.schemas.size;
                        return !this.schemas.has(e) && (this.types[t] = e, void 0 === e[Symbol.metadata] && eo.initialize(e), this.schemas.set(e, t), !0)
                    }
                    getTypeId(e) {
                        return this.schemas.get(e)
                    }
                    discoverTypes(e, t, i, n) {
                        var s, r, o;
                        if (n && this.registerFilteredByParent(e, t, i), !this.add(e)) return;
                        null === (s = es.inheritedTypes.get(e)) || void 0 === s || s.forEach(e => {
                            this.discoverTypes(e, t, i, n)
                        });
                        let a = e;
                        for (;
                            (a = Object.getPrototypeOf(a)) && a !== e_ && a !== Function.prototype;) this.discoverTypes(a);
                        let l = null !== (o = e[r = Symbol.metadata]) && void 0 !== o ? o : e[r] = {};
                        for (let t in l[E] && (this.hasFilters = !0), l) {
                            let i = l[t].type,
                                s = void 0 !== l[t].tag;
                            if ("string" != typeof i) {
                                if ("function" == typeof i) this.discoverTypes(i, e, t, n || s);
                                else {
                                    let r = Object.values(i)[0];
                                    if ("string" == typeof r) continue;
                                    this.discoverTypes(r, e, t, n || s)
                                }
                            }
                        }
                    }
                    registerFilteredByParent(e, t, i) {
                        var n;
                        let s = null !== (n = this.schemas.get(e)) && void 0 !== n ? n : this.schemas.size,
                            r = "".concat(s);
                        t && (r += "-".concat(this.schemas.get(t))), r += "-".concat(i), this.parentFiltered[r] = !0
                    }
                    debug() {
                        let e = "";
                        for (let t in this.parentFiltered) {
                            let i = t.split("-").map(Number),
                                n = i.pop();
                            e += "\n		" + "".concat(t, ": ").concat(i.reverse().map((e, t) => {
                                let i = this.types[e],
                                    s = i[Symbol.metadata],
                                    r = i.name;
                                return 0 === t && (r += "[".concat(s[n].name, "]")), "".concat(r)
                            }).join(" -> "))
                        }
                        return "TypeContext ->\n" + "	Schema types: ".concat(this.schemas.size, "\n") + "	hasFilters: ".concat(this.hasFilters, "\n") + "	parentFiltered:".concat(e)
                    }
                    constructor(e) {
                        this.types = {}, this.schemas = new Map, this.hasFilters = !1, this.parentFiltered = {}, e && this.discoverTypes(e)
                    }
                }

                function er(e) {
                    if (Array.isArray(e)) return {
                        array: er(e[0])
                    };
                    if (void 0 !== e.type) return e.type;
                    if (function(e) {
                            if ("function" == typeof e && e[Symbol.metadata]) return !1;
                            let t = Object.keys(e),
                                i = t.filter(e => /\d+/.test(e));
                            return !!(i.length > 0 && i.length === t.length / 2 && e[e[i[0]]] == i[0] || t.length > 0 && t.every(t => "string" == typeof e[t] && e[t] === t))
                        }(e)) return Object.keys(e).every(t => "string" == typeof e[t]) ? "string" : "number";
                    if ("object" == typeof e && null !== e) {
                        let t = Object.keys(e).find(e => void 0 !== et[e]);
                        t && (e[t] = er(e[t]))
                    }
                    return e
                }
                es.inheritedTypes = new Map, es.cachedContexts = new Map;
                let eo = {
                    addField(e, t, i, n, s) {
                        if (t > 64) throw Error("Can't define field '".concat(i, "'.\nSchema instances may only have up to 64 fields."));
                        e[t] = Object.assign(e[t] || {}, {
                            type: er(n),
                            index: t,
                            name: i
                        }), Object.defineProperty(e, v, {
                            value: e[v] || {},
                            enumerable: !1,
                            configurable: !0
                        }), s ? (e[v][i] = s, e[v]["_".concat(i)] = {
                            value: void 0,
                            writable: !0,
                            enumerable: !1,
                            configurable: !0
                        }) : e[v][i] = {
                            value: void 0,
                            writable: !0,
                            enumerable: !0,
                            configurable: !0
                        }, Object.defineProperty(e, p, {
                            value: t,
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(e, i, {
                            value: t,
                            enumerable: !1,
                            configurable: !0
                        }), "string" != typeof e[t].type && (void 0 === e[m] && Object.defineProperty(e, m, {
                            value: [],
                            enumerable: !1,
                            configurable: !0
                        }), e[m].push(t))
                    },
                    setTag(e, t, i) {
                        let n = e[t];
                        e[n].tag = i, e[E] || (Object.defineProperty(e, E, {
                            value: [],
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(e, y, {
                            value: {},
                            enumerable: !1,
                            configurable: !0
                        })), e[E].push(n), e[y][i] || (e[y][i] = []), e[y][i].push(n)
                    },
                    setFields(e, t) {
                        var i, n;
                        let s = e.prototype.constructor;
                        es.register(s);
                        let l = Object.getPrototypeOf(s),
                            h = l && l[Symbol.metadata],
                            d = eo.initialize(s);
                        s[r] || (s[r] = e_[r]), s[o] || (s[o] = e_[o]), s[a] || (s[a] = e_[a]), s.prototype.toJSON || (s.prototype.toJSON = e_.prototype.toJSON);
                        let c = null !== (n = null !== (i = d[p]) && void 0 !== i ? i : h && h[p]) && void 0 !== n ? n : -1;
                        for (let e in c++, t) {
                            let i = er(t[e]),
                                n = "string" == typeof Object.keys(i)[0] && et[Object.keys(i)[0]],
                                s = n ? Object.values(i)[0] : i;
                            eo.addField(d, c, e, i, ej("_".concat(e), c, s, n)), c++
                        }
                        return e
                    },
                    isDeprecated: (e, t) => !0 === e[t].deprecated,
                    init(e) {
                        let t = {};
                        e[Symbol.metadata] = t, Object.defineProperty(t, p, {
                            value: 0,
                            enumerable: !1,
                            configurable: !0
                        })
                    },
                    initialize(e) {
                        var t;
                        let i = Object.getPrototypeOf(e),
                            n = i[Symbol.metadata],
                            s = null !== (t = e[Symbol.metadata]) && void 0 !== t ? t : Object.create(null);
                        return i !== e_ && s === n && (s = Object.create(null), n && (Object.setPrototypeOf(s, n), Object.defineProperty(s, p, {
                            value: n[p],
                            enumerable: !1,
                            configurable: !0,
                            writable: !0
                        }), void 0 !== n[E] && (Object.defineProperty(s, E, {
                            value: [...n[E]],
                            enumerable: !1,
                            configurable: !0,
                            writable: !0
                        }), Object.defineProperty(s, y, {
                            value: { ...n[y]
                            },
                            enumerable: !1,
                            configurable: !0,
                            writable: !0
                        })), void 0 !== n[m] && Object.defineProperty(s, m, {
                            value: [...n[m]],
                            enumerable: !1,
                            configurable: !0,
                            writable: !0
                        }), Object.defineProperty(s, v, {
                            value: { ...n[v]
                            },
                            enumerable: !1,
                            configurable: !0,
                            writable: !0
                        }))), Object.defineProperty(e, Symbol.metadata, {
                            value: s,
                            writable: !1,
                            configurable: !0
                        }), s
                    },
                    isValidInstance: e => e.constructor[Symbol.metadata] && Object.prototype.hasOwnProperty.call(e.constructor[Symbol.metadata], p),
                    getFields(e) {
                        let t = e[Symbol.metadata],
                            i = {};
                        for (let e = 0; e <= t[p]; e++) i[t[e].name] = t[e].type;
                        return i
                    },
                    hasViewTagAtIndex(e, t) {
                        var i;
                        return null == e ? void 0 : null === (i = e[E]) || void 0 === i ? void 0 : i.includes(t)
                    }
                };

                function ea(e) {
                    return {
                        indexes: {},
                        operations: [],
                        queueRootNode: e
                    }
                }

                function el() {
                    return {
                        next: void 0,
                        tail: void 0
                    }
                }

                function eh(e, t) {
                    let i = e.indexes[t];
                    void 0 === i ? e.indexes[t] = e.operations.push(t) - 1 : e.operations[i] = t
                }

                function ed(e, t) {
                    let i = e.indexes[t];
                    if (void 0 === i) {
                        var n;
                        i = Object.values(e.indexes).at(-1), t = null === (n = Object.entries(e.indexes).find(e => {
                            let [t, n] = e;
                            return n === i
                        })) || void 0 === n ? void 0 : n[0]
                    }
                    e.operations[i] = void 0, delete e.indexes[t]
                }
                class ec {
                    setRoot(e) {
                        this.root = e;
                        let t = this.root.add(this);
                        this.checkIsFiltered(this.parent, this.parentIndex, t), t && this.forEachChild((t, i) => {
                            t.root !== e ? t.setRoot(e) : e.add(t)
                        })
                    }
                    setParent(e, t, i) {
                        if (this.addParent(e, i), !t) return;
                        let n = t.add(this);
                        t !== this.root && (this.root = t, this.checkIsFiltered(e, i, n)), n && this.forEachChild((e, i) => {
                            if (e.root === t) {
                                t.add(e), t.moveNextToParent(e);
                                return
                            }
                            e.setParent(this.ref, t, i)
                        })
                    }
                    forEachChild(e) {
                        var t, i, n, s;
                        if (this.ref[f]) {
                            if ("string" != typeof this.ref[f])
                                for (let [n, s] of this.ref.entries()) s && e(s[c], null !== (i = null === (t = this.indexes) || void 0 === t ? void 0 : t[n]) && void 0 !== i ? i : n)
                        } else
                            for (let t of null !== (s = null === (n = this.metadata) || void 0 === n ? void 0 : n[m]) && void 0 !== s ? s : []) {
                                let i = this.metadata[t],
                                    n = this.ref[i.name];
                                n && e(n[c], t)
                            }
                    }
                    operation(e) {
                        var t, i;
                        void 0 !== this.filteredChanges ? (this.filteredChanges.operations.push(-e), null === (t = this.root) || void 0 === t || t.enqueueChangeTree(this, "filteredChanges")) : (this.changes.operations.push(-e), null === (i = this.root) || void 0 === i || i.enqueueChangeTree(this, "changes"))
                    }
                    change(t) {
                        var i, n, s;
                        let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e.OPERATION.ADD,
                            o = this.isFiltered || (null === (n = this.metadata) || void 0 === n ? void 0 : null === (i = n[t]) || void 0 === i ? void 0 : i.tag) !== void 0,
                            a = o ? this.filteredChanges : this.changes,
                            l = this.indexedOperations[t];
                        if (!l || l === e.OPERATION.DELETE) {
                            let i = l && l === e.OPERATION.DELETE ? e.OPERATION.DELETE_AND_ADD : r;
                            this.indexedOperations[t] = i
                        }
                        eh(a, t), o ? (eh(this.allFilteredChanges, t), this.root && (this.root.enqueueChangeTree(this, "filteredChanges"), this.root.enqueueChangeTree(this, "allFilteredChanges"))) : (eh(this.allChanges, t), null === (s = this.root) || void 0 === s || s.enqueueChangeTree(this, "changes"))
                    }
                    shiftChangeIndexes(e) {
                        let t = this.isFiltered ? this.filteredChanges : this.changes,
                            i = {},
                            n = {};
                        for (let s in this.indexedOperations) i[Number(s) + e] = this.indexedOperations[s], n[Number(s) + e] = t.indexes[s];
                        this.indexedOperations = i, t.indexes = n, t.operations = t.operations.map(t => t + e)
                    }
                    shiftAllChangeIndexes(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        void 0 !== this.filteredChanges && this._shiftAllChangeIndexes(e, t, this.allFilteredChanges), this._shiftAllChangeIndexes(e, t, this.allChanges)
                    }
                    _shiftAllChangeIndexes(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                            i = arguments.length > 2 ? arguments[2] : void 0,
                            n = {},
                            s = 0;
                        for (let e in i.indexes) n[s++] = i.indexes[e];
                        i.indexes = n;
                        for (let n = 0; n < i.operations.length; n++) {
                            let s = i.operations[n];
                            s > t && (i.operations[n] = s + e)
                        }
                    }
                    indexedOperation(e, t) {
                        var i, n;
                        let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e;
                        this.indexedOperations[e] = t, void 0 !== this.filteredChanges ? (eh(this.allFilteredChanges, s), eh(this.filteredChanges, e), null === (i = this.root) || void 0 === i || i.enqueueChangeTree(this, "filteredChanges")) : (eh(this.allChanges, s), eh(this.changes, e), null === (n = this.root) || void 0 === n || n.enqueueChangeTree(this, "changes"))
                    }
                    getType(e) {
                        return this.ref[f] || this.metadata[e].type
                    }
                    getChange(e) {
                        return this.indexedOperations[e]
                    }
                    getValue(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        return this.ref[h](e, t)
                    }
                    delete(t, i) {
                        var n, s, r;
                        let o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : t;
                        if (void 0 === t) {
                            try {
                                throw Error("@colyseus/schema ".concat(this.ref.constructor.name, ": trying to delete non-existing index '").concat(t, "'"))
                            } catch (e) {
                                console.warn(e)
                            }
                            return
                        }
                        let a = void 0 !== this.filteredChanges ? this.filteredChanges : this.changes;
                        this.indexedOperations[t] = null != i ? i : e.OPERATION.DELETE, eh(a, t), ed(this.allChanges, o);
                        let l = this.getValue(t);
                        return l && l[c] && (null === (n = this.root) || void 0 === n || n.remove(l[c])), void 0 !== this.filteredChanges ? (ed(this.allFilteredChanges, o), null === (s = this.root) || void 0 === s || s.enqueueChangeTree(this, "filteredChanges")) : null === (r = this.root) || void 0 === r || r.enqueueChangeTree(this, "changes"), l
                    }
                    endEncode(e) {
                        var t, i;
                        this.indexedOperations = {}, this[e] = ea(), null === (t = (i = this.ref)[u]) || void 0 === t || t.call(i), this.isNew = !1
                    }
                    discard() {
                        var e, t;
                        let i = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        null === (e = (t = this.ref)[u]) || void 0 === e || e.call(t), this.indexedOperations = {}, this.changes = ea(this.changes.queueRootNode), void 0 !== this.filteredChanges && (this.filteredChanges = ea(this.filteredChanges.queueRootNode)), i && (this.allChanges = ea(this.allChanges.queueRootNode), void 0 !== this.allFilteredChanges && (this.allFilteredChanges = ea(this.allFilteredChanges.queueRootNode)))
                    }
                    discardAll() {
                        let e = Object.keys(this.indexedOperations);
                        for (let t = 0, i = e.length; t < i; t++) {
                            let i = this.getValue(Number(e[t]));
                            i && i[c] && i[c].discardAll()
                        }
                        this.discard()
                    }
                    get changed() {
                        return Object.entries(this.indexedOperations).length > 0
                    }
                    checkIsFiltered(e, t, i) {
                        var n, s, r, o;
                        this.root.types.hasFilters && (this._checkFilteredByParent(e, t), void 0 !== this.filteredChanges && (null === (n = this.root) || void 0 === n || n.enqueueChangeTree(this, "filteredChanges"), i && (null === (s = this.root) || void 0 === s || s.enqueueChangeTree(this, "allFilteredChanges")))), !this.isFiltered && (null === (r = this.root) || void 0 === r || r.enqueueChangeTree(this, "changes"), i && (null === (o = this.root) || void 0 === o || o.enqueueChangeTree(this, "allChanges")))
                    }
                    _checkFilteredByParent(e, t) {
                        let i;
                        if (!e) return;
                        let n = eo.isValidInstance(this.ref) ? this.ref.constructor : this.ref[f],
                            s = !eo.isValidInstance(e);
                        s ? (e = (i = e[c]).parent, t = i.parentIndex) : i = e[c];
                        let r = e.constructor,
                            o = "".concat(this.root.types.getTypeId(n));
                        r && (o += "-".concat(this.root.types.schemas.get(r))), o += "-".concat(t);
                        let a = eo.hasViewTagAtIndex(null == r ? void 0 : r[Symbol.metadata], t);
                        this.isFiltered = e[c].isFiltered || this.root.types.parentFiltered[o] || a, this.isFiltered && (this.isVisibilitySharedWithParent = i.isFiltered && "string" != typeof n && !a && s, this.filteredChanges || (this.filteredChanges = ea(), this.allFilteredChanges = ea()), this.changes.operations.length > 0 && (this.changes.operations.forEach(e => eh(this.filteredChanges, e)), this.allChanges.operations.forEach(e => eh(this.allFilteredChanges, e)), this.changes = ea(), this.allChanges = ea()))
                    }
                    get parent() {
                        var e;
                        return null === (e = this.parentChain) || void 0 === e ? void 0 : e.ref
                    }
                    get parentIndex() {
                        var e;
                        return null === (e = this.parentChain) || void 0 === e ? void 0 : e.index
                    }
                    addParent(e, t) {
                        if (this.hasParent((t, i) => t[c] === e[c])) {
                            this.parentChain.index = t;
                            return
                        }
                        this.parentChain = {
                            ref: e,
                            index: t,
                            next: this.parentChain
                        }
                    }
                    removeParent() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.parent,
                            t = this.parentChain,
                            i = null;
                        for (; t;) {
                            if (t.ref[c] === e[c]) return i ? i.next = t.next : this.parentChain = t.next, !0;
                            i = t, t = t.next
                        }
                        return void 0 === this.parentChain
                    }
                    findParent(e) {
                        let t = this.parentChain;
                        for (; t;) {
                            if (e(t.ref, t.index)) return t;
                            t = t.next
                        }
                    }
                    hasParent(e) {
                        return void 0 !== this.findParent(e)
                    }
                    getAllParents() {
                        let e = [],
                            t = this.parentChain;
                        for (; t;) e.push({
                            ref: t.ref,
                            index: t.index
                        }), t = t.next;
                        return e
                    }
                    constructor(e) {
                        var t;
                        this.isFiltered = !1, this.indexedOperations = {}, this.changes = {
                            indexes: {},
                            operations: []
                        }, this.allChanges = {
                            indexes: {},
                            operations: []
                        }, this.isNew = !0, this.ref = e, this.metadata = e.constructor[Symbol.metadata], (null === (t = this.metadata) || void 0 === t ? void 0 : t[E]) && (this.allFilteredChanges = {
                            indexes: {},
                            operations: []
                        }, this.filteredChanges = {
                            indexes: {},
                            operations: []
                        })
                    }
                }

                function ef(t, i, n, s, r, o) {
                    if ("string" == typeof n) {
                        var a;
                        null === (a = L[n]) || void 0 === a || a.call(L, i, s, o)
                    } else void 0 !== n[Symbol.metadata] ? (L.number(i, s[c].refId, o), (r & e.OPERATION.ADD) === e.OPERATION.ADD && t.tryEncodeTypeId(i, n, s.constructor, o)) : L.number(i, s[c].refId, o)
                }
                let eu = function(t, i, n, s, r, o, a, l, h) {
                        if (i[o.offset++] = (s | r) & 255, r === e.OPERATION.DELETE) return;
                        let d = n.ref,
                            c = h[s];
                        ef(t, i, h[s].type, d[c.name], r, o)
                    },
                    eg = function(t, i, n, s, r, o) {
                        if (i[o.offset++] = 255 & r, L.number(i, s, o), r === e.OPERATION.DELETE) return;
                        let a = n.ref;
                        if ((r & e.OPERATION.ADD) === e.OPERATION.ADD && "function" == typeof a.set) {
                            let e = n.ref.$indexes.get(s);
                            L.string(i, e, o)
                        }
                        ef(t, i, a[f], a[h](s), r, o)
                    },
                    ev = function(t, i, n, s, r, o, a, l) {
                        let h;
                        let d = n.ref;
                        if (l && n.isFiltered && "string" != typeof n.getType(s)) {
                            let t = d.tmpItems[s];
                            if (!t) return;
                            h = t[c].refId, r === e.OPERATION.DELETE ? r = e.OPERATION.DELETE_BY_REFID : r === e.OPERATION.ADD && (r = e.OPERATION.ADD_BY_REFID)
                        } else h = s;
                        i[o.offset++] = 255 & r, L.number(i, h, o), r !== e.OPERATION.DELETE && r !== e.OPERATION.DELETE_BY_REFID && ef(t, i, n.getType(s), n.getValue(s, a), r, o)
                    };

                function ep(t, i, n, s, r, o, a, l) {
                    let c;
                    let u = t.root,
                        g = n[h](s);
                    if ((i & e.OPERATION.DELETE) === e.OPERATION.DELETE) {
                        let t = u.refIds.get(g);
                        void 0 !== t && u.removeRef(t), i !== e.OPERATION.DELETE_AND_ADD && n[d](s), c = void 0
                    }
                    if (i === e.OPERATION.DELETE);
                    else if (e_.is(r)) {
                        let n = ee.number(o, a);
                        if (c = u.refs.get(n), (i & e.OPERATION.ADD) === e.OPERATION.ADD) {
                            let s = t.getInstanceType(o, a, r);
                            c || (c = t.createInstanceOfType(s)), u.addRef(n, c, c !== g || i === e.OPERATION.DELETE_AND_ADD && c === g)
                        }
                    } else if ("string" == typeof r) c = ee[r](o, a);
                    else {
                        let t = et[Object.keys(r)[0]],
                            n = ee.number(o, a),
                            s = u.refs.has(n) ? g || u.refs.get(n) : new t.constructor;
                        if ((c = s.clone(!0))[f] = Object.values(r)[0], g) {
                            let t = u.refIds.get(g);
                            if (void 0 !== t && n !== t) {
                                let i;
                                let n = g.entries();
                                for (;
                                    (i = n.next()) && !i.done;) {
                                    let [n, s] = i.value;
                                    "object" == typeof s && (t = u.refIds.get(s), u.removeRef(t)), l.push({
                                        ref: g,
                                        refId: t,
                                        op: e.OPERATION.DELETE,
                                        field: n,
                                        value: void 0,
                                        previousValue: s
                                    })
                                }
                            }
                        }
                        u.addRef(n, c, s !== g || i === e.OPERATION.DELETE_AND_ADD && s === g)
                    }
                    return {
                        value: c,
                        previousValue: g
                    }
                }
                let em = function(e, t, i, n, s) {
                        let r = t[i.offset++],
                            o = n.constructor[Symbol.metadata],
                            a = r >> 6 << 6,
                            l = r % (a || 255),
                            h = o[l];
                        if (void 0 === h) return console.warn("@colyseus/schema: field not defined at", {
                            index: l,
                            ref: n.constructor.name,
                            metadata: o
                        }), -1;
                        let {
                            value: d,
                            previousValue: c
                        } = ep(e, a, n, l, h.type, t, i, s);
                        null != d && (n[h.name] = d), c !== d && s.push({
                            ref: n,
                            refId: e.currentRefId,
                            op: a,
                            field: h.name,
                            value: d,
                            previousValue: c
                        })
                    },
                    eE = function(t, i, n, s, r) {
                        let o;
                        let a = i[n.offset++];
                        if (a === e.OPERATION.CLEAR) {
                            t.removeChildRefs(s, r), s.clear();
                            return
                        }
                        let l = ee.number(i, n),
                            h = s[f];
                        (a & e.OPERATION.ADD) === e.OPERATION.ADD ? "function" == typeof s.set ? (o = ee.string(i, n), s.setIndex(l, o)) : o = l : o = s.getIndex(l);
                        let {
                            value: d,
                            previousValue: c
                        } = ep(t, a, s, l, h, i, n, r);
                        if (null != d) {
                            if ("function" == typeof s.set) s.$items.set(o, d);
                            else if ("function" == typeof s.$setAt) s.$setAt(l, d, a);
                            else if ("function" == typeof s.add) {
                                let e = s.add(d);
                                "number" == typeof e && s.setIndex(e, e)
                            }
                        }
                        c !== d && r.push({
                            ref: s,
                            refId: t.currentRefId,
                            op: a,
                            field: "",
                            dynamicIndex: o,
                            value: d,
                            previousValue: c
                        })
                    };
                class ey extends Error {}

                function eb(e, t, i, n) {
                    if (!(e instanceof t)) throw new ey("a '".concat(t.name, "' was expected, but '").concat(e && e.constructor.name, "' was provided in ").concat(i.constructor.name, "#").concat(n))
                }
                let eO = (e, t) => {
                        let i = e.toString(),
                            n = t.toString();
                        return i < n ? -1 : i > n ? 1 : 0
                    },
                    eI = Symbol.iterator,
                    eA = Symbol.species;
                class eT {
                    static[l](e, t, i) {
                        var n;
                        return !i || "string" == typeof e[f] || i.isChangeTreeVisible(null === (n = e.tmpItems[t]) || void 0 === n ? void 0 : n[c])
                    }
                    static is(e) {
                        return Array.isArray(e) || void 0 !== e.array
                    }
                    static from(e) {
                        return new eT(...Array.from(e))
                    }
                    set length(e) {
                        0 === e ? this.clear() : e < this.items.length ? this.splice(e, this.length - e) : console.warn("ArraySchema: can't set .length to a higher value than its length.")
                    }
                    get length() {
                        return this.items.length
                    }
                    push() {
                        for (var t, i = arguments.length, n = Array(i), s = 0; s < i; s++) n[s] = arguments[s];
                        let r = this.tmpItems.length,
                            o = this[c];
                        for (let i = 0, s = n.length; i < s; i++, r++) {
                            let s = n[i];
                            if (null == s) return;
                            "object" == typeof s && this[f] && eb(s, this[f], this, i), o.indexedOperation(r, e.OPERATION.ADD, this.items.length), this.items.push(s), this.tmpItems.push(s), null === (t = s[c]) || void 0 === t || t.setParent(this, o.root, r)
                        }
                        return r
                    }
                    pop() {
                        let e = -1;
                        for (let t = this.tmpItems.length - 1; t >= 0; t--)
                            if (!0 !== this.deletedIndexes[t]) {
                                e = t;
                                break
                            }
                        if (!(e < 0)) return this[c].delete(e, void 0, this.items.length - 1), this.deletedIndexes[e] = !0, this.items.pop()
                    }
                    at(e) {
                        return e < 0 && (e += this.length), this.items[e]
                    }
                    $changeAt(t, i) {
                        var n;
                        if (null == i) {
                            console.error("ArraySchema items cannot be null nor undefined; Use `deleteAt(index)` instead.");
                            return
                        }
                        if (this.items[t] === i) return;
                        let s = void 0 !== this.items[t] ? "object" == typeof i ? e.OPERATION.DELETE_AND_ADD : e.OPERATION.REPLACE : e.OPERATION.ADD,
                            r = this[c];
                        r.change(t, s), null === (n = i[c]) || void 0 === n || n.setParent(this, r.root, t)
                    }
                    $deleteAt(e, t) {
                        this[c].delete(e, t)
                    }
                    $setAt(t, i, n) {
                        0 === t && n === e.OPERATION.ADD && void 0 !== this.items[t] ? this.items.unshift(i) : (n === e.OPERATION.DELETE_AND_MOVE && this.items.splice(t, 1), this.items[t] = i)
                    }
                    clear() {
                        if (0 === this.items.length) return;
                        let t = this[c];
                        t.forEachChild((e, i) => {
                            var n;
                            null === (n = t.root) || void 0 === n || n.remove(e)
                        }), t.discard(!0), t.operation(e.OPERATION.CLEAR), this.items.length = 0, this.tmpItems.length = 0
                    }
                    concat() {
                        for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                        return new eT(...this.items.concat(...t))
                    }
                    join(e) {
                        return this.items.join(e)
                    }
                    reverse() {
                        return this[c].operation(e.OPERATION.REVERSE), this.items.reverse(), this.tmpItems.reverse(), this
                    }
                    shift() {
                        if (0 === this.items.length) return;
                        let t = this[c],
                            i = this.tmpItems.findIndex(e => e === this.items[0]),
                            n = this.items.findIndex(e => e === this.items[0]);
                        return t.delete(i, e.OPERATION.DELETE, n), t.shiftAllChangeIndexes(-1, n), this.deletedIndexes[i] = !0, this.items.shift()
                    }
                    slice(e, t) {
                        let i = new eT;
                        return i.push(...this.items.slice(e, t)), i
                    }
                    sort() {
                        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : eO;
                        this.isMovingItems = !0;
                        let i = this[c];
                        return this.items.sort(t).forEach((t, n) => i.change(n, e.OPERATION.REPLACE)), this.tmpItems.sort(t), this.isMovingItems = !1, this
                    }
                    splice(t, i) {
                        for (var n, s, r, o, a = arguments.length, l = Array(a > 2 ? a - 2 : 0), h = 2; h < a; h++) l[h - 2] = arguments[h];
                        let d = this[c],
                            f = this.items.length,
                            u = this.tmpItems.length,
                            g = l.length,
                            v = [];
                        for (let e = 0; e < u; e++) !0 !== this.deletedIndexes[e] && v.push(e);
                        if (f > t) {
                            void 0 === i && (i = f - t);
                            for (let n = t; n < t + i; n++) {
                                let t = v[n];
                                d.delete(t, e.OPERATION.DELETE), this.deletedIndexes[t] = !0
                            }
                        } else i = 0;
                        if (g > 0) {
                            if (g > i) throw console.error("Inserting more elements than deleting during ArraySchema#splice()"), Error("ArraySchema#splice(): insertCount must be equal or lower than deleteCount.");
                            for (let i = 0; i < g; i++) {
                                let r = (null !== (s = v[t]) && void 0 !== s ? s : f) + i;
                                d.indexedOperation(r, this.deletedIndexes[r] ? e.OPERATION.DELETE_AND_ADD : e.OPERATION.ADD), null === (n = l[i][c]) || void 0 === n || n.setParent(this, d.root, r)
                            }
                        }
                        return i > g && d.shiftAllChangeIndexes(-(i - g), v[t + g]), void 0 !== d.filteredChanges ? null === (r = d.root) || void 0 === r || r.enqueueChangeTree(d, "filteredChanges") : null === (o = d.root) || void 0 === o || o.enqueueChangeTree(d, "changes"), this.items.splice(t, i, ...l)
                    }
                    unshift() {
                        for (var t = arguments.length, i = Array(t), n = 0; n < t; n++) i[n] = arguments[n];
                        let s = this[c];
                        return s.shiftChangeIndexes(i.length), s.isFiltered ? eh(s.filteredChanges, this.items.length) : eh(s.allChanges, this.items.length), i.forEach((t, i) => {
                            s.change(i, e.OPERATION.ADD)
                        }), this.tmpItems.unshift(...i), this.items.unshift(...i)
                    }
                    indexOf(e, t) {
                        return this.items.indexOf(e, t)
                    }
                    lastIndexOf(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.length - 1;
                        return this.items.lastIndexOf(e, t)
                    }
                    every(e, t) {
                        return this.items.every(e, t)
                    }
                    some(e, t) {
                        return this.items.some(e, t)
                    }
                    forEach(e, t) {
                        return this.items.forEach(e, t)
                    }
                    map(e, t) {
                        return this.items.map(e, t)
                    }
                    filter(e, t) {
                        return this.items.filter(e, t)
                    }
                    reduce(e, t) {
                        return this.items.reduce(e, t)
                    }
                    reduceRight(e, t) {
                        return this.items.reduceRight(e, t)
                    }
                    find(e, t) {
                        return this.items.find(e, t)
                    }
                    findIndex(e, t) {
                        return this.items.findIndex(e, t)
                    }
                    fill(e, t, i) {
                        throw Error("ArraySchema#fill() not implemented")
                    }
                    copyWithin(e, t, i) {
                        throw Error("ArraySchema#copyWithin() not implemented")
                    }
                    toString() {
                        return this.items.toString()
                    }
                    toLocaleString() {
                        return this.items.toLocaleString()
                    }[eI]() {
                        return this.items[Symbol.iterator]()
                    }
                    static get[eA]() {
                        return eT
                    }
                    entries() {
                        return this.items.entries()
                    }
                    keys() {
                        return this.items.keys()
                    }
                    values() {
                        return this.items.values()
                    }
                    includes(e, t) {
                        return this.items.includes(e, t)
                    }
                    flatMap(e, t) {
                        throw Error("ArraySchema#flatMap() is not supported.")
                    }
                    flat(e) {
                        throw Error("ArraySchema#flat() is not supported.")
                    }
                    findLast() {
                        return this.items.findLast.apply(this.items, arguments)
                    }
                    findLastIndex() {
                        for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                        return this.items.findLastIndex.apply(this.items, arguments)
                    }
                    with(e, t) {
                        let i = this.items.slice();
                        return e < 0 && (e += this.length), i[e] = t, new eT(...i)
                    }
                    toReversed() {
                        return this.items.slice().reverse()
                    }
                    toSorted(e) {
                        return this.items.slice().sort(e)
                    }
                    toSpliced(e, t) {
                        for (var i = arguments.length, n = Array(i > 2 ? i - 2 : 0), s = 2; s < i; s++) n[s - 2] = arguments[s];
                        return this.items.toSpliced.apply(copy, arguments)
                    }
                    shuffle() {
                        return this.move(e => {
                            let t = this.items.length;
                            for (; 0 != t;) {
                                let e = Math.floor(Math.random() * t);
                                t--, [this[t], this[e]] = [this[e], this[t]]
                            }
                        })
                    }
                    move(e) {
                        return this.isMovingItems = !0, e(this), this.isMovingItems = !1, this
                    }[h](e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        return t ? this.items[e] : this.deletedIndexes[e] ? this.items[e] : this.tmpItems[e] || this.items[e]
                    }[d](e) {
                        this.items[e] = void 0, this.tmpItems[e] = void 0
                    }[u]() {
                        this.tmpItems = this.items.slice(), this.deletedIndexes = {}
                    }[g]() {
                        this.items = this.items.filter(e => void 0 !== e), this.tmpItems = this.items.slice()
                    }
                    toArray() {
                        return this.items.slice(0)
                    }
                    toJSON() {
                        return this.toArray().map(e => "function" == typeof e.toJSON ? e.toJSON() : e)
                    }
                    clone(e) {
                        let t;
                        return e ? (t = new eT).push(...this.items) : t = new eT(...this.map(e => e[c] ? e.clone() : e)), t
                    }
                    constructor(...t) {
                        this.items = [], this.tmpItems = [], this.deletedIndexes = {}, this.isMovingItems = !1, Object.defineProperty(this, f, {
                            value: void 0,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        });
                        let i = new Proxy(this, {
                            get: (e, t) => "symbol" == typeof t || isNaN(t) ? Reflect.get(e, t) : this.items[t],
                            set: (t, i, n) => {
                                if ("symbol" == typeof i || isNaN(i)) return Reflect.set(t, i, n);
                                if (null == n) t.$deleteAt(i);
                                else {
                                    if (n[c]) {
                                        eb(n, t[f], t, i);
                                        let r = t.items[i];
                                        if (t.isMovingItems ? (void 0 !== r ? n[c].isNew ? t[c].indexedOperation(Number(i), e.OPERATION.MOVE_AND_ADD) : (t[c].getChange(Number(i)) & e.OPERATION.DELETE) === e.OPERATION.DELETE ? t[c].indexedOperation(Number(i), e.OPERATION.DELETE_AND_MOVE) : t[c].indexedOperation(Number(i), e.OPERATION.MOVE) : n[c].isNew && t[c].indexedOperation(Number(i), e.OPERATION.ADD), n[c].setParent(this, t[c].root, i)) : t.$changeAt(Number(i), n), void 0 !== r) {
                                            var s;
                                            null === (s = r[c].root) || void 0 === s || s.remove(r[c])
                                        }
                                    } else t.$changeAt(Number(i), n);
                                    t.items[i] = n, t.tmpItems[i] = n
                                }
                                return !0
                            },
                            deleteProperty: (e, t) => ("number" == typeof t ? e.$deleteAt(t) : delete e[t], !0),
                            has: (e, t) => "symbol" == typeof t || isNaN(Number(t)) ? Reflect.has(e, t) : Reflect.has(this.items, t)
                        });
                        return Object.defineProperty(this, c, {
                            value: new ec(i),
                            enumerable: !1,
                            writable: !0
                        }), t.length > 0 && this.push(...t), i
                    }
                }
                eT[o] = ev, eT[a] = function(t, i, n, s, r) {
                    let o, a = i[n.offset++];
                    if (a === e.OPERATION.CLEAR) {
                        t.removeChildRefs(s, r), s.clear();
                        return
                    }
                    if (a === e.OPERATION.REVERSE) {
                        s.reverse();
                        return
                    }
                    if (a === e.OPERATION.DELETE_BY_REFID) {
                        let a = ee.number(i, n),
                            l = t.root.refs.get(a);
                        o = s.findIndex(e => e === l), s[d](o), r.push({
                            ref: s,
                            refId: t.currentRefId,
                            op: e.OPERATION.DELETE,
                            field: "",
                            dynamicIndex: o,
                            value: void 0,
                            previousValue: l
                        });
                        return
                    }
                    if (a === e.OPERATION.ADD_BY_REFID) {
                        let e = ee.number(i, n),
                            r = t.root.refs.get(e);
                        r && (o = s.findIndex(e => e === r)), (-1 === o || void 0 === o) && (o = s.length)
                    } else o = ee.number(i, n);
                    let l = s[f],
                        h = o,
                        {
                            value: c,
                            previousValue: u
                        } = ep(t, a, s, o, l, i, n, r);
                    null != c && c !== u && s.$setAt(o, c, a), u !== c && r.push({
                        ref: s,
                        refId: t.currentRefId,
                        op: a,
                        field: "",
                        dynamicIndex: h,
                        value: c,
                        previousValue: u
                    })
                }, en("array", {
                    constructor: eT
                });
                let ex = Symbol.iterator,
                    eC = Symbol.toStringTag,
                    eR = Symbol.species;
                class eN {
                    static[l](e, t, i) {
                        var n;
                        return !i || "string" == typeof e[f] || i.isChangeTreeVisible((null !== (n = e[h](t)) && void 0 !== n ? n : e.deletedItems[t])[c])
                    }
                    static is(e) {
                        return void 0 !== e.map
                    }[ex]() {
                        return this.$items[Symbol.iterator]()
                    }
                    get[eC]() {
                        return this.$items[Symbol.toStringTag]
                    }
                    static get[eR]() {
                        return eN
                    }
                    set(t, i) {
                        var n, s;
                        let r, o;
                        if (null == i) throw Error("MapSchema#set('".concat(t, "', ").concat(i, "): trying to set ").concat(i, " value on '").concat(t, "'."));
                        "object" == typeof i && this[f] && eb(i, this[f], this, t), t = t.toString();
                        let a = this[c],
                            l = void 0 !== i[c];
                        if (void 0 !== a.indexes[t]) {
                            r = a.indexes[t], o = e.OPERATION.REPLACE;
                            let s = this.$items.get(t);
                            if (s === i) return;
                            l && (o = e.OPERATION.DELETE_AND_ADD, void 0 !== s && (null === (n = s[c].root) || void 0 === n || n.remove(s[c]))), this.deletedItems[r] && delete this.deletedItems[r]
                        } else r = null !== (s = a.indexes[p]) && void 0 !== s ? s : 0, o = e.OPERATION.ADD, this.$indexes.set(r, t), a.indexes[t] = r, a.indexes[p] = r + 1;
                        return this.$items.set(t, i), a.change(r, o), l && i[c].setParent(this, a.root, r), this
                    }
                    get(e) {
                        return this.$items.get(e)
                    }
                    delete(e) {
                        if (!this.$items.has(e)) return !1;
                        let t = this[c].indexes[e];
                        return this.deletedItems[t] = this[c].delete(t), this.$items.delete(e)
                    }
                    clear() {
                        let t = this[c];
                        t.discard(!0), t.indexes = {}, t.forEachChild((e, i) => {
                            var n;
                            null === (n = t.root) || void 0 === n || n.remove(e)
                        }), this.$indexes.clear(), this.$items.clear(), t.operation(e.OPERATION.CLEAR)
                    }
                    has(e) {
                        return this.$items.has(e)
                    }
                    forEach(e) {
                        this.$items.forEach(e)
                    }
                    entries() {
                        return this.$items.entries()
                    }
                    keys() {
                        return this.$items.keys()
                    }
                    values() {
                        return this.$items.values()
                    }
                    get size() {
                        return this.$items.size
                    }
                    setIndex(e, t) {
                        this.$indexes.set(e, t)
                    }
                    getIndex(e) {
                        return this.$indexes.get(e)
                    }[h](e) {
                        return this.$items.get(this.$indexes.get(e))
                    }[d](e) {
                        let t = this.$indexes.get(e);
                        this.$items.delete(t), this.$indexes.delete(e)
                    }[u]() {
                        let e = this[c];
                        for (let t in this.deletedItems) {
                            let i = parseInt(t),
                                n = this.$indexes.get(i);
                            delete e.indexes[n], this.$indexes.delete(i)
                        }
                        this.deletedItems = {}
                    }
                    toJSON() {
                        let e = {};
                        return this.forEach((t, i) => {
                            e[i] = "function" == typeof t.toJSON ? t.toJSON() : t
                        }), e
                    }
                    clone(e) {
                        let t;
                        return e ? t = Object.assign(new eN, this) : (t = new eN, this.forEach((e, i) => {
                            e[c] ? t.set(i, e.clone()) : t.set(i, e)
                        })), t
                    }
                    constructor(e) {
                        this.$items = new Map, this.$indexes = new Map, this.deletedItems = {};
                        let t = new ec(this);
                        if (t.indexes = {}, Object.defineProperty(this, c, {
                                value: t,
                                enumerable: !1,
                                writable: !0
                            }), e) {
                            if (e instanceof Map || e instanceof eN) e.forEach((e, t) => this.set(t, e));
                            else
                                for (let t in e) this.set(t, e[t])
                        }
                        Object.defineProperty(this, f, {
                            value: void 0,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        })
                    }
                }
                eN[o] = eg, eN[a] = eE, en("map", {
                    constructor: eN
                });
                let eP = Symbol.iterator;
                class eD {
                    static[l](e, t, i) {
                        var n;
                        return !i || "string" == typeof e[f] || i.isChangeTreeVisible((null !== (n = e[h](t)) && void 0 !== n ? n : e.deletedItems[t])[c])
                    }
                    static is(e) {
                        return void 0 !== e.collection
                    }
                    add(e) {
                        let t = this.$refId++;
                        return void 0 !== e[c] && e[c].setParent(this, this[c].root, t), this[c].indexes[t] = t, this.$indexes.set(t, t), this.$items.set(t, e), this[c].change(t), t
                    }
                    at(e) {
                        let t = Array.from(this.$items.keys())[e];
                        return this.$items.get(t)
                    }
                    entries() {
                        return this.$items.entries()
                    }
                    delete(e) {
                        let t, i;
                        let n = this.$items.entries();
                        for (;
                            (i = n.next()) && !i.done;)
                            if (e === i.value[1]) {
                                t = i.value[0];
                                break
                            }
                        return void 0 !== t && (this.deletedItems[t] = this[c].delete(t), this.$indexes.delete(t), this.$items.delete(t))
                    }
                    clear() {
                        let t = this[c];
                        t.discard(!0), t.indexes = {}, t.forEachChild((e, i) => {
                            var n;
                            null === (n = t.root) || void 0 === n || n.remove(e)
                        }), this.$indexes.clear(), this.$items.clear(), t.operation(e.OPERATION.CLEAR)
                    }
                    has(e) {
                        return Array.from(this.$items.values()).some(t => t === e)
                    }
                    forEach(e) {
                        this.$items.forEach((t, i, n) => e(t, i, this))
                    }
                    values() {
                        return this.$items.values()
                    }
                    get size() {
                        return this.$items.size
                    }[eP]() {
                        return this.$items.values()
                    }
                    setIndex(e, t) {
                        this.$indexes.set(e, t)
                    }
                    getIndex(e) {
                        return this.$indexes.get(e)
                    }[h](e) {
                        return this.$items.get(this.$indexes.get(e))
                    }[d](e) {
                        let t = this.$indexes.get(e);
                        this.$items.delete(t), this.$indexes.delete(e)
                    }[u]() {
                        this.deletedItems = {}
                    }
                    toArray() {
                        return Array.from(this.$items.values())
                    }
                    toJSON() {
                        let e = [];
                        return this.forEach((t, i) => {
                            e.push("function" == typeof t.toJSON ? t.toJSON() : t)
                        }), e
                    }
                    clone(e) {
                        let t;
                        return e ? t = Object.assign(new eD, this) : (t = new eD, this.forEach(e => {
                            e[c] ? t.add(e.clone()) : t.add(e)
                        })), t
                    }
                    constructor(e) {
                        this.$items = new Map, this.$indexes = new Map, this.deletedItems = {}, this.$refId = 0, this[c] = new ec(this), this[c].indexes = {}, e && e.forEach(e => this.add(e)), Object.defineProperty(this, f, {
                            value: void 0,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        })
                    }
                }
                eD[o] = eg, eD[a] = eE, en("collection", {
                    constructor: eD
                });
                let ew = Symbol.iterator;
                class eS {
                    static[l](e, t, i) {
                        var n;
                        return !i || "string" == typeof e[f] || i.visible.has((null !== (n = e[h](t)) && void 0 !== n ? n : e.deletedItems[t])[c])
                    }
                    static is(e) {
                        return void 0 !== e.set
                    }
                    add(t) {
                        var i, n;
                        if (this.has(t)) return !1;
                        let s = this.$refId++;
                        void 0 !== t[c] && t[c].setParent(this, this[c].root, s);
                        let r = null !== (n = null === (i = this[c].indexes[s]) || void 0 === i ? void 0 : i.op) && void 0 !== n ? n : e.OPERATION.ADD;
                        return this[c].indexes[s] = s, this.$indexes.set(s, s), this.$items.set(s, t), this[c].change(s, r), s
                    }
                    entries() {
                        return this.$items.entries()
                    }
                    delete(e) {
                        let t, i;
                        let n = this.$items.entries();
                        for (;
                            (i = n.next()) && !i.done;)
                            if (e === i.value[1]) {
                                t = i.value[0];
                                break
                            }
                        return void 0 !== t && (this.deletedItems[t] = this[c].delete(t), this.$indexes.delete(t), this.$items.delete(t))
                    }
                    clear() {
                        let t = this[c];
                        t.discard(!0), t.indexes = {}, this.$indexes.clear(), this.$items.clear(), t.operation(e.OPERATION.CLEAR)
                    }
                    has(e) {
                        let t;
                        let i = this.$items.values(),
                            n = !1;
                        for (;
                            (t = i.next()) && !t.done;)
                            if (e === t.value) {
                                n = !0;
                                break
                            }
                        return n
                    }
                    forEach(e) {
                        this.$items.forEach((t, i, n) => e(t, i, this))
                    }
                    values() {
                        return this.$items.values()
                    }
                    get size() {
                        return this.$items.size
                    }[ew]() {
                        return this.$items.values()
                    }
                    setIndex(e, t) {
                        this.$indexes.set(e, t)
                    }
                    getIndex(e) {
                        return this.$indexes.get(e)
                    }[h](e) {
                        return this.$items.get(this.$indexes.get(e))
                    }[d](e) {
                        let t = this.$indexes.get(e);
                        this.$items.delete(t), this.$indexes.delete(e)
                    }[u]() {
                        this.deletedItems = {}
                    }
                    toArray() {
                        return Array.from(this.$items.values())
                    }
                    toJSON() {
                        let e = [];
                        return this.forEach((t, i) => {
                            e.push("function" == typeof t.toJSON ? t.toJSON() : t)
                        }), e
                    }
                    clone(e) {
                        let t;
                        return e ? t = Object.assign(new eS, this) : (t = new eS, this.forEach(e => {
                            e[c] ? t.add(e.clone()) : t.add(e)
                        })), t
                    }
                    constructor(e) {
                        this.$items = new Map, this.$indexes = new Map, this.deletedItems = {}, this.$refId = 0, this[c] = new ec(this), this[c].indexes = {}, e && e.forEach(e => this.add(e)), Object.defineProperty(this, f, {
                            value: void 0,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        })
                    }
                }

                function e$() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1;
                    return function(t, i) {
                        var n, s;
                        let r = t.constructor,
                            o = Object.getPrototypeOf(r)[Symbol.metadata],
                            a = null !== (s = r[n = Symbol.metadata]) && void 0 !== s ? s : r[n] = Object.assign({}, r[Symbol.metadata], null != o ? o : Object.create(null));
                        eo.setTag(a, i, e)
                    }
                }

                function eF(e, t) {
                    return function(i, n) {
                        let s = i.constructor;
                        if (!e) throw Error("".concat(s.name, ': @type() reference provided for "').concat(n, "\" is undefined. Make sure you don't have any circular dependencies."));
                        e = er(e), es.register(s);
                        let r = Object.getPrototypeOf(s)[Symbol.metadata],
                            o = eo.initialize(s),
                            a = o[n];
                        if (void 0 !== o[a]) {
                            if (o[a].deprecated) return;
                            if (void 0 !== o[a].type) try {
                                throw Error("@colyseus/schema: Duplicate '".concat(n, "' definition on '").concat(s.name, "'.\nCheck @type() annotation"))
                            } catch (t) {
                                let e = t.stack.split("\n")[4].trim();
                                throw Error("".concat(t.message, " ").concat(e))
                            }
                        } else {
                            var l, h;
                            a = null !== (h = null !== (l = o[p]) && void 0 !== l ? l : r && r[p]) && void 0 !== h ? h : -1, a++
                        }
                        if (t && t.manual) eo.addField(o, a, n, e, {
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        });
                        else {
                            let t = "string" == typeof Object.keys(e)[0] && et[Object.keys(e)[0]],
                                i = t ? Object.values(e)[0] : e;
                            eo.addField(o, a, n, e, ej("_".concat(n), a, i, t))
                        }
                    }
                }

                function ej(t, i, n, s) {
                    return {
                        get: function() {
                            return this[t]
                        },
                        set: function(o) {
                            var a, l, h;
                            let d = null !== (a = this[t]) && void 0 !== a ? a : void 0;
                            if (o !== d) {
                                if (null != o) {
                                    s ? (s.constructor !== eT || o instanceof eT || (o = new eT(...o)), s.constructor !== eN || o instanceof eN || (o = new eN(o)), o[f] = n) : "string" != typeof n ? eb(o, n, this, t.substring(1)) : function(e, t, i, n) {
                                        let s;
                                        let r = !1;
                                        switch (t) {
                                            case "number":
                                            case "int8":
                                            case "uint8":
                                            case "int16":
                                            case "uint16":
                                            case "int32":
                                            case "uint32":
                                            case "int64":
                                            case "uint64":
                                            case "float32":
                                            case "float64":
                                                s = "number", isNaN(e) && console.log('trying to encode "NaN" in '.concat(i.constructor.name, "#").concat(n));
                                                break;
                                            case "bigint64":
                                            case "biguint64":
                                                s = "bigint";
                                                break;
                                            case "string":
                                                s = "string", r = !0;
                                                break;
                                            default:
                                                return
                                        }
                                        if (typeof e !== s && (!r || r && null !== e)) {
                                            let t = "'".concat(JSON.stringify(e), "'").concat(e && e.constructor && " (".concat(e.constructor.name, ")") || "");
                                            throw new ey("a '".concat(s, "' was expected, but ").concat(t, " was provided in ").concat(i.constructor.name, "#").concat(n))
                                        }
                                    }(o, n, this, t.substring(1));
                                    let a = this[c];
                                    void 0 !== d && d[c] ? (null === (h = a.root) || void 0 === h || h.remove(d[c]), this.constructor[r](a, i, e.OPERATION.DELETE_AND_ADD)) : this.constructor[r](a, i, e.OPERATION.ADD), null === (l = o[c]) || void 0 === l || l.setParent(this, a.root, i)
                                } else void 0 !== d && this[c].delete(i);
                                this[t] = o
                            }
                        },
                        enumerable: !0,
                        configurable: !0
                    }
                }

                function eL(e) {
                    return Array(e).fill(0).map((t, i) => i === e - 1 ? "└─ " : "   ").join("")
                }
                eS[o] = eg, eS[a] = eE, en("set", {
                    constructor: eS
                });
                class e_ {
                    static initialize(e) {
                        var t;
                        Object.defineProperty(e, c, {
                            value: new ec(e),
                            enumerable: !1,
                            writable: !0
                        }), Object.defineProperties(e, (null === (t = e.constructor[Symbol.metadata]) || void 0 === t ? void 0 : t[v]) || {})
                    }
                    static is(e) {
                        return "object" == typeof e[Symbol.metadata]
                    }
                    static[r](t, i) {
                        let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e.OPERATION.ADD;
                        t.change(i, n)
                    }
                    static[l](e, t, i) {
                        var n, s;
                        let r = null === (n = e.constructor[Symbol.metadata][t]) || void 0 === n ? void 0 : n.tag;
                        if (void 0 === i) return void 0 === r;
                        if (void 0 === r) return !0;
                        if (-1 === r) return i.isChangeTreeVisible(e[c]); {
                            let t = null === (s = i.tags) || void 0 === s ? void 0 : s.get(e[c]);
                            return t && t.has(r)
                        }
                    }
                    assign(e) {
                        return Object.assign(this, e), this
                    }
                    setDirty(e, t) {
                        let i = this.constructor[Symbol.metadata];
                        this[c].change(i[i[e]].index, t)
                    }
                    clone() {
                        let e = Object.create(this.constructor.prototype);
                        e_.initialize(e);
                        let t = this.constructor[Symbol.metadata];
                        for (let n in t) {
                            var i;
                            let s = t[n].name;
                            "object" == typeof this[s] && "function" == typeof(null === (i = this[s]) || void 0 === i ? void 0 : i.clone) ? e[s] = this[s].clone() : e[s] = this[s]
                        }
                        return e
                    }
                    toJSON() {
                        let e = {},
                            t = this.constructor[Symbol.metadata];
                        for (let i in t) {
                            let n = t[i],
                                s = n.name;
                            n.deprecated || null === this[s] || void 0 === this[s] || (e[s] = "function" == typeof this[s].toJSON ? this[s].toJSON() : this[s])
                        }
                        return e
                    }
                    discardAllChanges() {
                        this[c].discardAll()
                    }[h](e) {
                        return this[this.constructor[Symbol.metadata][e].name]
                    }[d](e) {
                        this[this.constructor[Symbol.metadata][e].name] = void 0
                    }
                    static debugRefIds(e) {
                        var t;
                        let i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                            n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                            s = arguments.length > 3 ? arguments[3] : void 0,
                            r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "",
                            o = i ? " - ".concat(JSON.stringify(e.toJSON())) : "",
                            a = e[c],
                            l = s ? s.root.refIds.get(e) : a.refId,
                            h = s ? s.root : a.root,
                            d = (null == h ? void 0 : null === (t = h.refCount) || void 0 === t ? void 0 : t[l]) > 1 ? " [\xd7".concat(h.refCount[l], "]") : "",
                            f = "".concat(eL(n)).concat(r).concat(e.constructor.name, " (refId: ").concat(l, ")").concat(d).concat(o, "\n");
                        return a.forEachChild((t, r) => {
                            let o = r;
                            if ("number" == typeof r && e.$indexes) {
                                var a;
                                o = null !== (a = e.$indexes.get(r)) && void 0 !== a ? a : r
                            }
                            let l = void 0 !== e.forEach && void 0 !== o ? '["'.concat(o, '"]: ') : "";
                            f += this.debugRefIds(t.ref, i, n + 1, s, l)
                        }), f
                    }
                    static debugRefIdEncodingOrder(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "allChanges",
                            i = [],
                            n = e[c].root[t].next;
                        for (; n;) n.changeTree && i.push(n.changeTree.refId), n = n.next;
                        return i
                    }
                    static debugRefIdsFromDecoder(e) {
                        return this.debugRefIds(e.state, !1, 0, e)
                    }
                    static debugChanges(t) {
                        let i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                            n = t[c],
                            s = i ? n.allChanges : n.changes,
                            r = "".concat(t.constructor.name, " (").concat(n.refId, ") -> .").concat(i ? "allChanges" : "changes", ":\n");

                        function o(t) {
                            t.operations.filter(e => e).forEach(t => {
                                let s = n.indexedOperations[t];
                                r += "- [".concat(t, "]: ").concat(e.OPERATION[s], " (").concat(JSON.stringify(n.getValue(Number(t), i)), ")\n")
                            })
                        }
                        return o(s), !i && n.filteredChanges && n.filteredChanges.operations.filter(e => e).length > 0 && (r += "".concat(t.constructor.name, " (").concat(n.refId, ") -> .filteredChanges:\n"), o(n.filteredChanges)), i && n.allFilteredChanges && n.allFilteredChanges.operations.filter(e => e).length > 0 && (r += "".concat(t.constructor.name, " (").concat(n.refId, ") -> .allFilteredChanges:\n"), o(n.allFilteredChanges)), r
                    }
                    static debugChangesDeep(t) {
                        let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "changes",
                            n = "",
                            s = t[c],
                            r = s.root,
                            o = new Map,
                            a = [],
                            l = 0;
                        for (let [e, n] of Object.entries(r[i])) {
                            var h, d;
                            let i = r.changeTrees[e];
                            if (!i) continue;
                            let f = !1,
                                u = [],
                                g = null === (h = i.parent) || void 0 === h ? void 0 : h[c];
                            if (i === s) f = !0;
                            else
                                for (; void 0 !== g;) {
                                    if (u.push(g), g.ref === t) {
                                        f = !0;
                                        break
                                    }
                                    g = null === (d = g.parent) || void 0 === d ? void 0 : d[c]
                                }
                            f && (a.push(i.refId), l += Object.keys(n).length, o.set(i, u.reverse()))
                        }
                        n += "---\n" + "root refId: ".concat(s.refId, "\n") + "Total instances: ".concat(a.length, " (refIds: ").concat(a.join(", "), ")\n") + "Total changes: ".concat(l, "\n") + "---\n";
                        let f = new WeakSet;
                        for (let [t, i] of o.entries()) {
                            i.forEach((e, t) => {
                                f.has(e) || (n += "".concat(eL(t)).concat(e.ref.constructor.name, " (refId: ").concat(e.refId, ")\n"), f.add(e))
                            });
                            let s = t.indexedOperations,
                                r = i.length,
                                o = eL(r),
                                a = r > 0 ? "(".concat(t.parentIndex, ") ") : "";
                            for (let i in n += "".concat(o).concat(a).concat(t.ref.constructor.name, " (refId: ").concat(t.refId, ") - changes: ").concat(Object.keys(s).length, "\n"), s) {
                                let t = s[i];
                                n += "".concat(eL(r + 1)).concat(e.OPERATION[t], ": ").concat(i, "\n")
                            }
                        }
                        return "".concat(n)
                    }
                    constructor(e) {
                        e_.initialize(this), e && Object.assign(this, e)
                    }
                }

                function ek(e, t, i, n) {
                    var s, r = arguments.length,
                        o = r < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, i) : n;
                    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, i, n);
                    else
                        for (var a = e.length - 1; a >= 0; a--)(s = e[a]) && (o = (r < 3 ? s(o) : r > 3 ? s(t, i, o) : s(t, i)) || o);
                    return r > 3 && o && Object.defineProperty(t, i, o), o
                }
                e_[o] = eu, e_[a] = em, "function" == typeof SuppressedError && SuppressedError;
                class eM {
                    getNextUniqueId() {
                        return this.nextUniqueId++
                    }
                    add(t) {
                        void 0 === t.refId && (t.refId = this.getNextUniqueId());
                        let i = void 0 === this.changeTrees[t.refId];
                        i && (this.changeTrees[t.refId] = t);
                        let n = this.refCount[t.refId];
                        if (0 === n) {
                            let i = t.allChanges.operations,
                                n = i.length;
                            for (; n--;) t.indexedOperations[i[n]] = e.OPERATION.ADD, eh(t.changes, n)
                        }
                        return this.refCount[t.refId] = (n || 0) + 1, i
                    }
                    remove(e) {
                        let t = this.refCount[e.refId] - 1;
                        return t <= 0 ? (e.root = void 0, delete this.changeTrees[e.refId], this.removeChangeFromChangeSet("allChanges", e), this.removeChangeFromChangeSet("changes", e), e.filteredChanges && (this.removeChangeFromChangeSet("allFilteredChanges", e), this.removeChangeFromChangeSet("filteredChanges", e)), this.refCount[e.refId] = 0, e.forEachChild((t, i) => {
                            t.removeParent(e.ref) && (void 0 === t.parentChain || t.parentChain && this.refCount[t.refId] > 0 ? this.remove(t) : t.parentChain && this.moveNextToParent(t))
                        })) : (this.refCount[e.refId] = t, this.recursivelyMoveNextToParent(e)), t
                    }
                    recursivelyMoveNextToParent(e) {
                        this.moveNextToParent(e), e.forEachChild((e, t) => this.recursivelyMoveNextToParent(e))
                    }
                    moveNextToParent(e) {
                        e.filteredChanges ? (this.moveNextToParentInChangeTreeList("filteredChanges", e), this.moveNextToParentInChangeTreeList("allFilteredChanges", e)) : (this.moveNextToParentInChangeTreeList("changes", e), this.moveNextToParentInChangeTreeList("allChanges", e))
                    }
                    moveNextToParentInChangeTreeList(e, t) {
                        var i;
                        let n = this[e],
                            s = t[e].queueRootNode;
                        if (!s) return;
                        let r = t.parent;
                        if (!r || !r[c]) return;
                        let o = null === (i = r[c][e]) || void 0 === i ? void 0 : i.queueRootNode;
                        if (!o || o === s) return;
                        let a = o.position;
                        s.position > a || (s.prev ? s.prev.next = s.next : n.next = s.next, s.next ? s.next.prev = s.prev : n.tail = s.prev, s.prev = o, s.next = o.next, o.next ? o.next.prev = s : n.tail = s, o.next = s, this.updatePositionsAfterMove(n, s, a + 1))
                    }
                    enqueueChangeTree(e, t) {
                        let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e[t].queueRootNode;
                        i || (e[t].queueRootNode = this.addToChangeTreeList(this[t], e))
                    }
                    addToChangeTreeList(e, t) {
                        let i = {
                            changeTree: t,
                            next: void 0,
                            prev: void 0,
                            position: e.tail ? e.tail.position + 1 : 0
                        };
                        return e.next ? (i.prev = e.tail, e.tail.next = i) : e.next = i, e.tail = i, i
                    }
                    updatePositionsAfterRemoval(e, t) {
                        let i = e.next,
                            n = 0;
                        for (; i;) n >= t && (i.position = n), i = i.next, n++
                    }
                    updatePositionsAfterMove(e, t, i) {
                        let n = e.next,
                            s = 0;
                        for (; n;) n.position = s, n = n.next, s++
                    }
                    removeChangeFromChangeSet(e, t) {
                        let i = this[e],
                            n = t[e].queueRootNode;
                        if (n && n.changeTree === t) {
                            let s = n.position;
                            return n.prev ? n.prev.next = n.next : i.next = n.next, n.next ? n.next.prev = n.prev : i.tail = n.prev, this.updatePositionsAfterRemoval(i, s), t[e].queueRootNode = void 0, !0
                        }
                        return !1
                    }
                    constructor(e) {
                        this.types = e, this.nextUniqueId = 0, this.refCount = {}, this.changeTrees = {}, this.allChanges = el(), this.allFilteredChanges = el(), this.changes = el(), this.filteredChanges = el()
                    }
                }
                class eV {
                    setState(e) {
                        this.state = e, this.state[c].setRoot(this.root)
                    }
                    encode() {
                        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                                offset: 0
                            },
                            i = arguments.length > 1 ? arguments[1] : void 0,
                            s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.sharedBuffer,
                            r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "changes",
                            a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "allChanges" === r,
                            h = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : t.offset,
                            d = void 0 !== i,
                            f = this.state[c],
                            u = this.root[r];
                        for (; u = u.next;) {
                            let n = u.changeTree;
                            if (d) {
                                if (!i.isChangeTreeVisible(n)) {
                                    i.invisible.add(n);
                                    continue
                                }
                                i.invisible.delete(n)
                            }
                            let c = n[r],
                                g = n.ref,
                                v = c.operations.length;
                            if (0 === v) continue;
                            let p = g.constructor,
                                m = p[o],
                                E = p[l],
                                y = p[Symbol.metadata];
                            (d || t.offset > h || n !== f) && (s[t.offset++] = 255, L.number(s, n.refId, t));
                            for (let r = 0; r < v; r++) {
                                let o = c.operations[r];
                                if (o < 0) {
                                    s[t.offset++] = 255 & Math.abs(o);
                                    continue
                                }
                                let l = a ? e.OPERATION.ADD : n.indexedOperations[o];
                                void 0 !== o && void 0 !== l && (!E || E(g, o, i)) && m(this, s, n, o, l, t, a, d, y)
                            }
                        }
                        if (!(t.offset > s.byteLength)) return s.subarray(0, t.offset); {
                            var g, v;
                            let e = Math.ceil(t.offset / (null !== (g = n.poolSize) && void 0 !== g ? g : 8192)) * (null !== (v = n.poolSize) && void 0 !== v ? v : 8192);
                            return console.warn('@colyseus/schema buffer overflow. Encoded state is higher than default BUFFER_SIZE. Use the following to increase default BUFFER_SIZE:\n\n    import { Encoder } from "@colyseus/schema";\n    Encoder.BUFFER_SIZE = '.concat(Math.round(e / 1024), " * 1024; // ").concat(Math.round(e / 1024), " KB\n")), (s = n.alloc(e, s)) === this.sharedBuffer && (this.sharedBuffer = s), this.encode({
                                offset: h
                            }, i, s, r, a)
                        }
                    }
                    encodeAll() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                                offset: 0
                            },
                            t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.sharedBuffer;
                        return this.encode(e, void 0, t, "allChanges", !0)
                    }
                    encodeAllView(e, t, i) {
                        let s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.sharedBuffer,
                            r = i.offset;
                        return this.encode(i, e, s, "allFilteredChanges", !0, r), n.concat([s.subarray(0, t), s.subarray(r, i.offset)])
                    }
                    encodeView(t, i, s) {
                        let r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.sharedBuffer,
                            a = s.offset;
                        for (let [i, n] of t.changes) {
                            let a = this.root.changeTrees[i];
                            if (void 0 === a) {
                                t.changes.delete(i);
                                continue
                            }
                            let l = Object.keys(n);
                            if (0 === l.length) continue;
                            let d = a.ref.constructor,
                                c = d[o],
                                f = d[Symbol.metadata];
                            r[s.offset++] = 255, L.number(r, a.refId, s);
                            for (let t = 0, i = l.length; t < i; t++) {
                                let i = Number(l[t]),
                                    o = void 0 !== a.ref[h](i) && n[i] || e.OPERATION.DELETE;
                                c(this, r, a, i, o, s, !1, !0, f)
                            }
                        }
                        return t.changes.clear(), this.encode(s, t, r, "filteredChanges", !1, a), n.concat([r.subarray(0, i), r.subarray(a, s.offset)])
                    }
                    discardChanges() {
                        let e = this.root.changes.next;
                        for (; e;) e.changeTree.endEncode("changes"), e = e.next;
                        for (this.root.changes = el(), e = this.root.filteredChanges.next; e;) e.changeTree.endEncode("filteredChanges"), e = e.next;
                        this.root.filteredChanges = el()
                    }
                    tryEncodeTypeId(e, t, i, n) {
                        let s = this.context.getTypeId(t),
                            r = this.context.getTypeId(i);
                        if (void 0 === r) {
                            console.warn('@colyseus/schema WARNING: Class "'.concat(i.name, '" is not registered on TypeRegistry - Please either tag the class with @entity or define a @type() field.'));
                            return
                        }
                        s !== r && (e[n.offset++] = 213, L.number(e, r, n))
                    }
                    get hasChanges() {
                        return void 0 !== this.root.changes.next || void 0 !== this.root.filteredChanges.next
                    }
                    constructor(e) {
                        this.sharedBuffer = n.allocUnsafe(eV.BUFFER_SIZE), this.context = es.cache(e.constructor), this.root = new eM(this.context), this.setState(e)
                    }
                }

                function eB(e, t) {
                    if (-1 === t || t >= e.length) return !1;
                    let i = e.length - 1;
                    for (let n = t; n < i; n++) e[n] = e[n + 1];
                    return e.length = i, !0
                }
                eV.BUFFER_SIZE = void 0 !== n && n.poolSize || 8192;
                class eq extends Error {
                    constructor(e) {
                        super(e), this.name = "DecodingWarning"
                    }
                }
                class ez {
                    getNextUniqueId() {
                        return this.nextUniqueId++
                    }
                    addRef(e, t) {
                        let i = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2];
                        this.refs.set(e, t), this.refIds.set(t, e), i && (this.refCount[e] = (this.refCount[e] || 0) + 1), this.deletedRefs.has(e) && this.deletedRefs.delete(e)
                    }
                    removeRef(e) {
                        let t = this.refCount[e];
                        if (void 0 === t) {
                            try {
                                throw new eq("trying to remove refId that doesn't exist: " + e)
                            } catch (e) {
                                console.warn(e)
                            }
                            return
                        }
                        if (0 === t) {
                            try {
                                let t = this.refs.get(e);
                                throw new eq("trying to remove refId '".concat(e, "' with 0 refCount (").concat(t.constructor.name, ": ").concat(JSON.stringify(t), ")"))
                            } catch (e) {
                                console.warn(e)
                            }
                            return
                        }(this.refCount[e] = t - 1) <= 0 && this.deletedRefs.add(e)
                    }
                    clearRefs() {
                        this.refs.clear(), this.deletedRefs.clear(), this.callbacks = {}, this.refCount = {}
                    }
                    garbageCollectDeletedRefs() {
                        this.deletedRefs.forEach(e => {
                            if (this.refCount[e] > 0) return;
                            let t = this.refs.get(e);
                            if (void 0 !== t.constructor[Symbol.metadata]) {
                                let e = t.constructor[Symbol.metadata];
                                for (let i in e) {
                                    let n = e[i].name,
                                        s = "object" == typeof t[n] && this.refIds.get(t[n]);
                                    s && !this.deletedRefs.has(s) && this.removeRef(s)
                                }
                            } else "function" == typeof t[f] && Array.from(t.values()).forEach(e => {
                                let t = this.refIds.get(e);
                                this.deletedRefs.has(t) || this.removeRef(t)
                            });
                            this.refs.delete(e), delete this.refCount[e], delete this.callbacks[e]
                        }), this.deletedRefs.clear()
                    }
                    addCallback(t, i, n) {
                        if (void 0 === t) {
                            let t = "number" == typeof i ? e.OPERATION[i] : i;
                            throw Error("Can't addCallback on '".concat(t, "' (refId is undefined)"))
                        }
                        return this.callbacks[t] || (this.callbacks[t] = {}), this.callbacks[t][i] || (this.callbacks[t][i] = []), this.callbacks[t][i].push(n), () => this.removeCallback(t, i, n)
                    }
                    removeCallback(e, t, i) {
                        var n, s, r;
                        let o = null === (r = this.callbacks) || void 0 === r ? void 0 : null === (s = r[e]) || void 0 === s ? void 0 : null === (n = s[t]) || void 0 === n ? void 0 : n.indexOf(i);
                        void 0 !== o && -1 !== o && eB(this.callbacks[e][t], o)
                    }
                    constructor() {
                        this.refs = new Map, this.refIds = new WeakMap, this.refCount = {}, this.deletedRefs = new Set, this.callbacks = {}, this.nextUniqueId = 0
                    }
                }
                class eJ {
                    setState(e) {
                        this.state = e, this.root = new ez, this.root.addRef(0, e)
                    }
                    decode(e) {
                        var t, i, n;
                        let s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                                offset: 0
                            },
                            r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.state,
                            o = [],
                            l = this.root,
                            h = e.byteLength,
                            d = r.constructor[a];
                        for (this.currentRefId = 0; s.offset < h;) {
                            if (255 == e[s.offset]) {
                                s.offset++, null === (n = r[g]) || void 0 === n || n.call(r);
                                let t = ee.number(e, s),
                                    i = l.refs.get(t);
                                i ? (d = (r = i).constructor[a], this.currentRefId = t) : (console.error('"refId" not found: '.concat(t), {
                                    previousRef: r,
                                    previousRefId: this.currentRefId
                                }), console.warn("Please report this issue to the developers."), this.skipCurrentStructure(e, s, h));
                                continue
                            }
                            if (-1 === d(this, e, s, r, o)) {
                                console.warn("@colyseus/schema: definition mismatch"), this.skipCurrentStructure(e, s, h);
                                continue
                            }
                        }
                        return null === (t = r[g]) || void 0 === t || t.call(r), null === (i = this.triggerChanges) || void 0 === i || i.call(this, o), l.garbageCollectDeletedRefs(), o
                    }
                    skipCurrentStructure(e, t, i) {
                        let n = {
                            offset: t.offset
                        };
                        for (; t.offset < i && !(255 === e[t.offset] && (n.offset = t.offset + 1, this.root.refs.has(ee.number(e, n))));) t.offset++
                    }
                    getInstanceType(e, t, i) {
                        let n;
                        if (213 === e[t.offset]) {
                            t.offset++;
                            let i = ee.number(e, t);
                            n = this.context.get(i)
                        }
                        return n || i
                    }
                    createInstanceOfType(e) {
                        return new e
                    }
                    removeChildRefs(t, i) {
                        let n = "string" != typeof t[f],
                            s = this.root.refIds.get(t);
                        t.forEach((r, o) => {
                            i.push({
                                ref: t,
                                refId: s,
                                op: e.OPERATION.DELETE,
                                field: o,
                                value: void 0,
                                previousValue: r
                            }), n && this.root.removeRef(this.root.refIds.get(r))
                        })
                    }
                    constructor(e, t) {
                        this.currentRefId = 0, this.setState(e), this.context = t || new es(e.constructor)
                    }
                }
                class eU extends e_ {}
                ek([eF("string")], eU.prototype, "name", void 0), ek([eF("string")], eU.prototype, "type", void 0), ek([eF("number")], eU.prototype, "referencedType", void 0);
                class eW extends e_ {
                    constructor() {
                        super(...arguments), this.fields = new eT
                    }
                }
                ek([eF("number")], eW.prototype, "id", void 0), ek([eF("number")], eW.prototype, "extendsId", void 0), ek([eF([eU])], eW.prototype, "fields", void 0);
                class eY extends e_ {
                    static encode(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                                offset: 0
                            },
                            i = e.context,
                            n = new eY,
                            s = new eV(n),
                            r = i.schemas.get(e.state.constructor);
                        r > 0 && (n.rootType = r);
                        let o = new Set,
                            a = {},
                            l = e => {
                                if (void 0 === e.extendsId || o.has(e.extendsId)) {
                                    o.add(e.id), n.types.push(e);
                                    let t = a[e.id];
                                    void 0 !== t && (delete a[e.id], t.forEach(e => l(e)))
                                } else void 0 === a[e.extendsId] && (a[e.extendsId] = []), a[e.extendsId].push(e)
                            };
                        for (let e in i.schemas.forEach((e, t) => {
                                let n = new eW;
                                n.id = Number(e);
                                let s = Object.getPrototypeOf(t);
                                s !== e_ && (n.extendsId = i.schemas.get(s));
                                let r = t[Symbol.metadata];
                                if (r !== s[Symbol.metadata])
                                    for (let e in r) {
                                        let t;
                                        let s = Number(e),
                                            o = r[s].name;
                                        if (!Object.prototype.hasOwnProperty.call(r, o)) continue;
                                        let a = new eU;
                                        a.name = o;
                                        let l = r[s];
                                        if ("string" == typeof l.type) t = l.type;
                                        else {
                                            let e;
                                            e_.is(l.type) ? (t = "ref", e = l.type) : (t = Object.keys(l.type)[0], "string" == typeof l.type[t] ? t += ":" + l.type[t] : e = l.type[t]), a.referencedType = e ? i.getTypeId(e) : -1
                                        }
                                        a.type = t, n.fields.push(a)
                                    }
                                l(n)
                            }), a) a[e].forEach(e => n.types.push(e));
                        return s.encodeAll(t).slice(0, t.offset)
                    }
                    static decode(e, t) {
                        let i = new eY;
                        new eJ(i).decode(e, t);
                        let n = new es;
                        i.types.forEach(e => {
                            var t;
                            let i = null !== (t = n.get(e.extendsId)) && void 0 !== t ? t : e_,
                                s = class extends i {};
                            es.register(s), n.add(s, e.id)
                        }, {});
                        let s = (e, t, i) => {
                            t.fields.forEach((t, s) => {
                                let r = i + s;
                                if (void 0 !== t.referencedType) {
                                    let i = t.type,
                                        s = n.get(t.referencedType);
                                    if (!s) {
                                        let e = t.type.split(":");
                                        i = e[0], s = e[1]
                                    }
                                    "ref" === i ? eo.addField(e, r, t.name, s) : eo.addField(e, r, t.name, {
                                        [i]: s
                                    })
                                } else eo.addField(e, r, t.name, t.type)
                            })
                        };
                        return i.types.forEach(e => {
                            let t = n.get(e.id),
                                r = eo.initialize(t),
                                o = [],
                                a = e;
                            do o.push(a), a = i.types.find(e => e.id === a.extendsId); while (a);
                            let l = 0;
                            o.reverse().forEach(e => {
                                s(r, e, l), l += e.fields.length
                            })
                        }), new eJ(new(n.get(i.rootType || 0)), n)
                    }
                    constructor() {
                        super(...arguments), this.types = new eT
                    }
                }
                ek([eF([eW])], eY.prototype, "types", void 0), ek([eF("number")], eY.prototype, "rootType", void 0);
                class eZ {
                    add(t) {
                        var i, n, s;
                        let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
                            o = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2],
                            a = null == t ? void 0 : t[c],
                            l = a.parent;
                        if (!a) return console.warn("StateView#add(), invalid object:", t), !1;
                        if (!l && 0 !== a.refId) throw Error('Cannot add a detached instance to the StateView. Make sure to assign the "'.concat(a.ref.constructor.name, '" instance to the state before calling view.add()'));
                        let h = t.constructor[Symbol.metadata];
                        this.visible.add(a), this.iterable && o && this.items.push(t), o && l && this.addParentOf(a, r);
                        let d = this.changes.get(a.refId);
                        void 0 === d && (d = {}, this.changes.set(a.refId, d));
                        let f = !1;
                        if (a.forEachChild((e, t) => {
                                (!h || void 0 === h[t].tag || h[t].tag === r) && this.add(e.ref, r, !1) && (f = !0)
                            }), -1 !== r) {
                            let t;
                            this.tags || (this.tags = new WeakMap), this.tags.has(a) ? t = this.tags.get(a) : (t = new Set, this.tags.set(a, t)), t.add(r), null == h || null === (n = h[y]) || void 0 === n || null === (i = n[r]) || void 0 === i || i.forEach(t => {
                                a.getChange(t) !== e.OPERATION.DELETE && (d[t] = e.OPERATION.ADD)
                            })
                        } else if (!a.isNew || f) {
                            let t = void 0 !== a.filteredChanges ? a.allFilteredChanges : a.allChanges,
                                i = this.invisible.has(a);
                            for (let n = 0, o = t.operations.length; n < o; n++) {
                                let o = t.operations[n];
                                if (void 0 === o) continue;
                                let l = null !== (s = a.indexedOperations[o]) && void 0 !== s ? s : e.OPERATION.ADD,
                                    c = null == h ? void 0 : h[o].tag;
                                l !== e.OPERATION.DELETE && (i || void 0 === c || c === r) && (d[o] = l, f = !0)
                            }
                        }
                        return f
                    }
                    addParentOf(t, i) {
                        let n = t.parent[c],
                            s = t.parentIndex;
                        if (!this.visible.has(n)) {
                            var r;
                            this.visible.add(n);
                            let e = null === (r = n.parent) || void 0 === r ? void 0 : r[c];
                            e && void 0 !== e.filteredChanges && this.addParentOf(n, i)
                        }
                        if (n.getChange(s) !== e.OPERATION.DELETE) {
                            let t, r = this.changes.get(n.refId);
                            void 0 === r && (r = {}, this.changes.set(n.refId, r)), this.tags || (this.tags = new WeakMap), this.tags.has(n) ? t = this.tags.get(n) : (t = new Set, this.tags.set(n, t)), t.add(i), r[s] = e.OPERATION.ADD
                        }
                    }
                    remove(t) {
                        let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
                            n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                            s = t[c];
                        if (!s) return console.warn("StateView#remove(), invalid object:", t), this;
                        this.visible.delete(s), this.iterable && !n && eB(this.items, this.items.indexOf(t));
                        let r = s.ref.constructor[Symbol.metadata],
                            o = this.changes.get(s.refId);
                        if (void 0 === o && (o = {}, this.changes.set(s.refId, o)), -1 === i) {
                            let t = s.parent;
                            if (t && !eo.isValidInstance(t) && s.isFiltered) {
                                let i = t[c],
                                    n = this.changes.get(i.refId);
                                void 0 === n ? (n = {}, this.changes.set(i.refId, n)) : n[s.parentIndex] === e.OPERATION.ADD && this.changes.delete(s.refId), n[s.parentIndex] = e.OPERATION.DELETE, this._recursiveDeleteVisibleChangeTree(s)
                            } else {
                                var a;
                                null == r || null === (a = r[E]) || void 0 === a || a.forEach(t => o[t] = e.OPERATION.DELETE)
                            }
                        } else null == r || r[y][i].forEach(t => o[t] = e.OPERATION.DELETE);
                        if (this.tags && this.tags.has(s)) {
                            let e = this.tags.get(s);
                            void 0 === i ? this.tags.delete(s) : (e.delete(i), 0 === e.size && this.tags.delete(s))
                        }
                        return this
                    }
                    has(e) {
                        return this.visible.has(e[c])
                    }
                    hasTag(e) {
                        var t, i;
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
                            s = null === (t = this.tags) || void 0 === t ? void 0 : t.get(e[c]);
                        return null !== (i = null == s ? void 0 : s.has(n)) && void 0 !== i && i
                    }
                    clear() {
                        if (!this.iterable) throw Error("StateView#clear() is only available for iterable StateView's. Use StateView(iterable: true) constructor.");
                        for (let e = 0, t = this.items.length; e < t; e++) this.remove(this.items[e], -1, !0);
                        this.items.length = 0
                    }
                    isChangeTreeVisible(e) {
                        let t = this.visible.has(e);
                        return !t && e.isVisibilitySharedWithParent && this.visible.has(e.parent[c]) && (this.visible.add(e), t = !0), t
                    }
                    _recursiveDeleteVisibleChangeTree(e) {
                        e.forEachChild(e => {
                            this.visible.delete(e), this._recursiveDeleteVisibleChangeTree(e)
                        })
                    }
                    constructor(e = !1) {
                        this.iterable = e, this.visible = new WeakSet, this.invisible = new WeakSet, this.changes = new Map, e && (this.items = [])
                    }
                }
                en("map", {
                    constructor: eN
                }), en("array", {
                    constructor: eT
                }), en("set", {
                    constructor: eS
                }), en("collection", {
                    constructor: eD
                }), e.$changes = c, e.$childType = f, e.$decoder = a, e.$deleteByIndex = d, e.$encoder = o, e.$filter = l, e.$getByIndex = h, e.$track = r, e.ArraySchema = eT, e.ChangeTree = ec, e.CollectionSchema = eD, e.Decoder = eJ, e.Encoder = eV, e.MapSchema = eN, e.Metadata = eo, e.Reflection = eY, e.ReflectionField = eU, e.ReflectionType = eW, e.Schema = e_, e.SetSchema = eS, e.StateView = eZ, e.TypeContext = es, e.decode = ee, e.decodeKeyValueOperation = eE, e.decodeSchemaOperation = em, e.defineCustomTypes = function(e) {
                    for (let t in e) en(t, e[t]);
                    return e => eF(e)
                }, e.defineTypes = function(e, t, i) {
                    for (let n in t) eF(t[n], i)(e.prototype, n);
                    return e
                }, e.deprecated = function() {
                    let e = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0];
                    return function(t, i) {
                        var n, s, r;
                        let o = t.constructor,
                            a = Object.getPrototypeOf(o)[Symbol.metadata],
                            l = null !== (s = o[n = Symbol.metadata]) && void 0 !== s ? s : o[n] = Object.assign({}, o[Symbol.metadata], null != a ? a : Object.create(null)),
                            h = l[i];
                        l[h].deprecated = !0, e && (null !== (r = l[v]) && void 0 !== r || (l[v] = {}), l[v][i] = {
                            get: function() {
                                throw Error("".concat(i, " is deprecated."))
                            },
                            set: function(e) {},
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(l, h, {
                            value: l[h],
                            enumerable: !1,
                            configurable: !0
                        })
                    }
                }, e.dumpChanges = function(t) {
                    let i = t[c].root,
                        n = {
                            ops: {},
                            refs: []
                        },
                        s = i.changes.next;
                    for (; s;) {
                        let t = s.changeTree;
                        if (void 0 === t) {
                            s = s.next;
                            continue
                        }
                        let i = t.indexedOperations;
                        for (let s in n.refs.push("refId#".concat(t.refId)), i) {
                            let t = i[s],
                                r = e.OPERATION[t];
                            n.ops[r] || (n.ops[r] = 0), n.ops[e.OPERATION[t]]++
                        }
                        s = s.next
                    }
                    return n
                }, e.encode = L, e.encodeArray = ev, e.encodeKeyValueOperation = eg, e.encodeSchemaOperation = eu, e.entity = function(e) {
                    return es.register(e), e
                }, e.getDecoderStateCallbacks = function(t) {
                    let i;
                    let n = t.root,
                        s = n.callbacks,
                        r = new WeakMap;
                    return t.triggerChanges = function(t) {
                            let i = new Set;
                            for (let d = 0, c = t.length; d < c; d++) {
                                var r, o, a, l, h;
                                let c = t[d],
                                    f = c.refId,
                                    u = c.ref,
                                    g = s[f];
                                if (g) {
                                    if ((c.op & e.OPERATION.DELETE) === e.OPERATION.DELETE && c.previousValue instanceof e_) {
                                        let t = null === (r = s[n.refIds.get(c.previousValue)]) || void 0 === r ? void 0 : r[e.OPERATION.DELETE];
                                        for (let e = (null == t ? void 0 : t.length) - 1; e >= 0; e--) t[e]()
                                    }
                                    if (u instanceof e_) {
                                        if (!i.has(f)) {
                                            let t = null == g ? void 0 : g[e.OPERATION.REPLACE];
                                            for (let e = (null == t ? void 0 : t.length) - 1; e >= 0; e--) t[e]()
                                        }
                                        if (g.hasOwnProperty(c.field)) {
                                            let e = g[c.field];
                                            for (let t = (null == e ? void 0 : e.length) - 1; t >= 0; t--) e[t](c.value, c.previousValue)
                                        }
                                    } else {
                                        if ((c.op & e.OPERATION.DELETE) === e.OPERATION.DELETE) {
                                            if (void 0 !== c.previousValue) {
                                                let t = g[e.OPERATION.DELETE];
                                                for (let e = (null == t ? void 0 : t.length) - 1; e >= 0; e--) t[e](c.previousValue, null !== (o = c.dynamicIndex) && void 0 !== o ? o : c.field)
                                            }
                                            if ((c.op & e.OPERATION.ADD) === e.OPERATION.ADD) {
                                                let t = g[e.OPERATION.ADD];
                                                for (let e = (null == t ? void 0 : t.length) - 1; e >= 0; e--) t[e](c.value, null !== (a = c.dynamicIndex) && void 0 !== a ? a : c.field)
                                            }
                                        } else if ((c.op & e.OPERATION.ADD) === e.OPERATION.ADD && c.previousValue !== c.value) {
                                            let t = g[e.OPERATION.ADD];
                                            for (let e = (null == t ? void 0 : t.length) - 1; e >= 0; e--) t[e](c.value, null !== (l = c.dynamicIndex) && void 0 !== l ? l : c.field)
                                        }
                                        if (c.value !== c.previousValue && (void 0 !== c.value || void 0 !== c.previousValue)) {
                                            let t = g[e.OPERATION.REPLACE];
                                            for (let e = (null == t ? void 0 : t.length) - 1; e >= 0; e--) t[e](c.value, null !== (h = c.dynamicIndex) && void 0 !== h ? h : c.field)
                                        }
                                    }
                                    i.add(f)
                                }
                            }
                        },
                        function t(s) {
                            return function s(o, a) {
                                var l;
                                let h = (null === (l = a.instance) || void 0 === l ? void 0 : l.constructor[Symbol.metadata]) || o,
                                    d = a.instance && "function" == typeof a.instance.forEach || o && void 0 === o[Symbol.metadata];
                                if (h && !d) {
                                    let o = function(e, t, s, o) {
                                        return o && void 0 !== a.instance[t] && !r.has(i) && s(a.instance[t], void 0), n.addCallback(n.refIds.get(e), t, s)
                                    };
                                    return new Proxy({
                                        listen: function(e, t) {
                                            let n = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2];
                                            if (a.instance) return o(a.instance, e, t, n); {
                                                let s = () => {};
                                                return a.onInstanceAvailable((a, l) => {
                                                    s = o(a, e, t, n && l && !r.has(i))
                                                }), () => s()
                                            }
                                        },
                                        onChange: function(t) {
                                            return n.addCallback(n.refIds.get(a.instance), e.OPERATION.REPLACE, t)
                                        },
                                        bindTo: function(t, i) {
                                            return i || (i = Object.keys(h).map(e => h[e].name)), n.addCallback(n.refIds.get(a.instance), e.OPERATION.REPLACE, () => {
                                                i.forEach(e => t[e] = a.instance[e])
                                            })
                                        }
                                    }, {
                                        get(e, i) {
                                            let r = h[h[i]];
                                            if (!r) return e[i]; {
                                                var o;
                                                let e = null === (o = a.instance) || void 0 === o ? void 0 : o[i];
                                                return s(r.type, {
                                                    instance: n.refIds.get(e) && e,
                                                    parentInstance: a.instance,
                                                    onInstanceAvailable: s => {
                                                        let r = t(a.instance).listen(i, (e, t) => {
                                                            s(e, !1), null == r || r()
                                                        }, !1);
                                                        void 0 !== n.refIds.get(e) && s(e, !0)
                                                    }
                                                })
                                            }
                                        },
                                        has: (e, t) => void 0 !== h[t],
                                        set(e, t, i) {
                                            throw Error("not allowed")
                                        },
                                        deleteProperty(e, t) {
                                            throw Error("not allowed")
                                        }
                                    })
                                } {
                                    let t = function(t, s, o) {
                                            return o && t.forEach((e, t) => s(e, t)), n.addCallback(n.refIds.get(t), e.OPERATION.ADD, (e, t) => {
                                                r.set(s, !0), i = s, s(e, t), r.delete(s), i = void 0
                                            })
                                        },
                                        s = function(t, i) {
                                            return n.addCallback(n.refIds.get(t), e.OPERATION.DELETE, i)
                                        },
                                        o = function(t, i) {
                                            return n.addCallback(n.refIds.get(t), e.OPERATION.REPLACE, i)
                                        };
                                    return new Proxy({
                                        onAdd: function(e) {
                                            let n = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
                                            if (a.instance) return t(a.instance, e, n && !r.has(i));
                                            if (a.onInstanceAvailable) {
                                                let s = () => {};
                                                return a.onInstanceAvailable((o, a) => {
                                                    s = t(o, e, n && a && !r.has(i))
                                                }), () => s()
                                            }
                                        },
                                        onRemove: function(e) {
                                            if (a.instance) return s(a.instance, e);
                                            if (a.onInstanceAvailable) {
                                                let t = () => {};
                                                return a.onInstanceAvailable(i => {
                                                    t = s(i, e)
                                                }), () => t()
                                            }
                                        },
                                        onChange: function(e) {
                                            if (a.instance) return o(a.instance, e);
                                            if (a.onInstanceAvailable) {
                                                let t = () => {};
                                                return a.onInstanceAvailable(i => {
                                                    t = o(i, e)
                                                }), () => t()
                                            }
                                        }
                                    }, {
                                        get(e, t) {
                                            if (!e[t]) throw Error("Can't access '".concat(t, "' through callback proxy. access the instance directly."));
                                            return e[t]
                                        },
                                        has: (e, t) => void 0 !== e[t],
                                        set(e, t, i) {
                                            throw Error("not allowed")
                                        },
                                        deleteProperty(e, t) {
                                            throw Error("not allowed")
                                        }
                                    })
                                }
                            }(void 0, {
                                instance: s
                            })
                        }
                }, e.getRawChangesCallback = function(e, t) {
                    e.triggerChanges = t
                }, e.registerType = en, e.schema = function e(t, i) {
                    let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e_,
                        s = {},
                        r = {},
                        o = {},
                        a = {};
                    for (let e in t) {
                        let i = t[e];
                        "object" == typeof i ? (void 0 !== i.view && (a[e] = "boolean" == typeof i.view ? -1 : i.view), s[e] = er(i), Object.prototype.hasOwnProperty.call(i, "default") ? o[e] = i.default : Array.isArray(i) || void 0 !== i.array ? o[e] = new eT : void 0 !== i.map ? o[e] = new eN : void 0 !== i.collection ? o[e] = new eD : void 0 !== i.set ? o[e] = new eS : void 0 !== i.type && e_.is(i.type) && (!i.type.prototype.initialize || 0 === i.type.prototype.initialize.length) && (o[e] = new i.type)) : "function" == typeof i ? e_.is(i) ? (i.prototype.initialize && 0 !== i.prototype.initialize.length || (o[e] = new i), s[e] = er(i)) : r[e] = i : s[e] = er(i)
                    }
                    let l = () => {
                            let e = {};
                            for (let t in o) {
                                let i = o[t];
                                i && "function" == typeof i.clone ? e[t] = i.clone() : e[t] = i
                            }
                            return e
                        },
                        h = e => {
                            let t = Object.keys(s),
                                i = {};
                            for (let n in e) t.includes(n) || (i[n] = e[n]);
                            return i
                        },
                        d = eo.setFields(class extends n {
                            constructor(...e) {
                                r.initialize && "function" == typeof r.initialize ? (super(Object.assign({}, l(), h(e[0] || {}))), new.target === d && r.initialize.apply(this, e)) : super(Object.assign({}, l(), e[0] || {}))
                            }
                        }, s);
                    for (let e in d._getDefaultValues = l, Object.assign(d.prototype, r), a) e$(a[e])(d.prototype, e);
                    return i && Object.defineProperty(d, "name", {
                        value: i
                    }), d.extends = (t, i) => e(t, i, d), d
                }, e.type = eF, e.view = e$
            }(t)
        }
    }
]);