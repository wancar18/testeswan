(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3184], {
        82312: function(e, t, a) {
            Promise.resolve().then(a.bind(a, 78295))
        },
        78295: function(e, t, a) {
            "use strict";
            a.r(t), a.d(t, {
                default: function() {
                    return S
                }
            });
            var r = a(3827),
                n = a(64090),
                o = a(47907),
                s = a(6739),
                i = a(76023);

            function l(e, t) {
                if (Object.is(e, t)) return !0;
                if ("object" != typeof e || null === e || "object" != typeof t || null === t) return !1;
                if (e instanceof Map && t instanceof Map) {
                    if (e.size !== t.size) return !1;
                    for (let [a, r] of e)
                        if (!Object.is(r, t.get(a))) return !1;
                    return !0
                }
                if (e instanceof Set && t instanceof Set) {
                    if (e.size !== t.size) return !1;
                    for (let a of e)
                        if (!t.has(a)) return !1;
                    return !0
                }
                let a = Object.keys(e);
                if (a.length !== Object.keys(t).length) return !1;
                for (let r of a)
                    if (!Object.prototype.hasOwnProperty.call(t, r) || !Object.is(e[r], t[r])) return !1;
                return !0
            }
            var d = a(85043),
                c = a(52235),
                m = a(35005),
                u = a(18994),
                f = a(66260),
                x = a(29733),
                g = a(10775),
                b = a(80037),
                h = a(11213),
                p = a(26490),
                j = a(20703),
                v = a(8792),
                w = a(10826);

            function y() {
                return (0, n.useEffect)(() => (function() {
                    let e = 0,
                        t = t => {
                            let a = Date.now();
                            a - e <= 300 && t.preventDefault(), e = a
                        },
                        a = e => {
                            e.preventDefault()
                        },
                        r = e => {
                            e.preventDefault()
                        },
                        n = e => {
                            e.preventDefault()
                        },
                        o = e => {
                            1 !== e.scale && e.preventDefault()
                        };
                    return document.addEventListener("touchend", t, !1), document.addEventListener("gesturestart", a, {
                        passive: !1
                    }), document.addEventListener("gesturechange", r, {
                        passive: !1
                    }), document.addEventListener("gestureend", n, {
                        passive: !1
                    }), document.addEventListener("touchmove", o, {
                        passive: !1
                    }), console.log("[Prevent Zoom] ✅ Prote\xe7\xf5es contra zoom ativadas"), () => {
                        document.removeEventListener("touchend", t, !1), document.removeEventListener("gesturestart", a), document.removeEventListener("gesturechange", r), document.removeEventListener("gestureend", n), document.removeEventListener("touchmove", o), console.log("[Prevent Zoom] \uD83E\uDDF9 Prote\xe7\xf5es contra zoom removidas")
                    }
                })(), []), null
            }
            var N = a(69102),
                k = a.n(N),
                I = a(53348),
                E = a(90043),
                z = a(23441),
                T = a(29910);

            function R() {
                let [e, t] = (0, n.useState)(!1), [a, o] = (0, n.useState)(!1), [s, i] = (0, n.useState)(!1), l = (0, n.useCallback)(() => {
                    let e = navigator.userAgent.toLowerCase(),
                        a = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobile|tablet/i.test(e),
                        r = "ontouchstart" in window || navigator.maxTouchPoints > 0,
                        n = window.innerWidth < 1024;
                    o((a || r) && n), t(window.innerHeight > window.innerWidth)
                }, []), d = (0, n.useCallback)(() => {
                    setTimeout(l, 100)
                }, [l]);
                return ((0, n.useEffect)(() => (l(), window.addEventListener("resize", l), window.addEventListener("orientationchange", d), () => {
                    window.removeEventListener("resize", l), window.removeEventListener("orientationchange", d)
                }), [l, d]), a && e) ? (0, r.jsxs)("div", {
                    className: "jsx-4ca526ad9687eb2 fixed inset-0 z-[100] bg-gradient-to-b from-[#0a0a0f] via-[#0d1117] to-[#0a0a0f] flex flex-col items-center justify-center p-6",
                    children: [(0, r.jsxs)("div", {
                        className: "jsx-4ca526ad9687eb2 relative mb-8",
                        children: [(0, r.jsx)("div", {
                            className: "jsx-4ca526ad9687eb2 relative w-32 h-48 animate-rotate-phone",
                            children: (0, r.jsxs)("div", {
                                className: "jsx-4ca526ad9687eb2 absolute inset-0 bg-gradient-to-b from-gray-800 to-gray-900 rounded-[2rem] border-4 border-gray-700 shadow-2xl overflow-hidden",
                                children: [(0, r.jsx)("div", {
                                    className: "jsx-4ca526ad9687eb2 absolute inset-2 bg-gradient-to-br from-pool-gold/20 to-green-500/20 rounded-[1.5rem] flex items-center justify-center",
                                    children: (0, r.jsxs)("div", {
                                        className: "jsx-4ca526ad9687eb2 w-16 h-10 bg-green-600/50 rounded-lg border-2 border-yellow-600/50 relative",
                                        children: [(0, r.jsx)("div", {
                                            className: "jsx-4ca526ad9687eb2 absolute -top-1 -left-1 w-2 h-2 bg-black rounded-full"
                                        }), (0, r.jsx)("div", {
                                            className: "jsx-4ca526ad9687eb2 absolute -top-1 -right-1 w-2 h-2 bg-black rounded-full"
                                        }), (0, r.jsx)("div", {
                                            className: "jsx-4ca526ad9687eb2 absolute -bottom-1 -left-1 w-2 h-2 bg-black rounded-full"
                                        }), (0, r.jsx)("div", {
                                            className: "jsx-4ca526ad9687eb2 absolute -bottom-1 -right-1 w-2 h-2 bg-black rounded-full"
                                        }), (0, r.jsx)("div", {
                                            className: "jsx-4ca526ad9687eb2 absolute top-2 left-3 w-2 h-2 bg-white rounded-full shadow"
                                        }), (0, r.jsx)("div", {
                                            className: "jsx-4ca526ad9687eb2 absolute top-3 right-4 w-2 h-2 bg-yellow-400 rounded-full shadow"
                                        }), (0, r.jsx)("div", {
                                            className: "jsx-4ca526ad9687eb2 absolute bottom-2 left-5 w-2 h-2 bg-red-500 rounded-full shadow"
                                        })]
                                    })
                                }), (0, r.jsx)("div", {
                                    className: "jsx-4ca526ad9687eb2 absolute top-3 left-1/2 -translate-x-1/2 w-12 h-1.5 bg-gray-700 rounded-full"
                                }), (0, r.jsx)("div", {
                                    className: "jsx-4ca526ad9687eb2 absolute bottom-2 left-1/2 -translate-x-1/2 w-10 h-1 bg-gray-600 rounded-full"
                                })]
                            })
                        }), (0, r.jsx)("div", {
                            className: "jsx-4ca526ad9687eb2 absolute -right-8 top-1/2 -translate-y-1/2 animate-pulse",
                            children: (0, r.jsx)(I.Z, {
                                size: 40,
                                className: "text-pool-gold"
                            })
                        })]
                    }), (0, r.jsx)("h1", {
                        className: "jsx-4ca526ad9687eb2 text-2xl font-bold text-white text-center mb-2",
                        children: "Gire seu dispositivo para jogar"
                    }), (0, r.jsx)("p", {
                        className: "jsx-4ca526ad9687eb2 text-white/60 text-center mb-6 max-w-xs",
                        children: "O jogo ser\xe1 exibido assim que o dispositivo estiver em modo paisagem."
                    }), (0, r.jsxs)("div", {
                        className: "jsx-4ca526ad9687eb2 flex items-center justify-center gap-4 mb-8",
                        children: [(0, r.jsxs)("div", {
                            className: "jsx-4ca526ad9687eb2 relative opacity-40",
                            children: [(0, r.jsx)("div", {
                                className: "jsx-4ca526ad9687eb2 w-12 h-20 bg-gray-800 rounded-xl border-2 border-gray-600 flex items-center justify-center",
                                children: (0, r.jsx)(E.Z, {
                                    size: 20,
                                    className: "text-gray-500"
                                })
                            }), (0, r.jsx)("div", {
                                className: "jsx-4ca526ad9687eb2 absolute -bottom-4 left-1/2 -translate-x-1/2 text-xs text-white/40",
                                children: "Retrato"
                            })]
                        }), (0, r.jsxs)("div", {
                            className: "jsx-4ca526ad9687eb2 flex items-center gap-1 text-pool-gold",
                            children: [(0, r.jsx)("div", {
                                className: "jsx-4ca526ad9687eb2 w-8 h-0.5 bg-pool-gold"
                            }), (0, r.jsx)(z.Z, {
                                size: 20,
                                className: "rotate-[-90deg]"
                            })]
                        }), (0, r.jsxs)("div", {
                            className: "jsx-4ca526ad9687eb2 relative",
                            children: [(0, r.jsx)("div", {
                                className: "jsx-4ca526ad9687eb2 w-20 h-12 bg-gradient-to-r from-pool-gold/30 to-green-500/30 rounded-xl border-2 border-pool-gold flex items-center justify-center shadow-lg shadow-pool-gold/20",
                                children: (0, r.jsx)(E.Z, {
                                    size: 20,
                                    className: "text-pool-gold rotate-90"
                                })
                            }), (0, r.jsx)("div", {
                                className: "jsx-4ca526ad9687eb2 absolute -bottom-4 left-1/2 -translate-x-1/2 text-xs text-pool-gold font-semibold whitespace-nowrap",
                                children: "Paisagem"
                            })]
                        })]
                    }), (0, r.jsxs)("button", {
                        onClick: () => i(!s),
                        className: "jsx-4ca526ad9687eb2 flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-white/70 hover:text-white transition-all text-sm",
                        children: [(0, r.jsx)(T.Z, {
                            size: 16
                        }), (0, r.jsx)("span", {
                            className: "jsx-4ca526ad9687eb2",
                            children: "Como habilitar a rota\xe7\xe3o?"
                        }), (0, r.jsx)(z.Z, {
                            size: 16,
                            className: "transition-transform ".concat(s ? "rotate-180" : "")
                        })]
                    }), s && (0, r.jsx)("div", {
                        className: "jsx-4ca526ad9687eb2 mt-4 p-4 bg-white/5 border border-white/10 rounded-xl max-w-sm animate-fadeIn",
                        children: (0, r.jsxs)("div", {
                            className: "jsx-4ca526ad9687eb2 space-y-3 text-sm",
                            children: [(0, r.jsxs)("div", {
                                className: "jsx-4ca526ad9687eb2 flex items-start gap-3",
                                children: [(0, r.jsx)("div", {
                                    className: "jsx-4ca526ad9687eb2 w-6 h-6 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0",
                                    children: (0, r.jsx)("svg", {
                                        viewBox: "0 0 24 24",
                                        fill: "currentColor",
                                        className: "jsx-4ca526ad9687eb2 w-4 h-4 text-white",
                                        children: (0, r.jsx)("path", {
                                            d: "M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z",
                                            className: "jsx-4ca526ad9687eb2"
                                        })
                                    })
                                }), (0, r.jsxs)("div", {
                                    className: "jsx-4ca526ad9687eb2",
                                    children: [(0, r.jsx)("p", {
                                        className: "jsx-4ca526ad9687eb2 text-white font-medium",
                                        children: "iPhone/iPad"
                                    }), (0, r.jsxs)("p", {
                                        className: "jsx-4ca526ad9687eb2 text-white/50 text-xs",
                                        children: ["Deslize de cima para baixo e desative o ", (0, r.jsx)("strong", {
                                            className: "jsx-4ca526ad9687eb2 text-white/70",
                                            children: "bloqueio de rota\xe7\xe3o"
                                        }), " (\xedcone de cadeado)"]
                                    })]
                                })]
                            }), (0, r.jsxs)("div", {
                                className: "jsx-4ca526ad9687eb2 flex items-start gap-3",
                                children: [(0, r.jsx)("div", {
                                    className: "jsx-4ca526ad9687eb2 w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0",
                                    children: (0, r.jsx)("svg", {
                                        viewBox: "0 0 24 24",
                                        fill: "currentColor",
                                        className: "jsx-4ca526ad9687eb2 w-4 h-4 text-green-400",
                                        children: (0, r.jsx)("path", {
                                            d: "M6 18c0 .55.45 1 1 1h1v3.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5V19h2v3.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5V19h1c.55 0 1-.45 1-1V8H6v10zM3.5 8C2.67 8 2 8.67 2 9.5v7c0 .83.67 1.5 1.5 1.5S5 17.33 5 16.5v-7C5 8.67 4.33 8 3.5 8zm17 0c-.83 0-1.5.67-1.5 1.5v7c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5v-7c0-.83-.67-1.5-1.5-1.5zm-4.97-5.84l1.3-1.3c.2-.2.2-.51 0-.71-.2-.2-.51-.2-.71 0l-1.48 1.48C13.85 1.23 12.95 1 12 1c-.96 0-1.86.23-2.66.63L7.85.15c-.2-.2-.51-.2-.71 0-.2.2-.2.51 0 .71l1.31 1.31C6.97 3.26 6 5.01 6 7h12c0-1.99-.97-3.75-2.47-4.84zM10 5H9V4h1v1zm5 0h-1V4h1v1z",
                                            className: "jsx-4ca526ad9687eb2"
                                        })
                                    })
                                }), (0, r.jsxs)("div", {
                                    className: "jsx-4ca526ad9687eb2",
                                    children: [(0, r.jsx)("p", {
                                        className: "jsx-4ca526ad9687eb2 text-white font-medium",
                                        children: "Android"
                                    }), (0, r.jsxs)("p", {
                                        className: "jsx-4ca526ad9687eb2 text-white/50 text-xs",
                                        children: ["Deslize de cima para baixo e ative a ", (0, r.jsx)("strong", {
                                            className: "jsx-4ca526ad9687eb2 text-white/70",
                                            children: "rota\xe7\xe3o autom\xe1tica"
                                        }), " (\xedcone de tela girando)"]
                                    })]
                                })]
                            })]
                        })
                    }), (0, r.jsx)("div", {
                        className: "jsx-4ca526ad9687eb2 absolute bottom-6 left-0 right-0 flex justify-center",
                        children: (0, r.jsxs)("div", {
                            className: "jsx-4ca526ad9687eb2 flex items-center gap-2 text-white/20 text-xs",
                            children: [(0, r.jsx)("div", {
                                className: "jsx-4ca526ad9687eb2 w-2 h-2 rounded-full bg-pool-gold/50 animate-pulse"
                            }), (0, r.jsx)("span", {
                                className: "jsx-4ca526ad9687eb2",
                                children: "Aguardando rota\xe7\xe3o..."
                            })]
                        })
                    }), (0, r.jsx)(k(), {
                        id: "4ca526ad9687eb2",
                        children: "@-webkit-keyframes rotate-phone{0%,100%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}25%{-webkit-transform:rotate(-15deg);transform:rotate(-15deg)}50%{-webkit-transform:rotate(-90deg);transform:rotate(-90deg)}75%{-webkit-transform:rotate(-75deg);transform:rotate(-75deg)}}@-moz-keyframes rotate-phone{0%,100%{-moz-transform:rotate(0deg);transform:rotate(0deg)}25%{-moz-transform:rotate(-15deg);transform:rotate(-15deg)}50%{-moz-transform:rotate(-90deg);transform:rotate(-90deg)}75%{-moz-transform:rotate(-75deg);transform:rotate(-75deg)}}@-o-keyframes rotate-phone{0%,100%{-o-transform:rotate(0deg);transform:rotate(0deg)}25%{-o-transform:rotate(-15deg);transform:rotate(-15deg)}50%{-o-transform:rotate(-90deg);transform:rotate(-90deg)}75%{-o-transform:rotate(-75deg);transform:rotate(-75deg)}}@keyframes rotate-phone{0%,100%{-webkit-transform:rotate(0deg);-moz-transform:rotate(0deg);-o-transform:rotate(0deg);transform:rotate(0deg)}25%{-webkit-transform:rotate(-15deg);-moz-transform:rotate(-15deg);-o-transform:rotate(-15deg);transform:rotate(-15deg)}50%{-webkit-transform:rotate(-90deg);-moz-transform:rotate(-90deg);-o-transform:rotate(-90deg);transform:rotate(-90deg)}75%{-webkit-transform:rotate(-75deg);-moz-transform:rotate(-75deg);-o-transform:rotate(-75deg);transform:rotate(-75deg)}}.animate-rotate-phone.jsx-4ca526ad9687eb2{-webkit-animation:rotate-phone 3s ease-in-out infinite;-moz-animation:rotate-phone 3s ease-in-out infinite;-o-animation:rotate-phone 3s ease-in-out infinite;animation:rotate-phone 3s ease-in-out infinite;-webkit-transform-origin:center center;-moz-transform-origin:center center;-ms-transform-origin:center center;-o-transform-origin:center center;transform-origin:center center}@-webkit-keyframes fadeIn{from{opacity:0;-webkit-transform:translatey(-10px);transform:translatey(-10px)}to{opacity:1;-webkit-transform:translatey(0);transform:translatey(0)}}@-moz-keyframes fadeIn{from{opacity:0;-moz-transform:translatey(-10px);transform:translatey(-10px)}to{opacity:1;-moz-transform:translatey(0);transform:translatey(0)}}@-o-keyframes fadeIn{from{opacity:0;-o-transform:translatey(-10px);transform:translatey(-10px)}to{opacity:1;-o-transform:translatey(0);transform:translatey(0)}}@keyframes fadeIn{from{opacity:0;-webkit-transform:translatey(-10px);-moz-transform:translatey(-10px);-o-transform:translatey(-10px);transform:translatey(-10px)}to{opacity:1;-webkit-transform:translatey(0);-moz-transform:translatey(0);-o-transform:translatey(0);transform:translatey(0)}}.animate-fadeIn.jsx-4ca526ad9687eb2{-webkit-animation:fadeIn.3s ease-out;-moz-animation:fadeIn.3s ease-out;-o-animation:fadeIn.3s ease-out;animation:fadeIn.3s ease-out}"
                    })]
                }) : null
            }
            let _ = {
                "Cue ball pocketed": "bola branca enca\xe7apada",
                "No ball hit": "nenhuma bola acertada",
                "Hit 8-ball first with balls remaining": "acertou a bola 8 primeiro",
                "Wrong ball hit first": "acertou a bola errada primeiro",
                "Pocketed opponent balls": "enca\xe7apou bolas do oponente"
            };

            function S() {
                let e = (0, o.useParams)(),
                    t = (0, o.useRouter)(),
                    a = e.id,
                    N = (0, n.useRef)(null),
                    k = (0, n.useRef)(!1),
                    I = (0, n.useRef)(null),
                    E = (0, n.useRef)(!1),
                    {
                        user: z,
                        isAuthenticated: T,
                        isLoading: S,
                        checkAuth: L
                    } = (0, s.tN)(),
                    P = (0, i.g)(d.ei),
                    C = (0, i.g)(d.xk),
                    A = (0, i.g)(e => e.reconnectAttempts),
                    G = (0, i.g)(d.vT),
                    Z = (0, i.g)(d.Dn),
                    D = (0, i.g)(d.Q0),
                    M = (0, i.g)(d.s8),
                    O = (0, i.g)(d.d1),
                    B = (0, i.g)(d.Ql),
                    U = (0, i.g)(d.hv),
                    V = (0, i.g)(d.z0),
                    W = (0, i.g)(d.yr),
                    F = (0, i.g)(d.ht),
                    J = (0, i.g)(d.cb),
                    Y = (0, i.g)(e => e.serverTimestamp),
                    H = (0, i.g)(e => e.cancelledByAdmin),
                    q = (0, i.g)(d.b4),
                    {
                        player1Name: K,
                        player2Name: Q,
                        opponentName: $
                    } = (0, i.g)(d.Ke, l),
                    {
                        opponentDisconnected: X,
                        opponentGraceEndTime: ee,
                        disconnectedPlayerName: et
                    } = (0, i.g)(d.TS, l),
                    {
                        isInitializing: ea,
                        initializationFailed: er,
                        initializationFailedReason: en,
                        player1GameReady: eo,
                        player2GameReady: es
                    } = (0, i.g)(d.JM, l),
                    ei = (0, i.g)(d.zR),
                    el = (0, i.g)(d.Et),
                    ed = (0, i.g)(d.tw),
                    ec = (0, i.g)(d.DW),
                    em = (0, i.g)(d.HU),
                    eu = (0, i.g)(d.Yb),
                    ef = (0, i.g)(d.zT),
                    ex = (0, i.g)(d.xG),
                    eg = (0, i.g)(d.Zx),
                    eb = (0, i.g)(d.To),
                    eh = (0, i.g)(d.m1),
                    ep = (0, i.g)(e => e.requestState),
                    [ej, ev] = (0, n.useState)(!1),
                    [ew, ey] = (0, n.useState)(!1),
                    eN = (0, n.useRef)(crypto.randomUUID()),
                    [ek, eI] = (0, n.useState)(null),
                    [eE, ez] = (0, n.useState)(30),
                    [eT, eR] = (0, n.useState)(!1),
                    e_ = (0, n.useRef)(null),
                    [eS, eL] = (0, n.useState)({
                        loading: !0,
                        canJoin: !1,
                        error: null
                    }),
                    [eP, eC] = (0, n.useState)(5);
                (0, n.useEffect)(() => {
                    E.current = !1, k.current = !1
                }, [a]), (0, n.useEffect)(() => {
                    L()
                }, [L]), (0, n.useEffect)(() => {
                    S || T || t.push("/login")
                }, [S, T, t]), (0, n.useEffect)(() => {
                    let e = !0;
                    return (async () => {
                        var r, n, o;
                        if (!T || !a) return;
                        if (E.current) {
                            console.log("[Game Page] Validation already done, skipping");
                            return
                        }
                        if (console.log("[Game Page] Validating room access:", a), !e) return;
                        eL({
                            loading: !0,
                            canJoin: !1,
                            error: null
                        });
                        let s = await w.h.getRoomStatus(a);
                        if (e) {
                            if (s.error) {
                                console.log("[Game Page] ❌ Room validation error:", s.error), eL({
                                    loading: !1,
                                    canJoin: !1,
                                    error: s.error
                                }), t.push("/lobby");
                                return
                            }
                            if (!(null === (r = s.data) || void 0 === r ? void 0 : r.canJoin)) {
                                let a = (null === (n = s.data) || void 0 === n ? void 0 : n.status) === "FINISHED" ? "Este jogo j\xe1 foi finalizado" : (null === (o = s.data) || void 0 === o ? void 0 : o.isParticipant) ? "N\xe3o foi poss\xedvel acessar este jogo" : "Voc\xea n\xe3o \xe9 participante deste jogo";
                                console.log("[Game Page] ❌ Cannot join room:", a), eL({
                                    loading: !1,
                                    canJoin: !1,
                                    error: a
                                }), setTimeout(() => {
                                    e && t.push("/lobby")
                                }, 2e3);
                                return
                            }
                            console.log("[Game Page] ✅ Room validation passed"), eL({
                                loading: !1,
                                canJoin: !0,
                                error: null
                            }), E.current = !0
                        }
                    })(), () => {
                        e = !1
                    }
                }, [T, a, t]), (0, n.useEffect)(() => {
                    !eS.canJoin || P || Z || (console.log("[Game Page] Connecting to WebSocket..."), ei(a))
                }, [eS.canJoin, P, Z, ei, a]), (0, n.useEffect)(() => {
                    let e = e => {
                        if (e.origin !== window.location.origin) {
                            console.warn("[Game Page] Blocked message from unauthorized origin:", e.origin);
                            return
                        }
                        if (!e.data || !e.data.type) return;
                        let t = e.data.type;
                        if ("IFRAME_READY" !== t && "INIT_ACK" !== t && e.data._st !== eN.current) {
                            console.warn("[Game Page] Blocked message with invalid session token:", t);
                            return
                        }
                        switch (t) {
                            case "IFRAME_READY":
                                console.log("[Game Page] Iframe listener ready, can send messages now"), k.current && (console.log("[Game Page] Iframe reloaded - resetting initSent for re-init"), k.current = !1), ey(!0);
                                break;
                            case "INIT_ACK":
                                console.log("[Game Page] Iframe acknowledged INIT_MULTIPLAYER"), I.current && (clearInterval(I.current), I.current = null);
                                break;
                            case "GAME_READY":
                                var a;
                                console.log("[Game Page] Game iframe ready"), ev(!0), (null === (a = N.current) || void 0 === a ? void 0 : a.contentWindow) && eb(N.current.contentWindow, eN.current), console.log("[Game Page] Sending game_ready to server"), eh();
                                break;
                            case "SHOT":
                                console.log("[Game Page] Received SHOT from iframe:", e.data.data), ed(e.data.data);
                                break;
                            case "SHOT_RESULT":
                                console.log("[Game Page] Received SHOT_RESULT from iframe:", e.data.data), ec(e.data.data);
                                break;
                            case "SHOT_OBSERVATION":
                                i.g.getState().sendShotObservation(e.data.data);
                                break;
                            case "STICK_UPDATE":
                                em(e.data.data);
                                break;
                            case "PLACE_CUE_BALL":
                                console.log("[Game Page] Received PLACE_CUE_BALL from iframe:", e.data.data), eu(e.data.data.x, e.data.data.y);
                                break;
                            case "CUE_BALL_MOVING":
                                ef(e.data.data.x, e.data.data.y);
                                break;
                            case "STICK_CHARGING":
                                ex(e.data.data);
                                break;
                            case "FORFEIT":
                                console.log("[Game Page] Received FORFEIT from iframe"), eg();
                                break;
                            case "REQUEST_STATE":
                                console.log("[Game Page] Received REQUEST_STATE from iframe"), ep();
                                break;
                            case "REQUEST_STATE_SYNC":
                                console.log("[Game Page] Received REQUEST_STATE_SYNC from iframe (timer fallback):", e.data.data), ep();
                                break;
                            case "GAME_OVER_ACK":
                                console.log("[Game Page] Received GAME_OVER_ACK from iframe - showing result modal"), e_.current && (clearTimeout(e_.current), e_.current = null), eR(!0)
                        }
                    };
                    return window.addEventListener("message", e), () => window.removeEventListener("message", e)
                }, [ed, ec, em, eu, ef, ex, eb, eh]), (0, n.useEffect)(() => {
                    var e;
                    if (console.log("[Game Page] useEffect - gameStarted:", G, "iframeReady:", ew, "initSent:", k.current, "playerNum:", M), G && ew && !k.current && !(M <= 0) && (null === (e = N.current) || void 0 === e ? void 0 : e.contentWindow)) {
                        let e = () => {
                            var e;
                            (null === (e = N.current) || void 0 === e ? void 0 : e.contentWindow) && (console.log("[Game Page] Sending INIT_MULTIPLAYER to iframe", {
                                roomId: a,
                                playerNum: M,
                                phase: O
                            }), N.current.contentWindow.postMessage({
                                type: "INIT_MULTIPLAYER",
                                _st: eN.current,
                                config: {
                                    roomId: a,
                                    userId: null == z ? void 0 : z.id,
                                    playerNum: M,
                                    opponentName: $,
                                    player1Name: K,
                                    player2Name: Q,
                                    isMyTurn: B,
                                    currentTurn: U,
                                    phase: O,
                                    isBreakShot: V,
                                    myBallType: W,
                                    balls: F,
                                    turnTimeRemaining: J,
                                    serverTimestamp: Y
                                }
                            }, window.location.origin))
                        };
                        k.current = !0, e(), console.log("[Game Page] INIT_MULTIPLAYER postMessage called"), I.current && clearInterval(I.current);
                        let t = 0;
                        I.current = setInterval(() => {
                            if (++t >= 5) {
                                console.error("[Game Page] INIT_MULTIPLAYER not acknowledged after 5 retries"), I.current && clearInterval(I.current), I.current = null;
                                return
                            }
                            console.log("[Game Page] Retrying INIT_MULTIPLAYER (attempt ".concat(t + 1, ")")), e()
                        }, 2e3)
                    }
                }, [G, ew, M]);
                let eA = (0, n.useRef)(null);
                if ((0, n.useEffect)(() => {
                        eA.current && (console.log("[Game Page] Clearing pending cleanup timer (Strict Mode re-mount)"), clearTimeout(eA.current), eA.current = null)
                    }, []), (0, n.useEffect)(() => {
                        let e = N.current;
                        return () => {
                            if (console.log("[Game Page] \uD83E\uDDF9 Component unmounting, scheduling cleanup..."), k.current = !1, I.current && (clearInterval(I.current), I.current = null), null == e ? void 0 : e.contentWindow) try {
                                let t = e.contentWindow;
                                "function" == typeof t.cleanupZoomPrevention && t.cleanupZoomPrevention()
                            } catch (e) {}
                            e && (e.src = "about:blank"), eA.current = setTimeout(() => {
                                console.log("[Game Page] \uD83E\uDDF9 Delayed cleanup executing (real unmount)");
                                let e = i.g.getState();
                                (e.room || e.isConnected) && el()
                            }, 100)
                        }
                    }, [el]), (0, n.useEffect)(() => {
                        let e = e => {
                            H || C || !P || !G || Z || (e.preventDefault(), e.returnValue = "Sair agora resultara em DERROTA IMEDIATA. Tem certeza?")
                        };
                        return window.addEventListener("beforeunload", e), () => window.removeEventListener("beforeunload", e)
                    }, [G, Z, H, C, P]), (0, n.useEffect)(() => {
                        if (Z && D) return e_.current = setTimeout(() => {
                            console.log("[Game Page] Game over fallback timer - showing modal"), eR(!0)
                        }, 6e3), () => {
                            e_.current && (clearTimeout(e_.current), e_.current = null)
                        };
                        eR(!1)
                    }, [Z, D]), (0, n.useEffect)(() => {
                        if (!eT || !D) {
                            eC(5);
                            return
                        }
                        let e = setInterval(() => {
                            eC(e => e - 1)
                        }, 1e3);
                        return () => clearInterval(e)
                    }, [eT, D]), (0, n.useEffect)(() => {
                        if (eT && D && eP <= 0) {
                            var e;
                            if (console.log("[Game Page] \uD83E\uDDF9 Redirecting to lobby after game over..."), eL({
                                    loading: !1,
                                    canJoin: !1,
                                    error: null
                                }), null === (e = N.current) || void 0 === e ? void 0 : e.contentWindow) try {
                                let e = N.current.contentWindow;
                                "function" == typeof e.cleanupZoomPrevention && e.cleanupZoomPrevention()
                            } catch (e) {}
                            N.current && (N.current.src = "about:blank"), el(), window.location.href = "/lobby"
                        }
                    }, [eP, eT, D]), (0, n.useEffect)(() => {
                        let e = 0,
                            t = () => {
                                let t = !document.hidden;
                                if (console.log("[Game Page] Visibility:", t ? "visible" : "hidden"), t && P && G && !Z) {
                                    let t = Date.now();
                                    if (t - e > 500) {
                                        var a;
                                        console.log("[Game Page] Tab visible again — posting VISIBILITY_RESTORED to iframe"), (null === (a = N.current) || void 0 === a ? void 0 : a.contentWindow) && N.current.contentWindow.postMessage({
                                            type: "VISIBILITY_RESTORED",
                                            timestamp: t
                                        }, "*"), e = t
                                    }
                                }
                            };
                        return document.addEventListener("visibilitychange", t), () => document.removeEventListener("visibilitychange", t)
                    }, [G, P, Z]), (0, n.useEffect)(() => {
                        if (!X || !ee) {
                            eI(null);
                            return
                        }
                        let e = () => {
                            eI(Math.max(0, Math.ceil((ee - Date.now()) / 1e3)))
                        };
                        e();
                        let t = setInterval(e, 1e3);
                        return () => clearInterval(t)
                    }, [X, ee]), (0, n.useEffect)(() => {
                        if (!ea) {
                            ez(30);
                            return
                        }
                        let e = setInterval(() => {
                            ez(e => Math.max(0, e - 1))
                        }, 1e3);
                        return () => clearInterval(e)
                    }, [ea]), eS.error) return (0, r.jsx)("main", {
                    className: "min-h-screen flex items-center justify-center p-4 bg-black",
                    children: (0, r.jsxs)("div", {
                        className: "card text-center max-w-md w-full",
                        children: [(0, r.jsx)("div", {
                            className: "inline-flex items-center justify-center w-24 h-24 rounded-full mb-6 bg-red-500/20",
                            children: (0, r.jsx)(c.Z, {
                                size: 48,
                                className: "text-red-400"
                            })
                        }), (0, r.jsx)("h1", {
                            className: "font-display text-2xl font-bold mb-2",
                            children: "Acesso Negado"
                        }), (0, r.jsx)("p", {
                            className: "text-white/60 mb-6",
                            children: eS.error
                        }), (0, r.jsx)("p", {
                            className: "text-white/40 text-sm mb-4",
                            children: "Redirecionando para o lobby..."
                        }), (0, r.jsxs)(v.default, {
                            href: "/lobby",
                            className: "btn-primary w-full flex items-center justify-center gap-2",
                            children: [(0, r.jsx)(m.Z, {
                                size: 20
                            }), "Ir para o Lobby"]
                        })]
                    })
                });
                if (S || !z || eS.loading) return (0, r.jsx)("div", {
                    className: "min-h-screen flex items-center justify-center bg-black",
                    children: (0, r.jsx)(u.Z, {
                        size: 40,
                        className: "animate-spin text-pool-gold"
                    })
                });
                if (eT && D) {
                    let e = D.id === z.id,
                        t = function(e, t) {
                            if (!e) return null;
                            if (t) {
                                if ("Pocketed 8-ball legally" === e) return "Bola 8 enca\xe7apada com sucesso!";
                                if ("opponent_forfeit" === e) return "Oponente desistiu da partida";
                                if ("opponent_disconnect" === e) return "Oponente desconectou";
                                if ("opponent_exceeded_disconnection_limit" === e) return "Oponente excedeu o limite de reconex\xf5es";
                                if ("Opponent pocketed 8-ball before ball types assigned" === e) return "Oponente enca\xe7apou a bola 8 antes da defini\xe7\xe3o de grupos";
                                let t = e.match(/^Opponent pocketed 8-ball with (\d+) balls? remaining$/);
                                if (t) {
                                    let e = t[1];
                                    return "Oponente enca\xe7apou a bola 8 com ".concat(e, " bola").concat(Number(e) > 1 ? "s" : "", " restante").concat(Number(e) > 1 ? "s" : "")
                                }
                                let r = e.match(/^Opponent pocketed 8-ball with foul: (.+)$/);
                                if (r) {
                                    var a;
                                    return "Oponente cometeu falta na bola 8: ".concat(_[a = r[1]] || a.toLowerCase())
                                }
                            }
                            return e
                        }(D.reason, e);
                    return (0, r.jsx)("main", {
                        className: "min-h-screen flex items-center justify-center p-4 bg-gradient-to-b from-pool-dark to-black",
                        children: (0, r.jsxs)("div", {
                            className: "text-center max-w-md w-full space-y-6",
                            children: [(0, r.jsx)(j.default, {
                                src: "/logos/logo-white-red.png",
                                alt: "Tacadinha",
                                width: 140,
                                height: 45,
                                className: "h-10 w-auto mx-auto"
                            }), (0, r.jsxs)("div", {
                                children: [(0, r.jsx)("div", {
                                    className: "inline-flex items-center justify-center w-24 h-24 rounded-full mb-4 ".concat(e ? "bg-yellow-500/10 ring-2 ring-yellow-500/40" : "bg-red-500/10 ring-2 ring-red-500/40"),
                                    children: e ? (0, r.jsx)(f.Z, {
                                        size: 48,
                                        className: "text-yellow-400"
                                    }) : (0, r.jsx)(c.Z, {
                                        size: 48,
                                        className: "text-red-400"
                                    })
                                }), (0, r.jsx)("h1", {
                                    className: "font-display text-4xl font-bold mb-1",
                                    children: e ? "Voc\xea Venceu!" : "Voc\xea Perdeu"
                                }), (0, r.jsx)("p", {
                                    className: "text-white/50 text-sm",
                                    children: e ? "Partida contra ".concat($) : "".concat(D.name, " venceu a partida")
                                })]
                            }), t && (0, r.jsx)("div", {
                                className: "inline-block px-4 py-2 rounded-full text-sm border ".concat(e ? "bg-yellow-500/10 border-yellow-500/30 text-yellow-300" : "bg-red-500/10 border-red-500/30 text-red-300"),
                                children: t
                            }), (0, r.jsxs)("div", {
                                className: "grid grid-cols-1 gap-3",
                                children: [e && D.prize > 0 && (0, r.jsxs)("div", {
                                    className: "bg-green-500/10 border border-green-500/30 rounded-xl p-4",
                                    children: [(0, r.jsx)("p", {
                                        className: "text-green-400/70 text-xs uppercase tracking-wider mb-1",
                                        children: "Pr\xeamio"
                                    }), (0, r.jsxs)("p", {
                                        className: "text-3xl font-bold text-green-400",
                                        children: ["R$ ", Number(D.prize).toFixed(2)]
                                    })]
                                }), D.rankingUpdate && (0, r.jsxs)("div", {
                                    className: "".concat(e ? "bg-pool-gold/10 border-pool-gold/30" : "bg-red-500/5 border-red-500/20", " border rounded-xl p-4"),
                                    children: [(0, r.jsxs)("div", {
                                        className: "flex items-center justify-center gap-1.5 mb-3",
                                        children: [e ? (0, r.jsx)(x.Z, {
                                            size: 14,
                                            className: "text-pool-gold"
                                        }) : (0, r.jsx)(g.Z, {
                                            size: 14,
                                            className: "text-red-400"
                                        }), (0, r.jsx)("span", {
                                            className: "text-white/50 text-xs uppercase tracking-wider",
                                            children: "Ranking da Temporada"
                                        })]
                                    }), (0, r.jsxs)("div", {
                                        className: "flex items-center justify-between",
                                        children: [(0, r.jsxs)("div", {
                                            children: [(0, r.jsxs)("span", {
                                                className: "text-2xl font-bold ".concat(e ? "text-pool-gold" : "text-red-400"),
                                                children: [e ? "+" : "", D.rankingUpdate.pointsChange]
                                            }), (0, r.jsx)("span", {
                                                className: "text-sm ml-1 ".concat(e ? "text-pool-gold/60" : "text-red-400/60"),
                                                children: "pts"
                                            })]
                                        }), (0, r.jsxs)("div", {
                                            className: "text-right",
                                            children: [(0, r.jsx)("span", {
                                                className: "text-white/40 text-xs block",
                                                children: "Novo total"
                                            }), (0, r.jsx)("span", {
                                                className: "text-white font-semibold text-lg",
                                                children: D.rankingUpdate.newPoints
                                            })]
                                        })]
                                    })]
                                })]
                            }), (0, r.jsxs)("div", {
                                className: "space-y-3 pt-2",
                                children: [(0, r.jsxs)(v.default, {
                                    href: "/lobby",
                                    className: "btn-primary w-full flex items-center justify-center gap-2",
                                    children: [(0, r.jsx)(m.Z, {
                                        size: 20
                                    }), "Voltar ao Lobby"]
                                }), (0, r.jsxs)("p", {
                                    className: "text-xs text-white/30",
                                    children: ["Redirecionando em ", eP, "s..."]
                                })]
                            })]
                        })
                    })
                }
                return (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(y, {}), (0, r.jsx)(R, {}), (0, r.jsxs)("main", {
                        className: "fixed inset-0 bg-black overflow-hidden",
                        children: [ea && (0, r.jsxs)("div", {
                            className: "absolute inset-0 z-35 flex flex-col items-center justify-center bg-gradient-to-b from-black via-black/95 to-black p-4",
                            children: [(0, r.jsxs)("div", {
                                className: "w-full max-w-md bg-gradient-to-b from-pool-dark/80 to-pool-dark/40 border border-white/10 rounded-2xl p-6 shadow-2xl",
                                children: [(0, r.jsxs)("div", {
                                    className: "flex flex-col items-center mb-6",
                                    children: [(0, r.jsxs)("div", {
                                        className: "relative mb-4",
                                        children: [(0, r.jsx)("div", {
                                            className: "absolute inset-0 w-20 h-20 rounded-full border-2 border-pool-gold/30 animate-ping"
                                        }), (0, r.jsx)("div", {
                                            className: "relative w-20 h-20 rounded-full bg-gradient-to-br from-pool-gold/20 to-pool-gold/5 flex items-center justify-center border border-pool-gold/40",
                                            children: (0, r.jsx)(u.Z, {
                                                size: 36,
                                                className: "text-pool-gold animate-spin"
                                            })
                                        })]
                                    }), (0, r.jsx)("h2", {
                                        className: "text-xl font-bold text-white",
                                        children: "Preparando Partida"
                                    }), (0, r.jsx)("p", {
                                        className: "text-white/50 text-sm mt-1",
                                        children: "Aguardando jogadores..."
                                    })]
                                }), (0, r.jsxs)("div", {
                                    className: "space-y-3 mb-6",
                                    children: [(0, r.jsxs)("div", {
                                        className: "relative flex items-center gap-4 p-4 rounded-xl transition-all duration-500 ".concat(eo ? "bg-green-500/10 border border-green-500/30" : "bg-white/5 border border-white/10"),
                                        children: [(0, r.jsxs)("div", {
                                            className: "relative w-12 h-12 rounded-full flex items-center justify-center transition-all duration-500 ".concat(eo ? "bg-gradient-to-br from-green-500 to-green-600 shadow-lg shadow-green-500/30" : "bg-pool-dark border border-white/20"),
                                            children: [eo ? (0, r.jsx)(b.Z, {
                                                size: 24,
                                                className: "text-white",
                                                strokeWidth: 3
                                            }) : (0, r.jsx)(h.Z, {
                                                size: 20,
                                                className: "text-white/50"
                                            }), !eo && (0, r.jsx)("div", {
                                                className: "absolute inset-0 rounded-full border-2 border-transparent border-t-pool-gold/50 animate-spin"
                                            })]
                                        }), (0, r.jsxs)("div", {
                                            className: "flex-1 min-w-0",
                                            children: [(0, r.jsxs)("div", {
                                                className: "flex items-center gap-2",
                                                children: [(0, r.jsx)("p", {
                                                    className: "font-semibold truncate ".concat(eo ? "text-green-400" : "text-white"),
                                                    children: K || "Jogador 1"
                                                }), 1 === M && (0, r.jsx)("span", {
                                                    className: "px-2 py-0.5 bg-pool-gold/20 text-pool-gold text-xs font-medium rounded-full",
                                                    children: "Voc\xea"
                                                })]
                                            }), (0, r.jsx)("p", {
                                                className: "text-sm ".concat(eo ? "text-green-400/70" : "text-white/40"),
                                                children: eo ? "✓ Jogo carregado" : "Carregando jogo..."
                                            })]
                                        }), (0, r.jsx)("div", {
                                            className: "w-3 h-3 rounded-full ".concat(eo ? "bg-green-500 shadow-lg shadow-green-500/50" : "bg-yellow-500 animate-pulse")
                                        })]
                                    }), (0, r.jsxs)("div", {
                                        className: "flex items-center justify-center py-1",
                                        children: [(0, r.jsx)("div", {
                                            className: "flex-1 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"
                                        }), (0, r.jsx)("span", {
                                            className: "px-3 text-white/30 text-xs font-medium",
                                            children: "VS"
                                        }), (0, r.jsx)("div", {
                                            className: "flex-1 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"
                                        })]
                                    }), (0, r.jsxs)("div", {
                                        className: "relative flex items-center gap-4 p-4 rounded-xl transition-all duration-500 ".concat(es ? "bg-green-500/10 border border-green-500/30" : "bg-white/5 border border-white/10"),
                                        children: [(0, r.jsxs)("div", {
                                            className: "relative w-12 h-12 rounded-full flex items-center justify-center transition-all duration-500 ".concat(es ? "bg-gradient-to-br from-green-500 to-green-600 shadow-lg shadow-green-500/30" : "bg-pool-dark border border-white/20"),
                                            children: [es ? (0, r.jsx)(b.Z, {
                                                size: 24,
                                                className: "text-white",
                                                strokeWidth: 3
                                            }) : (0, r.jsx)(h.Z, {
                                                size: 20,
                                                className: "text-white/50"
                                            }), !es && (0, r.jsx)("div", {
                                                className: "absolute inset-0 rounded-full border-2 border-transparent border-t-pool-gold/50 animate-spin"
                                            })]
                                        }), (0, r.jsxs)("div", {
                                            className: "flex-1 min-w-0",
                                            children: [(0, r.jsxs)("div", {
                                                className: "flex items-center gap-2",
                                                children: [(0, r.jsx)("p", {
                                                    className: "font-semibold truncate ".concat(es ? "text-green-400" : "text-white"),
                                                    children: Q || "Jogador 2"
                                                }), 2 === M && (0, r.jsx)("span", {
                                                    className: "px-2 py-0.5 bg-pool-gold/20 text-pool-gold text-xs font-medium rounded-full",
                                                    children: "Voc\xea"
                                                })]
                                            }), (0, r.jsx)("p", {
                                                className: "text-sm ".concat(es ? "text-green-400/70" : "text-white/40"),
                                                children: es ? "✓ Jogo carregado" : "Carregando jogo..."
                                            })]
                                        }), (0, r.jsx)("div", {
                                            className: "w-3 h-3 rounded-full ".concat(es ? "bg-green-500 shadow-lg shadow-green-500/50" : "bg-yellow-500 animate-pulse")
                                        })]
                                    })]
                                }), (0, r.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [(0, r.jsxs)("div", {
                                        className: "flex items-center justify-between text-xs",
                                        children: [(0, r.jsx)("span", {
                                            className: "text-white/40",
                                            children: "Tempo para carregar"
                                        }), (0, r.jsxs)("span", {
                                            className: "font-mono font-bold ".concat(eE <= 10 ? "text-red-400" : "text-pool-gold"),
                                            children: [eE, "s"]
                                        })]
                                    }), (0, r.jsx)("div", {
                                        className: "h-2 bg-white/10 rounded-full overflow-hidden",
                                        children: (0, r.jsx)("div", {
                                            className: "h-full rounded-full transition-all duration-1000 ease-linear ".concat(eE <= 10 ? "bg-gradient-to-r from-red-500 to-red-400" : "bg-gradient-to-r from-pool-gold to-yellow-400"),
                                            style: {
                                                width: "".concat(eE / 30 * 100, "%")
                                            }
                                        })
                                    })]
                                }), eE <= 10 && (0, r.jsx)("div", {
                                    className: "mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg",
                                    children: (0, r.jsx)("p", {
                                        className: "text-red-400 text-xs text-center",
                                        children: "⚠️ Pouco tempo restante! A partida ser\xe1 cancelada se ambos n\xe3o carregarem."
                                    })
                                })]
                            }), (0, r.jsx)("p", {
                                className: "mt-4 text-white/30 text-xs text-center max-w-sm",
                                children: "A partida iniciar\xe1 automaticamente quando ambos os jogadores estiverem prontos"
                            })]
                        }), er && (0, r.jsx)("div", {
                            className: "absolute inset-0 z-40 flex flex-col items-center justify-center bg-gradient-to-b from-black via-black/95 to-black p-4",
                            children: (0, r.jsxs)("div", {
                                className: "w-full max-w-md bg-gradient-to-b from-red-950/50 to-pool-dark/40 border border-red-500/20 rounded-2xl p-6 shadow-2xl",
                                children: [(0, r.jsxs)("div", {
                                    className: "flex flex-col items-center mb-6",
                                    children: [(0, r.jsx)("div", {
                                        className: "relative mb-4",
                                        children: (0, r.jsx)("div", {
                                            className: "w-20 h-20 rounded-full bg-gradient-to-br from-red-500/20 to-red-500/5 flex items-center justify-center border border-red-500/40",
                                            children: (0, r.jsx)(c.Z, {
                                                size: 40,
                                                className: "text-red-400"
                                            })
                                        })
                                    }), (0, r.jsx)("h2", {
                                        className: "text-xl font-bold text-white",
                                        children: "Falha ao Iniciar"
                                    })]
                                }), (0, r.jsx)("div", {
                                    className: "p-4 bg-red-500/10 border border-red-500/20 rounded-xl mb-6",
                                    children: (0, r.jsx)("p", {
                                        className: "text-red-300 text-sm text-center",
                                        children: en || "N\xe3o foi poss\xedvel iniciar a partida. O jogo foi cancelado."
                                    })
                                }), (0, r.jsx)("div", {
                                    className: "p-4 bg-green-500/10 border border-green-500/20 rounded-xl mb-6",
                                    children: (0, r.jsxs)("div", {
                                        className: "flex items-center justify-center gap-2 text-green-400",
                                        children: [(0, r.jsx)(b.Z, {
                                            size: 18
                                        }), (0, r.jsx)("p", {
                                            className: "text-sm font-medium",
                                            children: "Seu saldo foi reembolsado"
                                        })]
                                    })
                                }), (0, r.jsxs)("div", {
                                    className: "flex items-center justify-center gap-2 text-white/40",
                                    children: [(0, r.jsx)(u.Z, {
                                        size: 14,
                                        className: "animate-spin"
                                    }), (0, r.jsx)("p", {
                                        className: "text-sm",
                                        children: "Redirecionando para o lobby..."
                                    })]
                                })]
                            })
                        }), q && (0, r.jsxs)("div", {
                            className: "absolute inset-0 z-35 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm p-4",
                            children: [(0, r.jsx)("div", {
                                className: "w-20 h-20 rounded-full bg-blue-500/20 flex items-center justify-center mb-4 animate-pulse",
                                children: (0, r.jsx)(u.Z, {
                                    size: 40,
                                    className: "text-blue-400 animate-spin"
                                })
                            }), (0, r.jsx)("h2", {
                                className: "text-2xl font-bold text-white mb-2",
                                children: "Sincronizando partida"
                            }), (0, r.jsx)("p", {
                                className: "text-white/60 text-center mb-2",
                                children: "Aguardando atualiza\xe7\xe3o do servidor..."
                            }), (0, r.jsx)("p", {
                                className: "text-white/40 text-sm text-center",
                                children: "A jogada est\xe1 em andamento. Por favor, aguarde."
                            })]
                        }), X && null !== ek && (0, r.jsxs)("div", {
                            className: "absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm p-4",
                            children: [(0, r.jsx)("div", {
                                className: "w-20 h-20 rounded-full bg-yellow-500/20 flex items-center justify-center mb-4 animate-pulse",
                                children: (0, r.jsx)(p.Z, {
                                    size: 40,
                                    className: "text-yellow-400"
                                })
                            }), (0, r.jsx)("h2", {
                                className: "text-2xl font-bold text-white mb-2",
                                children: "Aguardando oponente"
                            }), (0, r.jsxs)("p", {
                                className: "text-white/60 text-center mb-2",
                                children: [et, " perdeu a conex\xe3o."]
                            }), (0, r.jsx)("p", {
                                className: "text-white/40 text-sm text-center mb-4",
                                children: "Aguardando reconex\xe3o..."
                            }), (0, r.jsx)("div", {
                                className: "bg-pool-dark/80 border border-yellow-500/30 rounded-lg px-6 py-3 mb-6",
                                children: (0, r.jsxs)("p", {
                                    className: "text-yellow-400 text-3xl font-bold font-mono",
                                    children: [Math.floor(ek / 60), ":", (ek % 60).toString().padStart(2, "0")]
                                })
                            }), (0, r.jsx)("p", {
                                className: "text-white/30 text-xs text-center",
                                children: "Voc\xea vencer\xe1 automaticamente se o oponente n\xe3o reconectar a tempo."
                            })]
                        }), C && (0, r.jsxs)("div", {
                            className: "absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-sm p-4",
                            children: [(0, r.jsx)("div", {
                                className: "w-20 h-20 rounded-full bg-yellow-500/20 flex items-center justify-center mb-4 animate-pulse",
                                children: (0, r.jsx)(u.Z, {
                                    size: 40,
                                    className: "text-yellow-400 animate-spin"
                                })
                            }), (0, r.jsx)("h2", {
                                className: "text-2xl font-bold text-white mb-2",
                                children: "Reconectando..."
                            }), (0, r.jsx)("p", {
                                className: "text-white/60 text-center mb-2",
                                children: "Tentando restabelecer conex\xe3o com o servidor."
                            }), (0, r.jsx)("p", {
                                className: "text-white/40 text-sm text-center mb-6",
                                children: A > 0 ? "Tentativa ".concat(A, "... Voc\xea tem 30 segundos para reconectar.") : "Voc\xea tem 30 segundos para reconectar antes de perder a partida."
                            }), (0, r.jsxs)(v.default, {
                                href: "/lobby",
                                className: "btn-secondary flex items-center justify-center gap-2 px-6",
                                onClick: () => i.g.getState().reset(),
                                children: [(0, r.jsx)(m.Z, {
                                    size: 20
                                }), "Desistir e Voltar ao Lobby"]
                            })]
                        }), (0, r.jsx)("iframe", {
                            ref: N,
                            src: "/game/index.html",
                            className: "w-full h-full border-0",
                            allow: "autoplay"
                        })]
                    })]
                })
            }
        },
        54012: function(e, t, a) {
            "use strict";

            function r(e, t) {
                window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                    event: e,
                    ...t
                }), console.log("[GTM] Event pushed: ".concat(e), t)
            }

            function n(e) {
                r("deposit_initiated", {
                    transaction_id: e.transactionId,
                    value: e.amount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function o(e) {
                r("deposit_completed", {
                    transaction_id: e.transactionId,
                    value: e.amount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function s(e) {
                r("withdrawal_requested", {
                    transaction_id: e.transactionId,
                    value: e.amount,
                    net_value: e.netAmount,
                    fee: e.fee,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function i(e) {
                r("match_created", {
                    room_id: e.roomId,
                    bet_amount: e.betAmount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function l(e) {
                r("game_started", {
                    match_id: e.matchId,
                    room_id: e.roomId,
                    bet_amount: e.betAmount,
                    player_num: e.playerNum,
                    is_break_shot: e.isBreakShot,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function d(e) {
                r("game_ended", {
                    match_id: e.matchId,
                    room_id: e.roomId,
                    won: e.won,
                    prize_amount: e.prizeAmount,
                    currency: "BRL",
                    user_id: e.userId
                })
            }

            function c(e) {
                r("sign_up", {
                    user_id: e.userId,
                    method: e.method || "email",
                    referral_code: e.referralCode
                })
            }
            a.d(t, {
                FA: function() {
                    return n
                },
                Jq: function() {
                    return l
                },
                Sw: function() {
                    return c
                },
                gh: function() {
                    return d
                },
                iy: function() {
                    return o
                },
                mY: function() {
                    return i
                },
                w7: function() {
                    return s
                }
            })
        },
        6739: function(e, t, a) {
            "use strict";
            a.d(t, {
                d8: function() {
                    return s
                },
                tN: function() {
                    return d
                }
            });
            var r = a(22020),
                n = a(10826);
            let o = "undefined" != typeof document;

            function s(e, t, a) {
                if (!o) return;
                let r = new Date;
                r.setTime(r.getTime() + 864e5 * a), document.cookie = "".concat(e, "=").concat(encodeURIComponent(t), ";expires=").concat(r.toUTCString(), ";path=/")
            }

            function i(e) {
                if (!o) return null;
                let t = document.cookie.match(RegExp("(^| )" + e + "=([^;]+)"));
                if (t) try {
                    return decodeURIComponent(t[2])
                } catch (e) {
                    return t[2]
                }
                return null
            }
            var l = a(54012);
            let d = (0, r.Ue)((e, t) => ({
                user: null,
                isAuthenticated: !1,
                isLoading: !0,
                error: null,
                banInfo: null,
                login: async (t, a) => {
                    e({
                        isLoading: !0,
                        error: null,
                        banInfo: null
                    });
                    let r = await n.h.login(t, a);
                    if (r.error) return e({
                        isLoading: !1,
                        error: r.error,
                        banInfo: r.banInfo || null
                    }), !1;
                    if (r.data) {
                        n.h.setToken(r.data.token), localStorage.setItem("userId", r.data.user.id);
                        let t = r.data.user;
                        return e({
                            user: {
                                id: t.id,
                                email: t.email,
                                name: t.name,
                                username: t.username,
                                phone: t.phone,
                                cpf: t.cpf,
                                role: t.role,
                                referralCode: t.referralCode || "",
                                managerCode: t.managerCode,
                                managedById: t.managedById,
                                balance: Number(t.balance),
                                affiliateWallet: Number(t.affiliateWallet || 0)
                            },
                            isAuthenticated: !0,
                            isLoading: !1
                        }), !0
                    }
                    return !1
                },
                register: async (t, a, r, o) => {
                    e({
                        isLoading: !0,
                        error: null
                    });
                    let s = i("referralCode"),
                        d = i("managerCode"),
                        c = await n.h.register(t, a, r, o || void 0, s || void 0, d || void 0);
                    if (c.error) return e({
                        isLoading: !1,
                        error: c.error
                    }), !1;
                    if (c.data) {
                        n.h.setToken(c.data.token), localStorage.setItem("userId", c.data.user.id);
                        let t = c.data.user;
                        return e({
                            user: {
                                id: t.id,
                                email: t.email,
                                name: t.name,
                                username: t.username,
                                phone: t.phone,
                                cpf: t.cpf,
                                role: t.role,
                                referralCode: t.referralCode || "",
                                managerCode: t.managerCode,
                                managedById: t.managedById,
                                balance: Number(t.balance),
                                affiliateWallet: Number(t.affiliateWallet || 0)
                            },
                            isAuthenticated: !0,
                            isLoading: !1
                        }), (0, l.Sw)({
                            userId: t.id,
                            referralCode: s || void 0
                        }), !0
                    }
                    return !1
                },
                logout: async () => {
                    try {
                        await n.h.logout()
                    } catch (e) {}
                    n.h.setToken(null), localStorage.removeItem("userId"), e({
                        user: null,
                        isAuthenticated: !1,
                        isLoading: !1
                    })
                },
                checkAuth: async () => {
                    let a = n.h.getToken(),
                        r = t();
                    if (r.isAuthenticated && r.user) {
                        e({
                            isLoading: !1
                        }), n.h.getProfile().then(t => {
                            if (t.data) {
                                let a = t.data;
                                e({
                                    user: {
                                        id: a.id,
                                        email: a.email,
                                        name: a.name,
                                        username: a.username,
                                        phone: a.phone,
                                        cpf: a.cpf,
                                        role: a.role,
                                        referralCode: a.referralCode || "",
                                        managerCode: a.managerCode,
                                        managedById: a.managedById,
                                        balance: Number(a.balance),
                                        affiliateWallet: Number(a.affiliateWallet || 0)
                                    }
                                })
                            }
                        }).catch(() => {});
                        return
                    }
                    if (!a) {
                        e({
                            isLoading: !1,
                            isAuthenticated: !1
                        });
                        return
                    }
                    let o = await n.h.getProfile();
                    if (o.error) {
                        "N\xe3o autorizado" === o.error || o.error.includes("401") || o.error.includes("Unauthorized") ? (n.h.setToken(null), e({
                            isLoading: !1,
                            isAuthenticated: !1,
                            user: null
                        })) : e({
                            isLoading: !1
                        });
                        return
                    }
                    if (o.data) {
                        localStorage.setItem("userId", o.data.id);
                        let t = o.data;
                        e({
                            user: {
                                id: t.id,
                                email: t.email,
                                name: t.name,
                                username: t.username,
                                phone: t.phone,
                                cpf: t.cpf,
                                role: t.role,
                                referralCode: t.referralCode || "",
                                managerCode: t.managerCode,
                                managedById: t.managedById,
                                balance: Number(t.balance),
                                affiliateWallet: Number(t.affiliateWallet || 0)
                            },
                            isAuthenticated: !0,
                            isLoading: !1
                        })
                    }
                },
                updateBalance: a => {
                    let r = t().user;
                    r && e({
                        user: { ...r,
                            balance: a
                        }
                    })
                },
                updatePhone: a => {
                    let r = t().user;
                    r && e({
                        user: { ...r,
                            phone: a
                        }
                    })
                },
                clearError: () => e({
                    error: null,
                    banInfo: null
                }),
                isAdmin: () => {
                    let {
                        user: e
                    } = t();
                    return (null == e ? void 0 : e.role) === "ADMIN"
                },
                isAffiliateManager: () => {
                    let {
                        user: e
                    } = t();
                    return (null == e ? void 0 : e.role) === "AFFILIATE_MANAGER"
                }
            }))
        },
        85043: function(e, t, a) {
            "use strict";
            a.d(t, {
                DW: function() {
                    return T
                },
                Dn: function() {
                    return m
                },
                Ec: function() {
                    return Z
                },
                Et: function() {
                    return E
                },
                HU: function() {
                    return R
                },
                JM: function() {
                    return k
                },
                Ke: function() {
                    return y
                },
                Q0: function() {
                    return u
                },
                Ql: function() {
                    return i
                },
                S: function() {
                    return p
                },
                TS: function() {
                    return N
                },
                To: function() {
                    return M
                },
                Yb: function() {
                    return _
                },
                Zw: function() {
                    return w
                },
                Zx: function() {
                    return P
                },
                b4: function() {
                    return v
                },
                bE: function() {
                    return h
                },
                cb: function() {
                    return j
                },
                d1: function() {
                    return s
                },
                dx: function() {
                    return O
                },
                ei: function() {
                    return r
                },
                ht: function() {
                    return x
                },
                hv: function() {
                    return l
                },
                i6: function() {
                    return G
                },
                kl: function() {
                    return b
                },
                m0: function() {
                    return A
                },
                m1: function() {
                    return D
                },
                mh: function() {
                    return g
                },
                s8: function() {
                    return o
                },
                tw: function() {
                    return z
                },
                vT: function() {
                    return c
                },
                wo: function() {
                    return C
                },
                xG: function() {
                    return L
                },
                xk: function() {
                    return n
                },
                yr: function() {
                    return f
                },
                z0: function() {
                    return d
                },
                zR: function() {
                    return I
                },
                zT: function() {
                    return S
                }
            });
            let r = e => e.isConnected,
                n = e => e.connectionLost,
                o = e => e.playerNum,
                s = e => e.phase,
                i = e => e.isMyTurn,
                l = e => e.currentTurn,
                d = e => e.isBreakShot,
                c = e => e.gameStarted,
                m = e => e.gameOver,
                u = e => e.winner,
                f = e => e.myBallType,
                x = e => e.balls,
                g = e => e.opponentName,
                b = e => e.roomStatus,
                h = e => e.confirmations,
                p = e => e.countdown,
                j = e => e.turnTimeRemaining,
                v = e => e.isSyncing,
                w = e => e.chatMessages,
                y = e => ({
                    playerNum: e.playerNum,
                    player1Name: e.player1Name,
                    player2Name: e.player2Name,
                    opponentName: e.opponentName,
                    myBallType: e.myBallType,
                    opponentBallType: e.opponentBallType
                }),
                N = e => ({
                    opponentDisconnected: e.opponentDisconnected,
                    opponentGraceEndTime: e.opponentGraceEndTime,
                    disconnectedPlayerName: e.disconnectedPlayerName
                }),
                k = e => ({
                    isInitializing: e.isInitializing,
                    initializationFailed: e.initializationFailed,
                    initializationFailedReason: e.initializationFailedReason,
                    player1GameReady: e.player1GameReady,
                    player2GameReady: e.player2GameReady
                }),
                I = e => e.connect,
                E = e => e.disconnect,
                z = e => e.sendShot,
                T = e => e.sendShotResult,
                R = e => e.sendStickUpdate,
                _ = e => e.sendPlaceCueBall,
                S = e => e.sendCueBallMoving,
                L = e => e.sendStickCharging,
                P = e => e.sendForfeit,
                C = e => e.confirmReady,
                A = e => e.cancelCountdown,
                G = e => e.sendChatMessage,
                Z = e => e.getChatHistory,
                D = e => e.sendGameReady,
                M = e => e.setIframeWindow,
                O = e => e.setOnRoomUpdate
        },
        80037: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, a(87461).Z)("Check", [
                ["path", {
                    d: "M20 6 9 17l-5-5",
                    key: "1gmf2c"
                }]
            ])
        },
        53348: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, a(87461).Z)("RotateCcw", [
                ["path", {
                    d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
                    key: "1357e3"
                }],
                ["path", {
                    d: "M3 3v5h5",
                    key: "1xhq8a"
                }]
            ])
        },
        29910: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, a(87461).Z)("Settings", [
                ["path", {
                    d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
                    key: "1qme2f"
                }],
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "3",
                    key: "1v7zrd"
                }]
            ])
        },
        90043: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, a(87461).Z)("Smartphone", [
                ["rect", {
                    width: "14",
                    height: "20",
                    x: "5",
                    y: "2",
                    rx: "2",
                    ry: "2",
                    key: "1yt0o3"
                }],
                ["path", {
                    d: "M12 18h.01",
                    key: "mhygvu"
                }]
            ])
        },
        10775: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, a(87461).Z)("TrendingDown", [
                ["polyline", {
                    points: "22 17 13.5 8.5 8.5 13.5 2 7",
                    key: "1r2t7k"
                }],
                ["polyline", {
                    points: "16 17 22 17 22 11",
                    key: "11uiuu"
                }]
            ])
        },
        29733: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, a(87461).Z)("TrendingUp", [
                ["polyline", {
                    points: "22 7 13.5 15.5 8.5 10.5 2 17",
                    key: "126l90"
                }],
                ["polyline", {
                    points: "16 7 22 7 22 13",
                    key: "kwv8wd"
                }]
            ])
        }
    },
    function(e) {
        e.O(0, [1615, 2807, 963, 703, 710, 4411, 9102, 826, 6023, 2971, 8069, 1744], function() {
            return e(e.s = 82312)
        }), _N_E = e.O()
    }
]);