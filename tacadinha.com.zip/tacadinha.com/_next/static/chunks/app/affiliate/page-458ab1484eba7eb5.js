(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2862], {
        89215: function(e, s, t) {
            Promise.resolve().then(t.bind(t, 80068))
        },
        80068: function(e, s, t) {
            "use strict";
            t.r(s), t.d(s, {
                default: function() {
                    return D
                }
            });
            var a = t(3827),
                l = t(64090),
                i = t(47907),
                n = t(6739),
                r = t(10826),
                c = t(4002),
                d = t(16112),
                o = t(99744),
                x = t(18994),
                m = t(17252),
                h = t(27271),
                u = t(32805),
                p = t(63854),
                f = t(57759),
                j = t(17021),
                g = t(80037),
                b = t(23416),
                N = t(34059),
                v = t(57976),
                w = t(29733),
                y = t(44715),
                k = t(10822),
                C = t(26490),
                Z = t(83484),
                S = t(98998),
                R = t(52235),
                z = t(79229),
                $ = t(10963);

            function D() {
                let e = (0, i.useRouter)(),
                    {
                        user: s,
                        isAuthenticated: t,
                        isLoading: D,
                        checkAuth: E
                    } = (0, n.tN)(),
                    [A, P] = (0, l.useState)(null),
                    [F, T] = (0, l.useState)([]),
                    [M, q] = (0, l.useState)([]),
                    [O, I] = (0, l.useState)(!1),
                    [L, G] = (0, l.useState)(!0),
                    [V, H] = (0, l.useState)("all"),
                    [W, _] = (0, l.useState)(!1),
                    [B, X] = (0, l.useState)(100),
                    [U, J] = (0, l.useState)(!1),
                    [Q, Y] = (0, l.useState)(""),
                    [K, ee] = (0, l.useState)(!1),
                    es = s ? "".concat(window.location.origin, "/register?ref=").concat(s.referralCode) : "";
                (0, l.useEffect)(() => {
                    E()
                }, [E]), (0, l.useEffect)(() => {
                    D || t || e.push("/login")
                }, [D, t, e]), (0, l.useEffect)(() => {
                    t && s && et()
                }, [t, s]);
                let et = async () => {
                        try {
                            G(!0);
                            let [e, s, t] = await Promise.all([r.h.getAffiliateStats(), r.h.getAffiliateCommissions(20), r.h.getAffiliateWithdrawals(10)]);
                            e.data && P(e.data), s.data && T(s.data), t.data && q(t.data)
                        } catch (e) {
                            console.error("[Affiliate] Error loading data:", e)
                        } finally {
                            G(!1)
                        }
                    },
                    ea = () => {
                        let e = document.createElement("textarea");
                        e.value = es, e.style.position = "fixed", e.style.left = "-999999px", e.style.top = "-999999px", document.body.appendChild(e), e.focus(), e.select();
                        try {
                            document.execCommand("copy"), I(!0), setTimeout(() => I(!1), 2e3)
                        } catch (e) {
                            console.error("Erro ao copiar:", e), alert("Erro ao copiar. Por favor, copie manualmente: " + es)
                        }
                        document.body.removeChild(e)
                    },
                    el = async () => {
                        if (!A) return;
                        if (B < 10) {
                            Y("Valor m\xednimo \xe9 R$ 10,00");
                            return
                        }
                        if (B > A.pendingCommissions) {
                            Y("Saldo insuficiente");
                            return
                        }
                        J(!0), Y("");
                        let e = await r.h.withdrawAffiliate(B);
                        if (e.error) {
                            Y(e.error), J(!1);
                            return
                        }
                        e.data && ($.default.success("Saque de R$ ".concat(e.data.amount.toFixed(2), " solicitado! Voc\xea receber\xe1 R$ ").concat(e.data.netAmount.toFixed(2))), _(!1), et()), J(!1)
                    };
                if (D || L) return (0, a.jsx)("main", {
                    className: "min-h-screen flex items-center justify-center",
                    children: (0, a.jsxs)("div", {
                        className: "text-center",
                        children: [(0, a.jsx)(x.Z, {
                            size: 40,
                            className: "animate-spin text-pool-gold mx-auto"
                        }), (0, a.jsx)("p", {
                            className: "text-white/60 mt-4",
                            children: "Carregando..."
                        })]
                    })
                });
                if (!s) return null;
                let ei = A && A.totalReferrals > 0 ? (A.activeReferrals / A.totalReferrals * 100).toFixed(1) : "0.0";
                return (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(c.Z, {}), (0, a.jsxs)("main", {
                        className: "min-h-screen p-4 md:p-8 max-w-7xl mx-auto",
                        children: [(0, a.jsxs)("div", {
                            className: "mb-8",
                            children: [(0, a.jsx)("h1", {
                                className: "font-display text-3xl font-bold",
                                children: "Indique e Ganhe"
                            }), (0, a.jsx)("p", {
                                className: "text-white/60 mt-1",
                                children: "Convide amigos e ganhe comiss\xf5es em cada partida"
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
                            children: [(0, a.jsxs)("div", {
                                className: "lg:col-span-1 space-y-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "card",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 mb-4",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-10 h-10 rounded-lg bg-pool-gold/20 flex items-center justify-center",
                                            children: (0, a.jsx)(m.Z, {
                                                size: 20,
                                                className: "text-pool-gold"
                                            })
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("h2", {
                                                className: "font-display text-lg font-bold",
                                                children: "Carteira de Afiliado"
                                            }), (0, a.jsx)("p", {
                                                className: "text-white/60 text-sm",
                                                children: "Suas comiss\xf5es acumuladas"
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "bg-gradient-to-br from-pool-gold/20 via-pool-gold/10 to-transparent border border-pool-gold/30 rounded-xl p-6 text-center",
                                        children: [(0, a.jsx)("p", {
                                            className: "text-white/60 text-sm mb-1",
                                            children: "Saldo Dispon\xedvel"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-4xl font-bold text-pool-gold mb-4",
                                            children: ["R$ ", Number(s.affiliateWallet || 0).toFixed(2)]
                                        }), (0, a.jsxs)("button", {
                                            onClick: () => {
                                                if (!(null == s ? void 0 : s.phone)) {
                                                    ee(!0);
                                                    return
                                                }
                                                _(!0), X(100), Y("")
                                            },
                                            className: "btn-primary w-full flex items-center justify-center gap-2",
                                            disabled: !s.affiliateWallet || 10 > Number(s.affiliateWallet),
                                            children: [(0, a.jsx)(h.Z, {
                                                size: 18
                                            }), "Sacar Comiss\xf5es"]
                                        }), (0, a.jsx)("p", {
                                            className: "text-white/40 text-xs mt-2",
                                            children: "M\xednimo R$ 10,00 • Via PIX"
                                        })]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "card",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 mb-4",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center",
                                            children: (0, a.jsx)(u.Z, {
                                                size: 20,
                                                className: "text-blue-400"
                                            })
                                        }), (0, a.jsx)("h2", {
                                            className: "font-display text-lg font-bold",
                                            children: "Como Funciona"
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "space-y-4",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex gap-3",
                                            children: [(0, a.jsx)("div", {
                                                className: "w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0",
                                                children: (0, a.jsx)(p.Z, {
                                                    size: 16,
                                                    className: "text-green-400"
                                                })
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsx)("p", {
                                                    className: "font-medium text-sm",
                                                    children: "1. Indique Amigos"
                                                }), (0, a.jsx)("p", {
                                                    className: "text-white/60 text-xs",
                                                    children: "Compartilhe seu link ou c\xf3digo"
                                                })]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "flex gap-3",
                                            children: [(0, a.jsx)("div", {
                                                className: "w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0",
                                                children: (0, a.jsx)(f.Z, {
                                                    size: 16,
                                                    className: "text-blue-400"
                                                })
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsx)("p", {
                                                    className: "font-medium text-sm",
                                                    children: "2. Ganhe R$10 de B\xf4nus"
                                                }), (0, a.jsx)("p", {
                                                    className: "text-white/60 text-xs",
                                                    children: "No primeiro dep\xf3sito de cada indicado"
                                                })]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "flex gap-3",
                                            children: [(0, a.jsx)("div", {
                                                className: "w-8 h-8 rounded-full bg-pool-gold/20 flex items-center justify-center flex-shrink-0",
                                                children: (0, a.jsx)(j.Z, {
                                                    size: 16,
                                                    className: "text-pool-gold"
                                                })
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsx)("p", {
                                                    className: "font-medium text-sm",
                                                    children: "3. Ganhe 5% da Taxa"
                                                }), (0, a.jsx)("p", {
                                                    className: "text-white/60 text-xs",
                                                    children: "Em cada partida que seus indicados jogarem"
                                                })]
                                            })]
                                        })]
                                    })]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "lg:col-span-2 space-y-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "card",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 mb-4",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center",
                                            children: (0, a.jsx)(u.Z, {
                                                size: 20,
                                                className: "text-green-400"
                                            })
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("h2", {
                                                className: "font-display text-lg font-bold",
                                                children: "Link de Indica\xe7\xe3o"
                                            }), (0, a.jsx)("p", {
                                                className: "text-white/60 text-sm",
                                                children: "Envie este link para seus amigos se cadastrarem"
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex gap-2",
                                        children: [(0, a.jsx)("input", {
                                            type: "text",
                                            value: es,
                                            readOnly: !0,
                                            className: "input-field flex-1 font-mono text-sm"
                                        }), (0, a.jsxs)("button", {
                                            onClick: () => {
                                                navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(es).then(() => {
                                                    I(!0), setTimeout(() => I(!1), 2e3)
                                                }).catch(() => ea()) : ea()
                                            },
                                            className: "btn-primary px-6 flex items-center gap-2",
                                            children: [O ? (0, a.jsx)(g.Z, {
                                                size: 18
                                            }) : (0, a.jsx)(b.Z, {
                                                size: 18
                                            }), (0, a.jsx)("span", {
                                                className: "hidden sm:inline",
                                                children: O ? "Copiado!" : "Copiar"
                                            })]
                                        })]
                                    })]
                                }), A && (0, a.jsxs)("div", {
                                    className: "grid grid-cols-2 md:grid-cols-4 gap-4",
                                    children: [(0, a.jsxs)("div", {
                                        className: "card",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2 mb-3",
                                            children: [(0, a.jsx)(N.Z, {
                                                size: 18,
                                                className: "text-blue-400"
                                            }), (0, a.jsx)("span", {
                                                className: "text-white/60 text-sm",
                                                children: "Cadastros"
                                            })]
                                        }), (0, a.jsx)("p", {
                                            className: "text-3xl font-bold",
                                            children: A.totalReferrals
                                        }), (0, a.jsx)("p", {
                                            className: "text-xs text-white/40 mt-1",
                                            children: "Total de indicados"
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "card",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2 mb-3",
                                            children: [(0, a.jsx)(v.Z, {
                                                size: 18,
                                                className: "text-green-400"
                                            }), (0, a.jsx)("span", {
                                                className: "text-white/60 text-sm",
                                                children: "Ativos"
                                            })]
                                        }), (0, a.jsx)("p", {
                                            className: "text-3xl font-bold text-green-400",
                                            children: A.activeReferrals
                                        }), (0, a.jsx)("p", {
                                            className: "text-xs text-white/40 mt-1",
                                            children: "Que depositaram"
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "card",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2 mb-3",
                                            children: [(0, a.jsx)(w.Z, {
                                                size: 18,
                                                className: "text-pool-gold"
                                            }), (0, a.jsx)("span", {
                                                className: "text-white/60 text-sm",
                                                children: "Faturado"
                                            })]
                                        }), (0, a.jsxs)("p", {
                                            className: "text-3xl font-bold text-pool-gold",
                                            children: ["R$ ", A.totalEarned.toFixed(2)]
                                        }), (0, a.jsx)("p", {
                                            className: "text-xs text-white/40 mt-1",
                                            children: "Total ganho"
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "card",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2 mb-3",
                                            children: [(0, a.jsx)(y.Z, {
                                                size: 18,
                                                className: "text-purple-400"
                                            }), (0, a.jsx)("span", {
                                                className: "text-white/60 text-sm",
                                                children: "Sacado"
                                            })]
                                        }), (0, a.jsxs)("p", {
                                            className: "text-3xl font-bold",
                                            children: ["R$ ", A.totalWithdrawn.toFixed(2)]
                                        }), (0, a.jsx)("p", {
                                            className: "text-xs text-white/40 mt-1",
                                            children: "Transferido"
                                        })]
                                    })]
                                }), A && (0, a.jsxs)("div", {
                                    className: "card",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 mb-4",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center",
                                            children: (0, a.jsx)(k.Z, {
                                                size: 20,
                                                className: "text-blue-400"
                                            })
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("h2", {
                                                className: "font-display text-lg font-bold",
                                                children: "Desempenho"
                                            }), (0, a.jsx)("p", {
                                                className: "text-white/60 text-sm",
                                                children: "Resumo das suas indica\xe7\xf5es"
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "grid grid-cols-1 md:grid-cols-3 gap-4",
                                        children: [(0, a.jsxs)("div", {
                                            className: "bg-pool-dark/50 rounded-xl p-4 border border-white/5",
                                            children: [(0, a.jsx)("p", {
                                                className: "text-white/60 text-sm mb-2",
                                                children: "Taxa de Convers\xe3o"
                                            }), (0, a.jsxs)("p", {
                                                className: "text-2xl font-bold text-blue-400",
                                                children: [ei, "%"]
                                            }), (0, a.jsx)("p", {
                                                className: "text-xs text-white/40 mt-1",
                                                children: "Cadastros que depositaram"
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "bg-pool-dark/50 rounded-xl p-4 border border-white/5",
                                            children: [(0, a.jsx)("p", {
                                                className: "text-white/60 text-sm mb-2",
                                                children: "M\xe9dia por Indicado"
                                            }), (0, a.jsxs)("p", {
                                                className: "text-2xl font-bold text-pool-gold",
                                                children: ["R$ ", A.activeReferrals > 0 ? (A.totalEarned / A.activeReferrals).toFixed(2) : "0.00"]
                                            }), (0, a.jsx)("p", {
                                                className: "text-xs text-white/40 mt-1",
                                                children: "Ganho m\xe9dio por ativo"
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "bg-pool-dark/50 rounded-xl p-4 border border-white/5",
                                            children: [(0, a.jsx)("p", {
                                                className: "text-white/60 text-sm mb-2",
                                                children: "Saldo Dispon\xedvel"
                                            }), (0, a.jsxs)("p", {
                                                className: "text-2xl font-bold text-green-400",
                                                children: ["R$ ", A.pendingCommissions.toFixed(2)]
                                            }), (() => {
                                                let e = M.filter(e => "PROCESSING" === e.status).reduce((e, s) => e + Math.abs(Number(s.amount)), 0);
                                                return e > 0 ? (0, a.jsxs)("p", {
                                                    className: "text-xs text-yellow-400 mt-1",
                                                    children: ["R$ ", e.toFixed(2), " em saque pendente"]
                                                }) : (0, a.jsx)("p", {
                                                    className: "text-xs text-white/40 mt-1",
                                                    children: "Dispon\xedvel para saque"
                                                })
                                            })()]
                                        })]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "card",
                                    children: [(0, a.jsx)("div", {
                                        className: "flex items-center justify-between mb-4",
                                        children: (0, a.jsxs)("div", {
                                            className: "flex items-center gap-3",
                                            children: [(0, a.jsx)("div", {
                                                className: "w-10 h-10 rounded-lg bg-pool-gold/20 flex items-center justify-center",
                                                children: (0, a.jsx)(C.Z, {
                                                    size: 20,
                                                    className: "text-pool-gold"
                                                })
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsx)("h2", {
                                                    className: "font-display text-lg font-bold",
                                                    children: "Hist\xf3rico de Transa\xe7\xf5es"
                                                }), (0, a.jsx)("p", {
                                                    className: "text-white/60 text-sm",
                                                    children: "Comiss\xf5es e saques"
                                                })]
                                            })]
                                        })
                                    }), (0, a.jsxs)("div", {
                                        className: "flex gap-2 mb-4",
                                        children: [(0, a.jsxs)("button", {
                                            onClick: () => H("all"),
                                            className: "px-4 py-2 rounded-lg text-sm font-medium transition-all ".concat("all" === V ? "bg-pool-gold text-pool-dark" : "bg-pool-dark/50 text-white/60 hover:text-white"),
                                            children: ["Todas (", F.length + M.length, ")"]
                                        }), (0, a.jsxs)("button", {
                                            onClick: () => H("income"),
                                            className: "px-4 py-2 rounded-lg text-sm font-medium transition-all ".concat("income" === V ? "bg-green-500 text-white" : "bg-pool-dark/50 text-white/60 hover:text-white"),
                                            children: ["Entradas (", F.length, ")"]
                                        }), (0, a.jsxs)("button", {
                                            onClick: () => H("withdrawals"),
                                            className: "px-4 py-2 rounded-lg text-sm font-medium transition-all ".concat("withdrawals" === V ? "bg-orange-500 text-white" : "bg-pool-dark/50 text-white/60 hover:text-white"),
                                            children: ["Sa\xeddas (", M.length, ")"]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [0 === F.length && 0 === M.length && (0, a.jsxs)("div", {
                                            className: "text-center py-12",
                                            children: [(0, a.jsx)(N.Z, {
                                                size: 48,
                                                className: "text-white/20 mx-auto mb-4"
                                            }), (0, a.jsx)("p", {
                                                className: "text-white/60",
                                                children: "Nenhuma transa\xe7\xe3o ainda"
                                            }), (0, a.jsx)("p", {
                                                className: "text-white/40 text-sm mt-1",
                                                children: "Comece a indicar amigos para ganhar!"
                                            })]
                                        }), (() => {
                                            let e = [];
                                            return "withdrawals" !== V && F.forEach(s => e.push({
                                                id: s.id,
                                                type: "commission",
                                                createdAt: s.createdAt,
                                                data: s
                                            })), "income" !== V && M.forEach(s => e.push({
                                                id: s.id,
                                                type: "withdrawal",
                                                createdAt: s.createdAt,
                                                data: s
                                            })), e.sort((e, s) => new Date(s.createdAt).getTime() - new Date(e.createdAt).getTime()), e.map(e => {
                                                if ("commission" === e.type) {
                                                    let s = e.data;
                                                    return (0, a.jsxs)("div", {
                                                        className: "bg-pool-dark/50 rounded-lg p-4 flex items-center justify-between hover:bg-pool-dark/70 transition-colors border border-white/5",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "flex items-center gap-3",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "w-10 h-10 rounded-full flex items-center justify-center ".concat("CPA" === s.type ? "bg-green-500/20" : "bg-pool-gold/20"),
                                                                children: "CPA" === s.type ? (0, a.jsx)(Z.Z, {
                                                                    size: 18,
                                                                    className: "text-green-400"
                                                                }) : (0, a.jsx)(k.Z, {
                                                                    size: 18,
                                                                    className: "text-pool-gold"
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                children: [(0, a.jsx)("p", {
                                                                    className: "font-semibold text-sm",
                                                                    children: "CPA" === s.type ? "B\xf4nus CPA" : "Comiss\xe3o de Partida"
                                                                }), (0, a.jsxs)("p", {
                                                                    className: "text-white/60 text-xs",
                                                                    children: [s.referredUser.name, " • ", new Date(s.createdAt).toLocaleDateString("pt-BR", {
                                                                        day: "2-digit",
                                                                        month: "2-digit",
                                                                        year: "2-digit",
                                                                        hour: "2-digit",
                                                                        minute: "2-digit"
                                                                    })]
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("p", {
                                                            className: "text-green-400 font-bold",
                                                            children: ["+ R$ ", Number(s.amount).toFixed(2)]
                                                        })]
                                                    }, "commission-".concat(e.id))
                                                } {
                                                    let s = e.data;
                                                    return (0, a.jsxs)("div", {
                                                        className: "bg-pool-dark/50 rounded-lg p-4 flex items-center justify-between hover:bg-pool-dark/70 transition-colors border border-white/5",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "flex items-center gap-3",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "w-10 h-10 rounded-full flex items-center justify-center ".concat("COMPLETED" === s.status ? "bg-green-500/20" : "PROCESSING" === s.status ? "bg-yellow-500/20" : "bg-red-500/20"),
                                                                children: "COMPLETED" === s.status ? (0, a.jsx)(v.Z, {
                                                                    size: 18,
                                                                    className: "text-green-400"
                                                                }) : "PROCESSING" === s.status ? (0, a.jsx)(C.Z, {
                                                                    size: 18,
                                                                    className: "text-yellow-400"
                                                                }) : (0, a.jsx)(S.Z, {
                                                                    size: 18,
                                                                    className: "text-red-400"
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                children: [(0, a.jsxs)("p", {
                                                                    className: "font-semibold text-sm",
                                                                    children: ["Saque via PIX", (0, a.jsx)("span", {
                                                                        className: "ml-2 text-xs px-2 py-0.5 rounded ".concat("COMPLETED" === s.status ? "bg-green-500/20 text-green-400" : "PROCESSING" === s.status ? "bg-yellow-500/20 text-yellow-400" : "bg-red-500/20 text-red-400"),
                                                                        children: "COMPLETED" === s.status ? "Conclu\xeddo" : "PROCESSING" === s.status ? "Processando" : "Falhou"
                                                                    })]
                                                                }), (0, a.jsxs)("p", {
                                                                    className: "text-white/60 text-xs",
                                                                    children: [new Date(s.createdAt).toLocaleDateString("pt-BR", {
                                                                        day: "2-digit",
                                                                        month: "2-digit",
                                                                        year: "2-digit",
                                                                        hour: "2-digit",
                                                                        minute: "2-digit"
                                                                    }), s.fee > 0 && (0, a.jsxs)("span", {
                                                                        className: "text-white/40 ml-2",
                                                                        children: ["Taxa: R$ ", Number(s.fee).toFixed(2)]
                                                                    })]
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("div", {
                                                            className: "text-right",
                                                            children: [(0, a.jsxs)("p", {
                                                                className: "text-orange-400 font-bold",
                                                                children: ["- R$ ", Math.abs(Number(s.amount)).toFixed(2)]
                                                            }), s.netAmount > 0 && (0, a.jsxs)("p", {
                                                                className: "text-white/40 text-xs",
                                                                children: ["L\xedquido: R$ ", Number(s.netAmount).toFixed(2)]
                                                            })]
                                                        })]
                                                    }, "withdrawal-".concat(e.id))
                                                }
                                            })
                                        })()]
                                    })]
                                })]
                            })]
                        })]
                    }), (0, a.jsx)(d.Z, {}), W && A && (0, a.jsx)("div", {
                        className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50",
                        children: (0, a.jsxs)("div", {
                            className: "card w-full max-w-lg max-h-[90vh] overflow-y-auto",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center justify-between mb-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-12 h-12 rounded-xl bg-orange-500/20 flex items-center justify-center",
                                        children: (0, a.jsx)(h.Z, {
                                            size: 24,
                                            className: "text-orange-400"
                                        })
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("h2", {
                                            className: "font-display text-xl font-bold",
                                            children: "Sacar Comiss\xf5es"
                                        }), (0, a.jsx)("p", {
                                            className: "text-white/60 text-sm",
                                            children: "Transfer\xeancia via PIX"
                                        })]
                                    })]
                                }), (0, a.jsx)("button", {
                                    onClick: () => _(!1),
                                    className: "w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors",
                                    children: (0, a.jsx)(R.Z, {
                                        size: 20
                                    })
                                })]
                            }), Q && (0, a.jsxs)("div", {
                                className: "bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-4 flex items-start gap-2",
                                children: [(0, a.jsx)(S.Z, {
                                    size: 18,
                                    className: "text-red-400 flex-shrink-0 mt-0.5"
                                }), (0, a.jsx)("p", {
                                    className: "text-red-300 text-sm",
                                    children: Q
                                })]
                            }), (0, a.jsx)("div", {
                                className: "bg-orange-500/10 border border-orange-500/20 rounded-xl p-4 mb-6",
                                children: (0, a.jsxs)("div", {
                                    className: "flex items-start gap-3",
                                    children: [(0, a.jsx)(z.Z, {
                                        size: 20,
                                        className: "text-orange-400 flex-shrink-0 mt-0.5"
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("p", {
                                            className: "text-orange-300 font-medium text-sm",
                                            children: "Limites de Saque"
                                        }), (0, a.jsxs)("ul", {
                                            className: "text-orange-300/70 text-xs mt-2 space-y-1",
                                            children: [(0, a.jsx)("li", {
                                                children: "• Valor m\xednimo: R$ 10,00"
                                            }), (0, a.jsx)("li", {
                                                children: "• Limite di\xe1rio: R$ 1.000,00"
                                            }), (0, a.jsx)("li", {
                                                children: "• M\xe1ximo 2 saques por dia"
                                            }), (0, a.jsx)("li", {
                                                children: "• Taxa: R$ 2,00 + 3% do valor"
                                            })]
                                        })]
                                    })]
                                })
                            }), (null == s ? void 0 : s.cpf) && (0, a.jsxs)("div", {
                                className: "mb-4 bg-pool-dark/50 border border-white/10 rounded-lg p-3",
                                children: [(0, a.jsx)("p", {
                                    className: "text-white/60 text-xs mb-1",
                                    children: "Chave PIX para recebimento"
                                }), (0, a.jsxs)("p", {
                                    className: "text-white font-mono text-sm",
                                    children: ["CPF: ", s.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mb-4 bg-pool-gold/10 border border-pool-gold/20 rounded-lg p-3 flex items-center justify-between",
                                children: [(0, a.jsx)("span", {
                                    className: "text-white/60 text-sm",
                                    children: "Saldo de comiss\xf5es"
                                }), (0, a.jsxs)("span", {
                                    className: "text-pool-gold font-bold",
                                    children: ["R$ ", A.pendingCommissions.toFixed(2)]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mb-4",
                                children: [(0, a.jsx)("label", {
                                    className: "block text-sm font-medium text-white/80 mb-2",
                                    children: "Valor (R$)"
                                }), (0, a.jsx)("input", {
                                    type: "number",
                                    value: B,
                                    onChange: e => X(Number(e.target.value)),
                                    className: "input-field text-xl font-bold text-center",
                                    min: 10,
                                    max: Math.min(1e3, A.pendingCommissions)
                                }), (0, a.jsx)("div", {
                                    className: "grid grid-cols-4 gap-2 mt-3",
                                    children: [50, 100, 200, 500].map(e => (0, a.jsxs)("button", {
                                        onClick: () => X(e),
                                        disabled: e > A.pendingCommissions,
                                        className: "py-2.5 rounded-lg text-sm font-medium transition-all ".concat(B === e ? "bg-pool-gold text-pool-dark" : "bg-pool-dark/50 text-white/60 hover:text-white disabled:opacity-30"),
                                        children: ["R$ ", e]
                                    }, e))
                                })]
                            }), B >= 10 && (0, a.jsxs)("div", {
                                className: "mb-6 bg-pool-dark/50 rounded-xl p-4 border border-white/10",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex justify-between text-sm mb-2",
                                    children: [(0, a.jsx)("span", {
                                        className: "text-white/60",
                                        children: "Valor solicitado"
                                    }), (0, a.jsxs)("span", {
                                        className: "text-white",
                                        children: ["R$ ", B.toFixed(2)]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "flex justify-between text-sm mb-2",
                                    children: [(0, a.jsx)("span", {
                                        className: "text-white/60",
                                        children: "Taxa (R$ 2,00 + 3%)"
                                    }), (0, a.jsxs)("span", {
                                        className: "text-red-400",
                                        children: ["- R$ ", (2 + .03 * B).toFixed(2)]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "flex justify-between text-base font-bold pt-3 border-t border-white/10",
                                    children: [(0, a.jsx)("span", {
                                        className: "text-pool-gold",
                                        children: "Voc\xea receber\xe1"
                                    }), (0, a.jsxs)("span", {
                                        className: "text-pool-gold",
                                        children: ["R$ ", Math.max(0, B - 2 - .03 * B).toFixed(2)]
                                    })]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex gap-3",
                                children: [(0, a.jsx)("button", {
                                    onClick: () => _(!1),
                                    className: "btn-secondary flex-1",
                                    children: "Cancelar"
                                }), (0, a.jsxs)("button", {
                                    onClick: el,
                                    disabled: U || B < 10 || B > A.pendingCommissions,
                                    className: "flex-1 flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
                                    children: [U ? (0, a.jsx)(x.Z, {
                                        size: 20,
                                        className: "animate-spin"
                                    }) : (0, a.jsx)(h.Z, {
                                        size: 20
                                    }), "Confirmar"]
                                })]
                            })]
                        })
                    }), (0, a.jsx)(o.Z, {
                        isOpen: K,
                        onClose: () => ee(!1),
                        onSuccess: () => {
                            ee(!1), _(!0), X(100), Y("")
                        }
                    })]
                })
            }
        },
        16112: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return n
                }
            });
            var a = t(3827),
                l = t(8792),
                i = t(20703);

            function n() {
                let e = new Date().getFullYear();
                return (0, a.jsx)("footer", {
                    className: "bg-pool-dark border-t border-white/5 mt-auto",
                    children: (0, a.jsx)("div", {
                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",
                        children: (0, a.jsxs)("div", {
                            className: "flex flex-col md:flex-row items-center justify-between gap-4",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-4",
                                children: [(0, a.jsx)(i.default, {
                                    src: "/logos/logo-white-red.png",
                                    alt: "Tacadinha",
                                    width: 100,
                                    height: 32,
                                    className: "h-6 w-auto opacity-50"
                                }), (0, a.jsx)("span", {
                                    className: "text-white/30 text-sm hidden sm:inline",
                                    children: "|"
                                }), (0, a.jsxs)("p", {
                                    className: "text-white/30 text-sm",
                                    children: ["\xa9 ", e, " Tacadinha"]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-6 text-sm",
                                children: [(0, a.jsx)(l.default, {
                                    href: "/termos",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Termos"
                                }), (0, a.jsx)(l.default, {
                                    href: "/privacidade",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Privacidade"
                                }), (0, a.jsx)(l.default, {
                                    href: "#",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Suporte"
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-3 text-white/30 text-xs",
                                children: [(0, a.jsx)("span", {
                                    children: "+18"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "•"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "Jogue com responsabilidade"
                                })]
                            })]
                        })
                    })
                })
            }
        },
        99744: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return h
                }
            });
            var a = t(3827),
                l = t(64090),
                i = t(85904),
                n = t(52235),
                r = t(98998),
                c = t(18994),
                d = t(80037),
                o = t(10826),
                x = t(6739),
                m = t(13176);

            function h(e) {
                let {
                    isOpen: s,
                    onClose: t,
                    onSuccess: h
                } = e, {
                    updatePhone: u
                } = (0, x.tN)(), [p, f] = (0, l.useState)(""), [j, g] = (0, l.useState)(!1), [b, N] = (0, l.useState)(""), v = e => 11 === e.replace(/\D/g, "").length, w = async e => {
                    if (e.preventDefault(), N(""), !v(p)) {
                        N("Telefone deve ter 11 d\xedgitos (DDD + n\xfamero)");
                        return
                    }
                    g(!0);
                    let s = await o.h.updateProfile({
                        phone: p
                    });
                    if (s.error) {
                        N(s.error), g(!1);
                        return
                    }
                    u(p), g(!1), h()
                };
                return s ? (0, a.jsx)("div", {
                    className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50",
                    children: (0, a.jsxs)("div", {
                        className: "card w-full max-w-md",
                        children: [(0, a.jsxs)("div", {
                            className: "flex items-center justify-between mb-6",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, a.jsx)("div", {
                                    className: "w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center",
                                    children: (0, a.jsx)(i.Z, {
                                        size: 24,
                                        className: "text-blue-400"
                                    })
                                }), (0, a.jsxs)("div", {
                                    children: [(0, a.jsx)("h2", {
                                        className: "font-display text-xl font-bold",
                                        children: "Adicionar Telefone"
                                    }), (0, a.jsx)("p", {
                                        className: "text-white/60 text-sm",
                                        children: "Necess\xe1rio para solicitar saque"
                                    })]
                                })]
                            }), (0, a.jsx)("button", {
                                onClick: t,
                                className: "w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors",
                                children: (0, a.jsx)(n.Z, {
                                    size: 20
                                })
                            })]
                        }), (0, a.jsx)("div", {
                            className: "bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 mb-6",
                            children: (0, a.jsxs)("div", {
                                className: "flex items-start gap-3",
                                children: [(0, a.jsx)(i.Z, {
                                    size: 20,
                                    className: "text-blue-400 flex-shrink-0 mt-0.5"
                                }), (0, a.jsxs)("div", {
                                    children: [(0, a.jsx)("p", {
                                        className: "text-blue-300 font-medium text-sm",
                                        children: "Por que precisamos do seu telefone?"
                                    }), (0, a.jsx)("p", {
                                        className: "text-blue-300/70 text-xs mt-1",
                                        children: "O n\xfamero de telefone \xe9 necess\xe1rio para validar sua identidade e processar saques com seguran\xe7a."
                                    })]
                                })]
                            })
                        }), b && (0, a.jsxs)("div", {
                            className: "bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-4 flex items-start gap-2",
                            children: [(0, a.jsx)(r.Z, {
                                size: 18,
                                className: "text-red-400 flex-shrink-0 mt-0.5"
                            }), (0, a.jsx)("p", {
                                className: "text-red-300 text-sm",
                                children: b
                            })]
                        }), (0, a.jsxs)("form", {
                            onSubmit: w,
                            children: [(0, a.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, a.jsx)("label", {
                                    htmlFor: "phone",
                                    className: "block text-sm font-medium text-white/80 mb-2",
                                    children: "N\xfamero de Telefone"
                                }), (0, a.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, a.jsx)("div", {
                                        className: "absolute left-4 top-1/2 -translate-y-1/2 text-white/30",
                                        children: (0, a.jsx)(i.Z, {
                                            size: 20
                                        })
                                    }), (0, a.jsx)("input", {
                                        id: "phone",
                                        type: "tel",
                                        value: p,
                                        onChange: e => f((0, m.CN)(e.target.value)),
                                        className: "w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-white/30 focus:outline-none focus:border-pool-gold/50 focus:bg-white/[0.07] transition-all text-lg",
                                        placeholder: "(99) 99999-9999",
                                        maxLength: 15,
                                        disabled: j,
                                        autoFocus: !0
                                    })]
                                }), (0, a.jsx)("p", {
                                    className: "text-white/40 text-xs mt-2",
                                    children: "Digite seu n\xfamero com DDD (exemplo: 11 99999-9999)"
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex gap-3",
                                children: [(0, a.jsx)("button", {
                                    type: "button",
                                    onClick: t,
                                    className: "btn-secondary flex-1",
                                    disabled: j,
                                    children: "Cancelar"
                                }), (0, a.jsx)("button", {
                                    type: "submit",
                                    disabled: j || !p,
                                    className: "flex-1 flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
                                    children: j ? (0, a.jsx)(c.Z, {
                                        size: 20,
                                        className: "animate-spin"
                                    }) : (0, a.jsxs)(a.Fragment, {
                                        children: [(0, a.jsx)(d.Z, {
                                            size: 20
                                        }), "Salvar"]
                                    })
                                })]
                            })]
                        })]
                    })
                }) : null
            }
        },
        13176: function(e, s, t) {
            "use strict";

            function a(e) {
                let s = e.replace(/\D/g, "");
                return 0 === s.length ? "" : s.length <= 2 ? "(".concat(s) : s.length <= 7 ? "(".concat(s.slice(0, 2), ") ").concat(s.slice(2)) : s.length <= 11 ? "(".concat(s.slice(0, 2), ") ").concat(s.slice(2, 7), "-").concat(s.slice(7)) : "(".concat(s.slice(0, 2), ") ").concat(s.slice(2, 7), "-").concat(s.slice(7, 11))
            }

            function l(e) {
                return /^\(\d{2}\) \d{4,5}-\d{4}$/.test(e)
            }

            function i(e) {
                return e.replace(/\D/g, "")
            }

            function n(e) {
                let s = e.replace(/\D/g, "");
                return 0 === s.length ? "" : s.length <= 3 ? s : s.length <= 6 ? "".concat(s.slice(0, 3), ".").concat(s.slice(3)) : s.length <= 9 ? "".concat(s.slice(0, 3), ".").concat(s.slice(3, 6), ".").concat(s.slice(6)) : "".concat(s.slice(0, 3), ".").concat(s.slice(3, 6), ".").concat(s.slice(6, 9), "-").concat(s.slice(9, 11))
            }

            function r(e) {
                return /^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(e)
            }

            function c(e) {
                return e.replace(/\D/g, "")
            }

            function d(e) {
                if (!e) return "";
                let s = e.replace(/\D/g, "");
                return 11 !== s.length ? e : n(s)
            }

            function o(e) {
                if (!e) return "";
                if (/^\(\d{2}\) \d{4,5}-\d{4}$/.test(e)) return e;
                let s = e.replace(/\D/g, "");
                return s.length < 10 || s.length > 11 ? e : a(s)
            }
            t.d(s, {
                CN: function() {
                    return a
                },
                Gt: function() {
                    return r
                },
                V$: function() {
                    return o
                },
                WF: function() {
                    return d
                },
                kj: function() {
                    return l
                },
                r: function() {
                    return c
                },
                w3: function() {
                    return n
                },
                wy: function() {
                    return i
                }
            })
        },
        57976: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("CheckCircle2", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["path", {
                    d: "m9 12 2 2 4-4",
                    key: "dzmm74"
                }]
            ])
        },
        57759: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("Coins", [
                ["circle", {
                    cx: "8",
                    cy: "8",
                    r: "6",
                    key: "3yglwk"
                }],
                ["path", {
                    d: "M18.09 10.37A6 6 0 1 1 10.34 18",
                    key: "t5s6rm"
                }],
                ["path", {
                    d: "M7 6h1v4",
                    key: "1obek4"
                }],
                ["path", {
                    d: "m16.71 13.88.7.71-2.82 2.82",
                    key: "1rbuyh"
                }]
            ])
        },
        44715: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("Download", [
                ["path", {
                    d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
                    key: "ih7n3h"
                }],
                ["polyline", {
                    points: "7 10 12 15 17 10",
                    key: "2ggqvy"
                }],
                ["line", {
                    x1: "12",
                    x2: "12",
                    y1: "15",
                    y2: "3",
                    key: "1vk2je"
                }]
            ])
        },
        17021: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("Gamepad2", [
                ["line", {
                    x1: "6",
                    x2: "10",
                    y1: "11",
                    y2: "11",
                    key: "1gktln"
                }],
                ["line", {
                    x1: "8",
                    x2: "8",
                    y1: "9",
                    y2: "13",
                    key: "qnk9ow"
                }],
                ["line", {
                    x1: "15",
                    x2: "15.01",
                    y1: "12",
                    y2: "12",
                    key: "krot7o"
                }],
                ["line", {
                    x1: "18",
                    x2: "18.01",
                    y1: "10",
                    y2: "10",
                    key: "1lcuu1"
                }],
                ["path", {
                    d: "M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",
                    key: "mfqc10"
                }]
            ])
        },
        83484: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("Gift", [
                ["rect", {
                    x: "3",
                    y: "8",
                    width: "18",
                    height: "4",
                    rx: "1",
                    key: "bkv52"
                }],
                ["path", {
                    d: "M12 8v13",
                    key: "1c76mn"
                }],
                ["path", {
                    d: "M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7",
                    key: "6wjy6b"
                }],
                ["path", {
                    d: "M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5",
                    key: "1ihvrl"
                }]
            ])
        },
        10822: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("Percent", [
                ["line", {
                    x1: "19",
                    x2: "5",
                    y1: "5",
                    y2: "19",
                    key: "1x9vlm"
                }],
                ["circle", {
                    cx: "6.5",
                    cy: "6.5",
                    r: "2.5",
                    key: "4mh3h7"
                }],
                ["circle", {
                    cx: "17.5",
                    cy: "17.5",
                    r: "2.5",
                    key: "1mdrzq"
                }]
            ])
        },
        63854: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("UserPlus", [
                ["path", {
                    d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
                    key: "1yyitq"
                }],
                ["circle", {
                    cx: "9",
                    cy: "7",
                    r: "4",
                    key: "nufk8"
                }],
                ["line", {
                    x1: "19",
                    x2: "19",
                    y1: "8",
                    y2: "14",
                    key: "1bvyxn"
                }],
                ["line", {
                    x1: "22",
                    x2: "16",
                    y1: "11",
                    y2: "11",
                    key: "1shjgl"
                }]
            ])
        },
        34059: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, t(87461).Z)("Users", [
                ["path", {
                    d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
                    key: "1yyitq"
                }],
                ["circle", {
                    cx: "9",
                    cy: "7",
                    r: "4",
                    key: "nufk8"
                }],
                ["path", {
                    d: "M22 21v-2a4 4 0 0 0-3-3.87",
                    key: "kshegd"
                }],
                ["path", {
                    d: "M16 3.13a4 4 0 0 1 0 7.75",
                    key: "1da9ce"
                }]
            ])
        }
    },
    function(e) {
        e.O(0, [2807, 963, 703, 9620, 826, 4002, 2971, 8069, 1744], function() {
            return e(e.s = 89215)
        }), _N_E = e.O()
    }
]);