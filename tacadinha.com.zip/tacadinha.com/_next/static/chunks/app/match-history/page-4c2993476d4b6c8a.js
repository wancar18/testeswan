(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1360], {
        98179: function(e, a, t) {
            Promise.resolve().then(t.bind(t, 98503))
        },
        98503: function(e, a, t) {
            "use strict";
            t.r(a), t.d(a, {
                default: function() {
                    return M
                }
            });
            var s = t(3827),
                l = t(64090),
                i = t(47907),
                n = t(6739),
                c = t(10826),
                o = t(76486),
                r = t(10963),
                d = t(4002),
                m = t(16112),
                x = t(56022),
                h = t(21369),
                p = t(65),
                u = t(38008),
                b = t(93459),
                g = t(52235),
                f = t(46578),
                j = t(61524),
                _ = t(80037),
                w = t(18994);
            let N = [{
                value: "DISRESPECTFUL_BEHAVIOR",
                label: "Comportamento desrespeitoso",
                description: "Linguagem ofensiva, provoca\xe7\xf5es ou ass\xe9dio no chat",
                icon: h.Z,
                color: "text-orange-400",
                selectedBorder: "border-orange-500/40",
                selectedBg: "bg-orange-500/10"
            }, {
                value: "CHEATING",
                label: "Trapa\xe7a",
                description: "Uso de programas externos ou explora\xe7\xe3o de falhas",
                icon: p.Z,
                color: "text-red-400",
                selectedBorder: "border-red-500/40",
                selectedBg: "bg-red-500/10"
            }, {
                value: "BUG_ABUSE",
                label: "Abuso de bugs",
                description: "Explora\xe7\xe3o intencional de erros do jogo para vantagem",
                icon: u.Z,
                color: "text-purple-400",
                selectedBorder: "border-purple-500/40",
                selectedBg: "bg-purple-500/10"
            }, {
                value: "OTHER",
                label: "Outro",
                description: "Qualquer outro comportamento inadequado",
                icon: b.Z,
                color: "text-white/60",
                selectedBorder: "border-white/30",
                selectedBg: "bg-white/5"
            }];

            function v(e) {
                let {
                    isOpen: a,
                    onClose: t,
                    onSubmit: i,
                    opponentUsername: n
                } = e, [c, o] = (0, l.useState)([]), [r, d] = (0, l.useState)(""), [m, h] = (0, l.useState)(!1), [p, u] = (0, l.useState)(!1);
                (0, l.useEffect)(() => (a && (o([]), d(""), u(!1), document.body.style.overflow = "hidden"), () => {
                    document.body.style.overflow = "unset"
                }), [a]), (0, l.useEffect)(() => {
                    if (!a) return;
                    let e = e => {
                        "Escape" !== e.key || m || t()
                    };
                    return document.addEventListener("keydown", e), () => document.removeEventListener("keydown", e)
                }, [a, t, m]);
                let b = e => {
                        o(a => a.includes(e) ? a.filter(a => a !== e) : [...a, e])
                    },
                    v = async () => {
                        if (0 !== c.length) {
                            h(!0);
                            try {
                                await i(c, r), u(!0)
                            } catch (e) {} finally {
                                h(!1)
                            }
                        }
                    };
                return a ? (0, s.jsxs)("div", {
                    className: "fixed inset-0 z-50 flex items-center justify-center p-4",
                    children: [(0, s.jsx)("div", {
                        className: "fixed inset-0 bg-black/60 backdrop-blur-sm animate-fade-in",
                        onClick: m ? void 0 : t
                    }), (0, s.jsxs)("div", {
                        className: "relative bg-pool-dark border border-white/10 rounded-xl shadow-2xl max-w-md w-full p-6 animate-fade-in",
                        children: [(0, s.jsx)("button", {
                            onClick: t,
                            disabled: m,
                            className: "absolute top-4 right-4 p-1 text-white/40 hover:text-white transition-colors disabled:opacity-50 rounded-lg hover:bg-white/10",
                            "aria-label": "Fechar",
                            children: (0, s.jsx)(g.Z, {
                                size: 18
                            })
                        }), p ? (0, s.jsxs)("div", {
                            className: "text-center py-6",
                            children: [(0, s.jsx)("div", {
                                className: "w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4",
                                children: (0, s.jsx)(f.Z, {
                                    size: 32,
                                    className: "text-green-400"
                                })
                            }), (0, s.jsx)("h3", {
                                className: "text-xl font-display font-bold text-white mb-2",
                                children: "Den\xfancia enviada"
                            }), (0, s.jsx)("p", {
                                className: "text-white/60 text-sm mb-6 leading-relaxed",
                                children: "Sua den\xfancia foi registrada com sucesso e ser\xe1 analisada pela nossa equipe."
                            }), (0, s.jsx)("button", {
                                onClick: t,
                                className: "px-6 py-2.5 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-colors font-medium text-sm",
                                children: "Fechar"
                            })]
                        }) : (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsxs)("div", {
                                className: "flex items-center gap-3 mb-6 pr-8",
                                children: [(0, s.jsx)("div", {
                                    className: "w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0",
                                    children: (0, s.jsx)(j.Z, {
                                        size: 20,
                                        className: "text-red-400"
                                    })
                                }), (0, s.jsxs)("div", {
                                    className: "flex-1 min-w-0",
                                    children: [(0, s.jsx)("h3", {
                                        className: "text-lg font-display font-bold text-white",
                                        children: "Denunciar Jogador"
                                    }), (0, s.jsxs)("div", {
                                        className: "flex items-center gap-2 mt-1",
                                        children: [(0, s.jsx)(x.Z, {
                                            username: n,
                                            size: "xs"
                                        }), (0, s.jsx)("span", {
                                            className: "text-white/60 text-sm truncate",
                                            children: n
                                        })]
                                    })]
                                })]
                            }), (0, s.jsxs)("div", {
                                className: "space-y-2 mb-5",
                                children: [(0, s.jsx)("p", {
                                    className: "text-sm text-white/70 font-medium mb-3",
                                    children: "Motivo da den\xfancia:"
                                }), N.map(e => {
                                    let a = c.includes(e.value),
                                        t = e.icon;
                                    return (0, s.jsxs)("button", {
                                        type: "button",
                                        onClick: () => b(e.value),
                                        className: "w-full flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all text-left ".concat(a ? "".concat(e.selectedBorder, " ").concat(e.selectedBg) : "border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/5"),
                                        children: [(0, s.jsx)("div", {
                                            className: "flex-shrink-0 mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center transition-all ".concat(a ? "bg-red-500 border-red-500" : "border-white/30 bg-transparent"),
                                            children: a && (0, s.jsx)(_.Z, {
                                                size: 12,
                                                className: "text-white"
                                            })
                                        }), (0, s.jsx)("div", {
                                            className: "flex-shrink-0 mt-0.5",
                                            children: (0, s.jsx)(t, {
                                                size: 18,
                                                className: a ? e.color : "text-white/40"
                                            })
                                        }), (0, s.jsxs)("div", {
                                            className: "flex-1 min-w-0",
                                            children: [(0, s.jsx)("span", {
                                                className: "text-sm font-medium block ".concat(a ? "text-white" : "text-white/80"),
                                                children: e.label
                                            }), (0, s.jsx)("span", {
                                                className: "text-xs text-white/40 block mt-0.5 leading-relaxed",
                                                children: e.description
                                            })]
                                        })]
                                    }, e.value)
                                })]
                            }), (0, s.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, s.jsxs)("label", {
                                    className: "block text-sm text-white/70 font-medium mb-2",
                                    children: ["Descri\xe7\xe3o adicional ", (0, s.jsx)("span", {
                                        className: "text-white/40 font-normal",
                                        children: "(opcional)"
                                    })]
                                }), (0, s.jsx)("textarea", {
                                    value: r,
                                    onChange: e => d(e.target.value.slice(0, 256)),
                                    placeholder: "Descreva o que aconteceu...",
                                    rows: 3,
                                    className: "w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-white/30 resize-none text-sm"
                                }), (0, s.jsxs)("p", {
                                    className: "text-xs text-white/30 mt-1 text-right",
                                    children: [r.length, "/", 256]
                                })]
                            }), (0, s.jsxs)("div", {
                                className: "flex items-center justify-end gap-3",
                                children: [(0, s.jsx)("button", {
                                    onClick: t,
                                    disabled: m,
                                    className: "px-4 py-2.5 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-colors font-medium text-sm disabled:opacity-50",
                                    children: "Cancelar"
                                }), (0, s.jsx)("button", {
                                    onClick: v,
                                    disabled: m || 0 === c.length,
                                    className: "px-5 py-2.5 rounded-lg bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-medium text-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md",
                                    children: m ? (0, s.jsxs)("span", {
                                        className: "flex items-center gap-2",
                                        children: [(0, s.jsx)(w.Z, {
                                            size: 16,
                                            className: "animate-spin"
                                        }), "Enviando..."]
                                    }) : "Enviar Den\xfancia"
                                })]
                            })]
                        })]
                    })]
                }) : null
            }
            var y = t(66260),
                Z = t(99325),
                k = t(15677),
                C = t(71483),
                z = t(58943),
                S = t(78147),
                E = t(17021),
                B = t(56227),
                D = t(10822),
                R = t(10775),
                T = t(29733),
                F = t(26490),
                P = t(49108),
                L = t(37805);
            let O = {
                    "Pocketed 8-ball legally": {
                        label: "Bola 8 enca\xe7apada",
                        icon: y.Z
                    },
                    opponent_forfeit: {
                        label: "Desist\xeancia do oponente",
                        icon: Z.Z
                    },
                    forfeit: {
                        label: "Desist\xeancia",
                        icon: Z.Z
                    },
                    opponent_disconnect: {
                        label: "Oponente desconectou",
                        icon: k.Z
                    },
                    opponent_disconnect_timeout: {
                        label: "Oponente desconectou (timeout)",
                        icon: k.Z
                    },
                    opponent_exceeded_disconnection_limit: {
                        label: "Oponente excedeu limite de desconex\xf5es",
                        icon: k.Z
                    },
                    "Scratched while pocketing 8-ball": {
                        label: "Scratch na bola 8",
                        icon: C.Z
                    },
                    "Pocketed 8-ball before clearing group": {
                        label: "Bola 8 enca\xe7apada prematuramente",
                        icon: C.Z
                    },
                    cancelled_by_admin: {
                        label: "Cancelada pelo administrador",
                        icon: Z.Z
                    },
                    cancelled_admin_force_cleanup: {
                        label: "Cancelada pelo administrador",
                        icon: Z.Z
                    },
                    cancelled_initialization_timeout: {
                        label: "Partida n\xe3o iniciou a tempo",
                        icon: C.Z
                    },
                    cancelled_corrupted_state: {
                        label: "Erro no jogo",
                        icon: C.Z
                    },
                    cancelled_redis_state_lost: {
                        label: "Erro no servidor",
                        icon: C.Z
                    },
                    cancelled_dispose_redis_failed: {
                        label: "Erro no servidor",
                        icon: C.Z
                    },
                    cancelled_room_by_creator: {
                        label: "Sala cancelada pelo criador",
                        icon: Z.Z
                    },
                    cancelled_confirming_timeout: {
                        label: "Timeout de confirma\xe7\xe3o",
                        icon: C.Z
                    },
                    cancelled_creator_disconnect: {
                        label: "Criador saiu da sala",
                        icon: k.Z
                    },
                    cancelled_match_creation_failed: {
                        label: "Erro ao criar partida",
                        icon: C.Z
                    },
                    cancelled_start_failed: {
                        label: "Erro ao iniciar partida",
                        icon: C.Z
                    },
                    cancelled_dispose_pregame: {
                        label: "Sala encerrada",
                        icon: C.Z
                    },
                    cancelled_room_empty: {
                        label: "Sala vazia",
                        icon: C.Z
                    },
                    cancelled_orphan_stuck: {
                        label: "Partida encerrada automaticamente",
                        icon: C.Z
                    },
                    cancelled_orphan_pregame: {
                        label: "Partida encerrada automaticamente",
                        icon: C.Z
                    },
                    cancelled_session_cleanup_timeout: {
                        label: "Partida encerrada automaticamente",
                        icon: C.Z
                    },
                    cancelled_session_cleanup_fallback: {
                        label: "Partida encerrada automaticamente",
                        icon: C.Z
                    },
                    admin_cancelled: {
                        label: "Cancelada pelo administrador",
                        icon: Z.Z
                    }
                },
                A = {
                    win: {
                        label: "Vit\xf3ria",
                        icon: f.Z,
                        color: "text-green-400",
                        borderColor: "border-green-500/20",
                        bg: "bg-gradient-to-r from-green-500/10 to-transparent"
                    },
                    loss: {
                        label: "Derrota",
                        icon: C.Z,
                        color: "text-red-400",
                        borderColor: "border-red-500/20",
                        bg: "bg-gradient-to-r from-red-500/10 to-transparent"
                    },
                    cancelled: {
                        label: "Cancelada",
                        icon: S.Z,
                        color: "text-white/50",
                        borderColor: "border-white/10",
                        bg: ""
                    }
                };

            function M() {
                var e;
                let a = (0, i.useRouter)(),
                    {
                        user: t,
                        isAuthenticated: h,
                        isLoading: p,
                        checkAuth: u
                    } = (0, n.tN)(),
                    [b, g] = (0, l.useState)([]),
                    [f, _] = (0, l.useState)(null),
                    [N, Z] = (0, l.useState)(!0),
                    [k, S] = (0, l.useState)(0),
                    [M, I] = (0, l.useState)({}),
                    [$, U] = (0, l.useState)(!1),
                    [q, H] = (0, l.useState)(null);
                (0, l.useEffect)(() => {
                    u()
                }, [u]), (0, l.useEffect)(() => {
                    p || h || a.push("/login")
                }, [p, h, a]);
                let V = (0, l.useCallback)(async () => {
                    Z(!0);
                    let e = await c.h.getMyMatchHistory({
                        take: 100
                    });
                    if (e.data) {
                        g(e.data.matches), _(e.data.stats);
                        let a = e.data.matches.filter(e => "cancelled" !== e.result && e.opponent).map(e => e.matchId);
                        if (a.length > 0) {
                            let e = await c.h.checkReportsBatch(a);
                            e.data && I(e.data)
                        }
                    } else r.default.error(e.error || "Erro ao carregar hist\xf3rico");
                    Z(!1)
                }, []);
                (0, l.useEffect)(() => {
                    h && V()
                }, [h, V]);
                let W = e => {
                        H(e), U(!0)
                    },
                    G = async (e, a) => {
                        if (!q) return;
                        let t = await c.h.createReport({
                            matchId: q.matchId,
                            categories: e,
                            description: a || void 0
                        });
                        if (t.error) throw r.default.error(t.error), Error(t.error);
                        I(e => ({ ...e,
                            [q.matchId]: !0
                        })), r.default.success("Den\xfancia enviada com sucesso")
                    },
                    J = Math.ceil(b.length / 10),
                    X = b.slice(10 * k, (k + 1) * 10);
                if (p) return (0, s.jsx)("main", {
                    className: "min-h-screen flex items-center justify-center",
                    children: (0, s.jsxs)("div", {
                        className: "text-center",
                        children: [(0, s.jsx)(w.Z, {
                            size: 40,
                            className: "animate-spin text-pool-gold mx-auto"
                        }), (0, s.jsx)("p", {
                            className: "text-white/60 mt-4",
                            children: "Carregando..."
                        })]
                    })
                });
                if (!t) return null;
                let Q = f ? f.totalWon - f.totalBet : 0;
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)(d.Z, {}), (0, s.jsxs)("main", {
                        className: "min-h-screen p-4 md:p-8 max-w-5xl mx-auto",
                        children: [(0, s.jsxs)("div", {
                            className: "mb-8",
                            children: [(0, s.jsx)("h1", {
                                className: "font-display text-3xl font-bold",
                                children: "Hist\xf3rico de Partidas"
                            }), (0, s.jsx)("p", {
                                className: "text-white/60 mt-1",
                                children: "Acompanhe seu desempenho e resultados"
                            })]
                        }), f && (0, s.jsxs)("div", {
                            className: "space-y-4 mb-8",
                            children: [(0, s.jsxs)("div", {
                                className: "grid grid-cols-2 md:grid-cols-3 gap-4",
                                children: [(0, s.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-xl p-4 border border-white/5",
                                    children: [(0, s.jsxs)("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [(0, s.jsx)(E.Z, {
                                            size: 16,
                                            className: "text-white/60"
                                        }), (0, s.jsx)("span", {
                                            className: "text-white/60 text-sm",
                                            children: "Partidas"
                                        })]
                                    }), (0, s.jsx)("p", {
                                        className: "text-3xl font-bold",
                                        children: f.totalMatches
                                    })]
                                }), (0, s.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-xl p-4 border border-green-500/20",
                                    children: [(0, s.jsxs)("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [(0, s.jsx)(y.Z, {
                                            size: 16,
                                            className: "text-green-400"
                                        }), (0, s.jsx)("span", {
                                            className: "text-white/60 text-sm",
                                            children: "Vit\xf3rias"
                                        })]
                                    }), (0, s.jsx)("p", {
                                        className: "text-3xl font-bold text-green-400",
                                        children: f.wins
                                    })]
                                }), (0, s.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-xl p-4 border border-red-500/20",
                                    children: [(0, s.jsxs)("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [(0, s.jsx)(B.Z, {
                                            size: 16,
                                            className: "text-red-400"
                                        }), (0, s.jsx)("span", {
                                            className: "text-white/60 text-sm",
                                            children: "Derrotas"
                                        })]
                                    }), (0, s.jsx)("p", {
                                        className: "text-3xl font-bold text-red-400",
                                        children: f.losses
                                    })]
                                }), (0, s.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-xl p-4 border border-blue-500/20",
                                    children: [(0, s.jsxs)("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [(0, s.jsx)(D.Z, {
                                            size: 16,
                                            className: "text-blue-400"
                                        }), (0, s.jsx)("span", {
                                            className: "text-white/60 text-sm",
                                            children: "Taxa de Vit\xf3ria"
                                        })]
                                    }), (0, s.jsxs)("p", {
                                        className: "text-3xl font-bold text-blue-400",
                                        children: [f.winRate.toFixed(1), "%"]
                                    })]
                                }), (0, s.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-xl p-4 border border-white/5",
                                    children: [(0, s.jsxs)("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [(0, s.jsx)(R.Z, {
                                            size: 16,
                                            className: "text-white/60"
                                        }), (0, s.jsx)("span", {
                                            className: "text-white/60 text-sm",
                                            children: "Total Apostado"
                                        })]
                                    }), (0, s.jsxs)("p", {
                                        className: "text-2xl font-bold",
                                        children: ["R$ ", f.totalBet.toFixed(2)]
                                    })]
                                }), (0, s.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-xl p-4 border border-pool-gold/20",
                                    children: [(0, s.jsxs)("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [(0, s.jsx)(T.Z, {
                                            size: 16,
                                            className: "text-pool-gold"
                                        }), (0, s.jsx)("span", {
                                            className: "text-white/60 text-sm",
                                            children: "Total Ganho"
                                        })]
                                    }), (0, s.jsxs)("p", {
                                        className: "text-2xl font-bold text-pool-gold",
                                        children: ["R$ ", f.totalWon.toFixed(2)]
                                    })]
                                })]
                            }), f.totalMatches > 0 && (0, s.jsxs)("div", {
                                className: "rounded-xl p-4 flex items-center justify-between ".concat(Q >= 0 ? "bg-green-500/10 border border-green-500/30" : "bg-red-500/10 border border-red-500/30"),
                                children: [(0, s.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [Q >= 0 ? (0, s.jsx)(T.Z, {
                                        size: 24,
                                        className: "text-green-400"
                                    }) : (0, s.jsx)(R.Z, {
                                        size: 24,
                                        className: "text-red-400"
                                    }), (0, s.jsxs)("div", {
                                        children: [(0, s.jsx)("p", {
                                            className: "text-white/60 text-sm",
                                            children: "Lucro / Preju\xedzo"
                                        }), (0, s.jsxs)("p", {
                                            className: "text-2xl font-bold ".concat(Q >= 0 ? "text-green-400" : "text-red-400"),
                                            children: [Q >= 0 ? "+" : "", "R$ ", Q.toFixed(2)]
                                        })]
                                    })]
                                }), (0, s.jsxs)("div", {
                                    className: "hidden sm:block text-right",
                                    children: [(0, s.jsxs)("p", {
                                        className: "text-sm text-white/60 mb-1",
                                        children: [f.wins, "V / ", f.losses, "D"]
                                    }), (0, s.jsx)("div", {
                                        className: "h-2 w-32 bg-pool-dark rounded-full overflow-hidden flex",
                                        children: f.totalMatches > 0 && (0, s.jsxs)(s.Fragment, {
                                            children: [(0, s.jsx)("div", {
                                                className: "h-full bg-gradient-to-r from-green-500 to-green-400 transition-all duration-500",
                                                style: {
                                                    width: "".concat(f.wins / f.totalMatches * 100, "%")
                                                }
                                            }), (0, s.jsx)("div", {
                                                className: "h-full bg-gradient-to-r from-red-500 to-red-400 transition-all duration-500",
                                                style: {
                                                    width: "".concat(f.losses / f.totalMatches * 100, "%")
                                                }
                                            })]
                                        })
                                    })]
                                })]
                            })]
                        }), N ? (0, s.jsx)("div", {
                            className: "flex items-center justify-center py-16",
                            children: (0, s.jsxs)("div", {
                                className: "text-center",
                                children: [(0, s.jsx)(w.Z, {
                                    className: "animate-spin text-pool-gold mx-auto",
                                    size: 28
                                }), (0, s.jsx)("p", {
                                    className: "text-white/40 text-sm mt-3",
                                    children: "Carregando partidas..."
                                })]
                            })
                        }) : 0 === X.length ? (0, s.jsxs)("div", {
                            className: "text-center py-20",
                            children: [(0, s.jsx)(E.Z, {
                                size: 56,
                                className: "text-white/15 mx-auto mb-4"
                            }), (0, s.jsx)("p", {
                                className: "text-white/60 text-lg",
                                children: "Nenhuma partida encontrada"
                            }), (0, s.jsx)("p", {
                                className: "text-white/40 text-sm mt-1",
                                children: "Jogue sua primeira partida para ver o hist\xf3rico aqui"
                            })]
                        }) : (0, s.jsx)("div", {
                            className: "space-y-3",
                            children: X.map(e => {
                                var a, t, l;
                                let i = A[e.result],
                                    n = i.icon,
                                    c = "solid" === (a = e.ballType) ? "Lisas" : "stripe" === a ? "Listradas" : null,
                                    r = (t = e.endReason) ? O[t] ? O[t] : t.startsWith("Opponent pocketed 8-ball") ? {
                                        label: "Bola 8 do oponente (irregular)",
                                        icon: C.Z
                                    } : {
                                        label: (0, o.X)(t),
                                        icon: z.Z
                                    } : null,
                                    d = (null == r ? void 0 : r.icon) || z.Z,
                                    m = "win" === e.result ? "+R$ ".concat(e.earnings.toFixed(2)) : "loss" === e.result ? "-R$ ".concat(e.betAmount.toFixed(2)) : e.earnings > 0 ? "+R$ ".concat(e.earnings.toFixed(2)) : null,
                                    h = "win" === (l = e.result) ? "text-green-400" : "loss" === l ? "text-red-400" : "text-white/50",
                                    p = "cancelled" !== e.result && e.opponent,
                                    u = M[e.matchId];
                                return (0, s.jsx)("div", {
                                    className: "card border ".concat(i.borderColor, " ").concat(i.bg, " hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200"),
                                    children: (0, s.jsxs)("div", {
                                        className: "flex items-center gap-4",
                                        children: [(0, s.jsx)("div", {
                                            className: "flex-shrink-0",
                                            children: (0, s.jsx)(n, {
                                                size: 28,
                                                className: i.color
                                            })
                                        }), (0, s.jsxs)("div", {
                                            className: "flex-1 min-w-0",
                                            children: [(0, s.jsxs)("div", {
                                                className: "flex items-center gap-2 mb-1",
                                                children: [(0, s.jsx)("span", {
                                                    className: "text-sm font-semibold ".concat(i.color),
                                                    children: i.label
                                                }), c && (0, s.jsx)("span", {
                                                    className: "text-xs px-2 py-0.5 rounded-full bg-white/10 text-white/60",
                                                    children: c
                                                })]
                                            }), (0, s.jsxs)("div", {
                                                className: "flex items-center gap-2 mb-1.5",
                                                children: [(0, s.jsx)("span", {
                                                    className: "text-white/40 text-sm",
                                                    children: "vs"
                                                }), e.opponent ? (0, s.jsxs)("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [(0, s.jsx)(x.Z, {
                                                        username: e.opponent.username,
                                                        size: "xs"
                                                    }), (0, s.jsx)("span", {
                                                        className: "text-base text-white font-medium truncate",
                                                        children: e.opponent.username
                                                    })]
                                                }) : (0, s.jsx)("span", {
                                                    className: "text-sm text-white/40",
                                                    children: "Oponente desconhecido"
                                                })]
                                            }), (0, s.jsxs)("div", {
                                                className: "flex items-center gap-3 flex-wrap",
                                                children: [r && "cancelled" !== e.result && (0, s.jsxs)("span", {
                                                    className: "flex items-center gap-1.5 text-xs text-white/40",
                                                    children: [(0, s.jsx)(d, {
                                                        size: 12
                                                    }), r.label]
                                                }), (0, s.jsxs)("span", {
                                                    className: "flex items-center gap-1 text-xs text-white/30",
                                                    children: [(0, s.jsx)(F.Z, {
                                                        size: 12
                                                    }), function(e) {
                                                        if (e < 60) return "".concat(e, "s");
                                                        let a = Math.floor(e / 60),
                                                            t = e % 60;
                                                        return t > 0 ? "".concat(a, "m ").concat(t, "s") : "".concat(a, "min")
                                                    }(e.duration)]
                                                })]
                                            })]
                                        }), (0, s.jsxs)("div", {
                                            className: "flex-shrink-0 text-right flex flex-col items-end gap-2",
                                            children: [(0, s.jsxs)("div", {
                                                children: [m && (0, s.jsx)("p", {
                                                    className: "text-lg font-bold ".concat(h),
                                                    children: m
                                                }), (0, s.jsxs)("p", {
                                                    className: "text-xs text-white/40 mt-0.5",
                                                    children: ["Aposta: R$ ", e.betAmount.toFixed(2)]
                                                }), (0, s.jsx)("p", {
                                                    className: "text-xs text-white/30 mt-1",
                                                    children: function(e) {
                                                        let a = new Date(e),
                                                            t = new Date().getTime() - a.getTime(),
                                                            s = t / 36e5;
                                                        if (s < 1) {
                                                            let e = Math.floor(t / 6e4);
                                                            return e <= 1 ? "Agora mesmo" : "".concat(e, " min atr\xe1s")
                                                        }
                                                        return s < 24 ? "".concat(Math.floor(s), "h atr\xe1s") : s < 48 ? "Ontem, ".concat(a.toLocaleTimeString("pt-BR", {
                                                            hour: "2-digit",
                                                            minute: "2-digit"
                                                        })) : a.toLocaleDateString("pt-BR", {
                                                            day: "2-digit",
                                                            month: "2-digit",
                                                            year: "2-digit",
                                                            hour: "2-digit",
                                                            minute: "2-digit"
                                                        })
                                                    }(e.createdAt)
                                                })]
                                            }), p && (0, s.jsxs)("button", {
                                                onClick: a => {
                                                    a.stopPropagation(), u || W(e)
                                                },
                                                disabled: u,
                                                className: "flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg transition-all ".concat(u ? "bg-white/5 text-white/30 cursor-not-allowed" : "bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 hover:border-red-500/40"),
                                                title: u ? "Den\xfancia j\xe1 enviada" : "Denunciar jogador",
                                                children: [(0, s.jsx)(j.Z, {
                                                    size: 12
                                                }), u ? "Denunciado" : "Denunciar"]
                                            })]
                                        })]
                                    })
                                }, e.matchId)
                            })
                        }), J > 1 && (0, s.jsxs)("div", {
                            className: "flex items-center justify-between mt-8",
                            children: [(0, s.jsxs)("span", {
                                className: "text-sm text-white/50",
                                children: ["P\xe1gina ", k + 1, " de ", J, " (", b.length, " partidas)"]
                            }), (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, s.jsx)("button", {
                                    onClick: () => S(Math.max(0, k - 1)),
                                    disabled: 0 === k,
                                    className: "p-2 rounded-lg bg-white/5 border border-white/10 text-white/60 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors",
                                    children: (0, s.jsx)(P.Z, {
                                        size: 16
                                    })
                                }), (0, s.jsx)("button", {
                                    onClick: () => S(Math.min(J - 1, k + 1)),
                                    disabled: k >= J - 1,
                                    className: "p-2 rounded-lg bg-white/5 border border-white/10 text-white/60 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors",
                                    children: (0, s.jsx)(L.Z, {
                                        size: 16
                                    })
                                })]
                            })]
                        })]
                    }), (0, s.jsx)(m.Z, {}), (0, s.jsx)(v, {
                        isOpen: $,
                        onClose: () => {
                            U(!1), H(null)
                        },
                        onSubmit: G,
                        opponentUsername: (null == q ? void 0 : null === (e = q.opponent) || void 0 === e ? void 0 : e.username) || ""
                    })]
                })
            }
        },
        16112: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return n
                }
            });
            var s = t(3827),
                l = t(8792),
                i = t(20703);

            function n() {
                let e = new Date().getFullYear();
                return (0, s.jsx)("footer", {
                    className: "bg-pool-dark border-t border-white/5 mt-auto",
                    children: (0, s.jsx)("div", {
                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",
                        children: (0, s.jsxs)("div", {
                            className: "flex flex-col md:flex-row items-center justify-between gap-4",
                            children: [(0, s.jsxs)("div", {
                                className: "flex items-center gap-4",
                                children: [(0, s.jsx)(i.default, {
                                    src: "/logos/logo-white-red.png",
                                    alt: "Tacadinha",
                                    width: 100,
                                    height: 32,
                                    className: "h-6 w-auto opacity-50"
                                }), (0, s.jsx)("span", {
                                    className: "text-white/30 text-sm hidden sm:inline",
                                    children: "|"
                                }), (0, s.jsxs)("p", {
                                    className: "text-white/30 text-sm",
                                    children: ["\xa9 ", e, " Tacadinha"]
                                })]
                            }), (0, s.jsxs)("div", {
                                className: "flex items-center gap-6 text-sm",
                                children: [(0, s.jsx)(l.default, {
                                    href: "/termos",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Termos"
                                }), (0, s.jsx)(l.default, {
                                    href: "/privacidade",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Privacidade"
                                }), (0, s.jsx)(l.default, {
                                    href: "#",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Suporte"
                                })]
                            }), (0, s.jsxs)("div", {
                                className: "flex items-center gap-3 text-white/30 text-xs",
                                children: [(0, s.jsx)("span", {
                                    children: "+18"
                                }), (0, s.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "•"
                                }), (0, s.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "Jogue com responsabilidade"
                                })]
                            })]
                        })
                    })
                })
            }
        },
        76486: function(e, a, t) {
            "use strict";
            t.d(a, {
                X: function() {
                    return i
                }
            });
            let s = {
                    "Pocketed 8-ball legally": "Bola 8 enca\xe7apada legalmente",
                    opponent_forfeit: "Desist\xeancia do oponente",
                    forfeit: "Desist\xeancia",
                    opponent_disconnect: "Desconex\xe3o do oponente",
                    opponent_disconnect_timeout: "Timeout por desconex\xe3o",
                    opponent_exceeded_disconnection_limit: "Limite de desconex\xf5es excedido",
                    "Scratched while pocketing 8-ball": "Scratch na bola 8",
                    "Pocketed 8-ball before clearing group": "Bola 8 enca\xe7apada prematuramente",
                    cancelled_by_admin: "Cancelada pelo administrador",
                    cancelled_admin_force_cleanup: "Limpeza for\xe7ada pelo admin",
                    cancelled_initialization_timeout: "Timeout de inicializa\xe7\xe3o",
                    cancelled_corrupted_state: "Estado corrompido",
                    cancelled_redis_state_lost: "Estado perdido no Redis",
                    cancelled_dispose_redis_failed: "Sala encerrada (Redis)",
                    cancelled_room_by_creator: "Cancelada pelo criador",
                    cancelled_confirming_timeout: "Timeout de confirma\xe7\xe3o",
                    cancelled_creator_disconnect: "Criador desconectou",
                    cancelled_match_creation_failed: "Falha ao criar partida",
                    cancelled_start_failed: "Falha ao iniciar partida",
                    cancelled_dispose_pregame: "Sala encerrada (pr\xe9-jogo)",
                    cancelled_room_empty: "Sala vazia",
                    cancelled_orphan_stuck: "Limpeza autom\xe1tica",
                    cancelled_orphan_pregame: "Limpeza autom\xe1tica",
                    cancelled_session_cleanup_timeout: "Sess\xe3o expirada",
                    cancelled_session_cleanup_fallback: "Limpeza de sess\xe3o",
                    admin_cancelled: "Cancelada pelo administrador",
                    admin_cancel: "Cancelada pelo administrador"
                },
                l = {
                    "Pocketed 8-ball legally": "Bola 8 legal",
                    opponent_forfeit: "Desist\xeancia",
                    forfeit: "Desist\xeancia",
                    opponent_disconnect: "Desconex\xe3o",
                    opponent_disconnect_timeout: "Timeout desconex\xe3o",
                    opponent_exceeded_disconnection_limit: "Limite desconex\xf5es",
                    "Scratched while pocketing 8-ball": "Scratch bola 8",
                    "Pocketed 8-ball before clearing group": "Bola 8 prematura",
                    "Opponent pocketed 8-ball before ball types assigned": "Bola 8 prematura",
                    cancelled_by_admin: "Admin cancelou",
                    cancelled_admin_force_cleanup: "Cleanup admin",
                    cancelled_initialization_timeout: "Timeout inicializa\xe7\xe3o",
                    cancelled_corrupted_state: "Estado corrompido",
                    cancelled_redis_state_lost: "Redis perdido",
                    cancelled_dispose_redis_failed: "Redis falhou",
                    cancelled_room_by_creator: "Criador cancelou",
                    cancelled_confirming_timeout: "Timeout confirma\xe7\xe3o",
                    cancelled_creator_disconnect: "Criador desconectou",
                    cancelled_match_creation_failed: "Falha criar match",
                    cancelled_start_failed: "Falha ao iniciar",
                    cancelled_dispose_pregame: "Dispose pr\xe9-jogo",
                    cancelled_room_empty: "Sala vazia",
                    cancelled_orphan_stuck: "Orphan stuck",
                    cancelled_orphan_pregame: "Orphan pr\xe9-jogo",
                    cancelled_session_cleanup_timeout: "Sess\xe3o expirada",
                    cancelled_session_cleanup_fallback: "Cleanup fallback",
                    admin_cancelled: "Admin cancelou",
                    admin_cancel: "Admin cancelou"
                };

            function i(e) {
                let a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    {
                        mode: t = "detailed",
                        status: i
                    } = a;
                if (!e) return "CANCELLED" === i ? "Motivo n\xe3o registrado" : "-";
                let n = "compact" === t ? l : s;
                return n[e] ? n[e] : e.startsWith("Opponent pocketed 8-ball") ? "compact" === t ? "Bola 8 irregular" : "Bola 8 do oponente (irregular)" : e.includes("Scratched") ? "compact" === t ? "Falta na bola 8" : "Scratch na bola 8" : e.startsWith("cancelled_") ? e.replace(/^cancelled_/, "").replace(/_/g, " ") : "compact" === t ? e.replace(/_/g, " ") : e.replace(/_/g, " ").replace(/\b\w/g, e => e.toUpperCase())
            }
        }
    },
    function(e) {
        e.O(0, [2807, 963, 703, 1154, 826, 4002, 2971, 8069, 1744], function() {
            return e(e.s = 98179)
        }), _N_E = e.O()
    }
]);