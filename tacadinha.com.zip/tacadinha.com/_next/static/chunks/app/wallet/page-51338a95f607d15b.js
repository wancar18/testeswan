(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3597], {
        18668: function(e, t, s) {
            Promise.resolve().then(s.bind(s, 60471))
        },
        60471: function(e, t, s) {
            "use strict";
            s.r(t), s.d(t, {
                default: function() {
                    return R
                }
            });
            var a = s(3827),
                l = s(64090),
                r = s(47907),
                n = s(6739),
                i = s(10826),
                d = s(18994),
                c = s(80037),
                o = s(52235),
                x = s(17252),
                m = s(70094),
                h = s(27271),
                u = s(26490),
                p = s(98998),
                b = s(10527),
                g = s(79229),
                j = s(87461);
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let f = (0, j.Z)("QrCode", [
                ["rect", {
                    width: "5",
                    height: "5",
                    x: "3",
                    y: "3",
                    rx: "1",
                    key: "1tu5fj"
                }],
                ["rect", {
                    width: "5",
                    height: "5",
                    x: "16",
                    y: "3",
                    rx: "1",
                    key: "1v8r4q"
                }],
                ["rect", {
                    width: "5",
                    height: "5",
                    x: "3",
                    y: "16",
                    rx: "1",
                    key: "1x03jg"
                }],
                ["path", {
                    d: "M21 16h-3a2 2 0 0 0-2 2v3",
                    key: "177gqh"
                }],
                ["path", {
                    d: "M21 21v.01",
                    key: "ents32"
                }],
                ["path", {
                    d: "M12 7v3a2 2 0 0 1-2 2H7",
                    key: "8crl2c"
                }],
                ["path", {
                    d: "M3 12h.01",
                    key: "nlz23k"
                }],
                ["path", {
                    d: "M12 3h.01",
                    key: "n36tog"
                }],
                ["path", {
                    d: "M12 16v.01",
                    key: "133mhm"
                }],
                ["path", {
                    d: "M16 12h1",
                    key: "1slzba"
                }],
                ["path", {
                    d: "M21 12v.01",
                    key: "1lwtk9"
                }],
                ["path", {
                    d: "M12 21v-1",
                    key: "1880an"
                }]
            ]);
            var N = s(23416);

            function v(e) {
                let {
                    isOpen: t,
                    onClose: s,
                    pixCode: r,
                    pixQrCode: n,
                    amount: i,
                    transactionId: x,
                    onPaymentConfirmed: m,
                    paymentConfirmed: h = !1
                } = e, [u, p] = (0, l.useState)(!1), [b, g] = (0, l.useState)(600);
                (0, l.useEffect)(() => {
                    if (!t) return;
                    let e = setInterval(() => {
                        g(t => t <= 1 ? (clearInterval(e), 0) : t - 1)
                    }, 1e3);
                    return () => clearInterval(e)
                }, [t]);
                let j = async () => {
                    try {
                        if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(r);
                        else {
                            let e = document.createElement("textarea");
                            e.value = r, e.style.position = "fixed", e.style.left = "-999999px", document.body.appendChild(e), e.select(), document.execCommand("copy"), document.body.removeChild(e)
                        }
                        p(!0), setTimeout(() => p(!1), 3e3)
                    } catch (e) {
                        console.error("Erro ao copiar:", e), alert("Erro ao copiar o c\xf3digo PIX. Tente selecionar e copiar manualmente.")
                    }
                };
                return t ? (0, a.jsx)("div", {
                    className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-2 sm:p-4 overflow-y-auto",
                    children: (0, a.jsxs)("div", {
                        className: "bg-pool-dark/95 border border-pool-gold/30 rounded-2xl max-w-md w-full p-4 sm:p-6 shadow-2xl my-auto max-h-[95vh] overflow-y-auto",
                        children: [(0, a.jsxs)("div", {
                            className: "flex justify-between items-center mb-4 sm:mb-6",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [h ? (0, a.jsx)(c.Z, {
                                    className: "text-green-400",
                                    size: 20
                                }) : (0, a.jsx)(f, {
                                    className: "text-pool-gold",
                                    size: 20
                                }), (0, a.jsx)("h2", {
                                    className: "text-lg sm:text-2xl font-bold text-white",
                                    children: h ? "Pagamento Confirmado" : "Pagamento PIX"
                                })]
                            }), (0, a.jsx)("button", {
                                onClick: s,
                                className: "text-white/60 hover:text-white transition-colors flex-shrink-0",
                                children: (0, a.jsx)(o.Z, {
                                    size: 20
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "text-center mb-4 sm:mb-6",
                            children: [(0, a.jsx)("p", {
                                className: "text-white/60 text-xs sm:text-sm mb-1",
                                children: h ? "Valor creditado" : "Valor a pagar"
                            }), (0, a.jsxs)("p", {
                                className: "text-2xl sm:text-4xl font-bold ".concat(h ? "text-green-400" : "text-pool-gold"),
                                children: ["R$ ", i.toFixed(2)]
                            })]
                        }), !h && (0, a.jsxs)(a.Fragment, {
                            children: [b > 0 ? (0, a.jsxs)("div", {
                                className: "text-center mb-4 sm:mb-6",
                                children: [(0, a.jsx)("p", {
                                    className: "text-white/60 text-sm mb-1",
                                    children: "Tempo restante"
                                }), (0, a.jsx)("p", {
                                    className: "text-xl font-mono text-white",
                                    children: "".concat(Math.floor(b / 60), ":").concat((b % 60).toString().padStart(2, "0"))
                                })]
                            }) : (0, a.jsx)("div", {
                                className: "bg-red-500/20 border border-red-500/50 rounded-lg p-4 mb-6",
                                children: (0, a.jsx)("p", {
                                    className: "text-red-400 text-sm text-center",
                                    children: "⏰ C\xf3digo PIX expirado. Feche e gere um novo c\xf3digo."
                                })
                            }), (0, a.jsx)("div", {
                                className: "bg-white rounded-xl p-3 sm:p-4 mb-4 sm:mb-6 flex justify-center",
                                children: n ? (0, a.jsx)("img", {
                                    src: n ? n.startsWith("data:image/") ? n : "data:image/png;base64,".concat(n) : "",
                                    alt: "QR Code PIX",
                                    className: "rounded-lg w-full max-w-[250px] h-auto"
                                }) : (0, a.jsx)("div", {
                                    className: "w-full max-w-[250px] aspect-square flex items-center justify-center",
                                    children: (0, a.jsx)(d.Z, {
                                        className: "animate-spin text-pool-dark",
                                        size: 48
                                    })
                                })
                            }), (0, a.jsxs)("div", {
                                className: "bg-pool-dark/50 border border-white/10 rounded-lg p-4 mb-4",
                                children: [(0, a.jsx)("h3", {
                                    className: "text-white font-semibold mb-3 text-sm",
                                    children: "Como pagar:"
                                }), (0, a.jsxs)("ol", {
                                    className: "text-white/80 text-sm space-y-2",
                                    children: [(0, a.jsxs)("li", {
                                        className: "flex gap-2",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-pool-gold font-bold",
                                            children: "1."
                                        }), (0, a.jsx)("span", {
                                            children: "Abra o app do seu banco"
                                        })]
                                    }), (0, a.jsxs)("li", {
                                        className: "flex gap-2",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-pool-gold font-bold",
                                            children: "2."
                                        }), (0, a.jsx)("span", {
                                            children: "Escolha pagar com PIX QR Code"
                                        })]
                                    }), (0, a.jsxs)("li", {
                                        className: "flex gap-2",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-pool-gold font-bold",
                                            children: "3."
                                        }), (0, a.jsx)("span", {
                                            children: "Escaneie o QR Code acima"
                                        })]
                                    }), (0, a.jsxs)("li", {
                                        className: "flex gap-2",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-pool-gold font-bold",
                                            children: "4."
                                        }), (0, a.jsx)("span", {
                                            children: "Confirme o pagamento"
                                        })]
                                    })]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, a.jsx)("label", {
                                    className: "text-white/60 text-xs mb-2 block",
                                    children: "Ou copie o c\xf3digo PIX:"
                                }), (0, a.jsxs)("div", {
                                    className: "flex gap-2",
                                    children: [(0, a.jsx)("input", {
                                        type: "text",
                                        value: r,
                                        readOnly: !0,
                                        className: "flex-1 bg-pool-dark/50 border border-white/20 rounded-lg px-3 py-2 text-white text-sm font-mono"
                                    }), (0, a.jsx)("button", {
                                        onClick: j,
                                        className: "px-4 py-2 rounded-lg font-semibold transition-all duration-200 flex items-center gap-2 ".concat(u ? "bg-green-500/20 text-green-400 border border-green-500/50" : "bg-pool-gold text-pool-dark border border-pool-gold hover:bg-yellow-500"),
                                        children: u ? (0, a.jsxs)(a.Fragment, {
                                            children: [(0, a.jsx)(c.Z, {
                                                size: 18
                                            }), (0, a.jsx)("span", {
                                                children: "Copiado!"
                                            })]
                                        }) : (0, a.jsxs)(a.Fragment, {
                                            children: [(0, a.jsx)(N.Z, {
                                                size: 18
                                            }), (0, a.jsx)("span", {
                                                children: "Copiar"
                                            })]
                                        })
                                    })]
                                })]
                            })]
                        }), h ? (0, a.jsx)("div", {
                            className: "bg-green-500/20 border border-green-500/50 rounded-lg p-4 mb-4",
                            children: (0, a.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, a.jsx)("div", {
                                    className: "w-10 h-10 rounded-full bg-green-500/30 flex items-center justify-center",
                                    children: (0, a.jsx)(c.Z, {
                                        className: "text-green-400",
                                        size: 24
                                    })
                                }), (0, a.jsxs)("div", {
                                    children: [(0, a.jsx)("p", {
                                        className: "text-green-400 font-bold text-lg",
                                        children: "Pagamento confirmado!"
                                    }), (0, a.jsx)("p", {
                                        className: "text-green-400/80 text-sm mt-1",
                                        children: "Seu saldo foi creditado com sucesso"
                                    })]
                                })]
                            })
                        }) : (0, a.jsx)("div", {
                            className: "bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-4",
                            children: (0, a.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, a.jsx)(d.Z, {
                                    className: "animate-spin text-blue-400",
                                    size: 20
                                }), (0, a.jsxs)("div", {
                                    children: [(0, a.jsx)("p", {
                                        className: "text-blue-400 font-semibold text-sm",
                                        children: "Aguardando pagamento..."
                                    }), (0, a.jsx)("p", {
                                        className: "text-blue-400/60 text-xs mt-1",
                                        children: "Seu saldo ser\xe1 creditado automaticamente ap\xf3s a confirma\xe7\xe3o"
                                    })]
                                })]
                            })
                        }), (0, a.jsx)("button", {
                            onClick: s,
                            className: "w-full font-semibold py-3 px-6 rounded-lg transition-all duration-200 ".concat(h ? "bg-green-500 text-white hover:bg-green-600" : "bg-pool-dark/50 text-white border border-white/20 hover:border-white/40"),
                            children: h ? "Continuar" : "Fechar"
                        }), (0, a.jsxs)("p", {
                            className: "text-white/40 text-xs text-center mt-4",
                            children: ["ID: ", x.substring(0, 8), "..."]
                        })]
                    })
                }) : null
            }
            var w = s(99744),
                y = s(4002),
                C = s(16112),
                k = s(54012);
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let E = (0, j.Z)("ArrowDownLeft", [
                ["path", {
                    d: "M17 7 7 17",
                    key: "15tmo1"
                }],
                ["path", {
                    d: "M17 17H7V7",
                    key: "1org7z"
                }]
            ]);
            var I = s(29733),
                S = s(8967);
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let T = (0, j.Z)("Receipt", [
                ["path", {
                    d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",
                    key: "q3az6g"
                }],
                ["path", {
                    d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",
                    key: "1h4pet"
                }],
                ["path", {
                    d: "M12 17.5v-11",
                    key: "1jc1ny"
                }]
            ]);
            var z = s(11213);
            let Z = ["DEPOSIT", "BET_WON", "MATCH_CANCELLED_REFUND", "REGISTRATION_BONUS"],
                D = (0, l.memo)(function(e) {
                    let {
                        transactions: t,
                        isLoading: s
                    } = e;
                    return s ? (0, a.jsx)("div", {
                        className: "flex justify-center py-12",
                        children: (0, a.jsx)(d.Z, {
                            size: 32,
                            className: "animate-spin text-pool-gold"
                        })
                    }) : 0 === t.length ? (0, a.jsxs)("div", {
                        className: "text-center py-12",
                        children: [(0, a.jsx)(T, {
                            size: 48,
                            className: "text-white/20 mx-auto mb-4"
                        }), (0, a.jsx)("p", {
                            className: "text-white/60",
                            children: "Nenhuma transa\xe7\xe3o ainda"
                        }), (0, a.jsx)("p", {
                            className: "text-white/40 text-sm mt-1",
                            children: "Fa\xe7a seu primeiro dep\xf3sito para come\xe7ar!"
                        })]
                    }) : (0, a.jsx)("div", {
                        className: "space-y-2",
                        children: t.map(e => {
                            var t, s, l, r;
                            let n = Z.includes(e.type);
                            return (0, a.jsxs)("div", {
                                className: "bg-pool-dark/50 rounded-lg p-4 flex items-center justify-between hover:bg-pool-dark/70 transition-colors border border-white/5",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-10 h-10 rounded-full flex items-center justify-center ".concat((t = e.type, Z.includes(t) ? "bg-green-500/20" : "WITHDRAWAL" === t ? "bg-orange-500/20" : "BET_PLACED" === t ? "bg-blue-500/20" : "USERNAME_CHANGE" === t ? "bg-purple-500/20" : "bg-white/10")),
                                        children: (s = e.type, ({
                                            DEPOSIT: (0, a.jsx)(E, {
                                                size: 18,
                                                className: "text-green-400"
                                            }),
                                            BET_WON: (0, a.jsx)(I.Z, {
                                                size: 18,
                                                className: "text-green-400"
                                            }),
                                            MATCH_CANCELLED_REFUND: (0, a.jsx)(E, {
                                                size: 18,
                                                className: "text-green-400"
                                            }),
                                            REGISTRATION_BONUS: (0, a.jsx)(E, {
                                                size: 18,
                                                className: "text-green-400"
                                            }),
                                            WITHDRAWAL: (0, a.jsx)(S.Z, {
                                                size: 18,
                                                className: "text-orange-400"
                                            }),
                                            BET_PLACED: (0, a.jsx)(g.Z, {
                                                size: 18,
                                                className: "text-blue-400"
                                            }),
                                            HOUSE_FEE: (0, a.jsx)(T, {
                                                size: 18,
                                                className: "text-white/40"
                                            }),
                                            USERNAME_CHANGE: (0, a.jsx)(z.Z, {
                                                size: 18,
                                                className: "text-purple-400"
                                            })
                                        })[s] || (0, a.jsx)(S.Z, {
                                            size: 18,
                                            className: "text-white/40"
                                        }))
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2",
                                            children: [(0, a.jsx)("p", {
                                                className: "font-semibold text-sm",
                                                children: {
                                                    DEPOSIT: "Dep\xf3sito",
                                                    WITHDRAWAL: "Saque",
                                                    BET_PLACED: "Entrada da partida",
                                                    BET_WON: "Pr\xeamio da partida",
                                                    HOUSE_FEE: "Taxa",
                                                    MATCH_CANCELLED_REFUND: "Reembolso de partida",
                                                    REGISTRATION_BONUS: "B\xf4nus de Cadastro",
                                                    USERNAME_CHANGE: "Altera\xe7\xe3o de Username"
                                                }[l = e.type] || l
                                            }), function(e) {
                                                if (!e) return null;
                                                let t = {
                                                    PENDING: {
                                                        label: "Pendente",
                                                        className: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                                                    },
                                                    PROCESSING: {
                                                        label: "Processando",
                                                        className: "bg-blue-500/20 text-blue-400 border-blue-500/30"
                                                    },
                                                    COMPLETED: {
                                                        label: "Conclu\xeddo",
                                                        className: "bg-green-500/20 text-green-400 border-green-500/30"
                                                    },
                                                    FAILED: {
                                                        label: "Falhou",
                                                        className: "bg-red-500/20 text-red-400 border-red-500/30"
                                                    },
                                                    CANCELLED: {
                                                        label: "Cancelado",
                                                        className: "bg-gray-500/20 text-gray-400 border-gray-500/30"
                                                    }
                                                }[e];
                                                return t ? (0, a.jsx)("span", {
                                                    className: "px-2 py-0.5 rounded text-xs border ".concat(t.className),
                                                    children: t.label
                                                }) : null
                                            }(e.status)]
                                        }), (0, a.jsx)("p", {
                                            className: "text-white/40 text-xs",
                                            children: new Date(e.createdAt).toLocaleDateString("pt-BR", {
                                                day: "2-digit",
                                                month: "2-digit",
                                                year: "2-digit",
                                                hour: "2-digit",
                                                minute: "2-digit"
                                            })
                                        }), void 0 !== e.fee && e.fee > 0 && (0, a.jsxs)("p", {
                                            className: "text-white/40 text-xs mt-0.5",
                                            children: ["Taxa: R$ ", Number(e.fee).toFixed(2), " | L\xedquido: R$ ", Number(e.netAmount).toFixed(2)]
                                        })]
                                    })]
                                }), (0, a.jsxs)("p", {
                                    className: "font-bold text-lg ".concat((r = e.type, Z.includes(r) ? "text-green-400" : "WITHDRAWAL" === r ? "text-orange-400" : "text-red-400")),
                                    children: [n ? "+" : "-", "R$ ", Math.abs(Number(e.amount)).toFixed(2)]
                                })]
                            }, e.id)
                        })
                    })
                }),
                A = (0, l.memo)(function(e) {
                    let {
                        transactions: t
                    } = e, {
                        totalDeposits: s,
                        totalWithdrawals: r,
                        totalWinnings: n
                    } = (0, l.useMemo)(() => ({
                        totalDeposits: t.filter(e => "DEPOSIT" === e.type && "COMPLETED" === e.status).reduce((e, t) => e + Math.abs(Number(t.amount)), 0),
                        totalWithdrawals: t.filter(e => "WITHDRAWAL" === e.type && "COMPLETED" === e.status).reduce((e, t) => e + Math.abs(Number(t.amount)), 0),
                        totalWinnings: t.filter(e => "BET_WON" === e.type).reduce((e, t) => e + Math.abs(Number(t.amount)), 0)
                    }), [t]);
                    return (0, a.jsxs)("div", {
                        className: "card",
                        children: [(0, a.jsxs)("div", {
                            className: "flex items-center gap-3 mb-4",
                            children: [(0, a.jsx)("div", {
                                className: "w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center",
                                children: (0, a.jsx)(I.Z, {
                                    size: 20,
                                    className: "text-blue-400"
                                })
                            }), (0, a.jsx)("h2", {
                                className: "font-display text-lg font-bold",
                                children: "Resumo"
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "space-y-3",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center justify-between py-2 border-b border-white/5",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, a.jsx)(E, {
                                        size: 16,
                                        className: "text-green-400"
                                    }), (0, a.jsx)("span", {
                                        className: "text-white/60 text-sm",
                                        children: "Total Depositado"
                                    })]
                                }), (0, a.jsxs)("span", {
                                    className: "font-semibold text-green-400",
                                    children: ["R$ ", s.toFixed(2)]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center justify-between py-2 border-b border-white/5",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, a.jsx)(S.Z, {
                                        size: 16,
                                        className: "text-orange-400"
                                    }), (0, a.jsx)("span", {
                                        className: "text-white/60 text-sm",
                                        children: "Total Sacado"
                                    })]
                                }), (0, a.jsxs)("span", {
                                    className: "font-semibold text-orange-400",
                                    children: ["R$ ", r.toFixed(2)]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center justify-between py-2",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, a.jsx)(I.Z, {
                                        size: 16,
                                        className: "text-pool-gold"
                                    }), (0, a.jsx)("span", {
                                        className: "text-white/60 text-sm",
                                        children: "Total em Pr\xeamios"
                                    })]
                                }), (0, a.jsxs)("span", {
                                    className: "font-semibold text-pool-gold",
                                    children: ["R$ ", n.toFixed(2)]
                                })]
                            })]
                        })]
                    })
                });

            function R() {
                let e = (0, r.useRouter)(),
                    {
                        user: t,
                        isAuthenticated: s,
                        isLoading: j,
                        checkAuth: f,
                        updateBalance: N
                    } = (0, n.tN)(),
                    [E, I] = (0, l.useState)([]),
                    [S, T] = (0, l.useState)(!0),
                    [z, Z] = (0, l.useState)(null),
                    [R, F] = (0, l.useState)(100),
                    [$, P] = (0, l.useState)(""),
                    [M, L] = (0, l.useState)(!1),
                    [O, _] = (0, l.useState)(""),
                    [W, H] = (0, l.useState)(""),
                    [B, V] = (0, l.useState)(!1),
                    [q, U] = (0, l.useState)(null),
                    [G, X] = (0, l.useState)(!1),
                    [Q, J] = (0, l.useState)(!1),
                    [Y, K] = (0, l.useState)(null);
                (0, l.useEffect)(() => {
                    f()
                }, [f]), (0, l.useEffect)(() => {
                    j || s || e.push("/login")
                }, [j, s, e]), (0, l.useEffect)(() => {
                    s && ee()
                }, [s]), (0, l.useEffect)(() => () => {
                    Y && clearInterval(Y)
                }, [Y]);
                let ee = async () => {
                        let e = await i.h.getTransactions();
                        e.data && I(e.data.transactions.filter(e => !["AFFILIATE_COMMISSION", "CPA_BONUS", "AFFILIATE_WITHDRAWAL", "BET_LOST"].includes(e.type))), T(!1)
                    },
                    et = (0, l.useCallback)(e => {
                        let s = setInterval(async () => {
                            let a = await i.h.getTransactionStatus(e);
                            if (a.data && a.data.isCompleted) {
                                X(!0), (0, k.iy)({
                                    transactionId: a.data.transactionId,
                                    amount: a.data.amount,
                                    userId: null == t ? void 0 : t.id
                                });
                                let e = await i.h.getBalance();
                                e.data && N(e.data.balance), clearInterval(s), K(null), await ee()
                            }
                        }, 3e3);
                        K(s), setTimeout(() => {
                            clearInterval(s), K(null)
                        }, 9e5)
                    }, [N, null == t ? void 0 : t.id]),
                    es = (0, l.useCallback)(() => {
                        Y && (clearInterval(Y), K(null))
                    }, [Y]),
                    ea = e => {
                        let t = e.replace(/\D/g, "");
                        if (11 !== t.length || /^(\d)\1{10}$/.test(t)) return !1;
                        let s = 0;
                        for (let e = 0; e < 9; e++) s += parseInt(t.charAt(e)) * (10 - e);
                        let a = 11 - s % 11;
                        if (a >= 10 && (a = 0), a !== parseInt(t.charAt(9))) return !1;
                        s = 0;
                        for (let e = 0; e < 10; e++) s += parseInt(t.charAt(e)) * (11 - e);
                        return (a = 11 - s % 11) >= 10 && (a = 0), a === parseInt(t.charAt(10))
                    },
                    el = e => {
                        let t = e.replace(/\D/g, "");
                        return t.length <= 11 ? t.replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d{1,2})$/, "$1-$2") : e
                    },
                    er = async () => {
                        if (!t) return;
                        if (L(!0), H(""), R < 25) {
                            H("Valor m\xednimo de dep\xf3sito \xe9 R$ 25,00"), L(!1);
                            return
                        }
                        if (R > 1e4) {
                            H("Valor m\xe1ximo de dep\xf3sito \xe9 R$ 10.000,00"), L(!1);
                            return
                        }
                        if ($ && !ea($)) {
                            H("CPF inv\xe1lido"), L(!1);
                            return
                        }
                        let e = await i.h.deposit(R, $ || void 0);
                        if (e.error) {
                            H(e.error), L(!1);
                            return
                        }
                        e.data && ((0, k.FA)({
                            transactionId: e.data.transactionId,
                            amount: e.data.amount,
                            userId: t.id
                        }), X(!1), U({
                            pixCode: e.data.pixCode,
                            pixQrCode: e.data.pixQrCode,
                            amount: e.data.amount,
                            transactionId: e.data.transactionId
                        }), V(!0), Z(null), et(e.data.transactionId)), L(!1)
                    },
                    en = async () => {
                        if (!t) return;
                        if (R < 10) {
                            H("Valor m\xednimo de saque \xe9 R$ 10,00");
                            return
                        }
                        if (R > t.balance) {
                            H("Saldo insuficiente");
                            return
                        }
                        L(!0), H("");
                        let e = await i.h.withdraw(R);
                        if (e.error) {
                            H(e.error), L(!1);
                            return
                        }
                        e.data && ((0, k.w7)({
                            transactionId: e.data.transactionId,
                            amount: e.data.amount,
                            netAmount: e.data.netAmount,
                            fee: e.data.fee,
                            userId: t.id
                        }), N(t.balance - e.data.amount), _("Saque de R$ ".concat(e.data.amount.toFixed(2), " solicitado! ") + "Voc\xea receber\xe1 R$ ".concat(e.data.netAmount.toFixed(2), " (taxa: R$ ").concat(e.data.fee.toFixed(2), ")")), ee(), Z(null)), L(!1)
                    };
                return j || !t ? (0, a.jsx)("div", {
                    className: "min-h-screen flex items-center justify-center",
                    children: (0, a.jsx)(d.Z, {
                        size: 40,
                        className: "animate-spin text-pool-gold"
                    })
                }) : (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(y.Z, {}), (0, a.jsxs)("main", {
                        className: "min-h-screen p-4 md:p-8 max-w-7xl mx-auto",
                        children: [(0, a.jsxs)("div", {
                            className: "mb-8",
                            children: [(0, a.jsx)("h1", {
                                className: "font-display text-3xl font-bold",
                                children: "Carteira"
                            }), (0, a.jsx)("p", {
                                className: "text-white/60 mt-1",
                                children: "Gerencie seu saldo, dep\xf3sitos e saques"
                            })]
                        }), O && (0, a.jsxs)("div", {
                            className: "bg-green-500/20 border border-green-500/30 rounded-xl p-4 mb-6 flex items-center justify-between",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, a.jsx)("div", {
                                    className: "w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center",
                                    children: (0, a.jsx)(c.Z, {
                                        size: 18,
                                        className: "text-green-400"
                                    })
                                }), (0, a.jsx)("p", {
                                    className: "text-green-300 text-sm",
                                    children: O
                                })]
                            }), (0, a.jsx)("button", {
                                onClick: () => _(""),
                                className: "text-green-300 hover:text-green-200",
                                children: (0, a.jsx)(o.Z, {
                                    size: 18
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
                            children: [(0, a.jsxs)("div", {
                                className: "lg:col-span-1 space-y-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "card",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 mb-6",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-12 h-12 rounded-xl bg-gradient-to-br from-pool-gold/30 to-pool-gold/10 flex items-center justify-center",
                                            children: (0, a.jsx)(x.Z, {
                                                size: 24,
                                                className: "text-pool-gold"
                                            })
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("p", {
                                                className: "text-white/60 text-sm",
                                                children: "Saldo Dispon\xedvel"
                                            }), (0, a.jsxs)("p", {
                                                className: "font-display text-3xl font-bold text-pool-gold",
                                                children: ["R$ ", Number(t.balance).toFixed(2)]
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "grid grid-cols-2 gap-3",
                                        children: [(0, a.jsxs)("button", {
                                            onClick: () => {
                                                Z("deposit"), F(25), H(""), P("")
                                            },
                                            className: "btn-primary flex items-center justify-center gap-2 py-3",
                                            children: [(0, a.jsx)(m.Z, {
                                                size: 20
                                            }), "Depositar"]
                                        }), (0, a.jsxs)("button", {
                                            onClick: () => {
                                                if (!(null == t ? void 0 : t.phone)) {
                                                    J(!0);
                                                    return
                                                }
                                                Z("withdraw"), F(50), H("")
                                            },
                                            className: "btn-secondary flex items-center justify-center gap-2 py-3",
                                            children: [(0, a.jsx)(h.Z, {
                                                size: 20
                                            }), "Sacar"]
                                        })]
                                    })]
                                }), (0, a.jsx)(A, {
                                    transactions: E
                                })]
                            }), (0, a.jsx)("div", {
                                className: "lg:col-span-2",
                                children: (0, a.jsxs)("div", {
                                    className: "card",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center justify-between mb-6",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-3",
                                            children: [(0, a.jsx)("div", {
                                                className: "w-10 h-10 rounded-lg bg-pool-gold/20 flex items-center justify-center",
                                                children: (0, a.jsx)(u.Z, {
                                                    size: 20,
                                                    className: "text-pool-gold"
                                                })
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsx)("h2", {
                                                    className: "font-display text-lg font-bold",
                                                    children: "Hist\xf3rico de Transa\xe7\xf5es"
                                                }), (0, a.jsx)("p", {
                                                    className: "text-white/60 text-sm",
                                                    children: "Todas as movimenta\xe7\xf5es da sua conta"
                                                })]
                                            })]
                                        }), E.length > 0 && (0, a.jsxs)("span", {
                                            className: "text-xs text-white/40 bg-white/5 px-2 py-1 rounded",
                                            children: [E.length, " registro(s)"]
                                        })]
                                    }), (0, a.jsx)(D, {
                                        transactions: E,
                                        isLoading: S
                                    })]
                                })
                            })]
                        }), z && (0, a.jsx)("div", {
                            className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50",
                            children: (0, a.jsxs)("div", {
                                className: "card w-full max-w-lg max-h-[90vh] overflow-y-auto",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center justify-between mb-6",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-12 h-12 rounded-xl flex items-center justify-center ".concat("deposit" === z ? "bg-green-500/20" : "bg-orange-500/20"),
                                            children: "deposit" === z ? (0, a.jsx)(m.Z, {
                                                size: 24,
                                                className: "text-green-400"
                                            }) : (0, a.jsx)(h.Z, {
                                                size: 24,
                                                className: "text-orange-400"
                                            })
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("h2", {
                                                className: "font-display text-xl font-bold",
                                                children: "deposit" === z ? "Depositar" : "Sacar"
                                            }), (0, a.jsx)("p", {
                                                className: "text-white/60 text-sm",
                                                children: "deposit" === z ? "Via PIX instant\xe2neo" : "Transfer\xeancia via PIX"
                                            })]
                                        })]
                                    }), (0, a.jsx)("button", {
                                        onClick: () => Z(null),
                                        className: "w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors",
                                        children: (0, a.jsx)(o.Z, {
                                            size: 20
                                        })
                                    })]
                                }), W && (0, a.jsxs)("div", {
                                    className: "bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-4 flex items-start gap-2",
                                    children: [(0, a.jsx)(p.Z, {
                                        size: 18,
                                        className: "text-red-400 flex-shrink-0 mt-0.5"
                                    }), (0, a.jsx)("p", {
                                        className: "text-red-300 text-sm",
                                        children: W
                                    })]
                                }), "deposit" === z && (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)("div", {
                                        className: "bg-green-500/10 border border-green-500/20 rounded-xl p-4 mb-6",
                                        children: (0, a.jsxs)("div", {
                                            className: "flex items-start gap-3",
                                            children: [(0, a.jsx)(b.Z, {
                                                size: 20,
                                                className: "text-green-400 flex-shrink-0 mt-0.5"
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsx)("p", {
                                                    className: "text-green-300 font-medium text-sm",
                                                    children: "Pagamento Instant\xe2neo"
                                                }), (0, a.jsx)("p", {
                                                    className: "text-green-300/70 text-xs mt-1",
                                                    children: "Seu saldo ser\xe1 creditado automaticamente ap\xf3s a confirma\xe7\xe3o do PIX."
                                                }), (0, a.jsx)("p", {
                                                    className: "text-green-300/50 text-xs mt-1",
                                                    children: "Dep\xf3sito m\xednimo: R$ 25,00"
                                                })]
                                            })]
                                        })
                                    }), t.cpf ? (0, a.jsxs)("div", {
                                        className: "mb-4 bg-pool-dark/50 border border-white/10 rounded-lg p-3 flex items-center gap-3",
                                        children: [(0, a.jsx)(c.Z, {
                                            size: 18,
                                            className: "text-green-400"
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("p", {
                                                className: "text-white/60 text-xs",
                                                children: "CPF cadastrado"
                                            }), (0, a.jsx)("p", {
                                                className: "text-white font-mono text-sm",
                                                children: t.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
                                            })]
                                        })]
                                    }) : (0, a.jsxs)("div", {
                                        className: "mb-4",
                                        children: [(0, a.jsxs)("label", {
                                            className: "block text-sm font-medium text-white/80 mb-2",
                                            children: ["CPF ", (0, a.jsx)("span", {
                                                className: "text-red-400 text-xs",
                                                children: "(obrigat\xf3rio no primeiro dep\xf3sito)"
                                            })]
                                        }), (0, a.jsx)("input", {
                                            type: "text",
                                            value: $,
                                            onChange: e => P(el(e.target.value)),
                                            placeholder: "000.000.000-00",
                                            className: "input-field",
                                            maxLength: 14,
                                            required: !0
                                        })]
                                    })]
                                }), "withdraw" === z && (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)("div", {
                                        className: "bg-orange-500/10 border border-orange-500/20 rounded-xl p-4 mb-6",
                                        children: (0, a.jsxs)("div", {
                                            className: "flex items-start gap-3",
                                            children: [(0, a.jsx)(g.Z, {
                                                size: 20,
                                                className: "text-orange-400 flex-shrink-0 mt-0.5"
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsx)("p", {
                                                    className: "text-orange-300 font-medium text-sm",
                                                    children: "Informa\xe7\xf5es do Saque"
                                                }), (0, a.jsxs)("ul", {
                                                    className: "text-orange-300/70 text-xs mt-2 space-y-1",
                                                    children: [(0, a.jsx)("li", {
                                                        children: "Valor m\xednimo: R$ 10,00"
                                                    }), (0, a.jsx)("li", {
                                                        children: "Taxa: R$ 2,00 + 3% do valor"
                                                    }), (0, a.jsx)("li", {
                                                        children: "Necess\xe1rio ter jogado 3+ partidas"
                                                    }), (0, a.jsx)("li", {
                                                        children: "Processamento em at\xe9 30 minutos"
                                                    })]
                                                })]
                                            })]
                                        })
                                    }), t.cpf && (0, a.jsxs)("div", {
                                        className: "mb-4 bg-pool-dark/50 border border-white/10 rounded-lg p-3",
                                        children: [(0, a.jsx)("p", {
                                            className: "text-white/60 text-xs mb-1",
                                            children: "Chave PIX para recebimento"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-white font-mono text-sm",
                                            children: ["CPF: ", t.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "mb-4 bg-pool-gold/10 border border-pool-gold/20 rounded-lg p-3 flex items-center justify-between",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-white/60 text-sm",
                                            children: "Saldo dispon\xedvel"
                                        }), (0, a.jsxs)("span", {
                                            className: "text-pool-gold font-bold",
                                            children: ["R$ ", Number(t.balance).toFixed(2)]
                                        })]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "mb-4",
                                    children: [(0, a.jsx)("label", {
                                        className: "block text-sm font-medium text-white/80 mb-2",
                                        children: "Valor (R$)"
                                    }), (0, a.jsx)("input", {
                                        type: "number",
                                        value: R,
                                        onChange: e => F(Number(e.target.value)),
                                        className: "input-field text-xl font-bold text-center",
                                        min: "deposit" === z ? 25 : 10,
                                        max: "deposit" === z ? 1e4 : t.balance
                                    }), (0, a.jsx)("div", {
                                        className: "grid grid-cols-4 gap-2 mt-3",
                                        children: ("deposit" === z ? [25, 50, 100, 200] : [50, 100, 200, 300]).map(e => (0, a.jsxs)("button", {
                                            onClick: () => F(e),
                                            disabled: "withdraw" === z && e > t.balance,
                                            className: "py-2.5 rounded-lg text-sm font-medium transition-all ".concat(R === e ? "bg-pool-gold text-pool-dark" : "bg-pool-dark/50 text-white/60 hover:text-white hover:bg-pool-dark/70 disabled:opacity-30 disabled:cursor-not-allowed"),
                                            children: ["R$ ", e]
                                        }, e))
                                    })]
                                }), "withdraw" === z && R >= 10 && (0, a.jsxs)("div", {
                                    className: "mb-6 bg-pool-dark/50 rounded-xl p-4 border border-white/10",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex justify-between text-sm mb-2",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-white/60",
                                            children: "Valor solicitado"
                                        }), (0, a.jsxs)("span", {
                                            className: "text-white",
                                            children: ["R$ ", R.toFixed(2)]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex justify-between text-sm mb-2",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-white/60",
                                            children: "Taxa (R$ 2,00 + 3%)"
                                        }), (0, a.jsxs)("span", {
                                            className: "text-red-400",
                                            children: ["- R$ ", (2 + .03 * R).toFixed(2)]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex justify-between text-base font-bold pt-3 border-t border-white/10",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-pool-gold",
                                            children: "Voc\xea receber\xe1"
                                        }), (0, a.jsxs)("span", {
                                            className: "text-pool-gold",
                                            children: ["R$ ", Math.max(0, R - 2 - .03 * R).toFixed(2)]
                                        })]
                                    })]
                                }), "deposit" === z && R >= 25 && (0, a.jsx)("div", {
                                    className: "mb-6 bg-pool-dark/50 rounded-xl p-4 border border-white/10",
                                    children: (0, a.jsxs)("div", {
                                        className: "flex justify-between text-base font-bold",
                                        children: [(0, a.jsx)("span", {
                                            className: "text-white/60",
                                            children: "Voc\xea receber\xe1"
                                        }), (0, a.jsxs)("span", {
                                            className: "text-green-400",
                                            children: ["R$ ", R.toFixed(2)]
                                        })]
                                    })
                                }), (0, a.jsxs)("div", {
                                    className: "flex gap-3",
                                    children: [(0, a.jsx)("button", {
                                        onClick: () => Z(null),
                                        className: "btn-secondary flex-1",
                                        children: "Cancelar"
                                    }), (0, a.jsx)("button", {
                                        onClick: "deposit" === z ? er : en,
                                        disabled: M || R < ("deposit" === z ? 25 : 10) || "withdraw" === z && R > t.balance,
                                        className: "flex-1 flex items-center justify-center gap-2 font-semibold py-3 px-4 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed ".concat("deposit" === z ? "bg-green-500 hover:bg-green-600 text-white" : "bg-orange-500 hover:bg-orange-600 text-white"),
                                        children: M ? (0, a.jsx)(d.Z, {
                                            size: 20,
                                            className: "animate-spin"
                                        }) : (0, a.jsxs)(a.Fragment, {
                                            children: ["deposit" === z ? (0, a.jsx)(m.Z, {
                                                size: 20
                                            }) : (0, a.jsx)(h.Z, {
                                                size: 20
                                            }), "Confirmar"]
                                        })
                                    })]
                                })]
                            })
                        })]
                    }), q && (0, a.jsx)(v, {
                        isOpen: B,
                        onClose: () => {
                            V(!1), U(null), X(!1), es(), ee()
                        },
                        pixCode: q.pixCode,
                        pixQrCode: q.pixQrCode,
                        amount: q.amount,
                        transactionId: q.transactionId,
                        paymentConfirmed: G
                    }), (0, a.jsx)(w.Z, {
                        isOpen: Q,
                        onClose: () => J(!1),
                        onSuccess: () => {
                            J(!1), Z("withdraw"), F(50), H("")
                        }
                    }), (0, a.jsx)(C.Z, {})]
                })
            }
        },
        16112: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return n
                }
            });
            var a = s(3827),
                l = s(8792),
                r = s(20703);

            function n() {
                let e = new Date().getFullYear();
                return (0, a.jsx)("footer", {
                    className: "bg-pool-dark border-t border-white/5 mt-auto",
                    children: (0, a.jsx)("div", {
                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",
                        children: (0, a.jsxs)("div", {
                            className: "flex flex-col md:flex-row items-center justify-between gap-4",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-4",
                                children: [(0, a.jsx)(r.default, {
                                    src: "/logos/logo-white-red.png",
                                    alt: "Tacadinha",
                                    width: 100,
                                    height: 32,
                                    className: "h-6 w-auto opacity-50"
                                }), (0, a.jsx)("span", {
                                    className: "text-white/30 text-sm hidden sm:inline",
                                    children: "|"
                                }), (0, a.jsxs)("p", {
                                    className: "text-white/30 text-sm",
                                    children: ["\xa9 ", e, " Tacadinha"]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-6 text-sm",
                                children: [(0, a.jsx)(l.default, {
                                    href: "/termos",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Termos"
                                }), (0, a.jsx)(l.default, {
                                    href: "/privacidade",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Privacidade"
                                }), (0, a.jsx)(l.default, {
                                    href: "#",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Suporte"
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-3 text-white/30 text-xs",
                                children: [(0, a.jsx)("span", {
                                    children: "+18"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "•"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "Jogue com responsabilidade"
                                })]
                            })]
                        })
                    })
                })
            }
        },
        99744: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return h
                }
            });
            var a = s(3827),
                l = s(64090),
                r = s(85904),
                n = s(52235),
                i = s(98998),
                d = s(18994),
                c = s(80037),
                o = s(10826),
                x = s(6739),
                m = s(13176);

            function h(e) {
                let {
                    isOpen: t,
                    onClose: s,
                    onSuccess: h
                } = e, {
                    updatePhone: u
                } = (0, x.tN)(), [p, b] = (0, l.useState)(""), [g, j] = (0, l.useState)(!1), [f, N] = (0, l.useState)(""), v = e => 11 === e.replace(/\D/g, "").length, w = async e => {
                    if (e.preventDefault(), N(""), !v(p)) {
                        N("Telefone deve ter 11 d\xedgitos (DDD + n\xfamero)");
                        return
                    }
                    j(!0);
                    let t = await o.h.updateProfile({
                        phone: p
                    });
                    if (t.error) {
                        N(t.error), j(!1);
                        return
                    }
                    u(p), j(!1), h()
                };
                return t ? (0, a.jsx)("div", {
                    className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50",
                    children: (0, a.jsxs)("div", {
                        className: "card w-full max-w-md",
                        children: [(0, a.jsxs)("div", {
                            className: "flex items-center justify-between mb-6",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, a.jsx)("div", {
                                    className: "w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center",
                                    children: (0, a.jsx)(r.Z, {
                                        size: 24,
                                        className: "text-blue-400"
                                    })
                                }), (0, a.jsxs)("div", {
                                    children: [(0, a.jsx)("h2", {
                                        className: "font-display text-xl font-bold",
                                        children: "Adicionar Telefone"
                                    }), (0, a.jsx)("p", {
                                        className: "text-white/60 text-sm",
                                        children: "Necess\xe1rio para solicitar saque"
                                    })]
                                })]
                            }), (0, a.jsx)("button", {
                                onClick: s,
                                className: "w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors",
                                children: (0, a.jsx)(n.Z, {
                                    size: 20
                                })
                            })]
                        }), (0, a.jsx)("div", {
                            className: "bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 mb-6",
                            children: (0, a.jsxs)("div", {
                                className: "flex items-start gap-3",
                                children: [(0, a.jsx)(r.Z, {
                                    size: 20,
                                    className: "text-blue-400 flex-shrink-0 mt-0.5"
                                }), (0, a.jsxs)("div", {
                                    children: [(0, a.jsx)("p", {
                                        className: "text-blue-300 font-medium text-sm",
                                        children: "Por que precisamos do seu telefone?"
                                    }), (0, a.jsx)("p", {
                                        className: "text-blue-300/70 text-xs mt-1",
                                        children: "O n\xfamero de telefone \xe9 necess\xe1rio para validar sua identidade e processar saques com seguran\xe7a."
                                    })]
                                })]
                            })
                        }), f && (0, a.jsxs)("div", {
                            className: "bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-4 flex items-start gap-2",
                            children: [(0, a.jsx)(i.Z, {
                                size: 18,
                                className: "text-red-400 flex-shrink-0 mt-0.5"
                            }), (0, a.jsx)("p", {
                                className: "text-red-300 text-sm",
                                children: f
                            })]
                        }), (0, a.jsxs)("form", {
                            onSubmit: w,
                            children: [(0, a.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, a.jsx)("label", {
                                    htmlFor: "phone",
                                    className: "block text-sm font-medium text-white/80 mb-2",
                                    children: "N\xfamero de Telefone"
                                }), (0, a.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, a.jsx)("div", {
                                        className: "absolute left-4 top-1/2 -translate-y-1/2 text-white/30",
                                        children: (0, a.jsx)(r.Z, {
                                            size: 20
                                        })
                                    }), (0, a.jsx)("input", {
                                        id: "phone",
                                        type: "tel",
                                        value: p,
                                        onChange: e => b((0, m.CN)(e.target.value)),
                                        className: "w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-white/30 focus:outline-none focus:border-pool-gold/50 focus:bg-white/[0.07] transition-all text-lg",
                                        placeholder: "(99) 99999-9999",
                                        maxLength: 15,
                                        disabled: g,
                                        autoFocus: !0
                                    })]
                                }), (0, a.jsx)("p", {
                                    className: "text-white/40 text-xs mt-2",
                                    children: "Digite seu n\xfamero com DDD (exemplo: 11 99999-9999)"
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex gap-3",
                                children: [(0, a.jsx)("button", {
                                    type: "button",
                                    onClick: s,
                                    className: "btn-secondary flex-1",
                                    disabled: g,
                                    children: "Cancelar"
                                }), (0, a.jsx)("button", {
                                    type: "submit",
                                    disabled: g || !p,
                                    className: "flex-1 flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
                                    children: g ? (0, a.jsx)(d.Z, {
                                        size: 20,
                                        className: "animate-spin"
                                    }) : (0, a.jsxs)(a.Fragment, {
                                        children: [(0, a.jsx)(c.Z, {
                                            size: 20
                                        }), "Salvar"]
                                    })
                                })]
                            })]
                        })]
                    })
                }) : null
            }
        },
        13176: function(e, t, s) {
            "use strict";

            function a(e) {
                let t = e.replace(/\D/g, "");
                return 0 === t.length ? "" : t.length <= 2 ? "(".concat(t) : t.length <= 7 ? "(".concat(t.slice(0, 2), ") ").concat(t.slice(2)) : t.length <= 11 ? "(".concat(t.slice(0, 2), ") ").concat(t.slice(2, 7), "-").concat(t.slice(7)) : "(".concat(t.slice(0, 2), ") ").concat(t.slice(2, 7), "-").concat(t.slice(7, 11))
            }

            function l(e) {
                return /^\(\d{2}\) \d{4,5}-\d{4}$/.test(e)
            }

            function r(e) {
                return e.replace(/\D/g, "")
            }

            function n(e) {
                let t = e.replace(/\D/g, "");
                return 0 === t.length ? "" : t.length <= 3 ? t : t.length <= 6 ? "".concat(t.slice(0, 3), ".").concat(t.slice(3)) : t.length <= 9 ? "".concat(t.slice(0, 3), ".").concat(t.slice(3, 6), ".").concat(t.slice(6)) : "".concat(t.slice(0, 3), ".").concat(t.slice(3, 6), ".").concat(t.slice(6, 9), "-").concat(t.slice(9, 11))
            }

            function i(e) {
                return /^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(e)
            }

            function d(e) {
                return e.replace(/\D/g, "")
            }

            function c(e) {
                if (!e) return "";
                let t = e.replace(/\D/g, "");
                return 11 !== t.length ? e : n(t)
            }

            function o(e) {
                if (!e) return "";
                if (/^\(\d{2}\) \d{4,5}-\d{4}$/.test(e)) return e;
                let t = e.replace(/\D/g, "");
                return t.length < 10 || t.length > 11 ? e : a(t)
            }
            s.d(t, {
                CN: function() {
                    return a
                },
                Gt: function() {
                    return i
                },
                V$: function() {
                    return o
                },
                WF: function() {
                    return c
                },
                kj: function() {
                    return l
                },
                r: function() {
                    return d
                },
                w3: function() {
                    return n
                },
                wy: function() {
                    return r
                }
            })
        },
        8967: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("ArrowUpRight", [
                ["path", {
                    d: "M7 7h10v10",
                    key: "1tivn9"
                }],
                ["path", {
                    d: "M7 17 17 7",
                    key: "1vkiza"
                }]
            ])
        },
        10527: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("CreditCard", [
                ["rect", {
                    width: "20",
                    height: "14",
                    x: "2",
                    y: "5",
                    rx: "2",
                    key: "ynyp8z"
                }],
                ["line", {
                    x1: "2",
                    x2: "22",
                    y1: "10",
                    y2: "10",
                    key: "1b3vmo"
                }]
            ])
        },
        70094: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Plus", [
                ["path", {
                    d: "M5 12h14",
                    key: "1ays0h"
                }],
                ["path", {
                    d: "M12 5v14",
                    key: "s699le"
                }]
            ])
        }
    },
    function(e) {
        e.O(0, [2807, 703, 9620, 826, 4002, 2971, 8069, 1744], function() {
            return e(e.s = 18668)
        }), _N_E = e.O()
    }
]);