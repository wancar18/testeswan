(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9901], {
        54945: function(e, s, t) {
            Promise.resolve().then(t.bind(t, 77508))
        },
        77508: function(e, s, t) {
            "use strict";
            t.r(s), t.d(s, {
                default: function() {
                    return M
                }
            });
            var a = t(3827),
                l = t(64090),
                i = t(47907),
                r = t(6739),
                n = t(10826),
                d = t(63861),
                c = t(39346),
                x = t(18994),
                o = t(66260),
                m = t(97307),
                h = t(40834),
                p = t(59496),
                g = t(28814),
                j = t(77326),
                b = t(34059),
                N = t(26490),
                u = t(22071),
                f = t(56227),
                w = t(17021),
                v = t(57976),
                y = t(71483),
                k = t(61524),
                z = t(75879),
                P = t(29733),
                Z = t(10775),
                R = t(97404),
                F = t(48219),
                S = t(10822),
                E = t(4002),
                C = t(16112),
                A = t(56022);

            function M() {
                let e = (0, i.useRouter)(),
                    {
                        user: s,
                        isAuthenticated: t,
                        isLoading: M,
                        checkAuth: D
                    } = (0, r.tN)(),
                    [T, G] = (0, l.useState)([]),
                    [I, V] = (0, l.useState)(null),
                    [B, L] = (0, l.useState)(null),
                    [O, J] = (0, l.useState)(0),
                    [W, $] = (0, l.useState)(null),
                    [_, q] = (0, l.useState)(!0),
                    [U, Y] = (0, l.useState)(!1),
                    [H, K] = (0, l.useState)("ranking"),
                    [Q, X] = (0, l.useState)(5),
                    [ee, es] = (0, l.useState)(15),
                    [et, ea] = (0, l.useState)(!0);
                (0, l.useEffect)(() => {
                    D()
                }, [D]), (0, l.useEffect)(() => {
                    M || t || e.push("/login")
                }, [M, t, e]), (0, l.useEffect)(() => {
                    t && el()
                }, [t]);
                let el = async () => {
                        try {
                            let s = await n.h.getPlatformStatus();
                            s.data ? (ea(s.data.rankingEnabled), s.data.rankingEnabled ? ei() : e.push("/lobby")) : ei()
                        } catch (e) {
                            console.error("Error checking ranking status:", e), ei()
                        }
                    },
                    ei = async function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        try {
                            e ? Y(!0) : q(!0);
                            let [s, t] = await Promise.all([n.h.getCurrentRanking(100), n.h.getMyRanking()]);
                            s.data && (G(s.data.rankings), V(s.data.season), J(s.data.totalPlayers), $(s.data.updatedAt), s.data.minGamesForRanking && X(s.data.minGamesForRanking), s.data.minGamesForPrizes && es(s.data.minGamesForPrizes)), t.data && (L(t.data.stats), t.data.minGamesForRanking && X(t.data.minGamesForRanking), t.data.minGamesForPrizes && es(t.data.minGamesForPrizes))
                        } catch (e) {
                            console.error("Error loading ranking:", e)
                        } finally {
                            q(!1), Y(!1)
                        }
                    },
                    er = e => new Date(e).toLocaleDateString("pt-BR", {
                        day: "2-digit",
                        month: "short"
                    }),
                    en = e => new Date(e).toLocaleString("pt-BR", {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit"
                    }),
                    ed = (e, s) => 0 === s ? 0 : Math.round(e / s * 100),
                    ec = e => {
                        switch (e) {
                            case 1:
                                return (0, a.jsx)(d.Z, {
                                    className: "text-yellow-400",
                                    size: 16
                                });
                            case 2:
                                return (0, a.jsx)(c.Z, {
                                    className: "text-gray-300",
                                    size: 16
                                });
                            case 3:
                                return (0, a.jsx)(c.Z, {
                                    className: "text-amber-600",
                                    size: 16
                                });
                            default:
                                return null
                        }
                    },
                    ex = e => {
                        switch (e) {
                            case 1:
                                return "bg-gradient-to-r from-yellow-500/20 via-yellow-400/10 to-transparent";
                            case 2:
                                return "bg-gradient-to-r from-gray-400/15 via-gray-300/5 to-transparent";
                            case 3:
                                return "bg-gradient-to-r from-amber-600/15 via-amber-500/5 to-transparent";
                            default:
                                return ""
                        }
                    };
                return M || !s ? (0, a.jsx)("div", {
                    className: "min-h-screen flex items-center justify-center",
                    children: (0, a.jsx)(x.Z, {
                        size: 40,
                        className: "animate-spin text-pool-gold"
                    })
                }) : (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(E.Z, {}), (0, a.jsxs)("main", {
                        className: "min-h-screen p-4 md:p-8 max-w-5xl mx-auto pb-24",
                        children: [_ && (0, a.jsxs)("div", {
                            className: "flex flex-col items-center justify-center py-20",
                            children: [(0, a.jsx)(x.Z, {
                                size: 40,
                                className: "animate-spin text-pool-gold mb-4"
                            }), (0, a.jsx)("p", {
                                className: "text-white/60",
                                children: "Carregando ranking..."
                            })]
                        }), !_ && !et && (0, a.jsxs)("div", {
                            className: "card text-center py-16",
                            children: [(0, a.jsx)("div", {
                                className: "w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4",
                                children: (0, a.jsx)(o.Z, {
                                    className: "text-white/30",
                                    size: 40
                                })
                            }), (0, a.jsx)("h2", {
                                className: "text-xl font-bold text-white mb-2",
                                children: "Ranking temporariamente indispon\xedvel"
                            }), (0, a.jsx)("p", {
                                className: "text-white/60 max-w-md mx-auto",
                                children: "O ranking est\xe1 sendo atualizado. Por favor, volte mais tarde."
                            })]
                        }), !_ && et && !I && (0, a.jsxs)("div", {
                            className: "card text-center py-16",
                            children: [(0, a.jsx)("div", {
                                className: "w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4",
                                children: (0, a.jsx)(o.Z, {
                                    className: "text-white/30",
                                    size: 40
                                })
                            }), (0, a.jsx)("h2", {
                                className: "text-xl font-bold text-white mb-2",
                                children: "Nenhuma temporada ativa"
                            }), (0, a.jsx)("p", {
                                className: "text-white/60 max-w-md mx-auto",
                                children: "Aguarde o in\xedcio da pr\xf3xima temporada para competir no ranking e ganhar pr\xeamios."
                            })]
                        }), !_ && et && I && (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsxs)("div", {
                                className: "card mb-6 bg-gradient-to-br from-pool-gold/10 via-pool-dark/60 to-pool-dark/60 border-pool-gold/30",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-14 h-14 rounded-xl bg-gradient-to-br from-yellow-500/30 to-amber-600/20 flex items-center justify-center",
                                            children: (0, a.jsx)(o.Z, {
                                                className: "text-yellow-400",
                                                size: 28
                                            })
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("h1", {
                                                className: "font-display text-xl md:text-2xl font-bold text-white",
                                                children: I.name
                                            }), (0, a.jsxs)("p", {
                                                className: "text-white/60 text-sm flex items-center gap-2",
                                                children: [(0, a.jsx)(m.Z, {
                                                    size: 14
                                                }), er(I.startDate), " - ", er(I.endDate)]
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [(0, a.jsxs)("div", {
                                            className: "bg-pool-gold/20 border border-pool-gold/40 rounded-lg px-4 py-2 text-center",
                                            children: [(0, a.jsx)("p", {
                                                className: "text-2xl font-bold text-pool-gold",
                                                children: (() => {
                                                    if (!I) return 0;
                                                    let e = new Date;
                                                    return Math.max(0, Math.ceil((new Date(I.endDate).getTime() - e.getTime()) / 864e5))
                                                })()
                                            }), (0, a.jsx)("p", {
                                                className: "text-[10px] text-white/50 uppercase tracking-wide",
                                                children: "dias restantes"
                                            })]
                                        }), (0, a.jsx)("button", {
                                            onClick: () => ei(!0),
                                            disabled: U,
                                            className: "btn-secondary p-3",
                                            title: "Atualizar",
                                            children: (0, a.jsx)(h.Z, {
                                                size: 18,
                                                className: U ? "animate-spin" : ""
                                            })
                                        })]
                                    })]
                                }), I.prizeConfig && (I.prizeConfig.first || I.prizeConfig.second || I.prizeConfig.third) && (0, a.jsxs)("div", {
                                    className: "border-t border-white/10 pt-4",
                                    children: [(0, a.jsxs)("p", {
                                        className: "text-xs text-white/50 uppercase tracking-wide mb-3 flex items-center gap-2",
                                        children: [(0, a.jsx)(p.Z, {
                                            size: 14,
                                            className: "text-pool-gold"
                                        }), "Premia\xe7\xe3o"]
                                    }), (0, a.jsxs)("div", {
                                        className: "grid grid-cols-3 gap-3",
                                        children: [I.prizeConfig.first > 0 && (0, a.jsxs)("div", {
                                            className: "text-center p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30",
                                            children: [(0, a.jsx)(d.Z, {
                                                className: "text-yellow-400 mx-auto mb-1",
                                                size: 20
                                            }), (0, a.jsxs)("p", {
                                                className: "text-lg font-bold text-yellow-400",
                                                children: ["R$ ", I.prizeConfig.first]
                                            }), (0, a.jsx)("p", {
                                                className: "text-[10px] text-white/40",
                                                children: "1\xb0 Lugar"
                                            })]
                                        }), I.prizeConfig.second > 0 && (0, a.jsxs)("div", {
                                            className: "text-center p-3 rounded-lg bg-gray-400/10 border border-gray-400/30",
                                            children: [(0, a.jsx)(c.Z, {
                                                className: "text-gray-300 mx-auto mb-1",
                                                size: 18
                                            }), (0, a.jsxs)("p", {
                                                className: "text-lg font-bold text-gray-300",
                                                children: ["R$ ", I.prizeConfig.second]
                                            }), (0, a.jsx)("p", {
                                                className: "text-[10px] text-white/40",
                                                children: "2\xb0 Lugar"
                                            })]
                                        }), I.prizeConfig.third > 0 && (0, a.jsxs)("div", {
                                            className: "text-center p-3 rounded-lg bg-amber-600/10 border border-amber-600/30",
                                            children: [(0, a.jsx)(c.Z, {
                                                className: "text-amber-500 mx-auto mb-1",
                                                size: 18
                                            }), (0, a.jsxs)("p", {
                                                className: "text-lg font-bold text-amber-500",
                                                children: ["R$ ", I.prizeConfig.third]
                                            }), (0, a.jsx)("p", {
                                                className: "text-[10px] text-white/40",
                                                children: "3\xb0 Lugar"
                                            })]
                                        })]
                                    })]
                                })]
                            }), (0, a.jsx)("div", {
                                className: "card mb-6 bg-gradient-to-r from-blue-500/5 to-transparent border-blue-500/20",
                                children: (0, a.jsxs)("div", {
                                    className: "flex items-start gap-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0",
                                        children: (0, a.jsx)(g.Z, {
                                            className: "text-blue-400",
                                            size: 18
                                        })
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("h3", {
                                            className: "font-semibold text-white mb-2",
                                            children: "Como funciona o sistema de pontos?"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-sm text-white/60 leading-relaxed mb-3",
                                            children: ["Utilizamos o sistema ", (0, a.jsx)("span", {
                                                className: "text-blue-400 font-medium",
                                                children: "ELO"
                                            }), ", similar ao usado no xadrez. Todos come\xe7am com ", (0, a.jsx)("span", {
                                                className: "text-white font-medium",
                                                children: "1000 pontos"
                                            }), ". Ao vencer um jogador mais forte, voc\xea ganha mais pontos. Ao perder para algu\xe9m mais fraco, perde mais pontos. Os rankings s\xe3o atualizados a cada 5 minutos."]
                                        }), (0, a.jsxs)("div", {
                                            className: "flex flex-wrap gap-3 text-xs",
                                            children: [(0, a.jsxs)("div", {
                                                className: "bg-yellow-500/10 border border-yellow-500/30 rounded-full px-3 py-1 flex items-center gap-1",
                                                children: [(0, a.jsx)(j.Z, {
                                                    size: 12,
                                                    className: "text-yellow-400"
                                                }), (0, a.jsxs)("span", {
                                                    className: "text-yellow-400/90",
                                                    children: ["M\xedn. ", Q, " partidas para aparecer no ranking"]
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "bg-green-500/10 border border-green-500/30 rounded-full px-3 py-1 flex items-center gap-1",
                                                children: [(0, a.jsx)(p.Z, {
                                                    size: 12,
                                                    className: "text-green-400"
                                                }), (0, a.jsxs)("span", {
                                                    className: "text-green-400/90",
                                                    children: ["M\xedn. ", ee, " partidas para premia\xe7\xe3o"]
                                                })]
                                            })]
                                        })]
                                    })]
                                })
                            }), (0, a.jsx)("div", {
                                className: "flex items-center justify-between mb-4",
                                children: (0, a.jsxs)("div", {
                                    className: "flex items-center gap-4 text-sm text-white/60",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-2",
                                        children: [(0, a.jsx)(b.Z, {
                                            size: 14
                                        }), (0, a.jsxs)("span", {
                                            children: [O, " jogadores"]
                                        })]
                                    }), W && (0, a.jsxs)("div", {
                                        className: "hidden sm:flex items-center gap-2",
                                        children: [(0, a.jsx)(N.Z, {
                                            size: 14
                                        }), (0, a.jsxs)("span", {
                                            children: ["Atualizado: ", en(W)]
                                        })]
                                    })]
                                })
                            }), (0, a.jsxs)("div", {
                                className: "flex gap-2 mb-4",
                                children: [(0, a.jsxs)("button", {
                                    onClick: () => K("ranking"),
                                    className: "flex-1 sm:flex-none px-6 py-3 rounded-lg font-medium text-sm transition-all ".concat("ranking" === H ? "bg-pool-gold text-pool-dark" : "bg-white/5 text-white/70 hover:bg-white/10"),
                                    children: [(0, a.jsx)(o.Z, {
                                        size: 16,
                                        className: "inline mr-2"
                                    }), "Temporada Atual"]
                                }), (0, a.jsxs)("button", {
                                    onClick: () => K("my-stats"),
                                    className: "flex-1 sm:flex-none px-6 py-3 rounded-lg font-medium text-sm transition-all ".concat("my-stats" === H ? "bg-pool-gold text-pool-dark" : "bg-white/5 text-white/70 hover:bg-white/10"),
                                    children: [(0, a.jsx)(u.Z, {
                                        size: 16,
                                        className: "inline mr-2"
                                    }), "Minhas Estat\xedsticas"]
                                })]
                            }), "ranking" === H && (0, a.jsxs)("div", {
                                className: "card p-0 overflow-hidden",
                                children: [(0, a.jsx)("div", {
                                    className: "bg-white/5 px-4 py-3 border-b border-white/10",
                                    children: (0, a.jsxs)("div", {
                                        className: "grid grid-cols-12 gap-2 text-xs text-white/50 uppercase tracking-wide",
                                        children: [(0, a.jsx)("div", {
                                            className: "col-span-1 text-center",
                                            children: "#"
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-4 sm:col-span-3",
                                            children: "Jogador"
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-2 text-center hidden sm:block",
                                            children: "Partidas"
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-2 text-center",
                                            children: "V/D"
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-2 text-center hidden sm:block",
                                            children: "Taxa"
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-3 sm:col-span-2 text-right",
                                            children: "Pontos"
                                        })]
                                    })
                                }), (0, a.jsx)("div", {
                                    className: "divide-y divide-white/5",
                                    children: T.map(e => (0, a.jsxs)("div", {
                                        className: "grid grid-cols-12 gap-2 items-center px-4 py-3 transition-colors ".concat(e.userId === (null == s ? void 0 : s.id) ? "bg-pool-gold/10 border-l-2 border-pool-gold" : ex(e.rank) || "hover:bg-white/5"),
                                        children: [(0, a.jsx)("div", {
                                            className: "col-span-1 text-center",
                                            children: (0, a.jsxs)("div", {
                                                className: "flex items-center justify-center gap-1",
                                                children: [ec(e.rank), (0, a.jsx)("span", {
                                                    className: "font-bold text-sm ".concat(1 === e.rank ? "text-yellow-400" : 2 === e.rank ? "text-gray-300" : 3 === e.rank ? "text-amber-500" : e.rank <= 10 ? "text-pool-gold" : "text-white/60"),
                                                    children: e.rank
                                                })]
                                            })
                                        }), (0, a.jsxs)("div", {
                                            className: "col-span-4 sm:col-span-3 flex items-center gap-2 min-w-0",
                                            children: [(0, a.jsx)(A.Z, {
                                                username: e.username,
                                                size: "sm"
                                            }), (0, a.jsxs)("div", {
                                                className: "min-w-0",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-1",
                                                    children: [(0, a.jsx)("p", {
                                                        className: "font-medium truncate text-sm ".concat(e.userId === (null == s ? void 0 : s.id) ? "text-pool-gold" : e.rank <= 3 ? "text-white" : "text-white/90"),
                                                        children: e.username
                                                    }), e.isProvisional && (0, a.jsx)("span", {
                                                        className: "hidden sm:inline-block text-[8px] px-1.5 py-0.5 bg-yellow-500/20 text-yellow-400/80 rounded-full border border-yellow-500/30",
                                                        title: "Jogador com rating provis\xf3rio (menos de 10 partidas)",
                                                        children: "PROV"
                                                    })]
                                                }), (0, a.jsxs)("div", {
                                                    className: "flex items-center gap-1",
                                                    children: [e.userId === (null == s ? void 0 : s.id) && (0, a.jsx)("p", {
                                                        className: "text-[10px] text-pool-gold/60",
                                                        children: "Voc\xea"
                                                    }), !e.isEligibleForPrizes && e.rank <= 3 && (0, a.jsx)("span", {
                                                        className: "text-[9px] text-orange-400/60",
                                                        title: "Precisa de ".concat(ee, " partidas para premia\xe7\xe3o"),
                                                        children: "(n\xe3o eleg\xedvel)"
                                                    })]
                                                })]
                                            })]
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-2 text-center hidden sm:block",
                                            children: (0, a.jsx)("span", {
                                                className: "text-sm text-white/70",
                                                children: e.gamesPlayed
                                            })
                                        }), (0, a.jsxs)("div", {
                                            className: "col-span-2 text-center",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-green-400 text-sm",
                                                children: e.wins
                                            }), (0, a.jsx)("span", {
                                                className: "text-white/30 mx-1",
                                                children: "/"
                                            }), (0, a.jsx)("span", {
                                                className: "text-red-400 text-sm",
                                                children: e.losses
                                            })]
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-2 text-center hidden sm:block",
                                            children: (0, a.jsxs)("span", {
                                                className: "text-sm font-medium ".concat(ed(e.wins, e.gamesPlayed) >= 60 ? "text-green-400" : ed(e.wins, e.gamesPlayed) >= 40 ? "text-white/70" : "text-red-400"),
                                                children: [ed(e.wins, e.gamesPlayed), "%"]
                                            })
                                        }), (0, a.jsx)("div", {
                                            className: "col-span-3 sm:col-span-2 text-right",
                                            children: (0, a.jsx)("p", {
                                                className: "font-bold ".concat(1 === e.rank ? "text-yellow-400" : 2 === e.rank ? "text-gray-300" : 3 === e.rank ? "text-amber-500" : "text-white"),
                                                children: e.points
                                            })
                                        })]
                                    }, e.userId))
                                }), 0 === T.length && (0, a.jsxs)("div", {
                                    className: "text-center py-16",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4",
                                        children: (0, a.jsx)(f.Z, {
                                            className: "text-white/30",
                                            size: 32
                                        })
                                    }), (0, a.jsx)("p", {
                                        className: "text-white/60",
                                        children: "Nenhum jogador no ranking ainda"
                                    }), (0, a.jsx)("p", {
                                        className: "text-white/40 text-sm mt-1",
                                        children: "Jogue partidas para aparecer no ranking!"
                                    })]
                                })]
                            }), "my-stats" === H && (0, a.jsx)("div", {
                                className: "space-y-4",
                                children: B ? (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsxs)("div", {
                                        className: "card bg-gradient-to-br from-white/5 to-transparent",
                                        children: [(0, a.jsxs)("h3", {
                                            className: "font-semibold text-white mb-4 flex items-center gap-2",
                                            children: [(0, a.jsx)(j.Z, {
                                                className: "text-blue-400",
                                                size: 18
                                            }), "Status de Elegibilidade"]
                                        }), (0, a.jsxs)("div", {
                                            className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
                                            children: [(0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl border ".concat(B.canAppearInRanking ? "bg-green-500/10 border-green-500/30" : "bg-amber-500/10 border-amber-500/30"),
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [B.canAppearInRanking ? (0, a.jsx)(v.Z, {
                                                        className: "text-green-400",
                                                        size: 18
                                                    }) : (0, a.jsx)(y.Z, {
                                                        className: "text-amber-400",
                                                        size: 18
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/70 font-medium",
                                                        children: "Vis\xedvel no Ranking"
                                                    })]
                                                }), B.canAppearInRanking ? (0, a.jsx)("p", {
                                                    className: "text-sm text-green-400 font-medium",
                                                    children: "Sim"
                                                }) : (0, a.jsxs)("p", {
                                                    className: "text-sm text-amber-400",
                                                    children: ["Faltam ", (0, a.jsx)("span", {
                                                        className: "font-bold",
                                                        children: Q - B.gamesPlayed
                                                    }), " partidas"]
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl border ".concat(B.isEligibleForPrizes ? "bg-green-500/10 border-green-500/30" : "bg-amber-500/10 border-amber-500/30"),
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [B.isEligibleForPrizes ? (0, a.jsx)(v.Z, {
                                                        className: "text-green-400",
                                                        size: 18
                                                    }) : (0, a.jsx)(y.Z, {
                                                        className: "text-amber-400",
                                                        size: 18
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/70 font-medium",
                                                        children: "Eleg\xedvel a Pr\xeamios"
                                                    })]
                                                }), B.isEligibleForPrizes ? (0, a.jsx)("p", {
                                                    className: "text-sm text-green-400 font-medium",
                                                    children: "Sim"
                                                }) : (0, a.jsxs)("p", {
                                                    className: "text-sm text-amber-400",
                                                    children: ["Faltam ", (0, a.jsx)("span", {
                                                        className: "font-bold",
                                                        children: ee - B.gamesPlayed
                                                    }), " partidas"]
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl border ".concat(B.isProvisional ? "bg-yellow-500/10 border-yellow-500/30" : "bg-green-500/10 border-green-500/30"),
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [B.isProvisional ? (0, a.jsx)(k.Z, {
                                                        className: "text-yellow-400",
                                                        size: 18
                                                    }) : (0, a.jsx)(v.Z, {
                                                        className: "text-green-400",
                                                        size: 18
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/70 font-medium",
                                                        children: "Rating"
                                                    })]
                                                }), B.isProvisional ? (0, a.jsx)("p", {
                                                    className: "text-sm text-yellow-400 font-medium",
                                                    children: "Provis\xf3rio"
                                                }) : (0, a.jsx)("p", {
                                                    className: "text-sm text-green-400 font-medium",
                                                    children: "Estabelecido"
                                                })]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "mt-4",
                                            children: [(0, a.jsxs)("div", {
                                                className: "flex items-center justify-between text-xs text-white/50 mb-2",
                                                children: [(0, a.jsx)("span", {
                                                    children: "Progresso para elegibilidade completa"
                                                }), (0, a.jsxs)("span", {
                                                    children: [B.gamesPlayed, "/", ee, " partidas"]
                                                })]
                                            }), (0, a.jsx)("div", {
                                                className: "h-2 bg-white/10 rounded-full overflow-hidden",
                                                children: (0, a.jsx)("div", {
                                                    className: "h-full bg-gradient-to-r from-amber-500 via-yellow-500 to-green-500 rounded-full transition-all duration-500",
                                                    style: {
                                                        width: "".concat(Math.min(100, B.gamesPlayed / ee * 100), "%")
                                                    }
                                                })
                                            }), (0, a.jsxs)("div", {
                                                className: "flex justify-between text-[10px] text-white/40 mt-1",
                                                children: [(0, a.jsx)("span", {
                                                    children: "0"
                                                }), (0, a.jsxs)("span", {
                                                    className: "text-yellow-500/60",
                                                    children: [Q, " (ranking)"]
                                                }), (0, a.jsxs)("span", {
                                                    className: "text-green-500/60",
                                                    children: [ee, " (pr\xeamios)"]
                                                })]
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "card bg-gradient-to-br from-pool-gold/10 via-pool-dark/60 to-pool-dark/60 border-pool-gold/30",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center justify-between mb-4",
                                            children: [(0, a.jsxs)("h3", {
                                                className: "font-semibold text-white flex items-center gap-2",
                                                children: [(0, a.jsx)(z.Z, {
                                                    className: "text-pool-gold",
                                                    size: 18
                                                }), "Sua Posi\xe7\xe3o", B.isProvisional && (0, a.jsx)("span", {
                                                    className: "text-[10px] px-2 py-0.5 bg-yellow-500/20 text-yellow-400 rounded-full border border-yellow-500/30",
                                                    children: "PROVIS\xd3RIO"
                                                })]
                                            }), B.lastMatchAt && (0, a.jsxs)("p", {
                                                className: "text-xs text-white/40",
                                                children: ["\xdaltima partida: ", en(B.lastMatchAt)]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
                                            children: [(0, a.jsxs)("div", {
                                                className: "text-center p-4 rounded-xl bg-white/5 border border-white/10",
                                                children: [(0, a.jsx)("p", {
                                                    className: "text-4xl font-bold text-pool-gold",
                                                    children: B.rank ? "#".concat(B.rank) : "-"
                                                }), (0, a.jsx)("p", {
                                                    className: "text-xs text-white/50 mt-1",
                                                    children: "Posi\xe7\xe3o Atual"
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "text-center p-4 rounded-xl bg-white/5 border border-white/10",
                                                children: [(0, a.jsx)("p", {
                                                    className: "text-4xl font-bold text-white",
                                                    children: B.points
                                                }), (0, a.jsx)("p", {
                                                    className: "text-xs text-white/50 mt-1",
                                                    children: "Pontos"
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "text-center p-4 rounded-xl bg-white/5 border border-white/10",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center justify-center gap-1",
                                                    children: [B.highestRank && B.rank && B.rank <= B.highestRank ? (0, a.jsx)(P.Z, {
                                                        className: "text-green-400",
                                                        size: 20
                                                    }) : (0, a.jsx)(Z.Z, {
                                                        className: "text-white/40",
                                                        size: 20
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-4xl font-bold text-white",
                                                        children: B.highestRank ? "#".concat(B.highestRank) : "-"
                                                    })]
                                                }), (0, a.jsx)("p", {
                                                    className: "text-xs text-white/50 mt-1",
                                                    children: "Melhor Posi\xe7\xe3o"
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "text-center p-4 rounded-xl bg-white/5 border border-white/10",
                                                children: [(0, a.jsxs)("p", {
                                                    className: "text-4xl font-bold ".concat(ed(B.wins, B.gamesPlayed) >= 50 ? "text-green-400" : "text-red-400"),
                                                    children: [ed(B.wins, B.gamesPlayed), "%"]
                                                }), (0, a.jsx)("p", {
                                                    className: "text-xs text-white/50 mt-1",
                                                    children: "Taxa de Vit\xf3ria"
                                                })]
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "card",
                                        children: [(0, a.jsxs)("h3", {
                                            className: "font-semibold text-white mb-4 flex items-center gap-2",
                                            children: [(0, a.jsx)(R.Z, {
                                                className: "text-yellow-400",
                                                size: 18
                                            }), "Desempenho"]
                                        }), (0, a.jsxs)("div", {
                                            className: "grid grid-cols-2 sm:grid-cols-3 gap-4",
                                            children: [(0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl bg-white/5 border border-white/10",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [(0, a.jsx)(w.Z, {
                                                        className: "text-blue-400",
                                                        size: 16
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/50",
                                                        children: "Partidas Jogadas"
                                                    })]
                                                }), (0, a.jsx)("p", {
                                                    className: "text-2xl font-bold text-white",
                                                    children: B.gamesPlayed
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl bg-green-500/10 border border-green-500/30",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [(0, a.jsx)(o.Z, {
                                                        className: "text-green-400",
                                                        size: 16
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/50",
                                                        children: "Vit\xf3rias"
                                                    })]
                                                }), (0, a.jsx)("p", {
                                                    className: "text-2xl font-bold text-green-400",
                                                    children: B.wins
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl bg-red-500/10 border border-red-500/30",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [(0, a.jsx)(f.Z, {
                                                        className: "text-red-400",
                                                        size: 16
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/50",
                                                        children: "Derrotas"
                                                    })]
                                                }), (0, a.jsx)("p", {
                                                    className: "text-2xl font-bold text-red-400",
                                                    children: B.losses
                                                })]
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "card",
                                        children: [(0, a.jsxs)("h3", {
                                            className: "font-semibold text-white mb-4 flex items-center gap-2",
                                            children: [(0, a.jsx)(F.Z, {
                                                className: "text-green-400",
                                                size: 18
                                            }), "Financeiro na Temporada"]
                                        }), (0, a.jsxs)("div", {
                                            className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
                                            children: [(0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl bg-white/5 border border-white/10",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [(0, a.jsx)(F.Z, {
                                                        className: "text-white/40",
                                                        size: 16
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/50",
                                                        children: "Total Apostado"
                                                    })]
                                                }), (0, a.jsxs)("p", {
                                                    className: "text-2xl font-bold text-white",
                                                    children: ["R$ ", B.totalBet.toFixed(2)]
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl bg-green-500/10 border border-green-500/30",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [(0, a.jsx)(P.Z, {
                                                        className: "text-green-400",
                                                        size: 16
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/50",
                                                        children: "Total Ganho"
                                                    })]
                                                }), (0, a.jsxs)("p", {
                                                    className: "text-2xl font-bold text-green-400",
                                                    children: ["R$ ", B.totalWon.toFixed(2)]
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "p-4 rounded-xl border ".concat(B.totalWon - B.totalBet >= 0 ? "bg-green-500/10 border-green-500/30" : "bg-red-500/10 border-red-500/30"),
                                                children: [(0, a.jsxs)("div", {
                                                    className: "flex items-center gap-2 mb-2",
                                                    children: [(0, a.jsx)(S.Z, {
                                                        className: B.totalWon - B.totalBet >= 0 ? "text-green-400" : "text-red-400",
                                                        size: 16
                                                    }), (0, a.jsx)("p", {
                                                        className: "text-xs text-white/50",
                                                        children: "Lucro/Preju\xedzo"
                                                    })]
                                                }), (0, a.jsxs)("p", {
                                                    className: "text-2xl font-bold ".concat(B.totalWon - B.totalBet >= 0 ? "text-green-400" : "text-red-400"),
                                                    children: [B.totalWon - B.totalBet >= 0 ? "+" : "", "R$ ", (B.totalWon - B.totalBet).toFixed(2)]
                                                })]
                                            })]
                                        })]
                                    }), B.rank && O > 0 && (0, a.jsxs)("div", {
                                        className: "card",
                                        children: [(0, a.jsxs)("h3", {
                                            className: "font-semibold text-white mb-4 flex items-center gap-2",
                                            children: [(0, a.jsx)(u.Z, {
                                                className: "text-purple-400",
                                                size: 18
                                            }), "Posi\xe7\xe3o no Ranking"]
                                        }), (0, a.jsxs)("div", {
                                            className: "relative h-8 bg-white/5 rounded-full overflow-hidden",
                                            children: [(0, a.jsx)("div", {
                                                className: "absolute inset-y-0 left-0 bg-gradient-to-r from-pool-gold to-yellow-500 rounded-full transition-all duration-500",
                                                style: {
                                                    width: "".concat(Math.max(5, 100 - (B.rank - 1) / O * 100), "%")
                                                }
                                            }), (0, a.jsxs)("div", {
                                                className: "absolute inset-0 flex items-center justify-center text-sm font-medium text-white",
                                                children: ["Voc\xea est\xe1 entre os top ", Math.round(B.rank / O * 100), "%"]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "flex justify-between text-xs text-white/40 mt-2",
                                            children: [(0, a.jsx)("span", {
                                                children: "#1"
                                            }), (0, a.jsxs)("span", {
                                                children: ["#", O]
                                            })]
                                        })]
                                    })]
                                }) : (0, a.jsxs)("div", {
                                    className: "card text-center py-12",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4",
                                        children: (0, a.jsx)(w.Z, {
                                            className: "text-white/30",
                                            size: 32
                                        })
                                    }), (0, a.jsx)("h3", {
                                        className: "text-lg font-semibold text-white mb-2",
                                        children: "Voc\xea ainda n\xe3o jogou nesta temporada"
                                    }), (0, a.jsx)("p", {
                                        className: "text-white/60 text-sm max-w-md mx-auto",
                                        children: "Jogue partidas ranqueadas para come\xe7ar a acumular pontos e aparecer no ranking."
                                    })]
                                })
                            })]
                        })]
                    }), (0, a.jsx)(C.Z, {})]
                })
            }
        },
        16112: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            var a = t(3827),
                l = t(8792),
                i = t(20703);

            function r() {
                let e = new Date().getFullYear();
                return (0, a.jsx)("footer", {
                    className: "bg-pool-dark border-t border-white/5 mt-auto",
                    children: (0, a.jsx)("div", {
                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",
                        children: (0, a.jsxs)("div", {
                            className: "flex flex-col md:flex-row items-center justify-between gap-4",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-4",
                                children: [(0, a.jsx)(i.default, {
                                    src: "/logos/logo-white-red.png",
                                    alt: "Tacadinha",
                                    width: 100,
                                    height: 32,
                                    className: "h-6 w-auto opacity-50"
                                }), (0, a.jsx)("span", {
                                    className: "text-white/30 text-sm hidden sm:inline",
                                    children: "|"
                                }), (0, a.jsxs)("p", {
                                    className: "text-white/30 text-sm",
                                    children: ["\xa9 ", e, " Tacadinha"]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-6 text-sm",
                                children: [(0, a.jsx)(l.default, {
                                    href: "/termos",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Termos"
                                }), (0, a.jsx)(l.default, {
                                    href: "/privacidade",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Privacidade"
                                }), (0, a.jsx)(l.default, {
                                    href: "#",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Suporte"
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-3 text-white/30 text-xs",
                                children: [(0, a.jsx)("span", {
                                    children: "+18"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "•"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "Jogue com responsabilidade"
                                })]
                            })]
                        })
                    })
                })
            }
        }
    },
    function(e) {
        e.O(0, [2807, 703, 6647, 826, 4002, 2971, 8069, 1744], function() {
            return e(e.s = 54945)
        }), _N_E = e.O()
    }
]);