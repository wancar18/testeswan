(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3185], {
        44521: function(e, t, n) {
            Promise.resolve().then(n.t.bind(n, 52445, 23)), Promise.resolve().then(n.bind(n, 75994)), Promise.resolve().then(n.bind(n, 42375)), Promise.resolve().then(n.bind(n, 44246)), Promise.resolve().then(n.bind(n, 27105)), Promise.resolve().then(n.t.bind(n, 46708, 23)), Promise.resolve().then(n.t.bind(n, 82485, 23)), Promise.resolve().then(n.bind(n, 10963))
        },
        75994: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return a
                }
            });
            var r = n(64090);

            function a() {
                return (0, r.useEffect)(() => {
                    if ("true" === new URLSearchParams(window.location.search).get("debug")) {
                        console.log("[Logger] Debug mode enabled via URL param");
                        return
                    }
                    let e = console.log,
                        t = console.info,
                        n = console.warn,
                        r = console.debug;
                    return console.log = () => {}, console.info = () => {}, console.warn = () => {}, console.debug = () => {}, () => {
                        console.log = e, console.info = t, console.warn = n, console.debug = r
                    }
                }, []), null
            }
        },
        42375: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(3827),
                a = n(64090);
            class o extends a.Component {
                static getDerivedStateFromError(e) {
                    return {
                        hasError: !0,
                        error: e
                    }
                }
                componentDidCatch(e, t) {
                    this.setState({
                        errorInfo: t
                    }), console.error("ErrorBoundary caught an error:", e, t), this.props.onError && this.props.onError(e, t)
                }
                render() {
                    return this.state.hasError ? this.props.fallback ? this.props.fallback : (0, r.jsx)("div", {
                        className: "min-h-screen bg-gray-900 flex items-center justify-center p-4",
                        children: (0, r.jsxs)("div", {
                            className: "max-w-md w-full bg-gray-800 rounded-lg shadow-xl p-6 text-center",
                            children: [(0, r.jsx)("div", {
                                className: "text-red-500 mb-4",
                                children: (0, r.jsx)("svg", {
                                    className: "w-16 h-16 mx-auto",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: (0, r.jsx)("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                    })
                                })
                            }), (0, r.jsx)("h2", {
                                className: "text-xl font-bold text-white mb-2",
                                children: "Algo deu errado"
                            }), (0, r.jsx)("p", {
                                className: "text-gray-400 mb-4",
                                children: "Ocorreu um erro inesperado. Por favor, tente recarregar a pagina."
                            }), !1, (0, r.jsxs)("div", {
                                className: "flex gap-3 justify-center",
                                children: [(0, r.jsx)("button", {
                                    onClick: this.handleReset,
                                    className: "px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors",
                                    children: "Tentar novamente"
                                }), (0, r.jsx)("button", {
                                    onClick: this.handleReload,
                                    className: "px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors",
                                    children: "Recarregar pagina"
                                })]
                            })]
                        })
                    }) : this.props.children
                }
                constructor(e) {
                    super(e), this.handleReset = () => {
                        this.setState({
                            hasError: !1,
                            error: null,
                            errorInfo: null
                        })
                    }, this.handleReload = () => {
                        window.location.reload()
                    }, this.state = {
                        hasError: !1,
                        error: null,
                        errorInfo: null
                    }
                }
            }
            t.default = o
        },
        44246: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                GoogleTagManagerWrapper: function() {
                    return o
                }
            });
            var r = n(3827),
                a = n(80946);

            function o(e) {
                let {
                    gtmId: t
                } = e;
                return (0, r.jsx)(a.fc, {
                    gtmId: t
                })
            }
            t.default = o
        },
        27105: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return u
                }
            });
            var r = n(3827),
                a = n(47907),
                o = n(54983),
                l = n(64090);
            let i = ["/room", "/game", "/admin"];

            function s() {
                var e, t;
                if (window.zE) {
                    try {
                        window.zE("webWidget", "hide")
                    } catch (e) {}
                    try {
                        window.zE("messenger", "hide")
                    } catch (e) {}
                    try {
                        window.zE("messenger:set", "zIndex", -1)
                    } catch (e) {}
                }
                if (null === (t = window.$zopim) || void 0 === t ? void 0 : null === (e = t.livechat) || void 0 === e ? void 0 : e.window) try {
                    window.$zopim.livechat.window.hide()
                } catch (e) {}
                if (!document.getElementById("zendesk-hide-style")) {
                    let e = document.createElement("style");
                    e.id = "zendesk-hide-style", e.innerHTML = '\n      iframe#launcher,\n      iframe[title="Button to launch messaging window"],\n      iframe[title="Messaging window"],\n      iframe[title="Number of unread messages"],\n      div[data-testid="launcher"],\n      #webWidget,\n      .zEWidget-launcher,\n      [data-product="web_widget"] {\n        display: none !important;\n        visibility: hidden !important;\n        opacity: 0 !important;\n        pointer-events: none !important;\n      }\n    ', document.head.appendChild(e)
                }
            }

            function u() {
                let e = (0, a.usePathname)(),
                    [t, n] = (0, l.useState)(!1),
                    u = i.some(t => null == e ? void 0 : e.startsWith(t));
                return (0, l.useEffect)(() => {
                    if (u) {
                        s();
                        let e = setInterval(s, 500);
                        return () => clearInterval(e)
                    }
                    t && function() {
                        var e, t;
                        let n = document.getElementById("zendesk-hide-style");
                        if (n && n.remove(), window.zE) {
                            try {
                                window.zE("webWidget", "show")
                            } catch (e) {}
                            try {
                                window.zE("messenger", "show")
                            } catch (e) {}
                            try {
                                window.zE("messenger:set", "zIndex", 999999)
                            } catch (e) {}
                        }
                        if (null === (t = window.$zopim) || void 0 === t ? void 0 : null === (e = t.livechat) || void 0 === e ? void 0 : e.window) try {
                            window.$zopim.livechat.window.show()
                        } catch (e) {}
                    }()
                }, [e, t, u]), (0, l.useEffect)(() => {
                    u && s()
                }, []), (0, r.jsx)(o.default, {
                    id: "ze-snippet",
                    src: "https://static.zdassets.com/ekr/snippet.js?key=612e31db-28dd-4e5e-964f-a71eb32af45f",
                    strategy: "lazyOnload",
                    onLoad: () => {
                        n(!0), u && s()
                    }
                })
            }
        },
        26016: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                let {
                    html: t,
                    height: n = null,
                    width: o = null,
                    children: l,
                    dataNtpc: i = ""
                } = e;
                return (0, a.useEffect)(() => {
                    i && performance.mark("mark_feature_usage", {
                        detail: {
                            feature: "next-third-parties-".concat(i)
                        }
                    })
                }, [i]), (0, r.jsxs)(r.Fragment, {
                    children: [l, t ? (0, r.jsx)("div", {
                        style: {
                            height: null != n ? "".concat(n, "px") : "auto",
                            width: null != o ? "".concat(o, "px") : "auto"
                        },
                        "data-ntpc": i,
                        dangerouslySetInnerHTML: {
                            __html: t
                        }
                    }) : null]
                })
            };
            let r = n(3827),
                a = n(64090)
        },
        91845: function(e, t, n) {
            "use strict";
            var r;
            let a;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.GoogleAnalytics = function(e) {
                let {
                    gaId: t,
                    debugMode: n,
                    dataLayerName: r = "dataLayer",
                    nonce: s
                } = e;
                return void 0 === a && (a = r), (0, l.useEffect)(() => {
                    performance.mark("mark_feature_usage", {
                        detail: {
                            feature: "next-third-parties-ga"
                        }
                    })
                }, []), (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)(i.default, {
                        id: "_next-ga-init",
                        dangerouslySetInnerHTML: {
                            __html: "\n          window['".concat(r, "'] = window['").concat(r, "'] || [];\n          function gtag(){window['").concat(r, "'].push(arguments);}\n          gtag('js', new Date());\n\n          gtag('config', '").concat(t, "' ").concat(n ? ",{ 'debug_mode': true }" : "", ");")
                        },
                        nonce: s
                    }), (0, o.jsx)(i.default, {
                        id: "_next-ga",
                        src: "https://www.googletagmanager.com/gtag/js?id=".concat(t),
                        nonce: s
                    })]
                })
            }, t.sendGAEvent = function() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                if (void 0 === a) {
                    console.warn("@next/third-parties: GA has not been initialized");
                    return
                }
                window[a] ? window[a].push(arguments) : console.warn("@next/third-parties: GA dataLayer ".concat(a, " does not exist"))
            };
            let o = n(3827),
                l = n(64090),
                i = (r = n(54983)) && r.__esModule ? r : {
                    default: r
                }
        },
        68739: function(e, t, n) {
            "use strict";
            var r;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                let {
                    apiKey: t,
                    ...n
                } = e, r = { ...n,
                    key: t
                }, {
                    html: i
                } = (0, o.GoogleMapsEmbed)(r);
                return (0, a.jsx)(l.default, {
                    height: r.height || null,
                    width: r.width || null,
                    html: i,
                    dataNtpc: "GoogleMapsEmbed"
                })
            };
            let a = n(3827),
                o = n(14982),
                l = (r = n(26016)) && r.__esModule ? r : {
                    default: r
                }
        },
        37388: function(e, t, n) {
            "use strict";
            var r;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.sendGTMEvent = void 0, t.GoogleTagManager = function(e) {
                let {
                    gtmId: t,
                    gtmScriptUrl: n,
                    dataLayerName: r = "dataLayer",
                    auth: s,
                    preview: u,
                    dataLayer: c,
                    nonce: d
                } = e;
                i = r;
                let f = new URL(n || "https://www.googletagmanager.com/gtm.js");
                return t && f.searchParams.set("id", t), "dataLayer" !== r && f.searchParams.set("l", r), s && f.searchParams.set("gtm_auth", s), u && (f.searchParams.set("gtm_preview", u), f.searchParams.set("gtm_cookies_win", "x")), (0, o.useEffect)(() => {
                    performance.mark("mark_feature_usage", {
                        detail: {
                            feature: "next-third-parties-gtm"
                        }
                    })
                }, []), (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(l.default, {
                        id: "_next-gtm-init",
                        dangerouslySetInnerHTML: {
                            __html: "\n      (function(w,l){\n        w[l]=w[l]||[];\n        w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});\n        ".concat(c ? "w[l].push(".concat(JSON.stringify(c), ")") : "", "\n      })(window,'").concat(r, "');")
                        },
                        nonce: d
                    }), (0, a.jsx)(l.default, {
                        id: "_next-gtm",
                        "data-ntpc": "GTM",
                        src: f.href,
                        nonce: d
                    })]
                })
            };
            let a = n(3827),
                o = n(64090),
                l = (r = n(54983)) && r.__esModule ? r : {
                    default: r
                },
                i = "dataLayer";
            t.sendGTMEvent = (e, t) => {
                let n = t || i;
                window[n] = window[n] || [], window[n].push(e)
            }
        },
        80946: function(e, t, n) {
            "use strict";
            t.fc = void 0, n(68739), n(45416);
            var r = n(37388);
            Object.defineProperty(t, "fc", {
                enumerable: !0,
                get: function() {
                    return r.GoogleTagManager
                }
            }), n(91845)
        },
        45416: function(e, t, n) {
            "use strict";
            var r = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                let {
                    html: t,
                    scripts: n,
                    stylesheets: r
                } = (0, l.YouTubeEmbed)(e);
                return (0, a.jsx)(i.default, {
                    height: e.height || null,
                    width: e.width || null,
                    html: t,
                    dataNtpc: "YouTubeEmbed",
                    children: null == n ? void 0 : n.map(e => (0, a.jsx)(o.default, {
                        src: e.url,
                        strategy: s[e.strategy],
                        stylesheets: r
                    }, e.url))
                })
            };
            let a = n(3827),
                o = r(n(54983)),
                l = n(14982),
                i = r(n(26016)),
                s = {
                    server: "beforeInteractive",
                    client: "afterInteractive",
                    idle: "lazyOnload",
                    worker: "worker"
                }
        },
        47907: function(e, t, n) {
            "use strict";
            var r = n(15313);
            n.o(r, "useParams") && n.d(t, {
                useParams: function() {
                    return r.useParams
                }
            }), n.o(r, "usePathname") && n.d(t, {
                usePathname: function() {
                    return r.usePathname
                }
            }), n.o(r, "useRouter") && n.d(t, {
                useRouter: function() {
                    return r.useRouter
                }
            }), n.o(r, "useSearchParams") && n.d(t, {
                useSearchParams: function() {
                    return r.useSearchParams
                }
            })
        },
        54983: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return a.a
                }
            });
            var r = n(85935),
                a = n.n(r),
                o = {};
            for (var l in r) "default" !== l && (o[l] = (function(e) {
                return r[e]
            }).bind(0, l));
            n.d(t, o)
        },
        13313: function(e, t) {
            "use strict";
            let n;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var n in t) Object.defineProperty(e, n, {
                        enumerable: !0,
                        get: t[n]
                    })
                }(t, {
                    DOMAttributeNames: function() {
                        return r
                    },
                    isEqualNode: function() {
                        return o
                    },
                    default: function() {
                        return l
                    }
                });
            let r = {
                acceptCharset: "accept-charset",
                className: "class",
                htmlFor: "for",
                httpEquiv: "http-equiv",
                noModule: "noModule"
            };

            function a(e) {
                let {
                    type: t,
                    props: n
                } = e, a = document.createElement(t);
                for (let e in n) {
                    if (!n.hasOwnProperty(e) || "children" === e || "dangerouslySetInnerHTML" === e || void 0 === n[e]) continue;
                    let o = r[e] || e.toLowerCase();
                    "script" === t && ("async" === o || "defer" === o || "noModule" === o) ? a[o] = !!n[e] : a.setAttribute(o, n[e])
                }
                let {
                    children: o,
                    dangerouslySetInnerHTML: l
                } = n;
                return l ? a.innerHTML = l.__html || "" : o && (a.textContent = "string" == typeof o ? o : Array.isArray(o) ? o.join("") : ""), a
            }

            function o(e, t) {
                if (e instanceof HTMLElement && t instanceof HTMLElement) {
                    let n = t.getAttribute("nonce");
                    if (n && !e.getAttribute("nonce")) {
                        let r = t.cloneNode(!0);
                        return r.setAttribute("nonce", ""), r.nonce = n, n === e.nonce && e.isEqualNode(r)
                    }
                }
                return e.isEqualNode(t)
            }

            function l() {
                return {
                    mountedInstances: new Set,
                    updateHead: e => {
                        let t = {};
                        e.forEach(e => {
                            if ("link" === e.type && e.props["data-optimized-fonts"]) {
                                if (document.querySelector('style[data-href="' + e.props["data-href"] + '"]')) return;
                                e.props.href = e.props["data-href"], e.props["data-href"] = void 0
                            }
                            let n = t[e.type] || [];
                            n.push(e), t[e.type] = n
                        });
                        let r = t.title ? t.title[0] : null,
                            a = "";
                        if (r) {
                            let {
                                children: e
                            } = r.props;
                            a = "string" == typeof e ? e : Array.isArray(e) ? e.join("") : ""
                        }
                        a !== document.title && (document.title = a), ["meta", "base", "link", "style", "script"].forEach(e => {
                            n(e, t[e] || [])
                        })
                    }
                }
            }
            n = (e, t) => {
                let n = document.getElementsByTagName("head")[0],
                    r = n.querySelector("meta[name=next-head-count]"),
                    l = Number(r.content),
                    i = [];
                for (let t = 0, n = r.previousElementSibling; t < l; t++, n = (null == n ? void 0 : n.previousElementSibling) || null) {
                    var s;
                    (null == n ? void 0 : null == (s = n.tagName) ? void 0 : s.toLowerCase()) === e && i.push(n)
                }
                let u = t.map(a).filter(e => {
                    for (let t = 0, n = i.length; t < n; t++)
                        if (o(i[t], e)) return i.splice(t, 1), !1;
                    return !0
                });
                i.forEach(e => {
                    var t;
                    return null == (t = e.parentNode) ? void 0 : t.removeChild(e)
                }), u.forEach(e => n.insertBefore(e, r)), r.content = (l - i.length + u.length).toString()
            }, ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        52185: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var n in t) Object.defineProperty(e, n, {
                        enumerable: !0,
                        get: t[n]
                    })
                }(t, {
                    requestIdleCallback: function() {
                        return n
                    },
                    cancelIdleCallback: function() {
                        return r
                    }
                });
            let n = "undefined" != typeof self && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function(e) {
                    let t = Date.now();
                    return self.setTimeout(function() {
                        e({
                            didTimeout: !1,
                            timeRemaining: function() {
                                return Math.max(0, 50 - (Date.now() - t))
                            }
                        })
                    }, 1)
                },
                r = "undefined" != typeof self && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function(e) {
                    return clearTimeout(e)
                };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        85935: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var n in t) Object.defineProperty(e, n, {
                        enumerable: !0,
                        get: t[n]
                    })
                }(t, {
                    handleClientScriptLoad: function() {
                        return h
                    },
                    initScriptLoader: function() {
                        return b
                    },
                    default: function() {
                        return v
                    }
                });
            let r = n(86921),
                a = n(91884),
                o = n(3827),
                l = r._(n(89542)),
                i = a._(n(64090)),
                s = n(27484),
                u = n(13313),
                c = n(52185),
                d = new Map,
                f = new Set,
                p = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"],
                m = e => {
                    if (l.default.preinit) {
                        e.forEach(e => {
                            l.default.preinit(e, {
                                as: "style"
                            })
                        });
                        return
                    } {
                        let t = document.head;
                        e.forEach(e => {
                            let n = document.createElement("link");
                            n.type = "text/css", n.rel = "stylesheet", n.href = e, t.appendChild(n)
                        })
                    }
                },
                g = e => {
                    let {
                        src: t,
                        id: n,
                        onLoad: r = () => {},
                        onReady: a = null,
                        dangerouslySetInnerHTML: o,
                        children: l = "",
                        strategy: i = "afterInteractive",
                        onError: s,
                        stylesheets: c
                    } = e, g = n || t;
                    if (g && f.has(g)) return;
                    if (d.has(t)) {
                        f.add(g), d.get(t).then(r, s);
                        return
                    }
                    let h = () => {
                            a && a(), f.add(g)
                        },
                        b = document.createElement("script"),
                        y = new Promise((e, t) => {
                            b.addEventListener("load", function(t) {
                                e(), r && r.call(this, t), h()
                            }), b.addEventListener("error", function(e) {
                                t(e)
                            })
                        }).catch(function(e) {
                            s && s(e)
                        });
                    for (let [n, r] of (o ? (b.innerHTML = o.__html || "", h()) : l ? (b.textContent = "string" == typeof l ? l : Array.isArray(l) ? l.join("") : "", h()) : t && (b.src = t, d.set(t, y)), Object.entries(e))) {
                        if (void 0 === r || p.includes(n)) continue;
                        let e = u.DOMAttributeNames[n] || n.toLowerCase();
                        b.setAttribute(e, r)
                    }
                    "worker" === i && b.setAttribute("type", "text/partytown"), b.setAttribute("data-nscript", i), c && m(c), document.body.appendChild(b)
                };

            function h(e) {
                let {
                    strategy: t = "afterInteractive"
                } = e;
                "lazyOnload" === t ? window.addEventListener("load", () => {
                    (0, c.requestIdleCallback)(() => g(e))
                }) : g(e)
            }

            function b(e) {
                e.forEach(h), [...document.querySelectorAll('[data-nscript="beforeInteractive"]'), ...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(e => {
                    let t = e.id || e.getAttribute("src");
                    f.add(t)
                })
            }

            function y(e) {
                let {
                    id: t,
                    src: n = "",
                    onLoad: r = () => {},
                    onReady: a = null,
                    strategy: u = "afterInteractive",
                    onError: d,
                    stylesheets: p,
                    ...m
                } = e, {
                    updateScripts: h,
                    scripts: b,
                    getIsSsr: y,
                    appDir: v,
                    nonce: w
                } = (0, i.useContext)(s.HeadManagerContext), _ = (0, i.useRef)(!1);
                (0, i.useEffect)(() => {
                    let e = t || n;
                    _.current || (a && e && f.has(e) && a(), _.current = !0)
                }, [a, t, n]);
                let j = (0, i.useRef)(!1);
                if ((0, i.useEffect)(() => {
                        !j.current && ("afterInteractive" === u ? g(e) : "lazyOnload" === u && ("complete" === document.readyState ? (0, c.requestIdleCallback)(() => g(e)) : window.addEventListener("load", () => {
                            (0, c.requestIdleCallback)(() => g(e))
                        })), j.current = !0)
                    }, [e, u]), ("beforeInteractive" === u || "worker" === u) && (h ? (b[u] = (b[u] || []).concat([{
                        id: t,
                        src: n,
                        onLoad: r,
                        onReady: a,
                        onError: d,
                        ...m
                    }]), h(b)) : y && y() ? f.add(t || n) : y && !y() && g(e)), v) {
                    if (p && p.forEach(e => {
                            l.default.preinit(e, {
                                as: "style"
                            })
                        }), "beforeInteractive" === u) return n ? (l.default.preload(n, m.integrity ? {
                        as: "script",
                        integrity: m.integrity
                    } : {
                        as: "script"
                    }), (0, o.jsx)("script", {
                        nonce: w,
                        dangerouslySetInnerHTML: {
                            __html: "(self.__next_s=self.__next_s||[]).push(" + JSON.stringify([n, { ...m,
                                id: t
                            }]) + ")"
                        }
                    })) : (m.dangerouslySetInnerHTML && (m.children = m.dangerouslySetInnerHTML.__html, delete m.dangerouslySetInnerHTML), (0, o.jsx)("script", {
                        nonce: w,
                        dangerouslySetInnerHTML: {
                            __html: "(self.__next_s=self.__next_s||[]).push(" + JSON.stringify([0, { ...m,
                                id: t
                            }]) + ")"
                        }
                    }));
                    "afterInteractive" === u && n && l.default.preload(n, m.integrity ? {
                        as: "script",
                        integrity: m.integrity
                    } : {
                        as: "script"
                    })
                }
                return null
            }
            Object.defineProperty(y, "__nextScript", {
                value: !0
            });
            let v = y;
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        14982: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.YouTubeEmbed = t.GoogleMapsEmbed = t.GoogleAnalytics = void 0;
            var r = n(66328);
            Object.defineProperty(t, "GoogleAnalytics", {
                enumerable: !0,
                get: function() {
                    return r.GoogleAnalytics
                }
            });
            var a = n(24456);
            Object.defineProperty(t, "GoogleMapsEmbed", {
                enumerable: !0,
                get: function() {
                    return a.GoogleMapsEmbed
                }
            });
            var o = n(25744);
            Object.defineProperty(t, "YouTubeEmbed", {
                enumerable: !0,
                get: function() {
                    return o.YouTubeEmbed
                }
            })
        },
        66328: function(e, t, n) {
            "use strict";
            var r, a = function(e, t) {
                var n = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (n[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var a = 0, r = Object.getOwnPropertySymbols(e); a < r.length; a++) 0 > t.indexOf(r[a]) && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]]);
                return n
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.GoogleAnalytics = void 0;
            let o = (r = n(46893)) && r.__esModule ? r : {
                    default: r
                },
                l = n(91531);
            t.GoogleAnalytics = e => {
                var t = a(e, []);
                return (0, l.formatData)(o.default, t)
            }
        },
        24456: function(e, t, n) {
            "use strict";
            var r, a = function(e, t) {
                var n = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (n[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var a = 0, r = Object.getOwnPropertySymbols(e); a < r.length; a++) 0 > t.indexOf(r[a]) && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]]);
                return n
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.GoogleMapsEmbed = void 0;
            let o = (r = n(46362)) && r.__esModule ? r : {
                    default: r
                },
                l = n(91531);
            t.GoogleMapsEmbed = e => {
                var t = a(e, []);
                return (0, l.formatData)(o.default, t)
            }
        },
        25744: function(e, t, n) {
            "use strict";
            var r, a = function(e, t) {
                var n = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (n[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var a = 0, r = Object.getOwnPropertySymbols(e); a < r.length; a++) 0 > t.indexOf(r[a]) && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]]);
                return n
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.YouTubeEmbed = void 0;
            let o = (r = n(95825)) && r.__esModule ? r : {
                    default: r
                },
                l = n(91531);
            t.YouTubeEmbed = e => {
                var t = a(e, []);
                return (0, l.formatData)(o.default, t)
            }
        },
        91531: function(e, t) {
            "use strict";

            function n(e, t) {
                let n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                return t ? Object.keys(e).filter(e => n ? !t.includes(e) : t.includes(e)).reduce((t, n) => (t[n] = e[n], t), {}) : {}
            }

            function r(e, t, n, r) {
                let a = r && Object.keys(r).length > 0 ? new URL(Object.values(r)[0], e) : new URL(e);
                return t && n && t.forEach(e => {
                    n[e] && a.searchParams.set(e, n[e])
                }), a.toString()
            }

            function a(e, t, n, a, o) {
                var l;
                if (!t) return "<".concat(e, "></").concat(e, ">");
                let i = (null === (l = t.src) || void 0 === l ? void 0 : l.url) ? Object.assign(Object.assign({}, t), {
                        src: r(t.src.url, t.src.params, a, o)
                    }) : t,
                    s = Object.keys(Object.assign(Object.assign({}, i), n)).reduce((e, t) => {
                        let r = null == n ? void 0 : n[t],
                            a = i[t],
                            o = null != r ? r : a,
                            l = !0 === o ? t : "".concat(t, '="').concat(o, '"');
                        return o ? e + " ".concat(l) : e
                    }, "");
                return "<".concat(e).concat(s, "></").concat(e, ">")
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.formatData = t.createHtml = t.formatUrl = void 0, t.formatUrl = r, t.createHtml = a, t.formatData = function(e, t) {
                var o, l, i, s, u;
                let c = n(t, null === (o = e.scripts) || void 0 === o ? void 0 : o.reduce((e, t) => [...e, ...Array.isArray(t.params) ? t.params : []], [])),
                    d = n(t, null === (i = null === (l = e.html) || void 0 === l ? void 0 : l.attributes.src) || void 0 === i ? void 0 : i.params),
                    f = n(t, [null === (u = null === (s = e.html) || void 0 === s ? void 0 : s.attributes.src) || void 0 === u ? void 0 : u.slugParam]),
                    p = n(t, [...Object.keys(c), ...Object.keys(d), ...Object.keys(f)], !0);
                return Object.assign(Object.assign({}, e), {
                    html: e.html ? a(e.html.element, e.html.attributes, p, d, f) : null,
                    scripts: e.scripts ? e.scripts.map(e => Object.assign(Object.assign({}, e), {
                        url: r(e.url, e.params, c)
                    })) : null
                })
            }
        },
        52445: function() {},
        46708: function(e) {
            e.exports = {
                style: {
                    fontFamily: "'__Inter_f367f3', '__Inter_Fallback_f367f3'",
                    fontStyle: "normal"
                },
                className: "__className_f367f3",
                variable: "__variable_f367f3"
            }
        },
        82485: function(e) {
            e.exports = {
                style: {
                    fontFamily: "'__Space_Grotesk_dd5b2f', '__Space_Grotesk_Fallback_dd5b2f'",
                    fontStyle: "normal"
                },
                className: "__className_dd5b2f",
                variable: "__variable_dd5b2f"
            }
        },
        46893: function(e) {
            "use strict";
            e.exports = JSON.parse('{"id":"google-analytics","description":"Install a Google Analytics tag on your website","website":"https://analytics.google.com/analytics/web/","scripts":[{"url":"https://www.googletagmanager.com/gtag/js","params":["id"],"strategy":"worker","location":"head","action":"append"},{"code":"window.dataLayer=window.dataLayer||[];window.gtag=function gtag(){window.dataLayer.push(arguments);};gtag(\'js\',new Date());gtag(\'config\',\'${args.id}\')","strategy":"worker","location":"head","action":"append"}]}')
        },
        46362: function(e) {
            "use strict";
            e.exports = JSON.parse('{"id":"google-maps-embed","description":"Embed a Google Maps embed on your webpage","website":"https://developers.google.com/maps/documentation/embed/get-started","html":{"element":"iframe","attributes":{"loading":"lazy","src":{"url":"https://www.google.com/maps/embed/v1/place","slugParam":"mode","params":["key","q","center","zoom","maptype","language","region"]},"referrerpolicy":"no-referrer-when-downgrade","frameborder":"0","style":"border:0","allowfullscreen":true,"width":null,"height":null}}}')
        },
        95825: function(e) {
            "use strict";
            e.exports = JSON.parse('{"id":"youtube-embed","description":"Embed a YouTube embed on your webpage.","website":"https://github.com/paulirish/lite-youtube-embed","html":{"element":"lite-youtube","attributes":{"videoid":null,"playlabel":null}},"stylesheets":["https://cdn.jsdelivr.net/gh/paulirish/lite-youtube-embed@master/src/lite-yt-embed.css"],"scripts":[{"url":"https://cdn.jsdelivr.net/gh/paulirish/lite-youtube-embed@master/src/lite-yt-embed.js","strategy":"idle","location":"head","action":"append"}]}')
        }
    },
    function(e) {
        e.O(0, [963, 2971, 8069, 1744], function() {
            return e(e.s = 44521)
        }), _N_E = e.O()
    }
]);