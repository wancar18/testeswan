(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [494], {
        93447: function(e, t, s) {
            Promise.resolve().then(s.bind(s, 78894))
        },
        78894: function(e, t, s) {
            "use strict";
            s.r(t), s.d(t, {
                default: function() {
                    return X
                }
            });
            var a = s(3827),
                l = s(64090),
                r = s(47907),
                i = s(6739),
                n = s(76023),
                o = s(10826),
                c = s(18994),
                d = s(52235);
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let x = (0, s(87461).Z)("Wrench", [
                ["path", {
                    d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z",
                    key: "cbrjhi"
                }]
            ]);
            var m = s(61524),
                h = s(40834),
                u = s(57277),
                p = s(70094),
                b = s(28670),
                g = s(34059),
                f = s(51652),
                j = s(37211),
                w = s(11213),
                v = s(26490),
                y = s(18025),
                N = s(17252),
                k = s(51930),
                Z = s(37841),
                C = s(66260),
                z = s(97404),
                S = s(4002),
                P = s(69102),
                M = s.n(P),
                A = s(20703),
                R = s(49108),
                F = s(37805);
            let I = [{
                id: "1",
                desktop: "/logos/home-banners/banner-01.png",
                mobile: "/logos/home-banners/banner-01-mobile.png",
                alt: "Baianinho de Mau\xe1 - O melhor do Brasil tamb\xe9m \xe9 Tacadinha"
            }, {
                id: "2",
                desktop: "/logos/home-banners/banner-02.png",
                mobile: "/logos/home-banners/banner-02-mobile.png",
                alt: "Baianinho de Mau\xe1 chegou pra elevar o n\xedvel do jogo"
            }, {
                id: "3",
                desktop: "/logos/home-banners/banner-03.png",
                mobile: "/logos/home-banners/banner-3-mobile.png",
                alt: "Aqui joga quem entende de sinuca - Fa\xe7a parte do time"
            }];

            function E() {
                let [e, t] = (0, l.useState)(0), [s, r] = (0, l.useState)("next"), [i, n] = (0, l.useState)(0), o = (0, l.useRef)(0), c = (0, l.useRef)(0), d = (0, l.useRef)(!1), x = (0, l.useCallback)((e, s) => {
                    r(s), t(e), n(e => e + 1)
                }, []), m = (0, l.useCallback)(() => {
                    x((e + 1) % I.length, "next")
                }, [e, x]), h = (0, l.useCallback)(() => {
                    x((e - 1 + I.length) % I.length, "prev")
                }, [e, x]), u = (0, l.useCallback)(t => {
                    t !== e && x(t, t > e ? "next" : "prev")
                }, [e, x]);
                (0, l.useEffect)(() => {
                    let e = setInterval(m, 8e3);
                    return () => clearInterval(e)
                }, [m]);
                let p = (0, l.useCallback)(e => {
                        o.current = e.clientX, c.current = 0, d.current = !0
                    }, []),
                    b = (0, l.useCallback)(e => {
                        d.current && (c.current = e.clientX - o.current)
                    }, []),
                    g = (0, l.useCallback)(() => {
                        d.current && (d.current = !1, c.current < -50 ? m() : c.current > 50 && h(), c.current = 0)
                    }, [m, h]);
                if (0 === I.length) return null;
                let f = I[e],
                    j = "next" === s ? "animate-slide-in-right" : "animate-slide-in-left";
                return (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(M(), {
                        id: "497b3a568b8524e",
                        children: "@-webkit-keyframes slideInRight{from{opacity:0;-webkit-transform:translatex(30px);transform:translatex(30px)}to{opacity:1;-webkit-transform:translatex(0);transform:translatex(0)}}@-moz-keyframes slideInRight{from{opacity:0;-moz-transform:translatex(30px);transform:translatex(30px)}to{opacity:1;-moz-transform:translatex(0);transform:translatex(0)}}@-o-keyframes slideInRight{from{opacity:0;-o-transform:translatex(30px);transform:translatex(30px)}to{opacity:1;-o-transform:translatex(0);transform:translatex(0)}}@keyframes slideInRight{from{opacity:0;-webkit-transform:translatex(30px);-moz-transform:translatex(30px);-o-transform:translatex(30px);transform:translatex(30px)}to{opacity:1;-webkit-transform:translatex(0);-moz-transform:translatex(0);-o-transform:translatex(0);transform:translatex(0)}}@-webkit-keyframes slideInLeft{from{opacity:0;-webkit-transform:translatex(-30px);transform:translatex(-30px)}to{opacity:1;-webkit-transform:translatex(0);transform:translatex(0)}}@-moz-keyframes slideInLeft{from{opacity:0;-moz-transform:translatex(-30px);transform:translatex(-30px)}to{opacity:1;-moz-transform:translatex(0);transform:translatex(0)}}@-o-keyframes slideInLeft{from{opacity:0;-o-transform:translatex(-30px);transform:translatex(-30px)}to{opacity:1;-o-transform:translatex(0);transform:translatex(0)}}@keyframes slideInLeft{from{opacity:0;-webkit-transform:translatex(-30px);-moz-transform:translatex(-30px);-o-transform:translatex(-30px);transform:translatex(-30px)}to{opacity:1;-webkit-transform:translatex(0);-moz-transform:translatex(0);-o-transform:translatex(0);transform:translatex(0)}}.animate-slide-in-right{-webkit-animation:slideInRight.35s ease-out both;-moz-animation:slideInRight.35s ease-out both;-o-animation:slideInRight.35s ease-out both;animation:slideInRight.35s ease-out both}.animate-slide-in-left{-webkit-animation:slideInLeft.35s ease-out both;-moz-animation:slideInLeft.35s ease-out both;-o-animation:slideInLeft.35s ease-out both;animation:slideInLeft.35s ease-out both}"
                    }), (0, a.jsxs)("div", {
                        onPointerDown: p,
                        onPointerMove: b,
                        onPointerUp: g,
                        onPointerLeave: g,
                        className: "jsx-497b3a568b8524e relative w-full rounded-xl overflow-hidden bg-pool-dark/30 border border-white/10 group touch-pan-y select-none",
                        children: [(0, a.jsx)("div", {
                            style: {
                                aspectRatio: "960 / 250"
                            },
                            className: "jsx-497b3a568b8524e " + "relative w-full hidden sm:block ".concat(j),
                            children: (0, a.jsx)(A.default, {
                                src: f.desktop,
                                alt: f.alt,
                                fill: !0,
                                className: "object-cover pointer-events-none",
                                priority: 0 === e,
                                sizes: "(min-width: 640px) 100vw",
                                draggable: !1
                            })
                        }, "d-".concat(i)), (0, a.jsx)("div", {
                            style: {
                                aspectRatio: "650 / 350"
                            },
                            className: "jsx-497b3a568b8524e " + "relative w-full sm:hidden ".concat(j),
                            children: (0, a.jsx)(A.default, {
                                src: f.mobile,
                                alt: f.alt,
                                fill: !0,
                                className: "object-cover pointer-events-none",
                                priority: 0 === e,
                                sizes: "100vw",
                                draggable: !1
                            })
                        }, "m-".concat(i)), I.length > 1 && (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("button", {
                                onClick: h,
                                "aria-label": "Banner anterior",
                                className: "jsx-497b3a568b8524e absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white/70 hover:text-white hover:bg-black/60 transition-all opacity-0 group-hover:opacity-100",
                                children: (0, a.jsx)(R.Z, {
                                    size: 18
                                })
                            }), (0, a.jsx)("button", {
                                onClick: m,
                                "aria-label": "Pr\xf3ximo banner",
                                className: "jsx-497b3a568b8524e absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white/70 hover:text-white hover:bg-black/60 transition-all opacity-0 group-hover:opacity-100",
                                children: (0, a.jsx)(F.Z, {
                                    size: 18
                                })
                            })]
                        }), I.length > 1 && (0, a.jsx)("div", {
                            className: "jsx-497b3a568b8524e absolute bottom-3 left-1/2 transform -translate-x-1/2 flex gap-2",
                            children: I.map((t, s) => (0, a.jsx)("button", {
                                onClick: () => u(s),
                                "aria-label": "Ir para banner ".concat(s + 1),
                                className: "jsx-497b3a568b8524e " + "h-2 rounded-full transition-all duration-300 ".concat(s === e ? "bg-pool-gold w-6" : "bg-white/40 hover:bg-white/60 w-2")
                            }, s))
                        })]
                    })]
                })
            }
            var D = s(16112),
                T = s(56022),
                $ = s(43081),
                L = s(81562),
                O = s(79251);
            let q = "tacadinha_welcome_video_seen";

            function B(e) {
                let {
                    isOpen: t,
                    onClose: s
                } = e, r = (0, l.useRef)(null), [i, n] = (0, l.useState)(!1), [o, c] = (0, l.useState)(!1), [x, m] = (0, l.useState)(!0), h = (0, l.useCallback)(() => {
                    localStorage.setItem(q, "true"), r.current && r.current.pause(), s()
                }, [s]), u = (0, l.useCallback)(() => {
                    let e = r.current;
                    e && (e.paused ? e.play() : e.pause())
                }, []), p = (0, l.useCallback)(() => {
                    let e = r.current;
                    e && (e.muted = !e.muted, c(e.muted))
                }, []), b = (0, l.useCallback)(() => {
                    m(!0)
                }, []), g = (0, l.useCallback)(() => {
                    n(!1), h()
                }, [h]);
                return ((0, l.useEffect)(() => {
                    t && r.current && r.current.play().then(() => {
                        n(!0)
                    }).catch(() => {
                        n(!1)
                    })
                }, [t]), (0, l.useEffect)(() => {
                    if (!i || !x) return;
                    let e = setTimeout(() => {
                        m(!1)
                    }, 3e3);
                    return () => clearTimeout(e)
                }, [i, x]), t) ? (0, a.jsxs)("div", {
                    className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm",
                    children: [(0, a.jsx)("button", {
                        onClick: h,
                        className: "absolute top-4 right-4 z-10 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors",
                        "aria-label": "Fechar v\xeddeo",
                        children: (0, a.jsx)(d.Z, {
                            size: 24
                        })
                    }), (0, a.jsxs)("div", {
                        className: "relative w-full max-w-4xl mx-4 rounded-2xl overflow-hidden shadow-2xl",
                        onMouseMove: b,
                        onClick: u,
                        children: [(0, a.jsx)("video", {
                            ref: r,
                            src: "/videos/tacadinha-welcome.mp4",
                            className: "w-full h-auto",
                            playsInline: !0,
                            onEnded: g,
                            onPlay: () => n(!0),
                            onPause: () => n(!1)
                        }), !i && (0, a.jsx)("div", {
                            className: "absolute inset-0 flex items-center justify-center bg-black/40",
                            children: (0, a.jsx)("button", {
                                onClick: e => {
                                    e.stopPropagation(), u()
                                },
                                className: "w-20 h-20 rounded-full bg-pool-gold flex items-center justify-center hover:bg-yellow-400 transition-colors",
                                children: (0, a.jsx)($.Z, {
                                    size: 40,
                                    className: "text-pool-dark ml-1",
                                    fill: "currentColor"
                                })
                            })
                        }), (0, a.jsx)("div", {
                            className: "absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent transition-opacity duration-300 ".concat(x || !i ? "opacity-100" : "opacity-0"),
                            children: (0, a.jsxs)("div", {
                                className: "flex items-center justify-between",
                                children: [(0, a.jsx)("div", {
                                    className: "flex items-center gap-2",
                                    children: (0, a.jsx)("button", {
                                        onClick: e => {
                                            e.stopPropagation(), p()
                                        },
                                        className: "p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors",
                                        children: o ? (0, a.jsx)(L.Z, {
                                            size: 20
                                        }) : (0, a.jsx)(O.Z, {
                                            size: 20
                                        })
                                    })
                                }), (0, a.jsx)("button", {
                                    onClick: e => {
                                        e.stopPropagation(), h()
                                    },
                                    className: "px-4 py-2 rounded-lg bg-pool-gold hover:bg-yellow-400 text-pool-dark font-semibold text-sm transition-colors",
                                    children: "Pular"
                                })]
                            })
                        })]
                    })]
                }) : null
            }
            var V = s(54012);
            let _ = (0, l.memo)(function(e) {
                let {
                    room: t,
                    userBalance: s,
                    isJoining: l,
                    onJoin: r,
                    onRequestPassword: i
                } = e, n = s < t.betAmount, o = (1.8 * Number(t.betAmount)).toFixed(0);
                return (0, a.jsxs)("div", {
                    className: "relative bg-pool-dark/50 rounded-xl p-4 border transition-all duration-200 group ".concat(t.isPrivate ? "border-yellow-500/20 hover:border-yellow-500/40" : "border-white/5 hover:border-white/20"),
                    children: [t.isPrivate && (0, a.jsx)("div", {
                        className: "absolute -top-2 -right-2 w-7 h-7 rounded-full bg-yellow-500/20 border border-yellow-500/30 flex items-center justify-center",
                        children: (0, a.jsx)(f.Z, {
                            size: 12,
                            className: "text-yellow-400"
                        })
                    }), (0, a.jsxs)("div", {
                        className: "flex items-center justify-between mb-3",
                        children: [(0, a.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: [(0, a.jsx)(T.Z, {
                                username: t.creator.username,
                                size: "sm"
                            }), (0, a.jsxs)("div", {
                                children: [(0, a.jsxs)("p", {
                                    className: "font-medium text-sm text-white truncate max-w-[100px]",
                                    children: ["@", t.creator.username]
                                }), (0, a.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [t.roomCode && (0, a.jsx)("span", {
                                        className: "text-[10px] font-mono text-pool-gold/70 bg-pool-gold/10 px-1.5 py-0.5 rounded",
                                        children: t.roomCode
                                    }), (0, a.jsxs)("span", {
                                        className: "text-[10px] text-white/40 flex items-center gap-0.5",
                                        children: [(0, a.jsx)(v.Z, {
                                            size: 8
                                        }), function(e) {
                                            let t = Math.floor((new Date().getTime() - new Date(e).getTime()) / 1e3);
                                            if (t < 60) return "agora";
                                            let s = Math.floor(t / 60);
                                            return s < 60 ? "".concat(s, "min") : "".concat(Math.floor(s / 60), "h")
                                        }(t.createdAt)]
                                    })]
                                })]
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "flex items-center gap-1 ".concat(t.isPrivate ? "text-yellow-400" : "text-green-400"),
                            children: [(0, a.jsx)("span", {
                                className: "w-1.5 h-1.5 rounded-full ".concat(t.isPrivate ? "bg-yellow-400" : "bg-green-400 animate-pulse")
                            }), (0, a.jsx)("span", {
                                className: "text-[10px]",
                                children: t.isPrivate ? "Privada" : "Aberta"
                            })]
                        })]
                    }), (0, a.jsx)("div", {
                        className: "rounded-lg p-3 mb-3 ".concat(t.isPrivate ? "bg-gradient-to-r from-yellow-500/10 to-yellow-500/5" : "bg-gradient-to-r from-pool-gold/20 to-pool-gold/5"),
                        children: (0, a.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [(0, a.jsxs)("div", {
                                children: [(0, a.jsx)("p", {
                                    className: "text-[10px] text-white/50 mb-0.5",
                                    children: "Aposta"
                                }), (0, a.jsxs)("p", {
                                    className: "text-xl font-bold ".concat(t.isPrivate ? "text-yellow-400" : "text-pool-gold"),
                                    children: ["R$ ", Number(t.betAmount).toFixed(0)]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "text-right",
                                children: [(0, a.jsx)("p", {
                                    className: "text-[10px] text-white/50 mb-0.5",
                                    children: "Pr\xeamio"
                                }), (0, a.jsxs)("p", {
                                    className: "text-base font-semibold text-green-400",
                                    children: ["R$ ", o]
                                })]
                            })]
                        })
                    }), (0, a.jsx)("button", {
                        onClick: () => {
                            t.isPrivate ? i(t) : r(t.id)
                        },
                        disabled: l || n,
                        className: "w-full py-2.5 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 transition-all ".concat(n ? "bg-white/5 text-white/40 cursor-not-allowed" : t.isPrivate ? "bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/30" : "bg-pool-gold hover:bg-pool-gold/90 text-pool-dark group-hover:gap-3"),
                        children: l ? (0, a.jsx)(c.Z, {
                            size: 16,
                            className: "animate-spin"
                        }) : n ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)(N.Z, {
                                size: 16
                            }), "Saldo Insuficiente"]
                        }) : t.isPrivate ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)(f.Z, {
                                size: 16
                            }), "Entrar com Senha"]
                        }) : (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)(z.Z, {
                                size: 16
                            }), "Entrar", (0, a.jsx)(y.Z, {
                                size: 16,
                                className: "transition-transform group-hover:translate-x-1"
                            })]
                        })
                    })]
                })
            });
            var U = s(57974);

            function G(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 8,
                    s = e || "???";
                return s.length <= t ? s : s.slice(0, t) + "..."
            }
            let H = (0, l.memo)(function(e) {
                    let {
                        matches: t,
                        matchesPerPage: s = 12
                    } = e, [r, i] = (0, l.useState)(0), [n, o] = (0, l.useState)(!1), [c, d] = (0, l.useState)("right"), x = (0, l.useMemo)(() => Math.ceil(t.length / s), [t.length, s]), m = (0, l.useMemo)(() => t.slice(r * s, (r + 1) * s), [t, r, s]), h = (0, l.useCallback)((e, t) => {
                        n || (d(t), o(!0), setTimeout(() => {
                            i(e), setTimeout(() => o(!1), 50)
                        }, 150))
                    }, [n]);
                    return 0 === t.length ? null : (0, a.jsxs)("div", {
                        className: "card mt-6",
                        children: [(0, a.jsxs)("div", {
                            className: "flex items-center justify-between mb-6",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, a.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-10 h-10 rounded-lg bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center",
                                        children: (0, a.jsx)(U.Z, {
                                            size: 20,
                                            className: "text-orange-400"
                                        })
                                    }), (0, a.jsx)("span", {
                                        className: "absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"
                                    })]
                                }), (0, a.jsxs)("div", {
                                    children: [(0, a.jsx)("h2", {
                                        className: "font-display text-lg font-bold",
                                        children: "Partidas em Andamento"
                                    }), (0, a.jsx)("p", {
                                        className: "text-white/60 text-sm",
                                        children: "Jogos acontecendo agora"
                                    })]
                                })]
                            }), (0, a.jsxs)("span", {
                                className: "text-xs text-white/40 bg-white/5 px-3 py-1.5 rounded-full flex items-center gap-2",
                                children: [(0, a.jsx)("span", {
                                    className: "w-2 h-2 bg-red-500 rounded-full animate-pulse"
                                }), t.length, " partida", 1 !== t.length ? "s" : ""]
                            })]
                        }), (0, a.jsx)("div", {
                            className: "relative overflow-hidden",
                            children: (0, a.jsx)("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 transition-all duration-300 ease-out ".concat(n ? "opacity-0 ".concat("right" === c ? "-translate-x-4" : "translate-x-4") : "opacity-100 translate-x-0"),
                                children: m.map((e, t) => {
                                    var s, l, r, i, n, o;
                                    let c = "IN_PROGRESS" === e.status,
                                        d = "COUNTDOWN" === e.status,
                                        x = (1.8 * e.betAmount).toFixed(0);
                                    return (0, a.jsxs)("div", {
                                        className: "relative overflow-hidden bg-pool-dark/50 rounded-xl p-4 border transition-all duration-300 ".concat(c ? "border-red-500/30" : "border-yellow-500/30"),
                                        style: {
                                            animationDelay: "".concat(30 * t, "ms")
                                        },
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center justify-between mb-3",
                                            children: [(0, a.jsxs)("div", {
                                                className: "flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-bold ".concat(c ? "bg-red-500/20 text-red-400" : "bg-yellow-500/20 text-yellow-400"),
                                                children: [c ? (0, a.jsx)($.Z, {
                                                    size: 10,
                                                    className: "fill-current"
                                                }) : (0, a.jsx)(v.Z, {
                                                    size: 10
                                                }), c ? "EM JOGO" : d ? "CONTAGEM" : "CONFIRMANDO"]
                                            }), c && (0, a.jsxs)("div", {
                                                className: "flex items-center gap-1 text-xs text-white/60",
                                                children: [(0, a.jsx)(v.Z, {
                                                    size: 10
                                                }), (0, a.jsx)("span", {
                                                    className: "font-mono",
                                                    children: function(e) {
                                                        if (!e) return "00:00";
                                                        let t = Math.floor((new Date().getTime() - new Date(e).getTime()) / 1e3);
                                                        return "".concat(Math.floor(t / 60).toString().padStart(2, "0"), ":").concat((t % 60).toString().padStart(2, "0"))
                                                    }(e.startedAt)
                                                })]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "flex items-center gap-2",
                                            children: [(0, a.jsxs)("div", {
                                                className: "flex-1 flex items-center gap-2",
                                                children: [(0, a.jsx)("div", {
                                                    className: "w-9 h-9 rounded-lg overflow-hidden ring-2 flex-shrink-0 ".concat(c ? "ring-red-500/40" : "ring-yellow-500/40"),
                                                    children: (0, a.jsx)(T.Z, {
                                                        username: null === (s = e.player1) || void 0 === s ? void 0 : s.username,
                                                        size: "sm"
                                                    })
                                                }), (0, a.jsxs)("div", {
                                                    className: "min-w-0",
                                                    children: [(0, a.jsx)("p", {
                                                        className: "text-xs font-medium text-white truncate",
                                                        title: null === (l = e.player1) || void 0 === l ? void 0 : l.username,
                                                        children: G(null === (r = e.player1) || void 0 === r ? void 0 : r.username)
                                                    }), (0, a.jsxs)("p", {
                                                        className: "text-[10px] text-pool-gold",
                                                        children: ["R$ ", e.betAmount.toFixed(0)]
                                                    })]
                                                })]
                                            }), (0, a.jsx)("div", {
                                                className: "w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ".concat(c ? "bg-red-500/20 text-red-400" : "bg-yellow-500/20 text-yellow-400"),
                                                children: (0, a.jsx)("span", {
                                                    className: "text-[10px] font-bold",
                                                    children: "VS"
                                                })
                                            }), (0, a.jsxs)("div", {
                                                className: "flex-1 flex items-center gap-2 justify-end",
                                                children: [(0, a.jsxs)("div", {
                                                    className: "min-w-0 text-right",
                                                    children: [(0, a.jsx)("p", {
                                                        className: "text-xs font-medium text-white truncate",
                                                        title: null === (i = e.player2) || void 0 === i ? void 0 : i.username,
                                                        children: G(null === (n = e.player2) || void 0 === n ? void 0 : n.username)
                                                    }), (0, a.jsxs)("p", {
                                                        className: "text-[10px] text-pool-gold",
                                                        children: ["R$ ", e.betAmount.toFixed(0)]
                                                    })]
                                                }), (0, a.jsx)("div", {
                                                    className: "w-9 h-9 rounded-lg overflow-hidden ring-2 flex-shrink-0 ".concat(c ? "ring-red-500/40" : "ring-yellow-500/40"),
                                                    children: (0, a.jsx)(T.Z, {
                                                        username: null === (o = e.player2) || void 0 === o ? void 0 : o.username,
                                                        size: "sm"
                                                    })
                                                })]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "mt-3 pt-2 border-t border-white/5 flex items-center justify-between",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-[10px] text-white/40 uppercase",
                                                children: "Premio"
                                            }), (0, a.jsxs)("span", {
                                                className: "text-sm font-bold ".concat(c ? "text-green-400" : "text-green-400/70"),
                                                children: ["R$ ", x]
                                            })]
                                        })]
                                    }, e.id)
                                })
                            })
                        }), x > 1 && (0, a.jsxs)("div", {
                            className: "flex items-center justify-center gap-3 mt-6 pt-4 border-t border-white/5",
                            children: [(0, a.jsx)("button", {
                                onClick: () => h(r - 1, "left"),
                                disabled: 0 === r || n,
                                className: "w-9 h-9 rounded-lg flex items-center justify-center transition-all ".concat(0 === r ? "bg-white/5 text-white/20 cursor-not-allowed" : "bg-white/10 text-white/60 hover:bg-white/20 hover:text-white"),
                                children: (0, a.jsx)(R.Z, {
                                    size: 18
                                })
                            }), (0, a.jsx)("div", {
                                className: "flex items-center gap-1.5",
                                children: Array.from({
                                    length: x
                                }).map((e, t) => (0, a.jsx)("button", {
                                    onClick: () => {
                                        t !== r && h(t, t > r ? "right" : "left")
                                    },
                                    disabled: n,
                                    className: "transition-all duration-200 rounded-full ".concat(t === r ? "w-6 h-2 bg-gradient-to-r from-orange-500 to-red-500" : "w-2 h-2 bg-white/20 hover:bg-white/40")
                                }, t))
                            }), (0, a.jsx)("button", {
                                onClick: () => h(r + 1, "right"),
                                disabled: r === x - 1 || n,
                                className: "w-9 h-9 rounded-lg flex items-center justify-center transition-all ".concat(r === x - 1 ? "bg-white/5 text-white/20 cursor-not-allowed" : "bg-white/10 text-white/60 hover:bg-white/20 hover:text-white"),
                                children: (0, a.jsx)(F.Z, {
                                    size: 18
                                })
                            }), (0, a.jsxs)("span", {
                                className: "text-xs text-white/40 ml-2",
                                children: [r + 1, " / ", x]
                            })]
                        })]
                    })
                }),
                J = [{
                    label: "Todas",
                    min: 0,
                    max: 1e4
                }, {
                    label: "R$ 5-10",
                    min: 5,
                    max: 10
                }, {
                    label: "R$ 10-50",
                    min: 10,
                    max: 50
                }, {
                    label: "R$ 50-100",
                    min: 50,
                    max: 100
                }, {
                    label: "R$ 100+",
                    min: 100,
                    max: 1e4
                }],
                W = [5, 10, 25, 50, 100, 200];

            function X() {
                let e = (0, r.useRouter)(),
                    {
                        user: t,
                        isAuthenticated: s,
                        isLoading: P,
                        checkAuth: M,
                        updateBalance: A
                    } = (0, i.tN)(),
                    {
                        rooms: R,
                        activeMatches: F,
                        platformSettings: I,
                        isLoading: $,
                        refresh: L
                    } = function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            {
                                enabled: t = !0,
                                pollInterval: s = 5e3,
                                settingsInterval: a = 3e4
                            } = e,
                            [r, i] = (0, l.useState)([]),
                            [n, c] = (0, l.useState)([]),
                            [d, x] = (0, l.useState)(null),
                            [m, h] = (0, l.useState)(!0),
                            u = (0, l.useRef)(!0),
                            p = (0, l.useCallback)(async () => {
                                if (u.current) try {
                                    let e = await o.h.getRooms();
                                    if (e.data && u.current) {
                                        let t = e.data.map(e => ({ ...e,
                                            betAmount: Number(e.betAmount)
                                        }));
                                        i(t)
                                    }
                                } catch (e) {
                                    console.error("Error loading rooms:", e)
                                }
                            }, []),
                            b = (0, l.useCallback)(async () => {
                                if (u.current) try {
                                    let e = await o.h.getActiveMatches();
                                    if (e.data && u.current) {
                                        let t = e.data.map(e => ({ ...e,
                                            betAmount: Number(e.betAmount)
                                        }));
                                        c(t)
                                    } else u.current && c([])
                                } catch (e) {
                                    console.error("Error loading active matches:", e), u.current && c([])
                                }
                            }, []),
                            g = (0, l.useCallback)(async () => {
                                if (u.current) try {
                                    let e = await o.h.getPlatformStatus();
                                    e.data && u.current ? x(e.data) : u.current && x({
                                        roomCreationEnabled: !0,
                                        maintenanceMode: !1,
                                        rankingEnabled: !0
                                    })
                                } catch (e) {
                                    u.current && x({
                                        roomCreationEnabled: !0,
                                        maintenanceMode: !1,
                                        rankingEnabled: !0
                                    })
                                }
                            }, []),
                            f = (0, l.useCallback)(async () => {
                                h(!0), await Promise.all([p(), b()]), h(!1)
                            }, [p, b]),
                            j = (0, l.useCallback)(async () => {
                                await g()
                            }, [g]);
                        return (0, l.useEffect)(() => {
                            if (u.current = !0, !t) return;
                            (async () => {
                                h(!0), await Promise.all([p(), b(), g()]), h(!1)
                            })();
                            let e = setInterval(() => {
                                    p(), b()
                                }, s),
                                l = setInterval(g, a);
                            return () => {
                                u.current = !1, clearInterval(e), clearInterval(l)
                            }
                        }, [t, s, a, p, b, g]), {
                            rooms: r,
                            activeMatches: n,
                            platformSettings: d,
                            isLoading: m,
                            refresh: f,
                            refreshSettings: j
                        }
                    }({
                        enabled: s
                    }),
                    [O, U] = (0, l.useState)(!1),
                    [G, X] = (0, l.useState)(!1),
                    [K, Y] = (0, l.useState)(10),
                    [Q, ee] = (0, l.useState)(null),
                    [et, es] = (0, l.useState)(""),
                    [ea, el] = (0, l.useState)(""),
                    [er, ei] = (0, l.useState)(0),
                    [en, eo] = (0, l.useState)(!1),
                    [ec, ed] = (0, l.useState)(0),
                    [ex, em] = (0, l.useState)(1e4),
                    [eh, eu] = (0, l.useState)("all"),
                    [ep, eb] = (0, l.useState)(!1),
                    [eg, ef] = (0, l.useState)(""),
                    [ej, ew] = (0, l.useState)([]),
                    [ev, ey] = (0, l.useState)(!1),
                    [eN, ek] = (0, l.useState)(!1),
                    [eZ, eC] = (0, l.useState)(""),
                    [ez, eS] = (0, l.useState)(""),
                    [eP, eM] = (0, l.useState)(!1),
                    [eA, eR] = (0, l.useState)(""),
                    [eF, eI] = (0, l.useState)(null),
                    [eE, eD] = (0, l.useState)(!1),
                    [eT, e$] = (0, l.useState)(""),
                    [eL, eO] = (0, l.useState)(!1),
                    [eq, eB] = (0, l.useState)(!1),
                    [eV, e_] = (0, l.useState)(null),
                    [eU, eG] = (0, l.useState)(""),
                    [eH, eJ] = (0, l.useState)(!1),
                    [eW, eX] = (0, l.useState)(!1),
                    [eK, eY] = (0, l.useState)(""),
                    [eQ, e0] = (0, l.useState)(!1),
                    [e1, e2] = (0, l.useState)(!1),
                    [e4, e5] = (0, l.useState)(!1),
                    [e3, e6] = (0, l.useState)(0),
                    [e7, e8] = (0, l.useState)(!1),
                    [e9, te] = (0, l.useState)("right"),
                    tt = () => {
                        e0(!0), setTimeout(() => {
                            X(!1), e0(!1), es("")
                        }, 200)
                    },
                    ts = () => {
                        e2(!0), setTimeout(() => {
                            ek(!1), e2(!1), td()
                        }, 200)
                    },
                    ta = () => {
                        e5(!0), setTimeout(() => {
                            eB(!1), e5(!1), e_(null), eG(""), eY("")
                        }, 200)
                    };
                (0, l.useEffect)(() => {
                    let e = n.g.getState();
                    (e.gameOver || e.roomFinished || e.gameStarted) && e.reset()
                }, []), (0, l.useEffect)(() => {
                    M()
                }, [M]), (0, l.useEffect)(() => {
                    P || s || e.push("/login")
                }, [P, s, e]), (0, l.useEffect)(() => {
                    s && !P && "true" !== localStorage.getItem(q) && eb(!0)
                }, [s, P]);
                let tl = async () => {
                        if (!t) return;
                        if (t.balance < K) {
                            es("Saldo insuficiente");
                            return
                        }
                        if (eE && (!eT || eT.length < 4)) {
                            es("Salas privadas requerem uma senha de no m\xednimo 4 caracteres");
                            return
                        }
                        U(!0), es("");
                        let s = await o.h.createRoom(K, eE, eE ? eT : void 0);
                        if (s.error) {
                            es(s.error), U(!1);
                            return
                        }
                        s.data && ((0, V.mY)({
                            roomId: s.data.id,
                            betAmount: K,
                            userId: t.id
                        }), eD(!1), e$(""), eO(!1), X(!1), e.push("/room/".concat(s.data.id)))
                    },
                    tr = async s => {
                        if (!t) return;
                        let a = R.find(e => e.id === s);
                        if (!a) return;
                        if (t.balance < a.betAmount) {
                            es("Saldo insuficiente para entrar nesta sala");
                            return
                        }
                        ee(s), es("");
                        let l = await o.h.joinRoom(s);
                        if (l.error) {
                            es(l.error), ee(null);
                            return
                        }
                        l.data && (A(t.balance - a.betAmount), e.push("/room/".concat(s)))
                    },
                    ti = e => {
                        ei(e), ed(J[e].min), em(J[e].max)
                    },
                    tn = async e => {
                        if (ef(e), e.trim().length < 2) {
                            ew([]);
                            return
                        }
                        ey(!0);
                        let t = await o.h.searchRooms(e);
                        t.data && ew(t.data.map(e => ({ ...e,
                            betAmount: Number(e.betAmount)
                        }))), ey(!1)
                    },
                    to = async () => {
                        if (6 !== eZ.trim().length) {
                            eR("O c\xf3digo deve ter 6 caracteres");
                            return
                        }
                        eM(!0), eR("");
                        let e = await o.h.getRoomByCode(eZ);
                        if (e.error) {
                            eR(e.error), eM(!1);
                            return
                        }
                        if (e.data) {
                            let t = { ...e.data,
                                betAmount: Number(e.data.betAmount)
                            };
                            eI(t), t.isPrivate || tc(t.id)
                        }
                        eM(!1)
                    },
                    tc = async s => {
                        if (!t) return;
                        eM(!0), eR("");
                        let a = await o.h.joinRoomByCode(eZ, (null == eF ? void 0 : eF.isPrivate) ? ez : void 0);
                        if (a.error) {
                            eR(a.error), eM(!1);
                            return
                        }
                        if (a.data) {
                            var l;
                            ek(!1), e.push("/room/".concat((null === (l = a.data.room) || void 0 === l ? void 0 : l.id) || s))
                        }
                    },
                    td = () => {
                        eC(""), eS(""), eR(""), eI(null)
                    },
                    tx = e => {
                        e_(e), eG(""), eY(""), eB(!0)
                    },
                    tm = async () => {
                        if (!eV || !t) return;
                        if (!eU) {
                            eY("Digite a senha da sala");
                            return
                        }
                        eX(!0), eY("");
                        let s = await o.h.joinRoomByCode(eV.roomCode || "", eU);
                        if (s.error) {
                            eY(s.error), eX(!1);
                            return
                        }
                        s.data && (eB(!1), e.push("/room/".concat(eV.id)))
                    },
                    th = (0, l.useMemo)(() => R.filter(e => {
                        let t = Number(e.betAmount),
                            s = t >= ec && t <= ex,
                            a = "all" === eh || "public" === eh && !e.isPrivate || "private" === eh && e.isPrivate;
                        return s && a
                    }).sort((e, t) => e.isPrivate !== t.isPrivate ? e.isPrivate ? 1 : -1 : new Date(t.createdAt).getTime() - new Date(e.createdAt).getTime()), [R, ec, ex, eh]),
                    tu = (0, l.useMemo)(() => R.filter(e => e.creator.id === (null == t ? void 0 : t.id)), [R, null == t ? void 0 : t.id]),
                    tp = (0, l.useMemo)(() => th.filter(e => e.creator.id !== (null == t ? void 0 : t.id)), [th, null == t ? void 0 : t.id]),
                    tb = e => {
                        let t = Math.floor((new Date().getTime() - new Date(e).getTime()) / 1e3);
                        if (t < 60) return "agora";
                        let s = Math.floor(t / 60);
                        return s < 60 ? "".concat(s, "min") : "".concat(Math.floor(s / 60), "h")
                    };
                return P || !t ? (0, a.jsx)("div", {
                    className: "min-h-screen flex items-center justify-center",
                    children: (0, a.jsx)(c.Z, {
                        size: 40,
                        className: "animate-spin text-pool-gold"
                    })
                }) : (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(B, {
                        isOpen: ep,
                        onClose: () => eb(!1)
                    }), (0, a.jsx)(S.Z, {}), (0, a.jsxs)("main", {
                        className: "min-h-screen p-4 md:p-8 max-w-7xl mx-auto",
                        children: [(0, a.jsx)("div", {
                            className: "mb-8",
                            children: (0, a.jsx)(E, {})
                        }), et && (0, a.jsxs)("div", {
                            className: "bg-red-500/20 border border-red-500/30 rounded-xl p-4 mb-6 flex items-center justify-between",
                            children: [(0, a.jsx)("p", {
                                className: "text-red-300 text-sm",
                                children: et
                            }), (0, a.jsx)("button", {
                                onClick: () => es(""),
                                className: "text-red-300 hover:text-red-200",
                                children: (0, a.jsx)(d.Z, {
                                    size: 18
                                })
                            })]
                        }), ea && (0, a.jsxs)("div", {
                            className: "bg-green-500/20 border border-green-500/30 rounded-xl p-4 mb-6 flex items-center justify-between",
                            children: [(0, a.jsx)("p", {
                                className: "text-green-300 text-sm",
                                children: ea
                            }), (0, a.jsx)("button", {
                                onClick: () => el(""),
                                className: "text-green-300 hover:text-green-200",
                                children: (0, a.jsx)(d.Z, {
                                    size: 18
                                })
                            })]
                        }), (null == I ? void 0 : I.maintenanceMode) && (0, a.jsxs)("div", {
                            className: "bg-red-500/20 border border-red-500/30 rounded-xl p-4 mb-6 flex items-center gap-3",
                            children: [(0, a.jsx)(x, {
                                className: "w-5 h-5 text-red-400 flex-shrink-0"
                            }), (0, a.jsxs)("div", {
                                children: [(0, a.jsx)("p", {
                                    className: "text-red-300 font-semibold",
                                    children: "Plataforma em Manuten\xe7\xe3o"
                                }), (0, a.jsx)("p", {
                                    className: "text-red-300/80 text-sm",
                                    children: "Novas partidas n\xe3o podem ser criadas no momento. Tente novamente mais tarde."
                                })]
                            })]
                        }), !(null == I ? void 0 : I.maintenanceMode) && (null == I ? void 0 : I.roomCreationEnabled) === !1 && (0, a.jsxs)("div", {
                            className: "bg-yellow-500/20 border border-yellow-500/30 rounded-xl p-4 mb-6 flex items-center gap-3",
                            children: [(0, a.jsx)(m.Z, {
                                className: "w-5 h-5 text-yellow-400 flex-shrink-0"
                            }), (0, a.jsxs)("div", {
                                children: [(0, a.jsx)("p", {
                                    className: "text-yellow-300 font-semibold",
                                    children: "Cria\xe7\xe3o de Partidas Desabilitada"
                                }), (0, a.jsx)("p", {
                                    className: "text-yellow-300/80 text-sm",
                                    children: "A cria\xe7\xe3o de novas partidas est\xe1 temporariamente desabilitada. Voc\xea ainda pode entrar em salas existentes."
                                })]
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6",
                            children: [(0, a.jsxs)("div", {
                                children: [(0, a.jsx)("h1", {
                                    className: "font-display text-2xl md:text-3xl font-bold",
                                    children: "Salas de Jogo"
                                }), (0, a.jsxs)("p", {
                                    className: "text-white/60 text-sm mt-1",
                                    children: [tp.length, " sala(s) dispon\xedvel(is) • Atualiza\xe7\xe3o autom\xe1tica"]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, a.jsx)("button", {
                                    onClick: L,
                                    disabled: $,
                                    className: "p-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-all",
                                    title: "Atualizar",
                                    children: (0, a.jsx)(h.Z, {
                                        size: 18,
                                        className: $ ? "animate-spin text-pool-gold" : "text-white/60"
                                    })
                                }), (0, a.jsxs)("button", {
                                    onClick: () => {
                                        td(), ek(!0)
                                    },
                                    className: "hidden sm:flex items-center gap-2 px-3 py-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-all text-sm text-white/60 hover:text-white",
                                    title: "Conectar por C\xf3digo",
                                    children: [(0, a.jsx)(u.Z, {
                                        size: 16
                                    }), (0, a.jsx)("span", {
                                        className: "hidden md:inline",
                                        children: "C\xf3digo"
                                    })]
                                }), (0, a.jsx)("button", {
                                    onClick: () => {
                                        td(), ek(!0)
                                    },
                                    className: "sm:hidden p-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-all",
                                    title: "Conectar por C\xf3digo",
                                    children: (0, a.jsx)(u.Z, {
                                        size: 18,
                                        className: "text-white/60"
                                    })
                                }), (0, a.jsxs)("button", {
                                    onClick: () => X(!0),
                                    disabled: (null == I ? void 0 : I.maintenanceMode) || (null == I ? void 0 : I.roomCreationEnabled) === !1,
                                    className: "btn-primary flex items-center gap-2 px-4 sm:px-6 py-2.5 disabled:opacity-50 disabled:cursor-not-allowed",
                                    title: (null == I ? void 0 : I.maintenanceMode) ? "Plataforma em manuten\xe7\xe3o" : (null == I ? void 0 : I.roomCreationEnabled) === !1 ? "Cria\xe7\xe3o de partidas desabilitada" : "Criar nova sala",
                                    children: [(0, a.jsx)(p.Z, {
                                        size: 18
                                    }), (0, a.jsx)("span", {
                                        children: "Criar Sala"
                                    })]
                                })]
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "bg-pool-dark/80 backdrop-blur-sm rounded-2xl border border-white/10 p-3 sm:p-4 mb-6",
                            children: [(0, a.jsx)("div", {
                                className: "flex gap-2 sm:gap-3 mb-3",
                                children: (0, a.jsxs)("div", {
                                    className: "flex-1 relative",
                                    children: [(0, a.jsx)(b.Z, {
                                        size: 16,
                                        className: "absolute left-3 top-1/2 -translate-y-1/2 text-white/40"
                                    }), (0, a.jsx)("input", {
                                        type: "text",
                                        value: eg,
                                        onChange: e => tn(e.target.value),
                                        placeholder: "Buscar c\xf3digo ou @username...",
                                        className: "w-full bg-white/5 border border-white/10 rounded-xl pl-9 pr-3 py-2.5 text-sm focus:outline-none focus:border-pool-gold/50 focus:bg-white/10 transition-all placeholder:text-white/30"
                                    }), ev && (0, a.jsx)(c.Z, {
                                        size: 14,
                                        className: "absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-pool-gold"
                                    })]
                                })
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-2 overflow-x-auto scrollbar-hide -mx-1 px-1",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center bg-white/5 rounded-lg p-0.5 flex-shrink-0",
                                    children: [(0, a.jsx)("button", {
                                        onClick: () => eu("all"),
                                        className: "px-3 py-1.5 rounded-md text-xs font-medium transition-all ".concat("all" === eh ? "bg-pool-gold text-pool-dark" : "text-white/60 hover:text-white"),
                                        children: "Todas"
                                    }), (0, a.jsxs)("button", {
                                        onClick: () => eu("public"),
                                        className: "px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1 ".concat("public" === eh ? "bg-pool-gold text-pool-dark" : "text-white/60 hover:text-white"),
                                        children: [(0, a.jsx)(g.Z, {
                                            size: 12
                                        }), "P\xfablicas"]
                                    }), (0, a.jsxs)("button", {
                                        onClick: () => eu("private"),
                                        className: "px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1 ".concat("private" === eh ? "bg-pool-gold text-pool-dark" : "text-white/60 hover:text-white"),
                                        children: [(0, a.jsx)(f.Z, {
                                            size: 12
                                        }), "Privadas"]
                                    })]
                                }), (0, a.jsx)("div", {
                                    className: "w-px h-6 bg-white/10 flex-shrink-0"
                                }), (0, a.jsx)("div", {
                                    className: "flex items-center gap-1.5 flex-shrink-0",
                                    children: J.map((e, t) => (0, a.jsx)("button", {
                                        onClick: () => ti(t),
                                        className: "px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ".concat(er === t ? "bg-white/20 text-white ring-1 ring-white/20" : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white/80"),
                                        children: e.label
                                    }, t))
                                }), (0, a.jsx)("button", {
                                    onClick: () => eo(!en),
                                    className: "ml-auto flex-shrink-0 p-2 rounded-lg transition-all ".concat(en ? "bg-pool-gold/20 text-pool-gold" : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"),
                                    title: "Filtro avan\xe7ado",
                                    children: (0, a.jsx)(j.Z, {
                                        size: 14
                                    })
                                })]
                            }), eg.trim().length >= 2 && (0, a.jsx)("div", {
                                className: "mt-3 pt-3 border-t border-white/10",
                                children: 0 === ej.length ? (0, a.jsxs)("p", {
                                    className: "text-white/40 text-xs text-center py-3",
                                    children: ['Nenhuma sala encontrada para "', eg, '"']
                                }) : (0, a.jsx)("div", {
                                    className: "space-y-1.5 max-h-48 overflow-y-auto",
                                    children: ej.map(e => (0, a.jsxs)("div", {
                                        className: "flex items-center justify-between rounded-lg p-2.5 transition-colors ".concat(e.isPrivate ? "bg-yellow-500/10 hover:bg-yellow-500/15 border border-yellow-500/20" : "bg-white/5 hover:bg-white/10"),
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2.5",
                                            children: [(0, a.jsxs)("div", {
                                                className: "flex items-center gap-1.5",
                                                children: [(0, a.jsx)("span", {
                                                    className: "text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ".concat(e.isPrivate ? "bg-yellow-500/20 text-yellow-400" : "bg-pool-gold/20 text-pool-gold"),
                                                    children: e.roomCode
                                                }), e.isPrivate && (0, a.jsx)(f.Z, {
                                                    size: 10,
                                                    className: "text-yellow-400"
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                children: [(0, a.jsxs)("p", {
                                                    className: "text-xs font-medium",
                                                    children: ["@", e.creator.username]
                                                }), (0, a.jsxs)("p", {
                                                    className: "text-[10px] text-white/40",
                                                    children: ["R$ ", e.betAmount.toFixed(0)]
                                                })]
                                            })]
                                        }), (0, a.jsx)("button", {
                                            onClick: () => {
                                                e.isPrivate ? (tx(e), ef(""), ew([])) : tr(e.id)
                                            },
                                            disabled: Q === e.id || t.balance < e.betAmount,
                                            className: "text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ".concat(t.balance < e.betAmount ? "bg-white/10 text-white/30" : e.isPrivate ? "bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/30" : "bg-pool-gold hover:bg-pool-gold/90 text-pool-dark"),
                                            children: Q === e.id ? (0, a.jsx)(c.Z, {
                                                size: 12,
                                                className: "animate-spin"
                                            }) : e.isPrivate ? (0, a.jsxs)(a.Fragment, {
                                                children: [(0, a.jsx)(f.Z, {
                                                    size: 10
                                                }), "Senha"]
                                            }) : "Entrar"
                                        })]
                                    }, e.id))
                                })
                            }), en && (0, a.jsxs)("div", {
                                className: "mt-3 pt-3 border-t border-white/10",
                                children: [(0, a.jsxs)("div", {
                                    className: "grid grid-cols-2 gap-3",
                                    children: [(0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("label", {
                                            className: "block text-[10px] uppercase tracking-wide text-white/40 mb-1.5",
                                            children: "M\xednimo"
                                        }), (0, a.jsxs)("div", {
                                            className: "relative",
                                            children: [(0, a.jsx)("span", {
                                                className: "absolute left-2.5 top-1/2 -translate-y-1/2 text-white/30 text-xs",
                                                children: "R$"
                                            }), (0, a.jsx)("input", {
                                                type: "number",
                                                value: ec,
                                                onChange: e => {
                                                    ed(Number(e.target.value)), ei(-1)
                                                },
                                                min: "0",
                                                className: "w-full bg-white/5 border border-white/10 rounded-lg pl-8 pr-3 py-2 text-sm focus:outline-none focus:border-pool-gold/50 transition-colors"
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("label", {
                                            className: "block text-[10px] uppercase tracking-wide text-white/40 mb-1.5",
                                            children: "M\xe1ximo"
                                        }), (0, a.jsxs)("div", {
                                            className: "relative",
                                            children: [(0, a.jsx)("span", {
                                                className: "absolute left-2.5 top-1/2 -translate-y-1/2 text-white/30 text-xs",
                                                children: "R$"
                                            }), (0, a.jsx)("input", {
                                                type: "number",
                                                value: ex,
                                                onChange: e => {
                                                    em(Number(e.target.value)), ei(-1)
                                                },
                                                min: "0",
                                                className: "w-full bg-white/5 border border-white/10 rounded-lg pl-8 pr-3 py-2 text-sm focus:outline-none focus:border-pool-gold/50 transition-colors"
                                            })]
                                        })]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "mt-2 flex items-center justify-between",
                                    children: [(0, a.jsxs)("p", {
                                        className: "text-white/30 text-[10px]",
                                        children: [th.length, " de ", R.length, " sala(s)"]
                                    }), (0, a.jsx)("button", {
                                        onClick: () => {
                                            ti(0), eu("all")
                                        },
                                        className: "text-[10px] text-pool-gold hover:underline",
                                        children: "Limpar filtros"
                                    })]
                                })]
                            })]
                        }), tu.length > 0 && (0, a.jsxs)("div", {
                            className: "mb-6",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-2 mb-4",
                                children: [(0, a.jsx)("div", {
                                    className: "w-8 h-8 rounded-lg bg-pool-gold/20 flex items-center justify-center",
                                    children: (0, a.jsx)(w.Z, {
                                        size: 16,
                                        className: "text-pool-gold"
                                    })
                                }), (0, a.jsx)("h2", {
                                    className: "font-display text-lg font-bold",
                                    children: "Minhas Salas"
                                }), (0, a.jsx)("span", {
                                    className: "text-xs text-white/40 bg-white/5 px-2 py-1 rounded-full ml-2",
                                    children: tu.length
                                })]
                            }), (0, a.jsx)("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4",
                                children: tu.map(t => (0, a.jsxs)("div", {
                                    onClick: () => e.push("/room/".concat(t.id)),
                                    className: "card cursor-pointer transition-all group ".concat(t.isPrivate ? "border-yellow-500/30 bg-gradient-to-br from-yellow-500/10 to-transparent hover:border-yellow-500/50" : "border-pool-gold/30 bg-gradient-to-br from-pool-gold/10 to-transparent hover:border-pool-gold/50"),
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center justify-between mb-3",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-xs px-2 py-1 rounded-full ".concat(t.isPrivate ? "text-yellow-400 bg-yellow-500/20" : "text-pool-gold bg-pool-gold/20"),
                                                children: "Sua Sala"
                                            }), t.isPrivate && (0, a.jsxs)("span", {
                                                className: "flex items-center gap-1 text-[10px] text-yellow-400/80",
                                                children: [(0, a.jsx)(f.Z, {
                                                    size: 10
                                                }), "Privada"]
                                            })]
                                        }), (0, a.jsxs)("span", {
                                            className: "text-xs text-white/40 flex items-center gap-1",
                                            children: [(0, a.jsx)(v.Z, {
                                                size: 12
                                            }), tb(t.createdAt)]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 mb-3",
                                        children: [(0, a.jsx)("div", {
                                            className: "w-12 h-12 rounded-xl flex items-center justify-center ".concat(t.isPrivate ? "bg-yellow-500/20" : "bg-pool-gold/20"),
                                            children: t.isPrivate ? (0, a.jsx)(f.Z, {
                                                size: 24,
                                                className: "text-yellow-400"
                                            }) : (0, a.jsx)("span", {
                                                className: "text-2xl",
                                                children: "\uD83C\uDFB1"
                                            })
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsxs)("p", {
                                                className: "text-2xl font-bold ".concat(t.isPrivate ? "text-yellow-400" : "text-pool-gold"),
                                                children: ["R$ ", Number(t.betAmount).toFixed(0)]
                                            }), (0, a.jsxs)("div", {
                                                className: "flex items-center gap-2",
                                                children: [t.roomCode && (0, a.jsx)("span", {
                                                    className: "text-[10px] font-mono text-white/50 bg-white/5 px-1.5 py-0.5 rounded",
                                                    children: t.roomCode
                                                }), (0, a.jsx)("span", {
                                                    className: "text-xs text-white/40",
                                                    children: "Aguardando..."
                                                })]
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex items-center justify-center gap-2 text-sm font-medium group-hover:gap-3 transition-all ".concat(t.isPrivate ? "text-yellow-400" : "text-pool-gold"),
                                        children: [(0, a.jsx)("span", {
                                            children: "Acessar Sala"
                                        }), (0, a.jsx)(y.Z, {
                                            size: 16
                                        })]
                                    })]
                                }, t.id))
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "card",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center justify-between mb-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center",
                                        children: (0, a.jsx)(g.Z, {
                                            size: 20,
                                            className: "text-blue-400"
                                        })
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("h2", {
                                            className: "font-display text-lg font-bold",
                                            children: "Salas Dispon\xedveis"
                                        }), (0, a.jsx)("p", {
                                            className: "text-white/60 text-sm",
                                            children: "Escolha uma sala para jogar"
                                        })]
                                    })]
                                }), tp.length > 0 && (0, a.jsxs)("span", {
                                    className: "text-xs text-white/40 bg-white/5 px-3 py-1.5 rounded-full",
                                    children: [tp.length, " sala(s)"]
                                })]
                            }), $ ? (0, a.jsxs)("div", {
                                className: "flex flex-col items-center justify-center py-16",
                                children: [(0, a.jsx)(c.Z, {
                                    size: 40,
                                    className: "animate-spin text-pool-gold mb-4"
                                }), (0, a.jsx)("p", {
                                    className: "text-white/60",
                                    children: "Carregando salas..."
                                })]
                            }) : 0 === tp.length ? (0, a.jsxs)("div", {
                                className: "text-center py-16",
                                children: [(0, a.jsx)("div", {
                                    className: "w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4",
                                    children: (0, a.jsx)("span", {
                                        className: "text-4xl",
                                        children: "\uD83C\uDFB1"
                                    })
                                }), (0, a.jsx)("p", {
                                    className: "text-white/60 font-medium mb-1",
                                    children: 0 === R.length ? "Nenhuma sala dispon\xedvel" : "Nenhuma sala neste filtro"
                                }), (0, a.jsx)("p", {
                                    className: "text-white/40 text-sm mb-6",
                                    children: 0 === R.length ? "Seja o primeiro a criar uma sala!" : "Tente ajustar os filtros"
                                }), (0, a.jsxs)("button", {
                                    onClick: () => X(!0),
                                    className: "btn-primary inline-flex items-center gap-2",
                                    children: [(0, a.jsx)(p.Z, {
                                        size: 20
                                    }), "Criar Nova Sala"]
                                })]
                            }) : (0, a.jsx)("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4",
                                children: tp.map(e => (0, a.jsx)(_, {
                                    room: e,
                                    userBalance: t.balance,
                                    isJoining: Q === e.id,
                                    onJoin: tr,
                                    onRequestPassword: tx
                                }, e.id))
                            })]
                        }), (0, a.jsx)(H, {
                            matches: F
                        })]
                    }), G && (0, a.jsx)("div", {
                        className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50",
                        style: {
                            animation: eQ ? "backdropFadeOut 0.2s ease-out forwards" : "backdropFadeIn 0.2s ease-out"
                        },
                        onClick: tt,
                        children: (0, a.jsxs)("div", {
                            className: "card w-full max-w-md",
                            style: {
                                animation: eQ ? "modalSlideDown 0.2s ease-out forwards" : "modalSlideUp 0.3s ease-out"
                            },
                            onClick: e => e.stopPropagation(),
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center justify-between mb-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-10 h-10 rounded-lg bg-pool-gold/20 flex items-center justify-center",
                                        children: (0, a.jsx)(p.Z, {
                                            size: 20,
                                            className: "text-pool-gold"
                                        })
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("h2", {
                                            className: "text-lg font-bold text-white",
                                            children: "Nova Partida"
                                        }), (0, a.jsx)("p", {
                                            className: "text-xs text-white/50",
                                            children: "Configure sua sala"
                                        })]
                                    })]
                                }), (0, a.jsx)("button", {
                                    onClick: tt,
                                    className: "w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors",
                                    children: (0, a.jsx)(d.Z, {
                                        size: 16,
                                        className: "text-white/60"
                                    })
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center justify-between py-2.5 px-3 bg-white/5 rounded-lg mb-5 border border-white/5",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-2 text-white/60",
                                    children: [(0, a.jsx)(N.Z, {
                                        size: 14
                                    }), (0, a.jsx)("span", {
                                        className: "text-xs",
                                        children: "Saldo dispon\xedvel"
                                    })]
                                }), (0, a.jsxs)("span", {
                                    className: "text-sm font-bold text-pool-gold",
                                    children: ["R$ ", Number(t.balance).toFixed(2)]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mb-5",
                                children: [(0, a.jsx)("label", {
                                    className: "block text-xs text-white/60 mb-2",
                                    children: "Valor da Aposta"
                                }), (0, a.jsx)("div", {
                                    className: "grid grid-cols-3 gap-1.5 mb-3",
                                    children: W.map(e => (0, a.jsxs)("button", {
                                        onClick: () => Y(e),
                                        disabled: e > t.balance,
                                        className: "py-2 rounded-lg text-sm font-semibold transition-all ".concat(K === e ? "bg-pool-gold text-pool-dark" : e > t.balance ? "bg-white/5 text-white/20 cursor-not-allowed" : "bg-white/5 text-white/70 hover:bg-white/10 hover:text-white"),
                                        children: ["R$ ", e]
                                    }, e))
                                }), (0, a.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, a.jsx)("span", {
                                        className: "absolute left-3 top-1/2 -translate-y-1/2 text-white/40 text-sm",
                                        children: "R$"
                                    }), (0, a.jsx)("input", {
                                        type: "number",
                                        value: K,
                                        onChange: e => Y(Number(e.target.value)),
                                        className: "input-field pl-10 text-center text-lg font-bold",
                                        min: 5,
                                        max: t.balance
                                    })]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mb-5",
                                children: [(0, a.jsx)("label", {
                                    className: "block text-xs text-white/60 mb-2",
                                    children: "Tipo de Sala"
                                }), (0, a.jsxs)("div", {
                                    className: "flex bg-white/5 rounded-lg p-1 border border-white/10",
                                    children: [(0, a.jsxs)("button", {
                                        onClick: () => eD(!1),
                                        className: "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-sm font-medium transition-all ".concat(eE ? "text-white/60 hover:text-white" : "bg-pool-gold text-pool-dark"),
                                        children: [(0, a.jsx)(g.Z, {
                                            size: 16
                                        }), "P\xfablica"]
                                    }), (0, a.jsxs)("button", {
                                        onClick: () => eD(!0),
                                        className: "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-sm font-medium transition-all ".concat(eE ? "bg-yellow-500 text-pool-dark" : "text-white/60 hover:text-white"),
                                        children: [(0, a.jsx)(f.Z, {
                                            size: 16
                                        }), "Privada"]
                                    })]
                                }), eE && (0, a.jsxs)("div", {
                                    className: "mt-3",
                                    children: [(0, a.jsxs)("div", {
                                        className: "relative",
                                        children: [(0, a.jsx)(f.Z, {
                                            size: 16,
                                            className: "absolute left-3 top-1/2 -translate-y-1/2 text-white/30"
                                        }), (0, a.jsx)("input", {
                                            type: eL ? "text" : "password",
                                            value: eT,
                                            onChange: e => e$(e.target.value),
                                            placeholder: "Senha (m\xedn. 4 caracteres)",
                                            className: "input-field pl-10 pr-10",
                                            minLength: 4,
                                            maxLength: 20
                                        }), (0, a.jsx)("button", {
                                            type: "button",
                                            onClick: () => eO(!eL),
                                            className: "absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60",
                                            children: eL ? (0, a.jsx)(k.Z, {
                                                size: 16
                                            }) : (0, a.jsx)(Z.Z, {
                                                size: 16
                                            })
                                        })]
                                    }), eT && eT.length > 0 && eT.length < 4 && (0, a.jsx)("p", {
                                        className: "text-xs text-red-400 mt-1.5",
                                        children: "M\xednimo 4 caracteres"
                                    })]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "bg-white/5 rounded-lg p-4 border border-white/10 mb-5",
                                children: [(0, a.jsxs)("div", {
                                    className: "grid grid-cols-3 gap-3 text-center mb-3",
                                    children: [(0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("p", {
                                            className: "text-[10px] text-white/40 uppercase mb-1",
                                            children: "Sua Aposta"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-sm font-bold text-white",
                                            children: ["R$ ", K]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("p", {
                                            className: "text-[10px] text-white/40 uppercase mb-1",
                                            children: "Taxa (10%)"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-sm font-bold text-red-400",
                                            children: ["-R$ ", (.2 * K).toFixed(0)]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("p", {
                                            className: "text-[10px] text-white/40 uppercase mb-1",
                                            children: "Pr\xeamio"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-sm font-bold text-green-400",
                                            children: ["R$ ", (1.8 * K).toFixed(0)]
                                        })]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "flex items-center justify-center gap-2 pt-3 border-t border-white/10",
                                    children: [(0, a.jsx)(C.Z, {
                                        size: 14,
                                        className: "text-green-400"
                                    }), (0, a.jsxs)("span", {
                                        className: "text-xs text-white/60",
                                        children: ["O vencedor leva ", (0, a.jsxs)("strong", {
                                            className: "text-green-400",
                                            children: ["R$ ", (1.8 * K).toFixed(0)]
                                        })]
                                    })]
                                })]
                            }), K > t.balance && (0, a.jsxs)("div", {
                                className: "flex items-center gap-2 bg-red-500/10 rounded-lg p-3 mb-4 border border-red-500/20",
                                children: [(0, a.jsx)(m.Z, {
                                    size: 16,
                                    className: "text-red-400 flex-shrink-0"
                                }), (0, a.jsxs)("p", {
                                    className: "text-xs text-red-300",
                                    children: ["Saldo insuficiente. Faltam R$ ", (K - t.balance).toFixed(2)]
                                })]
                            }), et && (0, a.jsxs)("div", {
                                className: "flex items-center gap-2 bg-red-500/10 rounded-lg p-3 mb-4 border border-red-500/20",
                                children: [(0, a.jsx)(m.Z, {
                                    size: 16,
                                    className: "text-red-400 flex-shrink-0"
                                }), (0, a.jsx)("p", {
                                    className: "text-xs text-red-300",
                                    children: et
                                })]
                            }), (0, a.jsx)("button", {
                                onClick: tl,
                                disabled: O || K < 5 || K > t.balance,
                                className: "btn-primary w-full flex items-center justify-center gap-2",
                                children: O ? (0, a.jsx)(c.Z, {
                                    size: 18,
                                    className: "animate-spin"
                                }) : (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(z.Z, {
                                        size: 18
                                    }), "Criar Partida • R$ ", K]
                                })
                            })]
                        })
                    }), eN && (0, a.jsx)("div", {
                        className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50",
                        style: {
                            animation: e1 ? "backdropFadeOut 0.2s ease-out forwards" : "backdropFadeIn 0.2s ease-out"
                        },
                        onClick: ts,
                        children: (0, a.jsxs)("div", {
                            className: "card w-full max-w-sm",
                            style: {
                                animation: e1 ? "modalSlideDown 0.2s ease-out forwards" : "modalSlideUp 0.3s ease-out"
                            },
                            onClick: e => e.stopPropagation(),
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center justify-between mb-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center",
                                        children: (0, a.jsx)(u.Z, {
                                            size: 18,
                                            className: "text-blue-400"
                                        })
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("h2", {
                                            className: "text-lg font-bold text-white",
                                            children: "Entrar por C\xf3digo"
                                        }), (0, a.jsx)("p", {
                                            className: "text-xs text-white/50",
                                            children: "Digite o c\xf3digo da sala"
                                        })]
                                    })]
                                }), (0, a.jsx)("button", {
                                    onClick: ts,
                                    className: "w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors",
                                    children: (0, a.jsx)(d.Z, {
                                        size: 16,
                                        className: "text-white/60"
                                    })
                                })]
                            }), eF ? (0, a.jsxs)(a.Fragment, {
                                children: [(0, a.jsxs)("div", {
                                    className: "bg-white/5 rounded-lg p-4 mb-5 border border-white/10",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center justify-between mb-3",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex items-center gap-2",
                                            children: [(0, a.jsx)("span", {
                                                className: "bg-pool-gold/20 text-pool-gold text-xs font-mono font-bold px-2 py-1 rounded",
                                                children: eF.roomCode
                                            }), eF.isPrivate && (0, a.jsxs)("span", {
                                                className: "flex items-center gap-1 text-[10px] text-yellow-400 bg-yellow-500/20 px-1.5 py-0.5 rounded",
                                                children: [(0, a.jsx)(f.Z, {
                                                    size: 10
                                                }), "Privada"]
                                            })]
                                        }), (0, a.jsx)("span", {
                                            className: "text-[10px] px-2 py-1 rounded-full font-medium ".concat("WAITING" === eF.status ? "bg-green-500/20 text-green-400" : "bg-yellow-500/20 text-yellow-400"),
                                            children: "WAITING" === eF.status ? "Dispon\xedvel" : eF.status
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 mb-3",
                                        children: [(0, a.jsx)(T.Z, {
                                            username: eF.creator.username,
                                            size: "sm"
                                        }), (0, a.jsxs)("div", {
                                            children: [(0, a.jsxs)("p", {
                                                className: "text-sm font-medium text-white",
                                                children: ["@", eF.creator.username]
                                            }), (0, a.jsx)("p", {
                                                className: "text-[10px] text-white/40",
                                                children: "Criador da sala"
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex items-center justify-between pt-3 border-t border-white/10",
                                        children: [(0, a.jsxs)("div", {
                                            children: [(0, a.jsx)("p", {
                                                className: "text-[10px] text-white/40 uppercase",
                                                children: "Aposta"
                                            }), (0, a.jsxs)("p", {
                                                className: "text-lg font-bold text-pool-gold",
                                                children: ["R$ ", eF.betAmount.toFixed(0)]
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: "text-right",
                                            children: [(0, a.jsx)("p", {
                                                className: "text-[10px] text-white/40 uppercase",
                                                children: "Pr\xeamio"
                                            }), (0, a.jsxs)("p", {
                                                className: "text-lg font-bold text-green-400",
                                                children: ["R$ ", (1.8 * eF.betAmount).toFixed(0)]
                                            })]
                                        })]
                                    })]
                                }), eF.isPrivate && (0, a.jsxs)("div", {
                                    className: "mb-5",
                                    children: [(0, a.jsx)("label", {
                                        className: "block text-xs text-white/60 mb-2",
                                        children: "Senha da Sala"
                                    }), (0, a.jsxs)("div", {
                                        className: "relative",
                                        children: [(0, a.jsx)(f.Z, {
                                            size: 16,
                                            className: "absolute left-3 top-1/2 -translate-y-1/2 text-white/30"
                                        }), (0, a.jsx)("input", {
                                            type: eL ? "text" : "password",
                                            value: ez,
                                            onChange: e => eS(e.target.value),
                                            placeholder: "Digite a senha",
                                            className: "input-field pl-10 pr-10"
                                        }), (0, a.jsx)("button", {
                                            type: "button",
                                            onClick: () => eO(!eL),
                                            className: "absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60",
                                            children: eL ? (0, a.jsx)(k.Z, {
                                                size: 16
                                            }) : (0, a.jsx)(Z.Z, {
                                                size: 16
                                            })
                                        })]
                                    })]
                                }), t && t.balance < eF.betAmount && (0, a.jsxs)("div", {
                                    className: "flex items-center gap-2 bg-red-500/10 rounded-lg p-3 mb-4 border border-red-500/20",
                                    children: [(0, a.jsx)(N.Z, {
                                        size: 14,
                                        className: "text-red-400 flex-shrink-0"
                                    }), (0, a.jsxs)("p", {
                                        className: "text-xs text-red-300",
                                        children: ["Saldo insuficiente. Faltam R$ ", (eF.betAmount - t.balance).toFixed(2)]
                                    })]
                                }), eA && (0, a.jsxs)("div", {
                                    className: "flex items-center gap-2 bg-red-500/10 rounded-lg p-3 mb-4 border border-red-500/20",
                                    children: [(0, a.jsx)(m.Z, {
                                        size: 14,
                                        className: "text-red-400 flex-shrink-0"
                                    }), (0, a.jsx)("p", {
                                        className: "text-xs text-red-300",
                                        children: eA
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "flex gap-3",
                                    children: [(0, a.jsx)("button", {
                                        onClick: () => {
                                            eI(null), eS(""), eR("")
                                        },
                                        className: "btn-secondary flex-1",
                                        disabled: eP,
                                        children: "Voltar"
                                    }), (0, a.jsx)("button", {
                                        onClick: () => tc(eF.id),
                                        disabled: eP || eF.isPrivate && !ez || t && t.balance < eF.betAmount || "WAITING" !== eF.status,
                                        className: "btn-primary flex-1 flex items-center justify-center gap-2",
                                        children: eP ? (0, a.jsx)(c.Z, {
                                            size: 16,
                                            className: "animate-spin"
                                        }) : (0, a.jsxs)(a.Fragment, {
                                            children: [(0, a.jsx)(z.Z, {
                                                size: 16
                                            }), "Entrar"]
                                        })
                                    })]
                                })]
                            }) : (0, a.jsxs)(a.Fragment, {
                                children: [(0, a.jsxs)("div", {
                                    className: "mb-5",
                                    children: [(0, a.jsx)("label", {
                                        className: "block text-xs text-white/60 mb-3 text-center",
                                        children: "C\xf3digo da Sala"
                                    }), (0, a.jsx)("div", {
                                        className: "flex justify-center gap-2 cursor-text",
                                        onClick: () => {
                                            var e;
                                            return null === (e = document.getElementById("connect-code-input")) || void 0 === e ? void 0 : e.focus()
                                        },
                                        children: [0, 1, 2, 3, 4, 5].map(e => (0, a.jsx)("div", {
                                            className: "w-11 h-14 rounded-lg border-2 flex items-center justify-center text-xl font-mono font-bold transition-all ".concat(eZ[e] ? "bg-pool-gold/20 border-pool-gold/50 text-pool-gold" : "bg-white/5 border-white/20 text-white/30"),
                                            children: eZ[e] || "•"
                                        }, e))
                                    }), (0, a.jsx)("input", {
                                        id: "connect-code-input",
                                        type: "text",
                                        value: eZ,
                                        onChange: e => eC(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6)),
                                        className: "opacity-0 absolute -z-10 pointer-events-none",
                                        autoFocus: !0,
                                        maxLength: 6,
                                        onKeyDown: e => {
                                            "Enter" === e.key && 6 === eZ.length && to()
                                        }
                                    }), (0, a.jsx)("p", {
                                        className: "text-xs text-white/40 text-center mt-3",
                                        children: "Clique nos boxes e digite o c\xf3digo"
                                    })]
                                }), eA && (0, a.jsxs)("div", {
                                    className: "flex items-center gap-2 bg-red-500/10 rounded-lg p-3 mb-4 border border-red-500/20",
                                    children: [(0, a.jsx)(m.Z, {
                                        size: 14,
                                        className: "text-red-400 flex-shrink-0"
                                    }), (0, a.jsx)("p", {
                                        className: "text-xs text-red-300",
                                        children: eA
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "flex gap-3",
                                    children: [(0, a.jsx)("button", {
                                        onClick: ts,
                                        className: "btn-secondary flex-1",
                                        disabled: eP,
                                        children: "Cancelar"
                                    }), (0, a.jsx)("button", {
                                        onClick: to,
                                        disabled: eP || 6 !== eZ.length,
                                        className: "btn-primary flex-1 flex items-center justify-center gap-2",
                                        children: eP ? (0, a.jsx)(c.Z, {
                                            size: 16,
                                            className: "animate-spin"
                                        }) : (0, a.jsxs)(a.Fragment, {
                                            children: [(0, a.jsx)(b.Z, {
                                                size: 16
                                            }), "Buscar"]
                                        })
                                    })]
                                })]
                            })]
                        })
                    }), eq && eV && (0, a.jsx)("div", {
                        className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50",
                        style: {
                            animation: e4 ? "backdropFadeOut 0.2s ease-out forwards" : "backdropFadeIn 0.2s ease-out"
                        },
                        onClick: ta,
                        children: (0, a.jsxs)("div", {
                            className: "card w-full max-w-sm",
                            style: {
                                animation: e4 ? "modalSlideDown 0.2s ease-out forwards" : "modalSlideUp 0.3s ease-out"
                            },
                            onClick: e => e.stopPropagation(),
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center justify-between mb-6",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center",
                                        children: (0, a.jsx)(f.Z, {
                                            size: 18,
                                            className: "text-yellow-400"
                                        })
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("h2", {
                                            className: "text-lg font-bold text-white",
                                            children: "Sala Privada"
                                        }), (0, a.jsx)("p", {
                                            className: "text-xs text-white/50",
                                            children: "Digite a senha para entrar"
                                        })]
                                    })]
                                }), (0, a.jsx)("button", {
                                    onClick: ta,
                                    className: "w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors",
                                    children: (0, a.jsx)(d.Z, {
                                        size: 16,
                                        className: "text-white/60"
                                    })
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "bg-white/5 rounded-lg p-4 mb-5 border border-white/10",
                                children: [(0, a.jsxs)("div", {
                                    className: "flex items-center justify-between mb-3",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-2",
                                        children: [(0, a.jsx)("span", {
                                            className: "bg-pool-gold/20 text-pool-gold text-xs font-mono font-bold px-2 py-1 rounded",
                                            children: eV.roomCode
                                        }), (0, a.jsxs)("span", {
                                            className: "flex items-center gap-1 text-[10px] text-yellow-400 bg-yellow-500/20 px-1.5 py-0.5 rounded",
                                            children: [(0, a.jsx)(f.Z, {
                                                size: 10
                                            }), "Privada"]
                                        })]
                                    }), (0, a.jsx)("span", {
                                        className: "text-[10px] px-2 py-1 rounded-full font-medium bg-green-500/20 text-green-400",
                                        children: "Dispon\xedvel"
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "flex items-center gap-3 mb-3",
                                    children: [(0, a.jsx)(T.Z, {
                                        username: eV.creator.username,
                                        size: "sm"
                                    }), (0, a.jsxs)("div", {
                                        children: [(0, a.jsxs)("p", {
                                            className: "text-sm font-medium text-white",
                                            children: ["@", eV.creator.username]
                                        }), (0, a.jsx)("p", {
                                            className: "text-[10px] text-white/40",
                                            children: "Criador da sala"
                                        })]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "flex items-center justify-between pt-3 border-t border-white/10",
                                    children: [(0, a.jsxs)("div", {
                                        children: [(0, a.jsx)("p", {
                                            className: "text-[10px] text-white/40 uppercase",
                                            children: "Aposta"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-lg font-bold text-pool-gold",
                                            children: ["R$ ", Number(eV.betAmount).toFixed(0)]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "text-right",
                                        children: [(0, a.jsx)("p", {
                                            className: "text-[10px] text-white/40 uppercase",
                                            children: "Pr\xeamio"
                                        }), (0, a.jsxs)("p", {
                                            className: "text-lg font-bold text-green-400",
                                            children: ["R$ ", (1.8 * Number(eV.betAmount)).toFixed(0)]
                                        })]
                                    })]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mb-5",
                                children: [(0, a.jsx)("label", {
                                    className: "block text-xs text-white/60 mb-2",
                                    children: "Senha da Sala"
                                }), (0, a.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, a.jsx)(f.Z, {
                                        size: 16,
                                        className: "absolute left-3 top-1/2 -translate-y-1/2 text-white/30"
                                    }), (0, a.jsx)("input", {
                                        type: eH ? "text" : "password",
                                        value: eU,
                                        onChange: e => {
                                            eG(e.target.value), eY("")
                                        },
                                        placeholder: "Digite a senha",
                                        className: "input-field pl-10 pr-10",
                                        autoFocus: !0,
                                        onKeyDown: e => {
                                            "Enter" === e.key && eU && tm()
                                        }
                                    }), (0, a.jsx)("button", {
                                        type: "button",
                                        onClick: () => eJ(!eH),
                                        className: "absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60",
                                        children: eH ? (0, a.jsx)(k.Z, {
                                            size: 16
                                        }) : (0, a.jsx)(Z.Z, {
                                            size: 16
                                        })
                                    })]
                                })]
                            }), t && t.balance < Number(eV.betAmount) && (0, a.jsxs)("div", {
                                className: "flex items-center gap-2 bg-red-500/10 rounded-lg p-3 mb-4 border border-red-500/20",
                                children: [(0, a.jsx)(N.Z, {
                                    size: 14,
                                    className: "text-red-400 flex-shrink-0"
                                }), (0, a.jsxs)("p", {
                                    className: "text-xs text-red-300",
                                    children: ["Saldo insuficiente. Faltam R$ ", (Number(eV.betAmount) - t.balance).toFixed(2)]
                                })]
                            }), eK && (0, a.jsxs)("div", {
                                className: "flex items-center gap-2 bg-red-500/10 rounded-lg p-3 mb-4 border border-red-500/20",
                                children: [(0, a.jsx)(m.Z, {
                                    size: 14,
                                    className: "text-red-400 flex-shrink-0"
                                }), (0, a.jsx)("p", {
                                    className: "text-xs text-red-300",
                                    children: eK
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex gap-3",
                                children: [(0, a.jsx)("button", {
                                    onClick: ta,
                                    className: "btn-secondary flex-1",
                                    disabled: eW,
                                    children: "Cancelar"
                                }), (0, a.jsx)("button", {
                                    onClick: tm,
                                    disabled: eW || !eU || t && t.balance < Number(eV.betAmount),
                                    className: "btn-primary flex-1 flex items-center justify-center gap-2",
                                    children: eW ? (0, a.jsx)(c.Z, {
                                        size: 16,
                                        className: "animate-spin"
                                    }) : (0, a.jsxs)(a.Fragment, {
                                        children: [(0, a.jsx)(z.Z, {
                                            size: 16
                                        }), "Entrar"]
                                    })
                                })]
                            })]
                        })
                    }), (0, a.jsx)(D.Z, {})]
                })
            }
        },
        16112: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return i
                }
            });
            var a = s(3827),
                l = s(8792),
                r = s(20703);

            function i() {
                let e = new Date().getFullYear();
                return (0, a.jsx)("footer", {
                    className: "bg-pool-dark border-t border-white/5 mt-auto",
                    children: (0, a.jsx)("div", {
                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",
                        children: (0, a.jsxs)("div", {
                            className: "flex flex-col md:flex-row items-center justify-between gap-4",
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-4",
                                children: [(0, a.jsx)(r.default, {
                                    src: "/logos/logo-white-red.png",
                                    alt: "Tacadinha",
                                    width: 100,
                                    height: 32,
                                    className: "h-6 w-auto opacity-50"
                                }), (0, a.jsx)("span", {
                                    className: "text-white/30 text-sm hidden sm:inline",
                                    children: "|"
                                }), (0, a.jsxs)("p", {
                                    className: "text-white/30 text-sm",
                                    children: ["\xa9 ", e, " Tacadinha"]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-6 text-sm",
                                children: [(0, a.jsx)(l.default, {
                                    href: "/termos",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Termos"
                                }), (0, a.jsx)(l.default, {
                                    href: "/privacidade",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Privacidade"
                                }), (0, a.jsx)(l.default, {
                                    href: "#",
                                    className: "text-white/40 hover:text-white/60 transition-colors",
                                    children: "Suporte"
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "flex items-center gap-3 text-white/30 text-xs",
                                children: [(0, a.jsx)("span", {
                                    children: "+18"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "•"
                                }), (0, a.jsx)("span", {
                                    className: "hidden sm:inline",
                                    children: "Jogue com responsabilidade"
                                })]
                            })]
                        })
                    })
                })
            }
        },
        61524: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("AlertTriangle", [
                ["path", {
                    d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z",
                    key: "c3ski4"
                }],
                ["path", {
                    d: "M12 9v4",
                    key: "juzpu7"
                }],
                ["path", {
                    d: "M12 17h.01",
                    key: "p32p05"
                }]
            ])
        },
        18025: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("ArrowRight", [
                ["path", {
                    d: "M5 12h14",
                    key: "1ays0h"
                }],
                ["path", {
                    d: "m12 5 7 7-7 7",
                    key: "xquz4c"
                }]
            ])
        },
        49108: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("ChevronLeft", [
                ["path", {
                    d: "m15 18-6-6 6-6",
                    key: "1wnfg3"
                }]
            ])
        },
        37805: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("ChevronRight", [
                ["path", {
                    d: "m9 18 6-6-6-6",
                    key: "mthhwq"
                }]
            ])
        },
        64178: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("ClipboardList", [
                ["rect", {
                    width: "8",
                    height: "4",
                    x: "8",
                    y: "2",
                    rx: "1",
                    ry: "1",
                    key: "tgr4d6"
                }],
                ["path", {
                    d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
                    key: "116196"
                }],
                ["path", {
                    d: "M12 11h4",
                    key: "1jrz19"
                }],
                ["path", {
                    d: "M12 16h4",
                    key: "n85exb"
                }],
                ["path", {
                    d: "M8 11h.01",
                    key: "1dfujw"
                }],
                ["path", {
                    d: "M8 16h.01",
                    key: "18s6g9"
                }]
            ])
        },
        51930: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("EyeOff", [
                ["path", {
                    d: "M9.88 9.88a3 3 0 1 0 4.24 4.24",
                    key: "1jxqfv"
                }],
                ["path", {
                    d: "M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68",
                    key: "9wicm4"
                }],
                ["path", {
                    d: "M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61",
                    key: "1jreej"
                }],
                ["line", {
                    x1: "2",
                    x2: "22",
                    y1: "2",
                    y2: "22",
                    key: "a6p6uj"
                }]
            ])
        },
        37841: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Eye", [
                ["path", {
                    d: "M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",
                    key: "rwhkz3"
                }],
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "3",
                    key: "1v7zrd"
                }]
            ])
        },
        37211: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Filter", [
                ["polygon", {
                    points: "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3",
                    key: "1yg77f"
                }]
            ])
        },
        57277: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Link2", [
                ["path", {
                    d: "M9 17H7A5 5 0 0 1 7 7h2",
                    key: "8i5ue5"
                }],
                ["path", {
                    d: "M15 7h2a5 5 0 1 1 0 10h-2",
                    key: "1b9ql8"
                }],
                ["line", {
                    x1: "8",
                    x2: "16",
                    y1: "12",
                    y2: "12",
                    key: "1jonct"
                }]
            ])
        },
        51652: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Lock", [
                ["rect", {
                    width: "18",
                    height: "11",
                    x: "3",
                    y: "11",
                    rx: "2",
                    ry: "2",
                    key: "1w4ew1"
                }],
                ["path", {
                    d: "M7 11V7a5 5 0 0 1 10 0v4",
                    key: "fwvmzm"
                }]
            ])
        },
        81049: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("LogOut", [
                ["path", {
                    d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",
                    key: "1uf3rs"
                }],
                ["polyline", {
                    points: "16 17 21 12 16 7",
                    key: "1gabdz"
                }],
                ["line", {
                    x1: "21",
                    x2: "9",
                    y1: "12",
                    y2: "12",
                    key: "1uyos4"
                }]
            ])
        },
        79744: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Menu", [
                ["line", {
                    x1: "4",
                    x2: "20",
                    y1: "12",
                    y2: "12",
                    key: "1e0a9i"
                }],
                ["line", {
                    x1: "4",
                    x2: "20",
                    y1: "6",
                    y2: "6",
                    key: "1owob3"
                }],
                ["line", {
                    x1: "4",
                    x2: "20",
                    y1: "18",
                    y2: "18",
                    key: "yk5zj1"
                }]
            ])
        },
        10933: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Network", [
                ["rect", {
                    x: "16",
                    y: "16",
                    width: "6",
                    height: "6",
                    rx: "1",
                    key: "4q2zg0"
                }],
                ["rect", {
                    x: "2",
                    y: "16",
                    width: "6",
                    height: "6",
                    rx: "1",
                    key: "8cvhb9"
                }],
                ["rect", {
                    x: "9",
                    y: "2",
                    width: "6",
                    height: "6",
                    rx: "1",
                    key: "1egb70"
                }],
                ["path", {
                    d: "M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3",
                    key: "1jsf9p"
                }],
                ["path", {
                    d: "M12 12V8",
                    key: "2874zd"
                }]
            ])
        },
        43081: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Play", [
                ["polygon", {
                    points: "5 3 19 12 5 21 5 3",
                    key: "191637"
                }]
            ])
        },
        70094: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Plus", [
                ["path", {
                    d: "M5 12h14",
                    key: "1ays0h"
                }],
                ["path", {
                    d: "M12 5v14",
                    key: "s699le"
                }]
            ])
        },
        40834: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("RefreshCw", [
                ["path", {
                    d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
                    key: "v9h5vc"
                }],
                ["path", {
                    d: "M21 3v5h-5",
                    key: "1q7to0"
                }],
                ["path", {
                    d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
                    key: "3uifl3"
                }],
                ["path", {
                    d: "M8 16H3v5",
                    key: "1cv678"
                }]
            ])
        },
        28670: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Search", [
                ["circle", {
                    cx: "11",
                    cy: "11",
                    r: "8",
                    key: "4ej97u"
                }],
                ["path", {
                    d: "m21 21-4.3-4.3",
                    key: "1qie3q"
                }]
            ])
        },
        32805: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Share2", [
                ["circle", {
                    cx: "18",
                    cy: "5",
                    r: "3",
                    key: "gq8acd"
                }],
                ["circle", {
                    cx: "6",
                    cy: "12",
                    r: "3",
                    key: "w7nqdw"
                }],
                ["circle", {
                    cx: "18",
                    cy: "19",
                    r: "3",
                    key: "1xt0gg"
                }],
                ["line", {
                    x1: "8.59",
                    x2: "15.42",
                    y1: "13.51",
                    y2: "17.49",
                    key: "47mynk"
                }],
                ["line", {
                    x1: "15.41",
                    x2: "8.59",
                    y1: "6.51",
                    y2: "10.49",
                    key: "1n3mei"
                }]
            ])
        },
        77326: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Shield", [
                ["path", {
                    d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",
                    key: "1irkt0"
                }]
            ])
        },
        57974: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Swords", [
                ["polyline", {
                    points: "14.5 17.5 3 6 3 3 6 3 17.5 14.5",
                    key: "1hfsw2"
                }],
                ["line", {
                    x1: "13",
                    x2: "19",
                    y1: "19",
                    y2: "13",
                    key: "1vrmhu"
                }],
                ["line", {
                    x1: "16",
                    x2: "20",
                    y1: "16",
                    y2: "20",
                    key: "1bron3"
                }],
                ["line", {
                    x1: "19",
                    x2: "21",
                    y1: "21",
                    y2: "19",
                    key: "13pww6"
                }],
                ["polyline", {
                    points: "14.5 6.5 18 3 21 3 21 6 17.5 9.5",
                    key: "hbey2j"
                }],
                ["line", {
                    x1: "5",
                    x2: "9",
                    y1: "14",
                    y2: "18",
                    key: "1hf58s"
                }],
                ["line", {
                    x1: "7",
                    x2: "4",
                    y1: "17",
                    y2: "20",
                    key: "pidxm4"
                }],
                ["line", {
                    x1: "3",
                    x2: "5",
                    y1: "19",
                    y2: "21",
                    key: "1pehsh"
                }]
            ])
        },
        34059: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Users", [
                ["path", {
                    d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
                    key: "1yyitq"
                }],
                ["circle", {
                    cx: "9",
                    cy: "7",
                    r: "4",
                    key: "nufk8"
                }],
                ["path", {
                    d: "M22 21v-2a4 4 0 0 0-3-3.87",
                    key: "kshegd"
                }],
                ["path", {
                    d: "M16 3.13a4 4 0 0 1 0 7.75",
                    key: "1da9ce"
                }]
            ])
        },
        79251: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Volume2", [
                ["polygon", {
                    points: "11 5 6 9 2 9 2 15 6 15 11 19 11 5",
                    key: "16drj5"
                }],
                ["path", {
                    d: "M15.54 8.46a5 5 0 0 1 0 7.07",
                    key: "ltjumu"
                }],
                ["path", {
                    d: "M19.07 4.93a10 10 0 0 1 0 14.14",
                    key: "1kegas"
                }]
            ])
        },
        81562: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("VolumeX", [
                ["polygon", {
                    points: "11 5 6 9 2 9 2 15 6 15 11 19 11 5",
                    key: "16drj5"
                }],
                ["line", {
                    x1: "22",
                    x2: "16",
                    y1: "9",
                    y2: "15",
                    key: "1ewh16"
                }],
                ["line", {
                    x1: "16",
                    x2: "22",
                    y1: "9",
                    y2: "15",
                    key: "5ykzw1"
                }]
            ])
        },
        17252: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Wallet", [
                ["path", {
                    d: "M21 12V7H5a2 2 0 0 1 0-4h14v4",
                    key: "195gfw"
                }],
                ["path", {
                    d: "M3 5v14a2 2 0 0 0 2 2h16v-5",
                    key: "195n9w"
                }],
                ["path", {
                    d: "M18 12a2 2 0 0 0 0 4h4v-4Z",
                    key: "vllfpd"
                }]
            ])
        },
        97404: function(e, t, s) {
            "use strict";
            s.d(t, {
                Z: function() {
                    return a
                }
            });
            /**
             * @license lucide-react v0.312.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let a = (0, s(87461).Z)("Zap", [
                ["polygon", {
                    points: "13 2 3 14 12 14 11 22 21 10 12 10 13 2",
                    key: "45s27k"
                }]
            ])
        }
    },
    function(e) {
        e.O(0, [1615, 2807, 963, 703, 710, 4411, 9102, 826, 4002, 6023, 2971, 8069, 1744], function() {
            return e(e.s = 93447)
        }), _N_E = e.O()
    }
]);