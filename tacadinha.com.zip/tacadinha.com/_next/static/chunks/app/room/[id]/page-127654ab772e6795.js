(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6786], {
        104: function(e, t, s) {
            Promise.resolve().then(s.bind(s, 69304))
        },
        69304: function(e, t, s) {
            "use strict";
            s.r(t), s.d(t, {
                default: function() {
                    return M
                }
            });
            var l = s(3827),
                a = s(64090),
                n = s(47907),
                r = s(8792),
                i = s(6739),
                o = s(76023),
                d = s(85043),
                c = s(10826),
                x = s(61524),
                m = s(95032),
                h = s(95200),
                u = s(18994),
                p = s(53879),
                g = s(52235),
                b = s(79251),
                f = s(81562),
                j = s(28814),
                w = s(67366),
                N = s(56227),
                v = s(97404),
                y = s(66260),
                C = s(18727),
                k = s(51652),
                z = s(34059),
                Z = s(57277),
                T = s(80037),
                S = s(23416),
                E = s(46578),
                A = s(26490),
                I = s(57974),
                R = s(11213),
                F = s(79990),
                O = s(4002),
                P = s(56022),
                D = s(4295),
                B = s(90043),
                L = s(81708);

            function G(e) {
                let {
                    isOpen: t,
                    browserName: s
                } = e, n = window.location.href;
                (0, a.useEffect)(() => (t && (document.body.style.overflow = "hidden"), () => {
                    document.body.style.overflow = "unset"
                }), [t]);
                let r = async () => {
                    try {
                        await navigator.clipboard.writeText(n), alert("Link copiado! Cole no Chrome ou Safari para jogar.")
                    } catch (t) {
                        let e = document.createElement("textarea");
                        e.value = n, document.body.appendChild(e), e.select(), document.execCommand("copy"), document.body.removeChild(e), alert("Link copiado! Cole no Chrome ou Safari para jogar.")
                    }
                };
                return t ? (0, l.jsxs)("div", {
                    className: "fixed inset-0 z-50 flex items-center justify-center p-4",
                    children: [(0, l.jsx)("div", {
                        className: "fixed inset-0 bg-black/80 backdrop-blur-sm"
                    }), (0, l.jsxs)("div", {
                        className: "relative bg-pool-dark border border-orange-500/30 rounded-xl shadow-2xl max-w-md w-full p-6 animate-fade-in",
                        children: [(0, l.jsx)("div", {
                            className: "flex justify-center mb-4",
                            children: (0, l.jsx)("div", {
                                className: "w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500/20 to-orange-600/10 flex items-center justify-center",
                                children: (0, l.jsx)(x.Z, {
                                    size: 32,
                                    className: "text-orange-400"
                                })
                            })
                        }), (0, l.jsx)("h3", {
                            className: "text-xl font-display font-bold text-white text-center mb-2",
                            children: "Navegador Incompativel"
                        }), s && (0, l.jsxs)("p", {
                            className: "text-orange-400 text-sm text-center mb-4",
                            children: ["Detectamos que voce esta usando o navegador do ", (0, l.jsx)("strong", {
                                children: s
                            })]
                        }), (0, l.jsxs)("div", {
                            className: "text-white/70 text-sm leading-relaxed mb-6 space-y-3",
                            children: [(0, l.jsxs)("p", {
                                children: ["O jogo precisa ser jogado em ", (0, l.jsx)("strong", {
                                    className: "text-white",
                                    children: "modo paisagem"
                                }), " e navegadores de apps como ", s || "este", " podem ter limitacoes."]
                            }), (0, l.jsx)("p", {
                                children: "Para a melhor experiencia, abra o jogo em um navegador como:"
                            }), (0, l.jsxs)("div", {
                                className: "flex items-center justify-center gap-4 py-3",
                                children: [(0, l.jsxs)("div", {
                                    className: "flex flex-col items-center gap-1",
                                    children: [(0, l.jsx)("div", {
                                        className: "w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center",
                                        children: (0, l.jsx)(D.Z, {
                                            size: 24,
                                            className: "text-blue-400"
                                        })
                                    }), (0, l.jsx)("span", {
                                        className: "text-xs text-white/50",
                                        children: "Chrome"
                                    })]
                                }), (0, l.jsxs)("div", {
                                    className: "flex flex-col items-center gap-1",
                                    children: [(0, l.jsx)("div", {
                                        className: "w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center",
                                        children: (0, l.jsx)(B.Z, {
                                            size: 24,
                                            className: "text-gray-300"
                                        })
                                    }), (0, l.jsx)("span", {
                                        className: "text-xs text-white/50",
                                        children: "Safari"
                                    })]
                                })]
                            })]
                        }), (0, l.jsxs)("div", {
                            className: "space-y-3",
                            children: [(0, l.jsxs)("button", {
                                onClick: () => {
                                    let e = /iphone|ipad|ipod/i.test(navigator.userAgent);
                                    /android/i.test(navigator.userAgent) ? window.location.href = "intent://" + n.replace(/^https?:\/\//, "") + "#Intent;scheme=https;package=com.android.chrome;end" : e ? r() : window.open(n, "_system")
                                },
                                className: "w-full px-4 py-3 rounded-xl bg-gradient-to-r from-pool-gold to-yellow-500 hover:from-yellow-500 hover:to-pool-gold text-pool-dark font-bold transition-all shadow-lg shadow-pool-gold/20 flex items-center justify-center gap-2",
                                children: [(0, l.jsx)(L.Z, {
                                    size: 18
                                }), "Abrir no Navegador"]
                            }), (0, l.jsxs)("button", {
                                onClick: r,
                                className: "w-full px-4 py-3 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-colors font-medium flex items-center justify-center gap-2",
                                children: [(0, l.jsx)(S.Z, {
                                    size: 18
                                }), "Copiar Link"]
                            })]
                        })]
                    })]
                }) : null
            }
            let V = "tacadinha_sound_enabled";

            function M() {
                var e, t, s, D, B, L;
                let M = (0, n.useParams)(),
                    U = (0, n.useRouter)(),
                    W = M.id,
                    {
                        user: _,
                        isAuthenticated: K,
                        isLoading: J,
                        checkAuth: H
                    } = (0, i.tN)(),
                    q = (0, o.g)(d.vT),
                    Q = (0, o.g)(d.Dn),
                    $ = (0, o.g)(d.s8),
                    X = (0, o.g)(d.kl),
                    Y = (0, o.g)(d.bE),
                    ee = (0, o.g)(d.S),
                    et = (0, o.g)(d.Zw),
                    es = (0, o.g)(d.mh),
                    el = (0, o.g)(d.zR),
                    ea = (0, o.g)(d.Et),
                    en = (0, o.g)(d.wo),
                    er = (0, o.g)(d.m0),
                    ei = (0, o.g)(d.i6),
                    eo = (0, o.g)(d.Ec),
                    ed = (0, o.g)(d.dx),
                    [ec, ex] = (0, a.useState)(null),
                    [em, eh] = (0, a.useState)(!0),
                    [eu, ep] = (0, a.useState)(""),
                    [eg, eb] = (0, a.useState)(!1),
                    [ef, ej] = (0, a.useState)(""),
                    [ew, eN] = (0, a.useState)(!1),
                    [ev, ey] = (0, a.useState)(!1),
                    [eC, ek] = (0, a.useState)(!1),
                    [ez, eZ] = (0, a.useState)(!1),
                    [eT, eS] = (0, a.useState)(!1),
                    [eE, eA] = (0, a.useState)(0),
                    eI = (0, a.useRef)(!1),
                    eR = (0, a.useRef)(null),
                    eF = (0, a.useRef)(null),
                    {
                        soundEnabled: eO,
                        toggleSound: eP,
                        playSound: eD
                    } = function() {
                        let [e, t] = (0, a.useState)(!0), [s, l] = (0, a.useState)(!1);
                        (0, a.useEffect)(() => {
                            let e = localStorage.getItem(V);
                            null !== e && t("true" === e), l(!0)
                        }, []);
                        let n = (0, a.useCallback)(() => {
                                t(e => {
                                    let t = !e;
                                    return localStorage.setItem(V, String(t)), t
                                })
                            }, []),
                            r = (0, a.useCallback)(t => {
                                if (e && s) try {
                                    let e = new Audio("/sounds/".concat(t));
                                    e.volume = .5, e.play().catch(e => {
                                        console.warn("Erro ao tocar som:", e)
                                    })
                                } catch (e) {
                                    console.warn("Erro ao criar \xe1udio:", e)
                                }
                            }, [e, s]);
                        return {
                            soundEnabled: e,
                            toggleSound: n,
                            playSound: r,
                            isLoaded: s
                        }
                    }(),
                    eB = (0, a.useRef)(!1),
                    eL = (0, a.useRef)(null),
                    eG = (0, a.useRef)(0),
                    eV = [{
                        Icon: x.Z,
                        text: "Plataforma em vers\xe3o beta - podem ocorrer instabilidades",
                        color: "text-yellow-400",
                        bgColor: "bg-yellow-400/10",
                        borderColor: "border-yellow-400/20"
                    }, {
                        Icon: m.Z,
                        text: "Mantenha uma conex\xe3o est\xe1vel para melhor experi\xeancia",
                        color: "text-blue-400",
                        bgColor: "bg-blue-400/10",
                        borderColor: "border-blue-400/20"
                    }, {
                        Icon: h.Z,
                        text: "Reporte bugs e sugest\xf5es para melhorarmos a plataforma",
                        color: "text-green-400",
                        bgColor: "bg-green-400/10",
                        borderColor: "border-green-400/20"
                    }],
                    eM = (null == ec ? void 0 : ec.roomCode) ? "".concat(window.location.origin, "/room/invite/").concat(ec.roomCode) : "",
                    eU = async () => {
                        if (eM) try {
                            await navigator.clipboard.writeText(eM), eZ(!0), setTimeout(() => eZ(!1), 2e3)
                        } catch (t) {
                            let e = document.createElement("input");
                            e.value = eM, document.body.appendChild(e), e.select(), document.execCommand("copy"), document.body.removeChild(e), eZ(!0), setTimeout(() => eZ(!1), 2e3)
                        }
                    },
                    eW = async () => {
                        if (null == ec ? void 0 : ec.roomCode) try {
                            await navigator.clipboard.writeText(ec.roomCode), eS(!0), setTimeout(() => eS(!1), 2e3)
                        } catch (t) {
                            let e = document.createElement("input");
                            e.value = ec.roomCode, document.body.appendChild(e), e.select(), document.execCommand("copy"), document.body.removeChild(e), eS(!0), setTimeout(() => eS(!1), 2e3)
                        }
                    },
                    {
                        isInAppBrowser: e_,
                        browserName: eK
                    } = function() {
                        let [e, t] = (0, a.useState)({
                            isInAppBrowser: !1,
                            browserName: null
                        });
                        return (0, a.useEffect)(() => {
                            t(function() {
                                if ("undefined" == typeof navigator) return {
                                    isInAppBrowser: !1,
                                    browserName: null
                                };
                                let e = navigator.userAgent || navigator.vendor || "";
                                for (let t of [{
                                        pattern: /FBAN|FBAV/i,
                                        name: "Facebook"
                                    }, {
                                        pattern: /Instagram/i,
                                        name: "Instagram"
                                    }, {
                                        pattern: /BytedanceWebview|TikTok|musical_ly/i,
                                        name: "TikTok"
                                    }, {
                                        pattern: /Twitter/i,
                                        name: "Twitter/X"
                                    }, {
                                        pattern: /LinkedInApp/i,
                                        name: "LinkedIn"
                                    }, {
                                        pattern: /Snapchat/i,
                                        name: "Snapchat"
                                    }, {
                                        pattern: /Pinterest/i,
                                        name: "Pinterest"
                                    }, {
                                        pattern: /Line\//i,
                                        name: "LINE"
                                    }, {
                                        pattern: /KAKAOTALK/i,
                                        name: "KakaoTalk"
                                    }, {
                                        pattern: /WhatsApp/i,
                                        name: "WhatsApp"
                                    }, {
                                        pattern: /Telegram/i,
                                        name: "Telegram"
                                    }, {
                                        pattern: /Messenger/i,
                                        name: "Messenger"
                                    }, {
                                        pattern: /; wv\)/i,
                                        name: "WebView"
                                    }])
                                    if (t.pattern.test(e)) return {
                                        isInAppBrowser: !0,
                                        browserName: t.name
                                    };
                                return {
                                    isInAppBrowser: !1,
                                    browserName: null
                                }
                            }())
                        }, []), e
                    }(),
                    eJ = (0, a.useCallback)(async () => {
                        var e;
                        let t = await c.h.getRoomStatus(W);
                        if (t.error || !(null === (e = t.data) || void 0 === e ? void 0 : e.canJoin)) {
                            U.push("/lobby");
                            return
                        }
                        let s = await c.h.getRoom(W);
                        s.error ? (ep(s.error), (s.error.includes("permiss\xe3o") || s.error.includes("autorizado")) && U.push("/lobby")) : s.data && (ex(s.data), "IN_PROGRESS" === s.data.status && U.push("/game/".concat(W))), eh(!1)
                    }, [W, U]);
                (0, a.useEffect)(() => {
                    H()
                }, [H]), (0, a.useEffect)(() => {
                    J || K || U.push("/login")
                }, [J, K, U]), (0, a.useEffect)(() => {
                    let e = o.g.getState();
                    (e.gameOver || e.roomFinished) && ea()
                }, []), (0, a.useEffect)(() => (eR.current && (clearTimeout(eR.current), eR.current = null), () => {
                    eR.current = setTimeout(() => {
                        let e = o.g.getState();
                        (!e.gameStarted || e.gameOver) && ea()
                    }, 200)
                }), []), (0, a.useEffect)(() => {
                    K && W && !eI.current && (eI.current = !0, eJ(), setTimeout(() => {
                        el(W), setTimeout(() => {
                            eo()
                        }, 500)
                    }, 100))
                }, [K, W]), (0, a.useEffect)(() => (ed(() => eJ), () => {
                    ed(null)
                }), [ed, eJ]), (0, a.useEffect)(() => {
                    es && "Aguardando..." !== es && ec && !ec.match && eJ()
                }, [es, ec, eJ]), (0, a.useEffect)(() => {
                    eF.current && (eF.current.scrollTop = eF.current.scrollHeight)
                }, [et]), (0, a.useEffect)(() => {
                    q && !Q && U.push("/game/".concat(W))
                }, [q, Q, W, U]), (0, a.useEffect)(() => {
                    let e = setInterval(() => {
                        eA(e => (e + 1) % eV.length)
                    }, 5e3);
                    return () => clearInterval(e)
                }, [eV.length]), (0, a.useEffect)(() => {
                    let e = !!(es && "Aguardando..." !== es && "WAITING" !== X);
                    !eB.current && e && eD("join.mp3"), eB.current && !e && eD("leave.mp3"), eB.current = e
                }, [es, X, eD]), (0, a.useEffect)(() => {
                    null !== ee && ee !== eL.current && eD("countdown.mp3"), eL.current = ee
                }, [ee, eD]), (0, a.useEffect)(() => {
                    et.length > eG.current && eG.current > 0 && eD("chat.mp3"), eG.current = et.length
                }, [et.length, eD]), (0, a.useEffect)(() => {
                    let e = e => {
                        ("CONFIRMING" === X || "COUNTDOWN" === X) && (e.preventDefault(), e.returnValue = "Voc\xea est\xe1 no meio de uma confirma\xe7\xe3o de partida. Sair agora cancelar\xe1 a partida. Tem certeza?")
                    };
                    return window.addEventListener("beforeunload", e), () => window.removeEventListener("beforeunload", e)
                }, [X]);
                let eH = async () => {
                        eb(!0);
                        let e = await c.h.cancelRoom(W);
                        if (e.error) {
                            ep(e.error), eb(!1);
                            return
                        }
                        U.push("/lobby")
                    },
                    eq = () => {
                        ea(), U.push("/lobby")
                    },
                    eQ = () => {
                        if (e_) {
                            ek(!0);
                            return
                        }
                        en()
                    },
                    e$ = () => {
                        er()
                    },
                    eX = () => {
                        ef.trim() && (ei(ef), ej(""))
                    },
                    eY = e => new Date(e).toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit"
                    });
                if (J || !_) return (0, l.jsx)("div", {
                    className: "min-h-screen flex items-center justify-center",
                    children: (0, l.jsxs)("div", {
                        className: "text-center",
                        children: [(0, l.jsx)(u.Z, {
                            size: 48,
                            className: "animate-spin text-pool-gold mx-auto mb-4"
                        }), (0, l.jsx)("p", {
                            className: "text-white/60 text-sm",
                            children: "Carregando..."
                        })]
                    })
                });
                if (em) return (0, l.jsx)("div", {
                    className: "min-h-screen flex items-center justify-center",
                    children: (0, l.jsxs)("div", {
                        className: "text-center",
                        children: [(0, l.jsx)(u.Z, {
                            size: 48,
                            className: "animate-spin text-pool-gold mx-auto mb-4"
                        }), (0, l.jsx)("p", {
                            className: "text-white/60 text-sm",
                            children: "Entrando na sala..."
                        })]
                    })
                });
                if (eu) return (0, l.jsx)("main", {
                    className: "min-h-screen p-4 md:p-8",
                    children: (0, l.jsxs)("div", {
                        className: "max-w-2xl mx-auto",
                        children: [(0, l.jsxs)(r.default, {
                            href: "/lobby",
                            className: "inline-flex items-center gap-2 text-white/60 hover:text-white mb-6 transition-colors",
                            children: [(0, l.jsx)(p.Z, {
                                size: 20
                            }), "Voltar ao Lobby"]
                        }), (0, l.jsxs)("div", {
                            className: "card text-center py-12",
                            children: [(0, l.jsx)("div", {
                                className: "w-20 h-20 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4",
                                children: (0, l.jsx)(g.Z, {
                                    size: 40,
                                    className: "text-red-400"
                                })
                            }), (0, l.jsx)("h2", {
                                className: "font-display text-2xl font-bold mb-3",
                                children: "Erro"
                            }), (0, l.jsx)("p", {
                                className: "text-white/70 mb-6",
                                children: eu
                            }), (0, l.jsxs)(r.default, {
                                href: "/lobby",
                                className: "btn-primary inline-flex items-center gap-2",
                                children: [(0, l.jsx)(p.Z, {
                                    size: 18
                                }), "Voltar ao Lobby"]
                            })]
                        })]
                    })
                });
                let e0 = (null == ec ? void 0 : ec.creator.id) === _.id,
                    e1 = null == ec ? void 0 : null === (s = ec.match) || void 0 === s ? void 0 : null === (t = s.players) || void 0 === t ? void 0 : null === (e = t.find(e => 1 === e.playerNum)) || void 0 === e ? void 0 : e.user,
                    e2 = (null == e1 ? void 0 : e1.username) || (null == ec ? void 0 : ec.creator.username),
                    e5 = (null == e1 ? void 0 : e1.username) || (null == ec ? void 0 : ec.creator.username),
                    e4 = null == ec ? void 0 : null === (L = ec.match) || void 0 === L ? void 0 : null === (B = L.players) || void 0 === B ? void 0 : null === (D = B.find(e => 2 === e.playerNum)) || void 0 === D ? void 0 : D.user,
                    e3 = "WAITING" === X ? null : (null == e4 ? void 0 : e4.username) || (es && "Aguardando..." !== es ? es : null),
                    e6 = null == e4 ? void 0 : e4.username,
                    e8 = e2 && e3,
                    e7 = 1 === $ ? Y.player1 : Y.player2;
                1 === $ ? Y.player2 : Y.player1;
                let e9 = Number((null == ec ? void 0 : ec.betAmount) || 0);
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)(O.Z, {}), (0, l.jsxs)("main", {
                        className: "min-h-screen p-3 sm:p-4 md:p-6 max-w-7xl mx-auto pb-28 lg:pb-8",
                        children: [(0, l.jsxs)("div", {
                            className: "flex items-center justify-between mb-4 lg:mb-6",
                            children: [(0, l.jsxs)("div", {
                                className: "flex items-center gap-2 sm:gap-3",
                                children: [(0, l.jsxs)(r.default, {
                                    href: "/lobby",
                                    className: "p-2 sm:p-2.5 rounded-lg sm:rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/10",
                                    children: [(0, l.jsx)(p.Z, {
                                        size: 18,
                                        className: "sm:hidden text-white/60"
                                    }), (0, l.jsx)(p.Z, {
                                        size: 20,
                                        className: "hidden sm:block text-white/60"
                                    })]
                                }), (0, l.jsxs)("div", {
                                    children: [(0, l.jsx)("h1", {
                                        className: "font-display text-lg sm:text-xl md:text-2xl font-bold",
                                        children: "Sala de Espera"
                                    }), (null == ec ? void 0 : ec.roomCode) && (0, l.jsxs)("p", {
                                        className: "text-white/50 text-xs sm:text-sm font-mono",
                                        children: ["#", ec.roomCode]
                                    })]
                                })]
                            }), (0, l.jsxs)("div", {
                                className: "flex items-center gap-1.5 sm:gap-2",
                                children: [(0, l.jsx)("button", {
                                    onClick: eP,
                                    className: "p-2 sm:p-2.5 rounded-lg sm:rounded-xl transition-all border ".concat(eO ? "bg-pool-gold/20 text-pool-gold border-pool-gold/30" : "bg-white/5 text-white/60 hover:bg-white/10 border-white/10"),
                                    title: eO ? "Desativar sons" : "Ativar sons",
                                    children: eO ? (0, l.jsxs)(l.Fragment, {
                                        children: [(0, l.jsx)(b.Z, {
                                            size: 18,
                                            className: "sm:hidden"
                                        }), (0, l.jsx)(b.Z, {
                                            size: 20,
                                            className: "hidden sm:block"
                                        })]
                                    }) : (0, l.jsxs)(l.Fragment, {
                                        children: [(0, l.jsx)(f.Z, {
                                            size: 18,
                                            className: "sm:hidden"
                                        }), (0, l.jsx)(f.Z, {
                                            size: 20,
                                            className: "hidden sm:block"
                                        })]
                                    })
                                }), (0, l.jsxs)("button", {
                                    onClick: () => eN(!ew),
                                    className: "p-2 sm:p-2.5 rounded-lg sm:rounded-xl transition-all border ".concat(ew ? "bg-pool-gold/20 text-pool-gold border-pool-gold/30" : "bg-white/5 text-white/60 hover:bg-white/10 border-white/10"),
                                    title: "Regras",
                                    children: [(0, l.jsx)(j.Z, {
                                        size: 18,
                                        className: "sm:hidden"
                                    }), (0, l.jsx)(j.Z, {
                                        size: 20,
                                        className: "hidden sm:block"
                                    })]
                                }), (0, l.jsxs)("button", {
                                    onClick: () => ey(!ev),
                                    className: "lg:hidden p-2 sm:p-2.5 rounded-lg sm:rounded-xl transition-all relative border ".concat(ev ? "bg-pool-gold/20 text-pool-gold border-pool-gold/30" : "bg-white/5 text-white/60 hover:bg-white/10 border-white/10"),
                                    title: "Chat",
                                    children: [(0, l.jsx)(w.Z, {
                                        size: 18,
                                        className: "sm:hidden"
                                    }), (0, l.jsx)(w.Z, {
                                        size: 20,
                                        className: "hidden sm:block"
                                    }), et.length > 0 && (0, l.jsx)("span", {
                                        className: "absolute -top-1 -right-1 bg-pool-gold text-pool-dark text-[10px] sm:text-xs font-bold w-4 h-4 sm:w-5 sm:h-5 rounded-full flex items-center justify-center",
                                        children: et.length > 9 ? "9+" : et.length
                                    })]
                                })]
                            })]
                        }), ew && (0, l.jsxs)("div", {
                            className: "card mb-4 lg:mb-6 p-3 sm:p-4",
                            children: [(0, l.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [(0, l.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, l.jsx)("div", {
                                        className: "w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center",
                                        children: (0, l.jsx)(j.Z, {
                                            size: 16,
                                            className: "text-blue-400"
                                        })
                                    }), (0, l.jsx)("h2", {
                                        className: "font-display text-sm sm:text-lg font-bold",
                                        children: "Regras do Jogo"
                                    })]
                                }), (0, l.jsx)("button", {
                                    onClick: () => eN(!1),
                                    className: "p-1.5 hover:bg-white/10 rounded-lg transition-colors",
                                    children: (0, l.jsx)(g.Z, {
                                        size: 16,
                                        className: "text-white/60"
                                    })
                                })]
                            }), (0, l.jsxs)("div", {
                                className: "grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4",
                                children: [(0, l.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-lg p-2.5 sm:p-4 border border-white/5",
                                    children: [(0, l.jsxs)("h3", {
                                        className: "font-semibold text-pool-gold flex items-center gap-1.5 mb-2 text-[11px] sm:text-sm",
                                        children: [(0, l.jsx)(N.Z, {
                                            size: 14
                                        }), "Como Jogar"]
                                    }), (0, l.jsxs)("ul", {
                                        className: "space-y-1 text-[10px] sm:text-xs text-white/70",
                                        children: [(0, l.jsx)("li", {
                                            children: "Jogue com lisas ou listradas"
                                        }), (0, l.jsx)("li", {
                                            children: "Mire e ajuste a for\xe7a"
                                        }), (0, l.jsx)("li", {
                                            children: "30 seg por jogada"
                                        })]
                                    })]
                                }), (0, l.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-lg p-2.5 sm:p-4 border border-white/5",
                                    children: [(0, l.jsxs)("h3", {
                                        className: "font-semibold text-pool-gold flex items-center gap-1.5 mb-2 text-[11px] sm:text-sm",
                                        children: [(0, l.jsx)(v.Z, {
                                            size: 14
                                        }), "Regras B\xe1sicas"]
                                    }), (0, l.jsxs)("ul", {
                                        className: "space-y-1 text-[10px] sm:text-xs text-white/70",
                                        children: [(0, l.jsx)("li", {
                                            children: "Enca\xe7ape antes da 8"
                                        }), (0, l.jsx)("li", {
                                            children: "Bola 8 antes = derrota"
                                        }), (0, l.jsx)("li", {
                                            children: "Falta: branca na ca\xe7apa"
                                        })]
                                    })]
                                }), (0, l.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-lg p-2.5 sm:p-4 border border-white/5",
                                    children: [(0, l.jsxs)("h3", {
                                        className: "font-semibold text-pool-gold flex items-center gap-1.5 mb-2 text-[11px] sm:text-sm",
                                        children: [(0, l.jsx)(y.Z, {
                                            size: 14
                                        }), "Apostas"]
                                    }), (0, l.jsxs)("ul", {
                                        className: "space-y-1 text-[10px] sm:text-xs text-white/70",
                                        children: [(0, l.jsx)("li", {
                                            children: "Ambos pagam entrada"
                                        }), (0, l.jsx)("li", {
                                            children: "Taxa da casa: 10%"
                                        }), (0, l.jsx)("li", {
                                            children: "Vencedor leva 90%"
                                        })]
                                    })]
                                }), (0, l.jsxs)("div", {
                                    className: "bg-pool-dark/50 rounded-lg p-2.5 sm:p-4 border border-white/5",
                                    children: [(0, l.jsxs)("h3", {
                                        className: "font-semibold text-pool-gold flex items-center gap-1.5 mb-2 text-[11px] sm:text-sm",
                                        children: [(0, l.jsx)(C.Z, {
                                            size: 14
                                        }), "Dicas"]
                                    }), (0, l.jsxs)("ul", {
                                        className: "space-y-1 text-[10px] sm:text-xs text-white/70",
                                        children: [(0, l.jsx)("li", {
                                            children: "Planeje suas jogadas"
                                        }), (0, l.jsx)("li", {
                                            children: "Use spin na bola"
                                        }), (0, l.jsx)("li", {
                                            children: "Posicione a branca"
                                        })]
                                    })]
                                })]
                            })]
                        }), (0, l.jsxs)("div", {
                            className: "grid lg:grid-cols-3 gap-4 lg:gap-6 lg:h-[calc(100vh-180px)] lg:max-h-[700px]",
                            children: [(0, l.jsxs)("div", {
                                className: "lg:col-span-2 flex flex-col gap-4 lg:gap-6",
                                children: [(0, l.jsx)("div", {
                                    className: "card bg-gradient-to-br from-pool-gold/20 via-pool-gold/10 to-transparent border-pool-gold/30 p-3 sm:p-4 lg:p-6",
                                    children: (0, l.jsxs)("div", {
                                        className: "flex items-center justify-between gap-2 sm:gap-3",
                                        children: [(0, l.jsxs)("div", {
                                            className: "flex items-center gap-2 sm:gap-4",
                                            children: [(0, l.jsxs)("div", {
                                                className: "w-10 h-10 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-lg sm:rounded-xl lg:rounded-2xl bg-gradient-to-br from-pool-gold to-yellow-600 flex items-center justify-center shadow-lg shadow-pool-gold/30 flex-shrink-0",
                                                children: [(0, l.jsx)(y.Z, {
                                                    size: 20,
                                                    className: "sm:hidden text-pool-dark"
                                                }), (0, l.jsx)(y.Z, {
                                                    size: 28,
                                                    className: "hidden sm:block lg:hidden text-pool-dark"
                                                }), (0, l.jsx)(y.Z, {
                                                    size: 32,
                                                    className: "hidden lg:block text-pool-dark"
                                                })]
                                            }), (0, l.jsxs)("div", {
                                                children: [(0, l.jsx)("p", {
                                                    className: "text-white/60 text-[10px] sm:text-xs lg:text-sm",
                                                    children: "Pr\xeamio do Vencedor"
                                                }), (0, l.jsxs)("p", {
                                                    className: "text-xl sm:text-3xl lg:text-4xl font-bold text-pool-gold font-display",
                                                    children: ["R$ ", (1.8 * e9).toFixed(2)]
                                                })]
                                            })]
                                        }), (0, l.jsxs)("div", {
                                            className: "flex items-center gap-1.5 sm:gap-3",
                                            children: [(0, l.jsxs)("div", {
                                                className: "text-center px-1.5 sm:px-3 lg:px-4 py-1 sm:py-2 bg-white/5 rounded-lg border border-white/10",
                                                children: [(0, l.jsx)("p", {
                                                    className: "text-[9px] sm:text-[10px] lg:text-xs text-white/50",
                                                    children: "Entrada"
                                                }), (0, l.jsxs)("p", {
                                                    className: "text-sm sm:text-lg lg:text-xl font-bold",
                                                    children: ["R$ ", e9.toFixed(0)]
                                                })]
                                            }), (0, l.jsxs)("div", {
                                                className: "text-center px-1.5 sm:px-3 lg:px-4 py-1 sm:py-2 bg-white/5 rounded-lg border border-white/10",
                                                children: [(0, l.jsx)("p", {
                                                    className: "text-[9px] sm:text-[10px] lg:text-xs text-white/50",
                                                    children: "Tipo"
                                                }), (0, l.jsx)("div", {
                                                    className: "flex items-center justify-center gap-0.5 sm:gap-1 mt-0.5",
                                                    children: (null == ec ? void 0 : ec.isPrivate) ? (0, l.jsxs)(l.Fragment, {
                                                        children: [(0, l.jsx)(k.Z, {
                                                            size: 10,
                                                            className: "sm:hidden text-yellow-400"
                                                        }), (0, l.jsx)(k.Z, {
                                                            size: 12,
                                                            className: "hidden sm:block lg:hidden text-yellow-400"
                                                        }), (0, l.jsx)(k.Z, {
                                                            size: 14,
                                                            className: "hidden lg:block text-yellow-400"
                                                        }), (0, l.jsx)("span", {
                                                            className: "text-yellow-400 font-semibold text-[10px] sm:text-xs lg:text-sm",
                                                            children: "Privada"
                                                        })]
                                                    }) : (0, l.jsxs)(l.Fragment, {
                                                        children: [(0, l.jsx)(z.Z, {
                                                            size: 10,
                                                            className: "sm:hidden text-green-400"
                                                        }), (0, l.jsx)(z.Z, {
                                                            size: 12,
                                                            className: "hidden sm:block lg:hidden text-green-400"
                                                        }), (0, l.jsx)(z.Z, {
                                                            size: 14,
                                                            className: "hidden lg:block text-green-400"
                                                        }), (0, l.jsx)("span", {
                                                            className: "text-green-400 font-semibold text-[10px] sm:text-xs lg:text-sm",
                                                            children: "P\xfablica"
                                                        })]
                                                    })
                                                })]
                                            })]
                                        })]
                                    })
                                }), (0, l.jsxs)("div", {
                                    className: "card relative overflow-hidden border-white/10 flex-1 flex flex-col p-4 sm:p-5 lg:p-6",
                                    children: ["COUNTDOWN" === X && null !== ee && (0, l.jsxs)("div", {
                                        className: "absolute inset-0 bg-pool-dark/95 backdrop-blur-sm flex flex-col items-center justify-center rounded-xl z-20",
                                        children: [(0, l.jsxs)("div", {
                                            className: "relative",
                                            children: [(0, l.jsx)("div", {
                                                className: "text-7xl sm:text-9xl font-bold text-pool-gold animate-pulse font-display",
                                                children: ee
                                            }), (0, l.jsx)("div", {
                                                className: "absolute inset-0 blur-3xl bg-pool-gold/30 -z-10"
                                            })]
                                        }), (0, l.jsx)("h3", {
                                            className: "text-xl sm:text-2xl font-bold text-white mt-4 sm:mt-6 mb-2",
                                            children: "Iniciando Partida"
                                        }), (0, l.jsx)("p", {
                                            className: "text-white/60 mb-4 sm:mb-6 text-sm",
                                            children: "Prepare-se para jogar!"
                                        }), (0, l.jsxs)("button", {
                                            onClick: e$,
                                            className: "btn-secondary flex items-center gap-2 text-sm",
                                            children: [(0, l.jsx)(g.Z, {
                                                size: 16
                                            }), "Cancelar"]
                                        })]
                                    }), (null == ec ? void 0 : ec.roomCode) && (0, l.jsxs)(l.Fragment, {
                                        children: [(0, l.jsxs)("div", {
                                            className: "lg:hidden flex flex-col gap-3 p-3 bg-gradient-to-r from-blue-500/10 via-transparent to-purple-500/10 rounded-xl border border-white/10 mb-6",
                                            children: [(0, l.jsxs)("div", {
                                                className: "flex items-center gap-2",
                                                children: [(0, l.jsx)("div", {
                                                    className: "w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center border border-blue-500/20 flex-shrink-0",
                                                    children: (0, l.jsx)(Z.Z, {
                                                        size: 16,
                                                        className: "text-blue-400"
                                                    })
                                                }), (0, l.jsxs)("div", {
                                                    className: "flex-1 min-w-0",
                                                    children: [(0, l.jsx)("h3", {
                                                        className: "font-semibold text-sm",
                                                        children: "Convide um Oponente"
                                                    }), (0, l.jsx)("p", {
                                                        className: "text-[10px] text-white/40",
                                                        children: "Compartilhe o c\xf3digo ou link"
                                                    })]
                                                }), (null == ec ? void 0 : ec.isPrivate) && (0, l.jsxs)("span", {
                                                    className: "flex items-center gap-1 text-yellow-400 text-[10px] bg-yellow-500/20 px-1.5 py-0.5 rounded border border-yellow-500/20 flex-shrink-0",
                                                    children: [(0, l.jsx)(k.Z, {
                                                        size: 10
                                                    }), "Privada"]
                                                })]
                                            }), (0, l.jsxs)("div", {
                                                className: "flex items-center gap-2",
                                                children: [(0, l.jsx)("div", {
                                                    className: "flex-1 flex items-center justify-center gap-1 bg-pool-dark/50 rounded-lg p-2 border border-white/10",
                                                    children: ec.roomCode.split("").map((e, t) => (0, l.jsx)("span", {
                                                        className: "w-7 h-8 bg-pool-dark border border-white/20 rounded flex items-center justify-center text-sm font-mono font-bold text-pool-gold",
                                                        children: e
                                                    }, t))
                                                }), (0, l.jsx)("button", {
                                                    onClick: eW,
                                                    className: "p-2.5 rounded-lg font-medium text-sm transition-all flex-shrink-0 ".concat(eT ? "bg-green-500 text-white" : "bg-white/5 text-white/80 hover:bg-white/10 border border-white/10"),
                                                    children: eT ? (0, l.jsx)(T.Z, {
                                                        size: 18
                                                    }) : (0, l.jsx)(S.Z, {
                                                        size: 18
                                                    })
                                                }), (0, l.jsx)("button", {
                                                    onClick: eU,
                                                    className: "p-2.5 rounded-lg font-medium text-sm transition-all flex-shrink-0 ".concat(ez ? "bg-green-500 text-white" : "bg-pool-gold text-pool-dark hover:bg-pool-gold/90"),
                                                    children: ez ? (0, l.jsx)(T.Z, {
                                                        size: 18
                                                    }) : (0, l.jsx)(Z.Z, {
                                                        size: 18
                                                    })
                                                })]
                                            })]
                                        }), (0, l.jsxs)("div", {
                                            className: "hidden lg:flex items-center justify-between gap-4 p-4 bg-gradient-to-r from-blue-500/10 via-transparent to-purple-500/10 rounded-xl border border-white/10 mb-6",
                                            children: [(0, l.jsxs)("div", {
                                                className: "flex items-center gap-3",
                                                children: [(0, l.jsx)("div", {
                                                    className: "w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center border border-blue-500/20",
                                                    children: (0, l.jsx)(Z.Z, {
                                                        size: 20,
                                                        className: "text-blue-400"
                                                    })
                                                }), (0, l.jsxs)("div", {
                                                    children: [(0, l.jsx)("h3", {
                                                        className: "font-semibold text-sm",
                                                        children: "Convide um Oponente"
                                                    }), (0, l.jsx)("p", {
                                                        className: "text-xs text-white/40",
                                                        children: "Compartilhe o c\xf3digo ou link da sala"
                                                    })]
                                                })]
                                            }), (0, l.jsxs)("div", {
                                                className: "flex items-center gap-3",
                                                children: [(0, l.jsx)("div", {
                                                    className: "flex items-center gap-1 bg-pool-dark/50 rounded-lg px-3 py-2 border border-white/10",
                                                    children: ec.roomCode.split("").map((e, t) => (0, l.jsx)("span", {
                                                        className: "w-6 h-7 bg-pool-dark border border-white/20 rounded flex items-center justify-center text-sm font-mono font-bold text-pool-gold",
                                                        children: e
                                                    }, t))
                                                }), (0, l.jsxs)("button", {
                                                    onClick: eW,
                                                    className: "flex items-center gap-1.5 px-3 py-2 rounded-lg font-medium text-sm transition-all ".concat(eT ? "bg-green-500 text-white" : "bg-white/5 text-white/80 hover:bg-white/10 border border-white/10"),
                                                    children: [eT ? (0, l.jsx)(T.Z, {
                                                        size: 16
                                                    }) : (0, l.jsx)(S.Z, {
                                                        size: 16
                                                    }), eT ? "Copiado!" : "C\xf3digo"]
                                                }), (0, l.jsxs)("button", {
                                                    onClick: eU,
                                                    className: "flex items-center gap-1.5 px-3 py-2 rounded-lg font-medium text-sm transition-all ".concat(ez ? "bg-green-500 text-white" : "bg-pool-gold text-pool-dark hover:bg-pool-gold/90"),
                                                    children: [ez ? (0, l.jsx)(T.Z, {
                                                        size: 16
                                                    }) : (0, l.jsx)(Z.Z, {
                                                        size: 16
                                                    }), ez ? "Copiado!" : "Link"]
                                                }), (null == ec ? void 0 : ec.isPrivate) && (0, l.jsxs)("span", {
                                                    className: "flex items-center gap-1 text-yellow-400 text-xs bg-yellow-500/20 px-2 py-1.5 rounded-lg border border-yellow-500/20",
                                                    children: [(0, l.jsx)(k.Z, {
                                                        size: 12
                                                    }), "Privada"]
                                                })]
                                            })]
                                        })]
                                    }), (0, l.jsx)("div", {
                                        className: "flex items-center justify-center mb-6 sm:mb-8 lg:mb-10",
                                        children: e8 ? (0, l.jsxs)("div", {
                                            className: "inline-flex items-center gap-3 px-5 py-2.5 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl border border-green-500/30",
                                            children: [(0, l.jsx)("div", {
                                                className: "w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center",
                                                children: (0, l.jsx)(E.Z, {
                                                    size: 18,
                                                    className: "text-green-400"
                                                })
                                            }), (0, l.jsxs)("div", {
                                                children: [(0, l.jsx)("span", {
                                                    className: "text-sm font-semibold text-green-400",
                                                    children: "Prontos para jogar!"
                                                }), (0, l.jsx)("p", {
                                                    className: "text-[10px] text-green-400/60",
                                                    children: "Confirme para iniciar a partida"
                                                })]
                                            })]
                                        }) : (0, l.jsxs)("div", {
                                            className: "inline-flex items-center gap-3 px-5 py-2.5 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-xl border border-yellow-500/20",
                                            children: [(0, l.jsx)("div", {
                                                className: "w-8 h-8 rounded-lg bg-yellow-500/20 flex items-center justify-center",
                                                children: (0, l.jsx)(A.Z, {
                                                    size: 18,
                                                    className: "text-yellow-400"
                                                })
                                            }), (0, l.jsxs)("div", {
                                                children: [(0, l.jsx)("span", {
                                                    className: "text-sm font-semibold text-yellow-400",
                                                    children: "Aguardando oponente"
                                                }), (0, l.jsx)("p", {
                                                    className: "text-[10px] text-yellow-400/60",
                                                    children: "Compartilhe o c\xf3digo da sala"
                                                })]
                                            }), (0, l.jsxs)("span", {
                                                className: "flex h-2.5 w-2.5 relative ml-1",
                                                children: [(0, l.jsx)("span", {
                                                    className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"
                                                }), (0, l.jsx)("span", {
                                                    className: "relative inline-flex rounded-full h-2.5 w-2.5 bg-yellow-500"
                                                })]
                                            })]
                                        })
                                    }), (0, l.jsxs)("div", {
                                        className: "flex items-center justify-center gap-8 sm:gap-12 lg:gap-20 flex-1",
                                        children: [(0, l.jsxs)("div", {
                                            className: "flex flex-col items-center",
                                            children: [(0, l.jsxs)("div", {
                                                className: "relative mb-3",
                                                children: [1 === $ && (0, l.jsx)("div", {
                                                    className: "absolute inset-0 bg-pool-gold/20 rounded-2xl blur-xl scale-110"
                                                }), (0, l.jsx)("div", {
                                                    className: "relative w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 rounded-2xl flex items-center justify-center transition-all overflow-hidden ".concat(1 === $ ? "ring-3 ring-pool-gold shadow-xl shadow-pool-gold/30" : "ring-2 ring-white/20"),
                                                    children: (0, l.jsx)(P.Z, {
                                                        username: e5,
                                                        size: "lg",
                                                        className: "w-full h-full"
                                                    })
                                                }), e8 && (0, l.jsx)("div", {
                                                    className: "absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap flex items-center gap-1 ".concat(Y.player1 ? "bg-green-500 text-white shadow-lg shadow-green-500/30" : "bg-white/10 text-white/60 border border-white/10"),
                                                    children: Y.player1 ? (0, l.jsxs)(l.Fragment, {
                                                        children: [(0, l.jsx)(E.Z, {
                                                            size: 11
                                                        }), "PRONTO"]
                                                    }) : (0, l.jsxs)(l.Fragment, {
                                                        children: [(0, l.jsx)(A.Z, {
                                                            size: 11
                                                        }), "AGUARDANDO"]
                                                    })
                                                })]
                                            }), (0, l.jsx)("p", {
                                                className: "font-bold text-base sm:text-lg lg:text-lg text-white truncate max-w-[100px] sm:max-w-[120px] lg:max-w-[130px]",
                                                children: e2
                                            }), 1 === $ && (0, l.jsx)("span", {
                                                className: "text-xs text-pool-gold font-medium mt-0.5",
                                                children: "Voc\xea"
                                            })]
                                        }), (0, l.jsxs)("div", {
                                            className: "flex flex-col items-center justify-center",
                                            children: [(0, l.jsxs)("div", {
                                                className: "w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-xl bg-gradient-to-br from-pool-gold/20 to-yellow-600/20 border border-pool-gold/30 flex items-center justify-center shadow-lg",
                                                children: [(0, l.jsx)(I.Z, {
                                                    size: 20,
                                                    className: "sm:hidden text-pool-gold"
                                                }), (0, l.jsx)(I.Z, {
                                                    size: 24,
                                                    className: "hidden sm:block lg:hidden text-pool-gold"
                                                }), (0, l.jsx)(I.Z, {
                                                    size: 28,
                                                    className: "hidden lg:block text-pool-gold"
                                                })]
                                            }), (0, l.jsx)("span", {
                                                className: "text-xs lg:text-sm font-bold text-pool-gold/50 mt-2",
                                                children: "VS"
                                            })]
                                        }), (0, l.jsx)("div", {
                                            className: "flex flex-col items-center",
                                            children: e3 ? (0, l.jsxs)(l.Fragment, {
                                                children: [(0, l.jsxs)("div", {
                                                    className: "relative mb-3",
                                                    children: [2 === $ && (0, l.jsx)("div", {
                                                        className: "absolute inset-0 bg-pool-gold/20 rounded-2xl blur-xl scale-110"
                                                    }), (0, l.jsx)("div", {
                                                        className: "relative w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 rounded-2xl flex items-center justify-center transition-all overflow-hidden ".concat(2 === $ ? "ring-3 ring-pool-gold shadow-xl shadow-pool-gold/30" : "ring-2 ring-white/20"),
                                                        children: (0, l.jsx)(P.Z, {
                                                            username: e6,
                                                            size: "lg",
                                                            className: "w-full h-full"
                                                        })
                                                    }), e8 && (0, l.jsx)("div", {
                                                        className: "absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap flex items-center gap-1 ".concat(Y.player2 ? "bg-green-500 text-white shadow-lg shadow-green-500/30" : "bg-white/10 text-white/60 border border-white/10"),
                                                        children: Y.player2 ? (0, l.jsxs)(l.Fragment, {
                                                            children: [(0, l.jsx)(E.Z, {
                                                                size: 11
                                                            }), "PRONTO"]
                                                        }) : (0, l.jsxs)(l.Fragment, {
                                                            children: [(0, l.jsx)(A.Z, {
                                                                size: 11
                                                            }), "AGUARDANDO"]
                                                        })
                                                    })]
                                                }), (0, l.jsx)("p", {
                                                    className: "font-bold text-base sm:text-lg lg:text-lg text-white truncate max-w-[100px] sm:max-w-[120px] lg:max-w-[130px]",
                                                    children: e3
                                                }), 2 === $ && (0, l.jsx)("span", {
                                                    className: "text-xs text-pool-gold font-medium mt-0.5",
                                                    children: "Voc\xea"
                                                })]
                                            }) : (0, l.jsxs)(l.Fragment, {
                                                children: [(0, l.jsx)("div", {
                                                    className: "relative mb-3",
                                                    children: (0, l.jsxs)("div", {
                                                        className: "w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 rounded-2xl bg-gradient-to-br from-white/5 to-white/[0.02] border-2 border-dashed border-white/20 flex flex-col items-center justify-center gap-2",
                                                        children: [(0, l.jsxs)("div", {
                                                            className: "w-9 h-9 lg:w-10 lg:h-10 rounded-full bg-white/5 flex items-center justify-center",
                                                            children: [(0, l.jsx)(R.Z, {
                                                                size: 18,
                                                                className: "lg:hidden text-white/30"
                                                            }), (0, l.jsx)(R.Z, {
                                                                size: 20,
                                                                className: "hidden lg:block text-white/30"
                                                            })]
                                                        }), (0, l.jsxs)("div", {
                                                            className: "flex items-center gap-1",
                                                            children: [(0, l.jsx)("span", {
                                                                className: "w-1.5 h-1.5 rounded-full bg-white/30 animate-bounce",
                                                                style: {
                                                                    animationDelay: "0ms"
                                                                }
                                                            }), (0, l.jsx)("span", {
                                                                className: "w-1.5 h-1.5 rounded-full bg-white/30 animate-bounce",
                                                                style: {
                                                                    animationDelay: "150ms"
                                                                }
                                                            }), (0, l.jsx)("span", {
                                                                className: "w-1.5 h-1.5 rounded-full bg-white/30 animate-bounce",
                                                                style: {
                                                                    animationDelay: "300ms"
                                                                }
                                                            })]
                                                        })]
                                                    })
                                                }), (0, l.jsx)("p", {
                                                    className: "text-white/40 text-base lg:text-lg font-medium",
                                                    children: "Aguardando..."
                                                }), (0, l.jsx)("span", {
                                                    className: "text-xs text-white/30 mt-0.5",
                                                    children: "Oponente"
                                                })]
                                            })
                                        })]
                                    }), (0, l.jsx)("div", {
                                        className: "mt-6 lg:mt-8 mb-4 lg:mb-0",
                                        children: (0, l.jsxs)("div", {
                                            className: "relative overflow-hidden rounded-xl border transition-all duration-500 ".concat(eV[eE].bgColor, " ").concat(eV[eE].borderColor),
                                            children: [(0, l.jsxs)("div", {
                                                className: "flex items-center gap-3 py-3 px-4",
                                                children: [(0, l.jsx)("div", {
                                                    className: "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ".concat(eV[eE].bgColor, " border ").concat(eV[eE].borderColor),
                                                    children: (() => {
                                                        let e = eV[eE].Icon;
                                                        return (0, l.jsx)(e, {
                                                            size: 18,
                                                            className: eV[eE].color
                                                        })
                                                    })()
                                                }), (0, l.jsx)("p", {
                                                    className: "text-xs sm:text-sm font-medium ".concat(eV[eE].color, " flex-1"),
                                                    children: eV[eE].text
                                                })]
                                            }), (0, l.jsx)("div", {
                                                className: "flex items-center justify-center gap-1.5 pb-2.5",
                                                children: eV.map((e, t) => (0, l.jsx)("button", {
                                                    onClick: () => eA(t),
                                                    className: "h-1 rounded-full transition-all ".concat(t === eE ? "".concat(eV[t].color.replace("text-", "bg-"), " w-6") : "bg-white/20 w-1 hover:bg-white/40"),
                                                    "aria-label": "Ver aviso ".concat(t + 1)
                                                }, t))
                                            })]
                                        })
                                    }), (0, l.jsxs)("div", {
                                        className: "hidden lg:block mt-auto pt-6 border-t border-white/10 space-y-3",
                                        children: [!e8 && (0, l.jsx)("button", {
                                            onClick: e0 ? eH : eq,
                                            disabled: eg,
                                            className: "btn-secondary w-full flex items-center justify-center gap-2",
                                            children: eg ? (0, l.jsx)(u.Z, {
                                                size: 18,
                                                className: "animate-spin"
                                            }) : (0, l.jsxs)(l.Fragment, {
                                                children: [(0, l.jsx)(g.Z, {
                                                    size: 18
                                                }), e0 ? "Cancelar Sala" : "Sair da Sala"]
                                            })
                                        }), e8 && "CONFIRMING" === X && (0, l.jsx)(l.Fragment, {
                                            children: e7 ? (0, l.jsxs)(l.Fragment, {
                                                children: [(0, l.jsxs)("div", {
                                                    className: "w-full bg-green-500/20 text-green-400 font-bold py-4 rounded-xl flex items-center justify-center gap-2 border border-green-500/30",
                                                    children: [(0, l.jsx)(E.Z, {
                                                        size: 22
                                                    }), "VOC\xca ACEITOU"]
                                                }), (0, l.jsx)("p", {
                                                    className: "text-center text-white/40 text-sm",
                                                    children: "Aguardando oponente aceitar..."
                                                }), (0, l.jsxs)("button", {
                                                    onClick: e$,
                                                    className: "w-full btn-secondary flex items-center justify-center gap-2 py-2.5",
                                                    children: [(0, l.jsx)(g.Z, {
                                                        size: 16
                                                    }), "Cancelar"]
                                                })]
                                            }) : (0, l.jsxs)(l.Fragment, {
                                                children: [(0, l.jsxs)("button", {
                                                    onClick: eQ,
                                                    className: "w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-green-500/30",
                                                    children: [(0, l.jsx)(E.Z, {
                                                        size: 22
                                                    }), "ACEITAR PARTIDA"]
                                                }), (0, l.jsxs)("button", {
                                                    onClick: e0 ? eH : eq,
                                                    className: "w-full btn-secondary flex items-center justify-center gap-2 py-2.5",
                                                    children: [(0, l.jsx)(g.Z, {
                                                        size: 16
                                                    }), e0 ? "Cancelar" : "Sair"]
                                                })]
                                            })
                                        })]
                                    })]
                                })]
                            }), (0, l.jsx)("div", {
                                className: "hidden lg:flex flex-col",
                                children: (0, l.jsxs)("div", {
                                    className: "card border-white/10 flex-1 flex flex-col min-h-0 p-4",
                                    children: [(0, l.jsxs)("div", {
                                        className: "flex items-center gap-2 pb-3 border-b border-white/10",
                                        children: [(0, l.jsx)(w.Z, {
                                            size: 18,
                                            className: "text-pool-gold"
                                        }), (0, l.jsx)("h2", {
                                            className: "font-semibold text-base",
                                            children: "Chat da Sala"
                                        }), (0, l.jsxs)("span", {
                                            className: "text-white/40 text-sm ml-auto",
                                            children: [et.length, " ", 1 === et.length ? "mensagem" : "mensagens"]
                                        })]
                                    }), (0, l.jsx)("div", {
                                        className: "flex-1 flex flex-col min-h-0 pt-4",
                                        children: e8 ? (0, l.jsxs)(l.Fragment, {
                                            children: [(0, l.jsx)("div", {
                                                ref: eF,
                                                className: "flex-1 overflow-y-auto space-y-3 pr-2",
                                                children: 0 === et.length ? (0, l.jsx)("div", {
                                                    className: "flex items-center justify-center h-full",
                                                    children: (0, l.jsx)("p", {
                                                        className: "text-white/30 text-sm",
                                                        children: "Nenhuma mensagem ainda"
                                                    })
                                                }) : et.map((e, t) => {
                                                    var s;
                                                    return (0, l.jsx)("div", {
                                                        className: "flex ".concat(e.userId === _.id ? "justify-end" : "justify-start"),
                                                        children: (0, l.jsxs)("div", {
                                                            className: "max-w-[85%] ".concat(e.userId === _.id ? "text-right" : "text-left"),
                                                            children: [(0, l.jsxs)("p", {
                                                                className: "text-xs text-white/40 mb-1",
                                                                children: [null === (s = e.userName) || void 0 === s ? void 0 : s.replace(/^@/, ""), " • ", eY(e.timestamp)]
                                                            }), (0, l.jsx)("div", {
                                                                className: "inline-block rounded-lg px-3 py-2 ".concat(e.userId === _.id ? "bg-pool-gold/20 text-white" : "bg-white/10 text-white/90"),
                                                                children: (0, l.jsx)("p", {
                                                                    className: "text-sm break-words",
                                                                    children: e.message
                                                                })
                                                            })]
                                                        })
                                                    }, t)
                                                })
                                            }), (0, l.jsx)("div", {
                                                className: "pt-4 border-t border-white/10 mt-auto",
                                                children: (0, l.jsxs)("div", {
                                                    className: "flex gap-2",
                                                    children: [(0, l.jsx)("input", {
                                                        type: "text",
                                                        value: ef,
                                                        onChange: e => ej(e.target.value),
                                                        onKeyPress: e => "Enter" === e.key && eX(),
                                                        placeholder: "Digite sua mensagem...",
                                                        className: "flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-pool-gold/50 transition-colors",
                                                        maxLength: 500
                                                    }), (0, l.jsx)("button", {
                                                        onClick: eX,
                                                        disabled: !ef.trim(),
                                                        className: "bg-pool-gold hover:bg-pool-gold/90 disabled:bg-white/10 disabled:text-white/30 text-pool-dark p-2.5 rounded-lg transition-colors",
                                                        children: (0, l.jsx)(F.Z, {
                                                            size: 18
                                                        })
                                                    })]
                                                })
                                            })]
                                        }) : (0, l.jsx)("div", {
                                            className: "flex-1 flex items-center justify-center text-center",
                                            children: (0, l.jsxs)("div", {
                                                children: [(0, l.jsx)(w.Z, {
                                                    size: 40,
                                                    className: "text-white/10 mx-auto mb-3"
                                                }), (0, l.jsx)("p", {
                                                    className: "text-white/30 text-sm",
                                                    children: "Aguardando oponente entrar na sala"
                                                })]
                                            })
                                        })
                                    })]
                                })
                            })]
                        }), ev && (0, l.jsx)("div", {
                            className: "lg:hidden fixed inset-0 z-50 bg-pool-dark",
                            children: (0, l.jsxs)("div", {
                                className: "h-full flex flex-col p-4",
                                children: [(0, l.jsxs)("div", {
                                    className: "flex items-center justify-between pb-4 border-b border-white/10",
                                    children: [(0, l.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [(0, l.jsx)("div", {
                                            className: "w-10 h-10 rounded-lg bg-pool-gold/20 flex items-center justify-center",
                                            children: (0, l.jsx)(w.Z, {
                                                size: 20,
                                                className: "text-pool-gold"
                                            })
                                        }), (0, l.jsx)("h2", {
                                            className: "font-bold text-lg",
                                            children: "Chat da Sala"
                                        })]
                                    }), (0, l.jsx)("button", {
                                        onClick: () => ey(!1),
                                        className: "p-2 hover:bg-white/10 rounded-lg transition-colors",
                                        children: (0, l.jsx)(g.Z, {
                                            size: 20
                                        })
                                    })]
                                }), (0, l.jsx)("div", {
                                    className: "flex-1 flex flex-col min-h-0 pt-4",
                                    children: e8 ? (0, l.jsxs)(l.Fragment, {
                                        children: [(0, l.jsx)("div", {
                                            ref: eF,
                                            className: "flex-1 overflow-y-auto space-y-4 pr-1",
                                            children: 0 === et.length ? (0, l.jsx)("div", {
                                                className: "flex items-center justify-center h-full",
                                                children: (0, l.jsx)("p", {
                                                    className: "text-white/30 text-base",
                                                    children: "Nenhuma mensagem ainda"
                                                })
                                            }) : et.map((e, t) => {
                                                var s;
                                                return (0, l.jsx)("div", {
                                                    className: "flex ".concat(e.userId === _.id ? "justify-end" : "justify-start"),
                                                    children: (0, l.jsxs)("div", {
                                                        className: "max-w-[85%] ".concat(e.userId === _.id ? "text-right" : "text-left"),
                                                        children: [(0, l.jsxs)("p", {
                                                            className: "text-sm text-white/40 mb-1",
                                                            children: [null === (s = e.userName) || void 0 === s ? void 0 : s.replace(/^@/, ""), " • ", eY(e.timestamp)]
                                                        }), (0, l.jsx)("div", {
                                                            className: "inline-block rounded-xl px-4 py-2.5 ".concat(e.userId === _.id ? "bg-pool-gold/20 text-white" : "bg-white/10 text-white/90"),
                                                            children: (0, l.jsx)("p", {
                                                                className: "text-base break-words",
                                                                children: e.message
                                                            })
                                                        })]
                                                    })
                                                }, t)
                                            })
                                        }), (0, l.jsx)("div", {
                                            className: "pt-4 border-t border-white/10",
                                            children: (0, l.jsxs)("div", {
                                                className: "flex gap-2",
                                                children: [(0, l.jsx)("input", {
                                                    type: "text",
                                                    value: ef,
                                                    onChange: e => ej(e.target.value),
                                                    onKeyPress: e => "Enter" === e.key && eX(),
                                                    placeholder: "Digite sua mensagem...",
                                                    className: "flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-base focus:outline-none focus:border-pool-gold/50 transition-colors",
                                                    maxLength: 500
                                                }), (0, l.jsx)("button", {
                                                    onClick: eX,
                                                    disabled: !ef.trim(),
                                                    className: "bg-pool-gold hover:bg-pool-gold/90 disabled:bg-white/10 disabled:text-white/30 text-pool-dark p-3 rounded-xl transition-colors",
                                                    children: (0, l.jsx)(F.Z, {
                                                        size: 20
                                                    })
                                                })]
                                            })
                                        })]
                                    }) : (0, l.jsx)("div", {
                                        className: "flex-1 flex items-center justify-center text-center p-6",
                                        children: (0, l.jsxs)("div", {
                                            children: [(0, l.jsx)(w.Z, {
                                                size: 48,
                                                className: "text-white/10 mx-auto mb-4"
                                            }), (0, l.jsx)("p", {
                                                className: "text-white/40 text-base",
                                                children: "Chat dispon\xedvel quando o oponente entrar"
                                            })]
                                        })
                                    })
                                })]
                            })
                        }), (0, l.jsxs)("div", {
                            className: "lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-pool-dark/95 backdrop-blur-sm border-t border-white/10 p-3",
                            children: [!e8 && (0, l.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, l.jsxs)("div", {
                                    className: "flex items-center justify-center gap-2 text-yellow-400 text-xs bg-yellow-500/10 py-1.5 px-3 rounded-lg",
                                    children: [(0, l.jsx)(u.Z, {
                                        size: 14,
                                        className: "animate-spin"
                                    }), "Aguardando oponente..."]
                                }), (0, l.jsx)("button", {
                                    onClick: e0 ? eH : eq,
                                    disabled: eg,
                                    className: "btn-secondary w-full flex items-center justify-center gap-2 py-2.5 text-sm",
                                    children: eg ? (0, l.jsx)(u.Z, {
                                        size: 18,
                                        className: "animate-spin"
                                    }) : (0, l.jsxs)(l.Fragment, {
                                        children: [(0, l.jsx)(g.Z, {
                                            size: 18
                                        }), e0 ? "Cancelar Sala" : "Sair da Sala"]
                                    })
                                })]
                            }), e8 && "CONFIRMING" === X && (0, l.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, l.jsxs)("div", {
                                    className: "flex items-center justify-between text-xs",
                                    children: [(0, l.jsxs)("div", {
                                        className: "flex items-center gap-1.5 px-2 py-1 rounded-lg ".concat(Y.player1 ? "bg-green-500/20 text-green-400" : "bg-white/10 text-white/50"),
                                        children: [Y.player1 ? (0, l.jsx)(E.Z, {
                                            size: 12
                                        }) : (0, l.jsx)(A.Z, {
                                            size: 12
                                        }), (0, l.jsx)("span", {
                                            className: "font-medium truncate max-w-[80px]",
                                            children: null == e2 ? void 0 : e2.split(" ")[0]
                                        })]
                                    }), (0, l.jsxs)("div", {
                                        className: "flex items-center gap-1.5 px-2 py-1 rounded-lg ".concat(Y.player2 ? "bg-green-500/20 text-green-400" : "bg-white/10 text-white/50"),
                                        children: [(0, l.jsx)("span", {
                                            className: "font-medium truncate max-w-[80px]",
                                            children: null == e3 ? void 0 : e3.split(" ")[0]
                                        }), Y.player2 ? (0, l.jsx)(E.Z, {
                                            size: 12
                                        }) : (0, l.jsx)(A.Z, {
                                            size: 12
                                        })]
                                    })]
                                }), e7 ? (0, l.jsxs)(l.Fragment, {
                                    children: [(0, l.jsxs)("div", {
                                        className: "w-full bg-green-500/20 text-green-400 font-bold py-3 rounded-xl flex items-center justify-center gap-2 text-base border-2 border-green-500/50",
                                        children: [(0, l.jsx)(E.Z, {
                                            size: 20
                                        }), "VOC\xca ACEITOU"]
                                    }), (0, l.jsxs)("button", {
                                        onClick: e$,
                                        className: "w-full bg-white/5 text-white/70 font-medium py-2 rounded-lg flex items-center justify-center gap-1.5 text-xs",
                                        children: [(0, l.jsx)(g.Z, {
                                            size: 14
                                        }), "Cancelar"]
                                    })]
                                }) : (0, l.jsxs)(l.Fragment, {
                                    children: [(0, l.jsxs)("button", {
                                        onClick: eQ,
                                        className: "w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 text-base shadow-lg shadow-green-500/30",
                                        children: [(0, l.jsx)(E.Z, {
                                            size: 20
                                        }), "ACEITAR PARTIDA"]
                                    }), (0, l.jsxs)("button", {
                                        onClick: e0 ? eH : eq,
                                        className: "w-full bg-white/5 text-white/70 font-medium py-2 rounded-lg flex items-center justify-center gap-1.5 text-xs",
                                        children: [(0, l.jsx)(g.Z, {
                                            size: 14
                                        }), e0 ? "Cancelar" : "Sair"]
                                    })]
                                })]
                            }), "COUNTDOWN" === X && null !== ee && (0, l.jsx)("div", {
                                className: "text-center py-2",
                                children: (0, l.jsxs)("div", {
                                    className: "flex items-center justify-center gap-3",
                                    children: [(0, l.jsx)("div", {
                                        className: "text-4xl font-bold text-pool-gold animate-pulse font-display",
                                        children: ee
                                    }), (0, l.jsxs)("div", {
                                        className: "text-left",
                                        children: [(0, l.jsx)("p", {
                                            className: "font-bold text-white text-sm",
                                            children: "Iniciando..."
                                        }), (0, l.jsx)("p", {
                                            className: "text-white/60 text-xs",
                                            children: "Prepare-se!"
                                        })]
                                    })]
                                })
                            })]
                        }), (0, l.jsx)(G, {
                            isOpen: eC,
                            browserName: eK
                        })]
                    })]
                })
            }
        },
        85043: function(e, t, s) {
            "use strict";
            s.d(t, {
                DW: function() {
                    return T
                },
                Dn: function() {
                    return x
                },
                Ec: function() {
                    return D
                },
                Et: function() {
                    return z
                },
                HU: function() {
                    return S
                },
                JM: function() {
                    return C
                },
                Ke: function() {
                    return v
                },
                Q0: function() {
                    return m
                },
                Ql: function() {
                    return i
                },
                S: function() {
                    return f
                },
                TS: function() {
                    return y
                },
                To: function() {
                    return L
                },
                Yb: function() {
                    return E
                },
                Zw: function() {
                    return N
                },
                Zx: function() {
                    return R
                },
                b4: function() {
                    return w
                },
                bE: function() {
                    return b
                },
                cb: function() {
                    return j
                },
                d1: function() {
                    return r
                },
                dx: function() {
                    return G
                },
                ei: function() {
                    return l
                },
                ht: function() {
                    return u
                },
                hv: function() {
                    return o
                },
                i6: function() {
                    return P
                },
                kl: function() {
                    return g
                },
                m0: function() {
                    return O
                },
                m1: function() {
                    return B
                },
                mh: function() {
                    return p
                },
                s8: function() {
                    return n
                },
                tw: function() {
                    return Z
                },
                vT: function() {
                    return c
                },
                wo: function() {
                    return F
                },
                xG: function() {
                    return I
                },
                xk: function() {
                    return a
                },
                yr: function() {
                    return h
                },
                z0: function() {
                    return d
                },
                zR: function() {
                    return k
                },
                zT: function() {
                    return A
                }
            });
            let l = e => e.isConnected,
                a = e => e.connectionLost,
                n = e => e.playerNum,
                r = e => e.phase,
                i = e => e.isMyTurn,
                o = e => e.currentTurn,
                d = e => e.isBreakShot,
                c = e => e.gameStarted,
                x = e => e.gameOver,
                m = e => e.winner,
                h = e => e.myBallType,
                u = e => e.balls,
                p = e => e.opponentName,
                g = e => e.roomStatus,
                b = e => e.confirmations,
                f = e => e.countdown,
                j = e => e.turnTimeRemaining,
                w = e => e.isSyncing,
                N = e => e.chatMessages,
                v = e => ({
                    playerNum: e.playerNum,
                    player1Name: e.player1Name,
                    player2Name: e.player2Name,
                    opponentName: e.opponentName,
                    myBallType: e.myBallType,
                    opponentBallType: e.opponentBallType
                }),
                y = e => ({
                    opponentDisconnected: e.opponentDisconnected,
                    opponentGraceEndTime: e.opponentGraceEndTime,
                    disconnectedPlayerName: e.disconnectedPlayerName
                }),
                C = e => ({
                    isInitializing: e.isInitializing,
                    initializationFailed: e.initializationFailed,
                    initializationFailedReason: e.initializationFailedReason,
                    player1GameReady: e.player1GameReady,
                    player2GameReady: e.player2GameReady
                }),
                k = e => e.connect,
                z = e => e.disconnect,
                Z = e => e.sendShot,
                T = e => e.sendShotResult,
                S = e => e.sendStickUpdate,
                E = e => e.sendPlaceCueBall,
                A = e => e.sendCueBallMoving,
                I = e => e.sendStickCharging,
                R = e => e.sendForfeit,
                F = e => e.confirmReady,
                O = e => e.cancelCountdown,
                P = e => e.sendChatMessage,
                D = e => e.getChatHistory,
                B = e => e.sendGameReady,
                L = e => e.setIframeWindow,
                G = e => e.setOnRoomUpdate
        }
    },
    function(e) {
        e.O(0, [1615, 2807, 963, 703, 710, 4411, 5018, 826, 4002, 6023, 2971, 8069, 1744], function() {
            return e(e.s = 104)
        }), _N_E = e.O()
    }
]);