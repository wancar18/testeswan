// Copyright 2012 Google Inc. All rights reserved.

(function() {

    var data = {
        "resource": {
            "version": "3",

            "macros": [{
                "function": "__e"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "value"
            }, {
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__e"
            }],
            "tags": [{
                "function": "__cvt_5RM3Q",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_disablePushState": false,
                "vtp_pixelId": "2719543051765605",
                "vtp_standardEventName": "PageView",
                "vtp_disableAutoConfig": false,
                "vtp_enhancedEcommerce": false,
                "vtp_dpoLDU": false,
                "vtp_eventName": "standard",
                "vtp_objectPropertiesFromVariable": false,
                "vtp_consent": true,
                "vtp_advancedMatching": false,
                "tag_id": 5
            }, {
                "function": "__cvt_5RM3Q",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_disablePushState": false,
                "vtp_pixelId": "2719543051765605",
                "vtp_objectPropertyList": ["list", ["map", "name", "value", "value", ["macro", 1]],
                    ["map", "name", "currency", "value", "BRL"]
                ],
                "vtp_standardEventName": "Purchase",
                "vtp_disableAutoConfig": false,
                "vtp_enhancedEcommerce": false,
                "vtp_dpoLDU": false,
                "vtp_eventName": "standard",
                "vtp_objectPropertiesFromVariable": false,
                "vtp_consent": true,
                "vtp_advancedMatching": false,
                "tag_id": 8
            }],
            "predicates": [{
                "function": "_eq",
                "arg0": ["macro", 0],
                "arg1": "gtm.js"
            }, {
                "function": "_eq",
                "arg0": ["macro", 0],
                "arg1": "deposit_completed"
            }],
            "rules": [
                [
                    ["if", 0],
                    ["add", 0]
                ],
                [
                    ["if", 1],
                    ["add", 1]
                ]
            ]
        },
        "runtime": [
            [50, "__cvt_5RM3Q", [46, "a"],
                [52, "b", ["require", "createQueue"]],
                [52, "c", ["require", "callInWindow"]],
                [52, "d", ["require", "aliasInWindow"]],
                [52, "e", ["require", "copyFromWindow"]],
                [52, "f", ["require", "setInWindow"]],
                [52, "g", ["require", "injectScript"]],
                [52, "h", ["require", "makeTableMap"]],
                [52, "i", ["require", "makeNumber"]],
                [52, "j", ["require", "getType"]],
                [52, "k", ["require", "copyFromDataLayer"]],
                [52, "l", ["require", "Math"]],
                [52, "m", ["require", "logToConsole"]],
                [52, "n", [30, ["e", "_fbq_gtm_ids"],
                    [7]
                ]],
                [52, "o", [17, [15, "a"], "pixelId"]],
                [52, "p", [7, "AddPaymentInfo", "AddToCart", "AddToWishlist", "CompleteRegistration", "Contact", "CustomizeProduct", "Donate", "FindLocation", "InitiateCheckout", "Lead", "PageView", "Purchase", "Schedule", "Search", "StartTrial", "SubmitApplication", "Subscribe", "ViewContent"]],
                [52, "q", ["k", "ecommerce", 1]],
                [52, "r", [51, "", [7, "aG"],
                    ["m", [15, "aG"]],
                    [2, [15, "a"], "gtmOnFailure", [7]]
                ]],
                [52, "s", [51, "", [7, "aG", "aH"],
                    [55, "aI", [15, "aH"],
                        [46, [22, [2, [15, "aH"], "hasOwnProperty", [7, [15, "aI"]]],
                            [46, [43, [15, "aG"],
                                [15, "aI"],
                                [16, [15, "aH"],
                                    [15, "aI"]
                                ]
                            ]]
                        ]]
                    ],
                    [36, [15, "aG"]]
                ]],
                [52, "t", [51, "", [7, "aG"],
                    [36, [8, "id", [17, [15, "aG"], "id"], "quantity", [17, [15, "aG"], "quantity"]]]
                ]],
                [41, "u", "v", "w"],
                [22, [17, [15, "a"], "enhancedEcommerce"],
                    [46, [22, [28, [15, "q"]],
                            [46, [36, ["r", "Facebook Pixel: No valid \"ecommerce\" object found in dataLayer"]]]
                        ],
                        [22, [17, [15, "q"], "detail"],
                            [46, [3, "u", "ViewContent"],
                                [3, "v", "detail"]
                            ],
                            [46, [22, [17, [15, "q"], "add"],
                                [46, [3, "u", "AddToCart"],
                                    [3, "v", "add"]
                                ],
                                [46, [22, [17, [15, "q"], "checkout"],
                                    [46, [3, "u", "InitiateCheckout"],
                                        [3, "v", "checkout"]
                                    ],
                                    [46, [22, [17, [15, "q"], "purchase"],
                                        [46, [3, "u", "Purchase"],
                                            [3, "v", "purchase"]
                                        ],
                                        [46, [36, ["r", "Facebook Pixel: Most recently pushed \"ecommerce\" object must be one of types \"detail\", \"add\", \"checkout\" or \"purchase\"."]]]
                                    ]]
                                ]]
                            ]]
                        ],
                        [22, [30, [28, [17, [16, [15, "q"],
                                    [15, "v"]
                                ], "products"]],
                                [21, ["j", [17, [16, [15, "q"],
                                    [15, "v"]
                                ], "products"]], "array"]
                            ],
                            [46, [36, ["r", "Facebook pixel: Most recently pushed \"ecommerce\" object did not have a valid \"products\" array."]]]
                        ],
                        [3, "w", [8, "content_type", "product", "contents", [2, [17, [16, [15, "q"],
                            [15, "v"]
                        ], "products"], "map", [7, [15, "t"]]], "value", [2, [17, [16, [15, "q"],
                            [15, "v"]
                        ], "products"], "reduce", [7, [51, "", [7, "aG", "aH"],
                            [52, "aI", [10, [2, [15, "l"], "round", [7, [26, [26, ["i", [30, [17, [15, "aH"], "price"], 0]],
                                [30, [17, [15, "aH"], "quantity"], 1]
                            ], 100]]], 100]],
                            [36, [0, [15, "aG"],
                                [15, "aI"]
                            ]]
                        ], 0]], "currency", [30, [17, [15, "q"], "currencyCode"], "USD"]]],
                        [22, [18, [2, [7, "InitiateCheckout", "Purchase"], "indexOf", [7, [15, "u"]]],
                                [27, 1]
                            ],
                            [46, [43, [15, "w"], "num_items", [2, [17, [16, [15, "q"],
                                [15, "v"]
                            ], "products"], "reduce", [7, [51, "", [7, "aG", "aH"],
                                [36, [0, [15, "aG"],
                                    ["i", [30, [17, [15, "aH"], "quantity"], 1]]
                                ]]
                            ], 0]]]]
                        ]
                    ]
                ],
                [52, "x", [39, [1, [17, [15, "a"], "advancedMatchingList"],
                        [17, [17, [15, "a"], "advancedMatchingList"], "length"]
                    ],
                    ["h", [17, [15, "a"], "advancedMatchingList"], "name", "value"],
                    [8]
                ]],
                [52, "y", [39, [1, [17, [15, "a"], "objectPropertyList"],
                        [17, [17, [15, "a"], "objectPropertyList"], "length"]
                    ],
                    ["h", [17, [15, "a"], "objectPropertyList"], "name", "value"],
                    [8]
                ]],
                [52, "z", [39, [20, ["j", [17, [15, "a"], "objectPropertiesFromVariable"]], "object"],
                    [17, [15, "a"], "objectPropertiesFromVariable"],
                    [8]
                ]],
                [52, "aA", ["s", [15, "z"],
                    [15, "y"]
                ]],
                [52, "aB", ["s", [30, [15, "w"],
                        [8]
                    ],
                    [15, "aA"]
                ]],
                [3, "u", [30, [15, "u"],
                    [39, [20, [17, [15, "a"], "eventName"], "custom"],
                        [17, [15, "a"], "customEventName"],
                        [39, [20, [17, [15, "a"], "eventName"], "variable"],
                            [17, [15, "a"], "variableEventName"],
                            [17, [15, "a"], "standardEventName"]
                        ]
                    ]
                ]],
                [52, "aC", [39, [20, [2, [15, "p"], "indexOf", [7, [15, "u"]]],
                    [27, 1]
                ], "trackSingleCustom", "trackSingle"]],
                [52, "aD", [39, [20, [17, [15, "a"], "consent"], false], "revoke", "grant"]],
                [52, "aE", [51, "", [7],
                    [41, "aG"],
                    [3, "aG", ["e", "fbq"]],
                    [22, [15, "aG"],
                        [46, [36, [15, "aG"]]]
                    ],
                    ["f", "fbq", [51, "", [7],
                        [52, "aH", ["e", "fbq.callMethod.apply"]],
                        [22, [15, "aH"],
                            [46, ["c", "fbq.callMethod.apply", [45],
                                [15, "arguments"]
                            ]],
                            [46, ["c", "fbq.queue.push", [15, "arguments"]]]
                        ]
                    ]],
                    ["d", "_fbq", "fbq"],
                    ["b", "fbq.queue"],
                    [36, ["e", "fbq"]]
                ]],
                [52, "aF", ["aE"]],
                ["aF", "consent", [15, "aD"]],
                [22, [17, [15, "a"], "dpoLDU"],
                    [46, ["aF", "dataProcessingOptions", [7, "LDU"],
                        ["i", [17, [15, "a"], "dpoCountry"]],
                        ["i", [17, [15, "a"], "dpoState"]]
                    ]]
                ],
                [2, [2, [15, "o"], "split", [7, ","]], "forEach", [7, [51, "", [7, "aG"],
                    [22, [20, [2, [15, "n"], "indexOf", [7, [15, "aG"]]],
                            [27, 1]
                        ],
                        [46, [22, [17, [15, "a"], "disableAutoConfig"],
                                [46, ["aF", "set", "autoConfig", false, [15, "aG"]]]
                            ],
                            [22, [17, [15, "a"], "disablePushState"],
                                [46, ["f", "fbq.disablePushState", true]]
                            ],
                            ["aF", "init", [15, "aG"],
                                [15, "x"]
                            ],
                            ["aF", "set", "agent", "tmSimo-GTM-WebTemplate", [15, "aG"]],
                            [2, [15, "n"], "push", [7, [15, "aG"]]],
                            ["f", "_fbq_gtm_ids", [15, "n"], true]
                        ]
                    ],
                    [22, [17, [15, "a"], "eventId"],
                        [46, ["aF", [15, "aC"],
                            [15, "aG"],
                            [15, "u"],
                            [15, "aB"],
                            [8, "eventID", [17, [15, "a"], "eventId"]]
                        ]],
                        [46, ["aF", [15, "aC"],
                            [15, "aG"],
                            [15, "u"],
                            [15, "aB"]
                        ]]
                    ]
                ]]],
                ["g", "https://connect.facebook.net/en_US/fbevents.js", [17, [15, "a"], "gtmOnSuccess"],
                    [17, [15, "a"], "gtmOnFailure"], "fbPixel"
                ]
            ],
            [50, "__e", [46, "a"],
                [36, [13, [41, "$0"],
                    [3, "$0", ["require", "internal.getEventData"]],
                    ["$0", "event"]
                ]]
            ],
            [50, "__f", [46, "a"],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "getReferrerUrl"]],
                [52, "d", ["require", "makeString"]],
                [52, "e", ["require", "parseUrl"]],
                [52, "f", [15, "__module_legacyUrls"]],
                [52, "g", [30, ["b", "gtm.referrer", 1],
                    ["c"]
                ]],
                [22, [28, [15, "g"]],
                    [46, [36, ["d", [15, "g"]]]]
                ],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "C", [7, [15, "g"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "E", [7, [15, "g"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [22, [17, [15, "a"], "queryKey"],
                                [46, [53, [36, [2, [15, "f"], "H", [7, [15, "g"],
                                    [17, [15, "a"], "queryKey"]
                                ]]]]]
                            ],
                            [52, "h", ["e", [15, "g"]]],
                            [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]]
                        ]],
                        [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]]
                    ]
                ]
            ],
            [50, "__u", [46, "a"],
                [50, "k", [46, "l", "m"],
                    [52, "n", [17, [15, "m"], "multiQueryKeys"]],
                    [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
                    [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
                    [22, [20, [15, "o"], ""],
                        [46, [53, [52, "r", [2, [17, ["i", [15, "l"]], "search"], "replace", [7, "?", ""]]],
                            [36, [39, [1, [28, [15, "r"]],
                                    [15, "p"]
                                ],
                                [44],
                                [15, "r"]
                            ]]
                        ]]
                    ],
                    [41, "q"],
                    [22, [15, "n"],
                        [46, [53, [22, [20, ["e", [15, "o"]], "array"],
                            [46, [53, [3, "q", [15, "o"]]]],
                            [46, [53, [52, "r", ["c", "\\s+", "g"]],
                                [3, "q", [2, [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]], "split", [7, ","]]]
                            ]]
                        ]]],
                        [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]]
                    ],
                    [65, "r", [15, "q"],
                        [46, [53, [52, "s", [2, [15, "h"], "H", [7, [15, "l"],
                                [15, "r"]
                            ]]],
                            [22, [29, [15, "s"],
                                    [44]
                                ],
                                [46, [53, [22, [1, [15, "p"],
                                            [20, [15, "s"], ""]
                                        ],
                                        [46, [53, [6]]]
                                    ],
                                    [36, [15, "s"]]
                                ]]
                            ]
                        ]]
                    ],
                    [36, [44]]
                ],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "internal.createRegex"]],
                [52, "d", ["require", "getUrl"]],
                [52, "e", ["require", "getType"]],
                [52, "f", ["require", "makeString"]],
                [52, "g", ["require", "parseUrl"]],
                [52, "h", [15, "__module_legacyUrls"]],
                [52, "i", ["require", "internal.legacyParseUrl"]],
                [41, "j"],
                [22, [17, [15, "a"], "customUrlSource"],
                    [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
                    [46, [53, [3, "j", ["b", "gtm.url", 1]]]]
                ],
                [3, "j", [30, [15, "j"],
                    ["d"]
                ]],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "EXTENSION", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "C", [7, [15, "j"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "E", [7, [15, "j"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
                        [5, [46, [36, ["k", [15, "j"],
                            [15, "a"]
                        ]]]],
                        [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]]
                    ]
                ]
            ],
            [50, "__v", [46, "a"],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "internal.createRegex"]],
                [52, "d", ["require", "getType"]],
                [52, "e", [17, [15, "a"], "name"]],
                [22, [30, [28, [15, "e"]],
                        [21, ["d", [15, "e"]], "string"]
                    ],
                    [46, [36, false]]
                ],
                [52, "f", [2, [15, "e"], "replace", [7, ["c", "\\\\.", "g"], "."]]],
                [52, "g", ["b", [15, "f"],
                    [30, [17, [15, "a"], "dataLayerVersion"], 1]
                ]],
                [36, [39, [21, [15, "g"],
                        [44]
                    ],
                    [15, "g"],
                    [17, [15, "a"], "defaultValue"]
                ]]
            ],
            [52, "__module_legacyUrls", [13, [41, "$0"],
                [3, "$0", [51, "", [7],
                    [50, "a", [46],
                        [50, "h", [46, "p"],
                            [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                            [36, [39, [23, [15, "q"], 0],
                                [15, "p"],
                                [2, [15, "p"], "substring", [7, 0, [15, "q"]]]
                            ]]
                        ],
                        [50, "i", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                            [36, [39, [15, "q"],
                                [2, [15, "q"], "replace", [7, ":", ""]], ""
                            ]]
                        ],
                        [50, "j", [46, "p", "q"],
                            [41, "r"],
                            [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                            [22, [28, [15, "r"]],
                                [46, [36, ""]]
                            ],
                            [52, "s", ["b", ":[0-9]+"]],
                            [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                            [22, [15, "q"],
                                [46, [53, [52, "t", ["b", "^www\\d*\\."]],
                                    [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                                    [22, [1, [15, "u"],
                                            [16, [15, "u"], 0]
                                        ],
                                        [46, [3, "r", [2, [15, "r"], "substring", [7, [17, [16, [15, "u"], 0], "length"]]]]]
                                    ]
                                ]]
                            ],
                            [36, [15, "r"]]
                        ],
                        [50, "k", [46, "p"],
                            [52, "q", ["e", [15, "p"]]],
                            [41, "r"],
                            [3, "r", ["f", [17, [15, "q"], "port"]]],
                            [22, [28, [15, "r"]],
                                [46, [53, [22, [20, [17, [15, "q"], "protocol"], "http:"],
                                    [46, [53, [3, "r", 80]]],
                                    [46, [22, [20, [17, [15, "q"], "protocol"], "https:"],
                                        [46, [53, [3, "r", 443]]],
                                        [46, [53, [3, "r", ""]]]
                                    ]]
                                ]]]
                            ],
                            [36, ["g", [15, "r"]]]
                        ],
                        [50, "l", [46, "p", "q"],
                            [52, "r", ["e", [15, "p"]]],
                            [41, "s"],
                            [3, "s", [39, [20, [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]], 0],
                                [17, [15, "r"], "pathname"],
                                [0, "/", [17, [15, "r"], "pathName"]]
                            ]],
                            [22, [20, ["d", [15, "q"]], "array"],
                                [46, [53, [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                                    [22, [19, [2, [15, "q"], "indexOf", [7, [16, [15, "t"],
                                            [37, [17, [15, "t"], "length"], 1]
                                        ]]], 0],
                                        [46, [53, [43, [15, "t"],
                                                [37, [17, [15, "t"], "length"], 1], ""
                                            ],
                                            [3, "s", [2, [15, "t"], "join", [7, "/"]]]
                                        ]]
                                    ]
                                ]]
                            ],
                            [36, [15, "s"]]
                        ],
                        [50, "m", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                            [52, "r", [2, [15, "q"], "split", [7, "."]]],
                            [41, "s"],
                            [3, "s", [39, [18, [17, [15, "r"], "length"], 1],
                                [16, [15, "r"],
                                    [37, [17, [15, "r"], "length"], 1]
                                ], ""
                            ]],
                            [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]]
                        ],
                        [50, "n", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "hash"]],
                            [36, [2, [15, "q"], "replace", [7, "#", ""]]]
                        ],
                        [50, "o", [46, "p", "q"],
                            [50, "s", [46, "t"],
                                [36, ["c", [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]]]]
                            ],
                            [52, "r", [2, [17, ["e", [15, "p"]], "search"], "replace", [7, "?", ""]]],
                            [65, "t", [2, [15, "r"], "split", [7, "&"]],
                                [46, [53, [52, "u", [2, [15, "t"], "split", [7, "="]]],
                                    [22, [21, ["s", [16, [15, "u"], 0]],
                                            [15, "q"]
                                        ],
                                        [46, [6]]
                                    ],
                                    [36, ["s", [2, [2, [15, "u"], "slice", [7, 1]], "join", [7, "="]]]]
                                ]]
                            ],
                            [36]
                        ],
                        [52, "b", ["require", "internal.createRegex"]],
                        [52, "c", ["require", "decodeUriComponent"]],
                        [52, "d", ["require", "getType"]],
                        [52, "e", ["require", "internal.legacyParseUrl"]],
                        [52, "f", ["require", "makeNumber"]],
                        [52, "g", ["require", "makeString"]],
                        [36, [8, "F", [15, "m"], "H", [15, "o"], "G", [15, "n"], "C", [15, "j"], "E", [15, "l"], "D", [15, "k"], "B", [15, "i"], "A", [15, "h"]]]
                    ],
                    [36, ["a"]]
                ]],
                ["$0"]
            ]]

        ],
        "entities": {
            "__e": {
                "2": true,
                "5": true
            },
            "__f": {
                "2": true,
                "5": true
            },
            "__u": {
                "2": true,
                "5": true
            },
            "__v": {
                "2": true,
                "5": true
            }


        },
        "blob": {
            "1": "3",
            "10": "GTM-TRCC43VX",
            "14": "62h1",
            "15": "0",
            "16": "ChAIgOPVzAYQ5uGiubeDzeR3Eh0A9WOQUXkJpCROkiLpzt7kk8I/VfY6HfLIRW7mzhoCg6M=",
            "19": "dataLayer",
            "20": "",
            "21": "www.googletagmanager.com",
            "22": "eyIwIjoiQlIiLCIxIjoiQlItR08iLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jb20uYnIiLCI0IjoiIiwiNSI6ZmFsc2UsIjYiOmZhbHNlLCI3IjoiYWRfc3RvcmFnZXxhbmFseXRpY3Nfc3RvcmFnZXxhZF91c2VyX2RhdGF8YWRfcGVyc29uYWxpemF0aW9uIiwiOCI6IiJ9",
            "23": "google.tagmanager.debugui2.queue",
            "24": "tagassistant.google.com",
            "27": 0.005,
            "3": "www.googletagmanager.com",
            "30": "BR",
            "31": "BR-GO",
            "32": false,
            "36": "https://adservice.google.com/pagead/regclk",
            "37": "__TAGGY_INSTALLED",
            "38": "cct.google",
            "39": "googTaggyReferrer",
            "40": "https://cct.google/taggy/agent.js",
            "41": "google.tagmanager.ta.prodqueue",
            "42": 0.01,
            "43": "{\"keys\":[{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BDq5JQO/YOyKjPtimYyMJLFywxJfmnlPNG9qHx/PjcYnPzi4vBwEQsZsqqepj1FoqxEP2oxjJlu02V0mwpSZpXE=\",\"version\":0},\"id\":\"f7005d1b-1dba-48be-916c-a3e465549321\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BLhkwYTS+8fBjiqGNvzx7sD4/nLI4n8u2bQ5PUR4XAXc2ZdAxOPinxJ1MJS2Rb/Wx8SfB95qTK448OJFy1zOUuo=\",\"version\":0},\"id\":\"dc1cd531-2dde-4a0a-8b7c-207a9c597653\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BCr5mUqAFK2jH6Dc1wUQqTf3rd7BJDfeHAohlGw0FIOkDdK9dBWBWF87xLw7jJb4RQpApSro8lkzAMvivu90CX0=\",\"version\":0},\"id\":\"86fa8088-320d-4ec6-ace1-bc1117a5ebe2\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BBsBD5sqBsmD4P5lvY+qWptTZqzv5HH9rtqb/5E1nbfB72s1VXT54rPk2YXzQvX7aeMyJ7SaF45s0J+vEnTTkuI=\",\"version\":0},\"id\":\"5fa14387-cc95-4486-aaf7-d1f0b8974fdf\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BGcEKLut6kH7BrWew93xyur/X4wzqOx9QPDCoTQgdPH8OkJ9G5mjJ8BRI56OcNHtt/PMP9G3JtraZL/0YX/Y21I=\",\"version\":0},\"id\":\"1ed0dd7c-e25c-43a8-86df-3a72c9779945\"}]}",
            "44": "103116026~103200004~104684208~104684211~117455676~117455678",
            "46": {
                "1": "1000",
                "10": "6240",
                "11": "6240",
                "14": "1000",
                "16": "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
                "17": "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
                "2": "9",
                "20": "5000",
                "21": "5000",
                "22": "4.2.0",
                "23": "0.0.0",
                "25": "1",
                "26": "4000",
                "27": "100",
                "3": "5",
                "4": "ad_storage|analytics_storage|ad_user_data|ad_personalization",
                "44": "15000",
                "48": "30000",
                "5": "ad_storage|analytics_storage|ad_user_data",
                "6": "1",
                "62": "A6ONHRY7/bvBro+IMZd/a6LNjn7SSv999SkN/hFAE9L6vMr34dNgfdSVdYmv4U+NHZg1sxd38RtciRpRUtIRPgQAAACCeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiU2hhcmVkV29ya2VyRXh0ZW5kZWRMaWZldGltZSIsImV4cGlyeSI6MTc3NjcyOTYwMCwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
                "66": "100",
                "7": "10"
            },
            "48": true,
            "5": "GTM-TRCC43VX",
            "55": [],
            "56": [{
                "1": 403,
                "3": 0.5,
                "4": 115938465,
                "5": 115938466,
                "6": 0,
                "7": 2
            }, {
                "1": 404,
                "3": 0.5,
                "4": 115938468,
                "5": 115938469,
                "6": 0,
                "7": 1
            }, {
                "1": 476,
                "2": true
            }, {
                "1": 454,
                "2": true
            }, {
                "1": 448,
                "2": true
            }, {
                "1": 453,
                "2": true
            }, {
                "1": 433,
                "2": true
            }, {
                "1": 430,
                "2": true
            }, {
                "1": 457,
                "2": true
            }, {
                "1": 429,
                "2": true
            }, {
                "1": 455,
                "2": true
            }, {
                "1": 477,
                "2": true
            }, {
                "1": 447,
                "2": true
            }, {
                "1": 439,
                "3": 0.1,
                "4": 117416194,
                "5": 117416195,
                "6": 117485608,
                "7": 1
            }, {
                "1": 417,
                "2": true
            }, {
                "1": 420,
                "2": true
            }, {
                "1": 451,
                "2": true
            }, {
                "1": 450,
                "3": 0.01,
                "4": 117227714,
                "5": 117227715,
                "6": 117227716,
                "7": 3
            }, {
                "1": 444,
                "3": 0.01,
                "4": 117384405,
                "5": 117384406,
                "6": 0,
                "7": 1
            }, {
                "1": 426,
                "2": true
            }, {
                "1": 460,
                "3": 0.001,
                "4": 117395003,
                "5": 117395004,
                "6": 117395005,
                "7": 1
            }, {
                "1": 406,
                "2": true
            }, {
                "1": 449,
                "2": true
            }, {
                "1": 424,
                "3": 0.1,
                "4": 117531287,
                "5": 117531288,
                "6": 0,
                "7": 1
            }, {
                "1": 463,
                "3": 0.01,
                "4": 117527079,
                "5": 117527080,
                "6": 117527106,
                "7": 1
            }, {
                "1": 415,
                "2": true
            }, {
                "1": 423,
                "3": 0.1,
                "4": 116491844,
                "5": 116491845,
                "6": 116491846,
                "7": 2
            }, {
                "1": 412,
                "2": true
            }, {
                "1": 441,
                "2": true
            }],
            "59": ["GTM-TRCC43VX"],
            "6": "241024451"
        },
        "permissions": {
            "__cvt_5RM3Q": {
                "access_globals": {
                    "keys": [{
                        "key": "fbq",
                        "read": true,
                        "write": true,
                        "execute": false
                    }, {
                        "key": "_fbq_gtm",
                        "read": true,
                        "write": true,
                        "execute": false
                    }, {
                        "key": "_fbq",
                        "read": false,
                        "write": true,
                        "execute": false
                    }, {
                        "key": "_fbq_gtm_ids",
                        "read": true,
                        "write": true,
                        "execute": false
                    }, {
                        "key": "fbq.callMethod.apply",
                        "read": true,
                        "write": false,
                        "execute": true
                    }, {
                        "key": "fbq.queue.push",
                        "read": false,
                        "write": false,
                        "execute": true
                    }, {
                        "key": "fbq.queue",
                        "read": true,
                        "write": true,
                        "execute": false
                    }, {
                        "key": "fbq.disablePushState",
                        "read": true,
                        "write": true,
                        "execute": false
                    }]
                },
                "inject_script": {
                    "urls": ["https:\/\/connect.facebook.net\/en_US\/fbevents.js"]
                },
                "logging": {
                    "environments": "debug"
                },
                "read_data_layer": {
                    "allowedKeys": "specific",
                    "keyPatterns": ["ecommerce"]
                }
            },
            "__e": {
                "read_event_data": {
                    "eventDataAccess": "specific",
                    "keyPatterns": ["event"]
                }
            },
            "__f": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.referrer"]
                },
                "get_referrer": {
                    "urlParts": "any"
                }
            },
            "__u": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.url"]
                },
                "get_url": {
                    "urlParts": "any"
                }
            },
            "__v": {
                "read_data_layer": {
                    "allowedKeys": "any"
                }
            }


        }

        ,
        "sandboxed_scripts": [
                "__cvt_5RM3Q"

            ]

            ,
        "security_groups": {
            "google": [
                "__e",
                "__f",
                "__u",
                "__v"

            ]


        }



    };




    var k, ba = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ca = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ea = function(a) {
            for (var b = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global], c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d && d.Math == Math) return d
            }
            throw Error("Cannot find global object");
        },
        fa = ea(this),
        ia = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ka = {},
        oa = {},
        pa = function(a, b, c) {
            if (!c || a != null) {
                var d = oa[b];
                if (d == null) return a[b];
                var e = a[d];
                return e !== void 0 ? e : a[b]
            }
        },
        qa = function(a, b, c) {
            if (b) a: {
                var d = a.split("."),
                    e = d.length === 1,
                    f = d[0],
                    g;!e && f in ka ? g = ka : g = fa;
                for (var h = 0; h < d.length - 1; h++) {
                    var l = d[h];
                    if (!(l in g)) break a;
                    g = g[l]
                }
                var n = d[d.length - 1],
                    p = ia && c === "es6" ? g[n] : null,
                    q = b(p);
                if (q != null)
                    if (e) ca(ka, n, {
                        configurable: !0,
                        writable: !0,
                        value: q
                    });
                    else if (q !== p) {
                    if (oa[n] === void 0) {
                        var r =
                            Math.random() * 1E9 >>> 0;
                        oa[n] = ia ? fa.Symbol(n) : "$jscp$" + r + "$" + n
                    }
                    ca(g, oa[n], {
                        configurable: !0,
                        writable: !0,
                        value: q
                    })
                }
            }
        },
        ra;
    if (ia && typeof Object.setPrototypeOf == "function") ra = Object.setPrototypeOf;
    else {
        var sa;
        a: {
            var ta = {
                    a: !0
                },
                va = {};
            try {
                va.__proto__ = ta;
                sa = va.a;
                break a
            } catch (a) {}
            sa = !1
        }
        ra = sa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var wa = ra,
        xa = function(a, b) {
            a.prototype = ba(b.prototype);
            a.prototype.constructor = a;
            if (wa) wa(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Rs = b.prototype
        },
        ya = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        m = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: ya(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        za = function(a) {
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            return c
        },
        Aa = function(a) {
            return a instanceof Array ? a : za(m(a))
        },
        Ca = function(a) {
            return Ba(a, a)
        },
        Ba = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        Da = ia && typeof pa(Object, "assign") == "function" ? pa(Object, "assign") : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
            }
            return a
        };
    qa("Object.assign", function(a) {
        return a || Da
    }, "es6");
    var Fa = function(a) {
            if (!(a instanceof Object)) throw new TypeError("Iterator result " + a + " is not an object");
        },
        Ga = function() {
            this.fa = !1;
            this.T = null;
            this.ma = void 0;
            this.D = 1;
            this.O = this.V = 0;
            this.sb = this.J = null
        },
        Ha = function(a) {
            if (a.fa) throw new TypeError("Generator is already running");
            a.fa = !0
        };
    Ga.prototype.Ta = function(a) {
        this.ma = a
    };
    var Ia = function(a, b) {
        a.J = {
            Kn: b,
            isException: !0
        };
        a.D = a.V || a.O
    };
    Ga.prototype.getNextAddressJsc = function() {
        return this.D
    };
    Ga.prototype.getYieldResultJsc = function() {
        return this.ma
    };
    Ga.prototype.return = function(a) {
        this.J = {
            return: a
        };
        this.D = this.O
    };
    Ga.prototype["return"] = Ga.prototype.return;
    Ga.prototype.qj = function(a) {
        this.J = {
            fd: a
        };
        this.D = this.O
    };
    Ga.prototype.jumpThroughFinallyBlocks = Ga.prototype.qj;
    Ga.prototype.bc = function(a, b) {
        this.D = b;
        return {
            value: a
        }
    };
    Ga.prototype.yield = Ga.prototype.bc;
    Ga.prototype.Nq = function(a, b) {
        var c = m(a),
            d = c.next();
        Fa(d);
        if (d.done) this.ma = d.value, this.D = b;
        else return this.T = c, this.bc(d.value, b)
    };
    Ga.prototype.yieldAll = Ga.prototype.Nq;
    Ga.prototype.fd = function(a) {
        this.D = a
    };
    Ga.prototype.jumpTo = Ga.prototype.fd;
    Ga.prototype.rj = function() {
        this.D = 0
    };
    Ga.prototype.jumpToEnd = Ga.prototype.rj;
    Ga.prototype.Gq = function(a, b) {
        this.V = a;
        b != void 0 && (this.O = b)
    };
    Ga.prototype.setCatchFinallyBlocks = Ga.prototype.Gq;
    Ga.prototype.tg = function(a) {
        this.V = 0;
        this.O = a || 0
    };
    Ga.prototype.setFinallyBlock = Ga.prototype.tg;
    Ga.prototype.sj = function(a, b) {
        this.D = a;
        this.V = b || 0
    };
    Ga.prototype.leaveTryBlock = Ga.prototype.sj;
    Ga.prototype.pj = function(a) {
        this.V = a || 0;
        var b = this.J.Kn;
        this.J = null;
        return b
    };
    Ga.prototype.enterCatchBlock = Ga.prototype.pj;
    Ga.prototype.Zc = function(a, b, c) {
        c ? this.sb[c] = this.J : this.sb = [this.J];
        this.V = a || 0;
        this.O = b || 0
    };
    Ga.prototype.enterFinallyBlock = Ga.prototype.Zc;
    Ga.prototype.Ud = function(a, b) {
        var c = this.sb.splice(b || 0)[0],
            d = this.J = this.J || c;
        d ? d.isException ? this.D = this.V || this.O : d.fd != void 0 && this.O < d.fd ? (this.D = d.fd, this.J = null) : this.D = this.O : this.D = a
    };
    Ga.prototype.leaveFinallyBlock = Ga.prototype.Ud;
    Ga.prototype.Td = function(a) {
        return new Ja(a)
    };
    Ga.prototype.forIn = Ga.prototype.Td;
    var Ja = function(a) {
        this.J = a;
        this.D = [];
        for (var b in a) this.D.push(b);
        this.D.reverse()
    };
    Ja.prototype.Pn = function() {
        for (; this.D.length > 0;) {
            var a = this.D.pop();
            if (a in this.J) return a
        }
        return null
    };
    Ja.prototype.getNext = Ja.prototype.Pn;
    var Ka = function(a) {
            this.D = new Ga;
            this.J = a
        },
        Na = function(a, b) {
            Ha(a.D);
            var c = a.D.T;
            if (c) return La(a, "return" in c ? c["return"] : function(d) {
                return {
                    value: d,
                    done: !0
                }
            }, b, a.D.return);
            a.D.return(b);
            return Ma(a)
        },
        La = function(a, b, c, d) {
            try {
                var e = b.call(a.D.T, c);
                Fa(e);
                if (!e.done) return a.D.fa = !1, e;
                var f = e.value
            } catch (g) {
                return a.D.T = null, Ia(a.D, g), Ma(a)
            }
            a.D.T = null;
            d.call(a.D, f);
            return Ma(a)
        },
        Ma = function(a) {
            for (; a.D.D;) try {
                var b = a.J(a.D);
                if (b) return a.D.fa = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (d) {
                a.D.ma = void 0, Ia(a.D,
                    d)
            }
            a.D.fa = !1;
            if (a.D.J) {
                var c = a.D.J;
                a.D.J = null;
                if (c.isException) throw c.Kn;
                return {
                    value: c.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        Oa = function(a) {
            this.next = function(b) {
                var c;
                Ha(a.D);
                a.D.T ? c = La(a, a.D.T.next, b, a.D.Ta) : (a.D.Ta(b), c = Ma(a));
                return c
            };
            this.throw = function(b) {
                var c;
                Ha(a.D);
                a.D.T ? c = La(a, a.D.T["throw"], b, a.D.Ta) : (Ia(a.D, b), c = Ma(a));
                return c
            };
            this.return = function(b) {
                return Na(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        },
        Pa = function(a, b) {
            var c = new Oa(new Ka(b));
            wa && a.prototype && wa(c,
                a.prototype);
            return c
        },
        Qa = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        },
        Ra = function(a) {
            return a
        };
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Sa = this || self,
        Ta = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Rs = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.xu = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Ua = function(a, b) {
        this.type = a;
        this.data = b
    };
    var Va = function() {
        this.map = {};
        this.D = {}
    };
    Va.prototype.get = function(a) {
        return this.map["dust." + a]
    };
    Va.prototype.set = function(a, b) {
        var c = "dust." + a;
        this.D.hasOwnProperty(c) || (this.map[c] = b)
    };
    Va.prototype.has = function(a) {
        return this.map.hasOwnProperty("dust." + a)
    };
    Va.prototype.remove = function(a) {
        var b = "dust." + a;
        this.D.hasOwnProperty(b) || delete this.map[b]
    };
    var Wa = function(a, b) {
        var c = [],
            d;
        for (d in a.map)
            if (a.map.hasOwnProperty(d)) {
                var e = d.substring(5);
                switch (b) {
                    case 1:
                        c.push(e);
                        break;
                    case 2:
                        c.push(a.map[d]);
                        break;
                    case 3:
                        c.push([e, a.map[d]])
                }
            }
        return c
    };
    Va.prototype.Aa = function() {
        return Wa(this, 1)
    };
    Va.prototype.Hc = function() {
        return Wa(this, 2)
    };
    Va.prototype.kc = function() {
        return Wa(this, 3)
    };
    var Xa = function() {};
    Xa.prototype.reset = function() {};
    var Za = function(a, b) {
        this.T = a;
        this.parent = b;
        this.O = this.D = void 0;
        this.Hb = !1;
        this.J = function(c, d, e) {
            return c.apply(d, e)
        };
        this.values = new Va
    };
    Za.prototype.add = function(a, b) {
        $a(this, a, b, !1)
    };
    Za.prototype.Qh = function(a, b) {
        $a(this, a, b, !0)
    };
    var $a = function(a, b, c, d) {
        if (!a.Hb)
            if (d) {
                var e = a.values;
                e.set(b, c);
                e.D["dust." + b] = !0
            } else a.values.set(b, c)
    };
    k = Za.prototype;
    k.set = function(a, b) {
        this.Hb || (!this.values.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.values.set(a, b))
    };
    k.get = function(a) {
        return this.values.has(a) ? this.values.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.values.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.ub = function() {
        var a = new Za(this.T, this);
        this.D && a.Tb(this.D);
        a.kd(this.J);
        a.he(this.O);
        return a
    };
    k.Xd = function() {
        return this.T
    };
    k.Tb = function(a) {
        this.D = a
    };
    k.On = function() {
        return this.D
    };
    k.kd = function(a) {
        this.J = a
    };
    k.Dj = function() {
        return this.J
    };
    k.Wa = function() {
        this.Hb = !0
    };
    k.he = function(a) {
        this.O = a
    };
    k.xb = function() {
        return this.O
    };
    var ab = function() {
        this.value = {};
        this.prefix = "gtm."
    };
    k = ab.prototype;
    k.set = function(a, b) {
        this.value[this.prefix + String(a)] = b
    };
    k.get = function(a) {
        return this.value[this.prefix + String(a)]
    };
    k.has = function(a) {
        return this.value.hasOwnProperty(this.prefix + String(a))
    };
    k.delete = function(a) {
        var b = this.prefix + String(a);
        return this.value.hasOwnProperty(b) ? (delete this.value[b], !0) : !1
    };
    k.clear = function() {
        this.value = {}
    };
    k.values = function() {
        var a = this;
        return function c() {
            var d, e, f;
            return Pa(c, function(g) {
                switch (g.D) {
                    case 1:
                        g.tg(2), e = g.Td(a.value);
                    case 4:
                        if ((d = e.Pn()) == null) {
                            g.fd(2);
                            break
                        }
                        if (!a.value.hasOwnProperty(d)) {
                            g.fd(4);
                            break
                        }
                        f = Ra;
                        return g.bc(a.value[d], 8);
                    case 8:
                        f(g.ma);
                        g.fd(4);
                        break;
                    case 2:
                        g.Zc(), g.Ud(0)
                }
            })
        }()
    };
    fa.Object.defineProperties(ab.prototype, {
        size: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.keys(this.value).length
            }
        }
    });

    function bb() {
        try {
            if (Map) return new Map
        } catch (a) {}
        return new ab
    };
    var cb = function() {
        this.values = []
    };
    cb.prototype.add = function(a) {
        this.values.indexOf(a) === -1 && this.values.push(a)
    };
    cb.prototype.has = function(a) {
        return this.values.indexOf(a) > -1
    };
    var db = function(a, b) {
        this.fa = a;
        this.parent = b;
        this.T = this.J = void 0;
        this.Hb = !1;
        this.O = function(d, e, f) {
            return d.apply(e, f)
        };
        this.D = bb();
        var c;
        a: {
            try {
                if (Set) {
                    c = new Set;
                    break a
                }
            } catch (d) {}
            c = new cb
        }
        this.V = c
    };
    db.prototype.add = function(a, b) {
        eb(this, a, b, !1)
    };
    db.prototype.Qh = function(a, b) {
        eb(this, a, b, !0)
    };
    var eb = function(a, b, c, d) {
        a.Hb || a.V.has(b) || (d && a.V.add(b), a.D.set(b, c))
    };
    k = db.prototype;
    k.set = function(a, b) {
        this.Hb || (!this.D.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.V.has(a) || this.D.set(a, b))
    };
    k.get = function(a) {
        return this.D.has(a) ? this.D.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.D.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.ub = function() {
        var a = new db(this.fa, this);
        this.J && a.Tb(this.J);
        a.kd(this.O);
        a.he(this.T);
        return a
    };
    k.Xd = function() {
        return this.fa
    };
    k.Tb = function(a) {
        this.J = a
    };
    k.On = function() {
        return this.J
    };
    k.kd = function(a) {
        this.O = a
    };
    k.Dj = function() {
        return this.O
    };
    k.Wa = function() {
        this.Hb = !0
    };
    k.he = function(a) {
        this.T = a
    };
    k.xb = function() {
        return this.T
    };
    var fb = function(a, b, c) {
        var d;
        d = Error.call(this, a.message);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.eo = a;
        this.Dn = c === void 0 ? !1 : c;
        this.debugInfo = [];
        this.D = b
    };
    xa(fb, Error);
    var gb = function(a) {
        return a instanceof fb ? a : new fb(a, void 0, !0)
    };
    var hb = [];

    function ib(a) {
        return hb[a] === void 0 ? !1 : hb[a]
    };
    var jb = bb();

    function kb(a, b) {
        for (var c, d = m(b), e = d.next(); !e.done && !(c = lb(a, e.value), c instanceof Ua); e = d.next());
        return c
    }

    function lb(a, b) {
        try {
            if (ib(17)) {
                var c = b[0],
                    d = b.slice(1),
                    e = String(c),
                    f = jb.has(e) ? jb.get(e) : a.get(e);
                if (!f || typeof f.invoke !== "function") throw gb(Error("Attempting to execute non-function " + b[0] + "."));
                return f.apply(a, d)
            }
            var g = m(b),
                h = g.next().value,
                l = za(g),
                n = a.get(String(h));
            if (!n || typeof n.invoke !== "function") throw gb(Error("Attempting to execute non-function " + b[0] + "."));
            return n.invoke.apply(n, [a].concat(Aa(l)))
        } catch (q) {
            var p = a.On();
            p && p(q, b.context ? {
                id: b[0],
                line: b.context.line
            } : null);
            throw q;
        }
    };
    var mb = function() {
        this.J = new Xa;
        this.D = ib(17) ? new db(this.J) : new Za(this.J)
    };
    k = mb.prototype;
    k.Xd = function() {
        return this.J
    };
    k.Tb = function(a) {
        this.D.Tb(a)
    };
    k.kd = function(a) {
        this.D.kd(a)
    };
    k.execute = function(a) {
        return this.gk([a].concat(Aa(Qa.apply(1, arguments))))
    };
    k.gk = function() {
        for (var a, b = m(Qa.apply(0, arguments)), c = b.next(); !c.done; c = b.next()) a = lb(this.D, c.value);
        return a
    };
    k.kq = function(a) {
        var b = Qa.apply(1, arguments),
            c = this.D.ub();
        c.he(a);
        for (var d, e = m(b), f = e.next(); !f.done; f = e.next()) d = lb(c, f.value);
        return d
    };
    k.Wa = function() {
        this.D.Wa()
    };
    var nb = function() {
        this.Ja = !1;
        this.ia = new Va
    };
    k = nb.prototype;
    k.get = function(a) {
        return this.ia.get(a)
    };
    k.set = function(a, b) {
        this.Ja || this.ia.set(a, b)
    };
    k.has = function(a) {
        return this.ia.has(a)
    };
    k.remove = function(a) {
        this.Ja || this.ia.remove(a)
    };
    k.Aa = function() {
        return this.ia.Aa()
    };
    k.Hc = function() {
        return this.ia.Hc()
    };
    k.kc = function() {
        return this.ia.kc()
    };
    k.Wa = function() {
        this.Ja = !0
    };
    k.Hb = function() {
        return this.Ja
    };

    function ob() {
        for (var a = pb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function qb() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var pb, rb;

    function sb(a) {
        pb = pb || qb();
        rb = rb || ob();
        for (var b = [], c = 0; c < a.length; c += 3) {
            var d = c + 1 < a.length,
                e = c + 2 < a.length,
                f = a.charCodeAt(c),
                g = d ? a.charCodeAt(c + 1) : 0,
                h = e ? a.charCodeAt(c + 2) : 0,
                l = f >> 2,
                n = (f & 3) << 4 | g >> 4,
                p = (g & 15) << 2 | h >> 6,
                q = h & 63;
            e || (q = 64, d || (p = 64));
            b.push(pb[l], pb[n], pb[p], pb[q])
        }
        return b.join("")
    }

    function tb(a) {
        function b(l) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = rb[n];
                if (p != null) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return l
        }
        pb = pb || qb();
        rb = rb || ob();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                h = b(64);
            if (h === 64 && e === -1) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            g !== 64 && (c += String.fromCharCode(f << 4 & 240 | g >> 2), h !== 64 && (c += String.fromCharCode(g << 6 & 192 | h)))
        }
    };
    var ub = {};

    function vb(a, b) {
        var c = ub[a];
        c || (c = ub[a] = []);
        c[b] = !0
    }

    function wb() {
        delete ub.GA4_EVENT
    }

    function xb() {
        var a = zb.D.slice();
        ub.GTAG_EVENT_FEATURE_CHANNEL = a
    }

    function Ab(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) d % 8 === 0 && d > 0 && (b.push(String.fromCharCode(c)), c = 0), a[d] && (c |= 1 << d % 8);
        c > 0 && b.push(String.fromCharCode(c));
        return sb(b.join("")).replace(/\.+$/, "")
    };

    function Bb() {}

    function Cb(a) {
        return typeof a === "function"
    }

    function Db(a) {
        return typeof a === "string"
    }

    function Eb(a) {
        return typeof a === "number" && !isNaN(a)
    }

    function Fb(a) {
        return Array.isArray(a) ? a : [a]
    }

    function Gb(a, b) {
        if (a && Array.isArray(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function Hb(a, b) {
        if (!Eb(a) || !Eb(b) || a > b) a = 0, b = 2147483647;
        return Math.floor(Math.random() * (b - a + 1) + a)
    }

    function Ib(a, b) {
        for (var c = new Kb, d = 0; d < a.length; d++) c.set(a[d], !0);
        for (var e = 0; e < b.length; e++)
            if (c.get(b[e])) return !0;
        return !1
    }

    function Lb(a, b) {
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
    }

    function Mb(a) {
        return !!a && (Object.prototype.toString.call(a) === "[object Arguments]" || Object.prototype.hasOwnProperty.call(a, "callee"))
    }

    function Nb(a) {
        return Math.round(Number(a)) || 0
    }

    function Ob(a) {
        return "false" === String(a).toLowerCase() ? !1 : !!a
    }

    function Pb(a) {
        var b = [];
        if (Array.isArray(a))
            for (var c = 0; c < a.length; c++) b.push(String(a[c]));
        return b
    }

    function Qb(a) {
        return a ? a.replace(/^\s+|\s+$/g, "") : ""
    }

    function Sb() {
        return new Date(Date.now())
    }

    function Tb() {
        return Sb().getTime()
    }
    var Kb = function() {
        this.prefix = "gtm.";
        this.values = {}
    };
    Kb.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    Kb.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    Kb.prototype.contains = function(a) {
        return this.get(a) !== void 0
    };

    function Ub(a, b, c) {
        return a && a.hasOwnProperty(b) ? a[b] : c
    }

    function Vb(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = void 0;
                try {
                    c()
                } catch (d) {}
            }
        }
    }

    function Wb(a, b) {
        for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
    }

    function Xb(a, b) {
        for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
        return c
    }

    function Yb(a, b) {
        return a.length >= b.length && a.substring(0, b.length) === b
    }

    function Zb(a, b) {
        return a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    }

    function $b(a, b, c) {
        c = c || [];
        for (var d = a, e = 0; e < b.length - 1; e++) {
            if (!d.hasOwnProperty(b[e])) return;
            d = d[b[e]];
            if (c.indexOf(d) >= 0) return
        }
        return d
    }

    function ac(a, b) {
        for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
        d[e[e.length - 1]] = b;
        return c
    }
    var bc = /^\w{1,9}$/;

    function cc(a, b) {
        a = a || {};
        b = b || ",";
        var c = [];
        Lb(a, function(d, e) {
            bc.test(d) && e && c.push(d)
        });
        return c.join(b)
    }

    function dc(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            d < 128 ? b.push(d) : d < 2048 ? b.push(192 | d >> 6, 128 | d & 63) : d < 55296 || d >= 57344 ? b.push(224 | d >> 12, 128 | d >> 6 & 63, 128 | d & 63) : (d = 65536 + ((d & 1023) << 10 | a.charCodeAt(++c) & 1023), b.push(240 | d >> 18, 128 | d >> 12 & 63, 128 | d >> 6 & 63, 128 | d & 63))
        }
        return new Uint8Array(b)
    }

    function ec(a, b) {
        function c() {
            e && ++d === b && (e(), e = null, c.done = !0)
        }
        var d = 0,
            e = a;
        c.done = !1;
        return c
    }

    function fc(a) {
        if (!a) return a;
        var b = a;
        try {
            b = decodeURIComponent(a)
        } catch (d) {}
        var c = b.split(",");
        return c.length === 2 && c[0] === c[1] ? c[0] : a
    }

    function hc(a, b, c) {
        function d(n) {
            var p = n.split("=")[0];
            if (a.indexOf(p) < 0) return n;
            if (c !== void 0) return p + "=" + c
        }

        function e(n) {
            return n.split("&").map(d).filter(function(p) {
                return p !== void 0
            }).join("&")
        }
        var f = b.href.split(/[?#]/)[0],
            g = b.search,
            h = b.hash;
        g[0] === "?" && (g = g.substring(1));
        h[0] === "#" && (h = h.substring(1));
        g = e(g);
        h = e(h);
        g !== "" && (g = "?" + g);
        h !== "" && (h = "#" + h);
        var l = "" + f + g + h;
        l[l.length - 1] === "/" && (l = l.substring(0, l.length - 1));
        return l
    }

    function ic(a) {
        for (var b = 0; b < 3; ++b) try {
            var c = decodeURIComponent(a).replace(/\+/g, " ");
            if (c === a) break;
            a = c
        } catch (d) {
            return ""
        }
        return a
    }

    function jc() {
        var a = w,
            b;
        a: {
            var c = a.crypto || a.msCrypto;
            if (c && c.getRandomValues) try {
                var d = new Uint8Array(25);
                c.getRandomValues(d);
                b = btoa(String.fromCharCode.apply(String, Aa(d))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
                break a
            } catch (e) {}
            b = void 0
        }
        return b
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var kc = globalThis.trustedTypes,
        lc;

    function mc() {
        var a = null;
        if (!kc) return a;
        try {
            var b = function(c) {
                return c
            };
            a = kc.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function nc() {
        lc === void 0 && (lc = mc());
        return lc
    };
    var oc = function(a) {
        this.D = a
    };
    oc.prototype.toString = function() {
        return this.D + ""
    };

    function pc(a) {
        var b = a,
            c = nc(),
            d = c ? c.createScriptURL(b) : b;
        return new oc(d)
    }

    function qc(a) {
        if (a instanceof oc) return a.D;
        throw Error("");
    };
    var rc = Ca([""]),
        sc = Ba(["\x00"], ["\\0"]),
        tc = Ba(["\n"], ["\\n"]),
        vc = Ba(["\x00"], ["\\u0000"]);

    function wc(a) {
        return a.toString().indexOf("`") === -1
    }
    wc(function(a) {
        return a(rc)
    }) || wc(function(a) {
        return a(sc)
    }) || wc(function(a) {
        return a(tc)
    }) || wc(function(a) {
        return a(vc)
    });
    var xc = function(a) {
        this.D = a
    };
    xc.prototype.toString = function() {
        return this.D
    };
    var yc = function(a) {
        this.Yr = a
    };

    function zc(a) {
        return new yc(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    }
    var Ac = [zc("data"), zc("http"), zc("https"), zc("mailto"), zc("ftp"), new yc(function(a) {
        return /^[^:]*([/?#]|$)/.test(a)
    })];

    function Bc(a) {
        var b;
        b = b === void 0 ? Ac : b;
        if (a instanceof xc) return a;
        for (var c = 0; c < b.length; ++c) {
            var d = b[c];
            if (d instanceof yc && d.Yr(a)) return new xc(a)
        }
    }
    var Cc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Dc(a) {
        var b;
        if (a instanceof xc)
            if (a instanceof xc) b = a.D;
            else throw Error("");
        else b = Cc.test(a) ? a : void 0;
        return b
    };

    function Fc(a, b) {
        var c = Dc(b);
        c !== void 0 && (a.action = c)
    };

    function Gc(a, b) {
        throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
    };
    var Hc = function(a) {
        this.D = a
    };
    Hc.prototype.toString = function() {
        return this.D + ""
    };
    var Jc = function() {
        this.D = Ic
    };
    Jc.prototype.toString = function() {
        return this.D + ""
    };
    var Lc = function() {
        this.D = Kc[0].toLowerCase()
    };
    Lc.prototype.toString = function() {
        return this.D
    };

    function Mc(a, b) {
        var c = [new Lc];
        if (c.length === 0) throw Error("");
        var d = c.map(function(f) {
                var g;
                if (f instanceof Lc) g = f.D;
                else throw Error("");
                return g
            }),
            e = b.toLowerCase();
        if (d.every(function(f) {
                return e.indexOf(f) !== 0
            })) throw Error('Attribute "' + b + '" does not match any of the allowed prefixes.');
        a.setAttribute(b, "true")
    };
    var Nc = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };

    function Oc(a, b) {
        return new SharedWorker(qc(a), b)
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function Pc(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    var w = window,
        Qc = window.history,
        A = document,
        Rc = navigator;

    function Sc() {
        var a;
        try {
            a = Rc.serviceWorker
        } catch (b) {
            return
        }
        return a
    }
    var Tc = A.currentScript,
        Uc = Tc && Tc.src;

    function Vc(a, b) {
        var c = w,
            d = c[a];
        c[a] = d === void 0 ? b : d;
        return c[a]
    }

    function Wc(a) {
        return (Rc.userAgent || "").indexOf(a) !== -1
    }

    function Xc() {
        return Wc("Firefox") || Wc("FxiOS")
    }

    function Yc() {
        return (Wc("GSA") || Wc("GoogleApp")) && (Wc("iPhone") || Wc("iPad"))
    }

    function Zc() {
        return Wc("Edg/") || Wc("EdgA/") || Wc("EdgiOS/")
    }
    var $c = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        ad = {
            height: 1,
            onload: 1,
            src: 1,
            style: 1,
            width: 1
        };

    function bd(a, b, c) {
        b && Lb(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }

    function cd(a, b, c, d, e) {
        var f = A.createElement("script");
        bd(f, d, $c);
        f.type = "text/javascript";
        f.async = d && d.async === !1 ? !1 : !0;
        var g;
        g = pc(Pc(a));
        f.src = qc(g);
        var h, l = f.ownerDocument;
        l = l === void 0 ? document : l;
        var n, p, q = (p = (n = l).querySelector) == null ? void 0 : p.call(n, "script[nonce]");
        (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") && f.setAttribute("nonce", h);
        b && (f.onload = b);
        c && (f.onerror = c);
        if (e) e.appendChild(f);
        else {
            var r = A.getElementsByTagName("script")[0] || A.body || A.head;
            r.parentNode.insertBefore(f, r)
        }
        return f
    }

    function dd() {
        if (Uc) {
            var a = Uc.toLowerCase();
            if (a.indexOf("https://") === 0) return 2;
            if (a.indexOf("http://") === 0) return 3
        }
        return 1
    }

    function ed(a, b, c, d, e, f) {
        f = f === void 0 ? !0 : f;
        var g = e,
            h = !1;
        g || (g = A.createElement("iframe"), h = !0);
        bd(g, c, ad);
        d && Lb(d, function(n, p) {
            g.dataset[n] = p
        });
        f && (g.height = "0", g.width = "0", g.style.display = "none", g.style.visibility = "hidden");
        a !== void 0 && (g.src = a);
        if (h) {
            var l = A.body && A.body.lastChild || A.body || A.head;
            l.parentNode.insertBefore(g, l)
        }
        b && (g.onload = b);
        return g
    }

    function fd(a, b, c, d) {
        return gd(a, b, c, d)
    }

    function hd(a, b, c, d) {
        a.addEventListener && a.addEventListener(b, c, !!d)
    }

    function id(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1)
    }

    function jd(a) {
        w.setTimeout(a, 0)
    }

    function kd(a, b) {
        return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value : null
    }

    function ld(a) {
        var b = a.innerText || a.textContent || "";
        b && b !== " " && (b = b.replace(/^[\s\xa0]+/g, ""), b = b.replace(/[\s\xa0]+$/g, ""));
        b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
        return b
    }

    function md(a) {
        var b = A.createElement("div"),
            c = b,
            d, e = Pc("A<div>" + a + "</div>"),
            f = nc(),
            g = f ? f.createHTML(e) : e;
        d = new Hc(g);
        if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName)) throw Error("");
        var h;
        if (d instanceof Hc) h = d.D;
        else throw Error("");
        c.innerHTML = h;
        b = b.lastChild;
        for (var l = []; b && b.firstChild;) l.push(b.removeChild(b.firstChild));
        return l
    }

    function nd(a, b, c) {
        c = c || 100;
        for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
        for (var f = a, g = 0; f && g <= c; g++) {
            if (d[String(f.tagName).toLowerCase()]) return f;
            f = f.parentElement
        }
        return null
    }

    function od(a, b, c) {
        var d;
        try {
            d = Rc.sendBeacon && Rc.sendBeacon(a)
        } catch (e) {
            vb("TAGGING", 15)
        }
        d ? b == null || b() : gd(a, b, c)
    }

    function pd(a, b) {
        try {
            if (Rc.sendBeacon !== void 0) return Rc.sendBeacon(a, b)
        } catch (c) {
            vb("TAGGING", 15)
        }
        return !1
    }
    var qd = Object.freeze({
        cache: "no-store",
        credentials: "include",
        keepalive: !0,
        method: "POST",
        mode: "no-cors",
        redirect: "follow"
    });

    function rd(a, b, c, d, e) {
        if (sd()) {
            var f = pa(Object, "assign").call(Object, {}, qd);
            b && (f.body = b);
            c && (c.attributionReporting && (f.attributionReporting = c.attributionReporting), c.browsingTopics !== void 0 && (f.browsingTopics = c.browsingTopics), c.credentials && (f.credentials = c.credentials), c.keepalive !== void 0 && (f.keepalive = c.keepalive), c.method && (f.method = c.method), c.mode && (f.mode = c.mode));
            try {
                var g = w.fetch(a, f);
                if (g) return g.then(function(l) {
                    l && (l.ok || l.status === 0) ? d == null || d() : e == null || e()
                }).catch(function() {
                    e ==
                        null || e()
                }), !0
            } catch (l) {}
        }
        if ((c == null ? 0 : c.Rg) || (c == null ? 0 : c.credentials) && c.credentials !== "include") return e == null || e(), !1;
        if (b) {
            var h = pd(a, b);
            h ? d == null || d() : e == null || e();
            return h
        }
        td(a, d, e);
        return !0
    }

    function sd() {
        return typeof w.fetch === "function"
    }

    function ud(a, b) {
        var c = a[b];
        c && typeof c.animVal === "string" && (c = c.animVal);
        return c
    }

    function vd() {
        var a = w.performance;
        if (a && Cb(a.now)) return a.now()
    }

    function wd() {
        var a, b = w.performance;
        if (b && b.getEntriesByType) try {
            var c = b.getEntriesByType("navigation");
            c && c.length > 0 && (a = c[0].type)
        } catch (d) {
            return "e"
        }
        if (!a) return "u";
        switch (a) {
            case "navigate":
                return "n";
            case "back_forward":
                return "h";
            case "reload":
                return "r";
            case "prerender":
                return "p";
            default:
                return "x"
        }
    }

    function xd() {
        return w.performance || void 0
    }

    function yd() {
        var a = w.webPixelsManager;
        return a ? a.createShopifyExtend !== void 0 : !1
    }
    var gd = function(a, b, c, d) {
            var e = new Image(1, 1);
            bd(e, d, {});
            e.onload = function() {
                e.onload = null;
                b && b()
            };
            e.onerror = function() {
                e.onerror = null;
                c && c()
            };
            e.src = a;
            return e
        },
        td = od;

    function zd(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function Ad(a, b) {
        return this.evaluate(a) === this.evaluate(b)
    }

    function Bd(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function Cd(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        return String(c).indexOf(String(d)) > -1
    }

    function Dd(a, b) {
        var c = String(this.evaluate(a)),
            d = String(this.evaluate(b));
        return c.substring(0, d.length) === d
    }

    function Ed(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        switch (c) {
            case "pageLocation":
                var e = w.location.href;
                d instanceof nb && d.get("stripProtocol") && (e = e.replace(/^https?:\/\//, ""));
                return e
        }
    };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
    */
    var Fd = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        Gd = function(a) {
            if (a == null) return String(a);
            var b = Fd.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        Hd = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        Id = function(a) {
            if (!a || Gd(a) != "object" || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !Hd(a, "constructor") && !Hd(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return b === void 0 ||
                Hd(a, b)
        },
        Jd = function(a, b) {
            var c = b || (Gd(a) == "array" ? [] : {}),
                d;
            for (d in a)
                if (Hd(a, d)) {
                    var e = a[d];
                    Gd(e) == "array" ? (Gd(c[d]) != "array" && (c[d] = []), c[d] = Jd(e, c[d])) : Id(e) ? (Id(c[d]) || (c[d] = {}), c[d] = Jd(e, c[d])) : c[d] = e
                }
            return c
        };

    function Kd(a) {
        return typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0 || typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a)
    };
    var Ld = function(a) {
        a = a === void 0 ? [] : a;
        this.ia = new Va;
        this.values = [];
        this.Ja = !1;
        for (var b in a) a.hasOwnProperty(b) && (Kd(b) ? this.values[Number(b)] = a[Number(b)] : this.ia.set(b, a[b]))
    };
    k = Ld.prototype;
    k.toString = function(a) {
        if (a && a.indexOf(this) >= 0) return "";
        for (var b = [], c = 0; c < this.values.length; c++) {
            var d = this.values[c];
            d === null || d === void 0 ? b.push("") : d instanceof Ld ? (a = a || [], a.push(this), b.push(d.toString(a)), a.pop()) : b.push(String(d))
        }
        return b.join(",")
    };
    k.set = function(a, b) {
        if (!this.Ja)
            if (a === "length") {
                if (!Kd(b)) throw gb(Error("RangeError: Length property must be a valid integer."));
                this.values.length = Number(b)
            } else Kd(a) ? this.values[Number(a)] = b : this.ia.set(a, b)
    };
    k.get = function(a) {
        return a === "length" ? this.length() : Kd(a) ? this.values[Number(a)] : this.ia.get(a)
    };
    k.length = function() {
        return this.values.length
    };
    k.Aa = function() {
        for (var a = this.ia.Aa(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(String(b));
        return a
    };
    k.Hc = function() {
        for (var a = this.ia.Hc(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(this.values[b]);
        return a
    };
    k.kc = function() {
        for (var a = this.ia.kc(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
        return a
    };
    k.remove = function(a) {
        Kd(a) ? delete this.values[Number(a)] : this.Ja || this.ia.remove(a)
    };
    k.pop = function() {
        return this.values.pop()
    };
    k.push = function() {
        return this.values.push.apply(this.values, Aa(Qa.apply(0, arguments)))
    };
    k.shift = function() {
        return this.values.shift()
    };
    k.splice = function(a, b) {
        var c = Qa.apply(2, arguments);
        return b === void 0 && c.length === 0 ? new Ld(this.values.splice(a)) : new Ld(this.values.splice.apply(this.values, [a, b || 0].concat(Aa(c))))
    };
    k.unshift = function() {
        return this.values.unshift.apply(this.values, Aa(Qa.apply(0, arguments)))
    };
    k.has = function(a) {
        return Kd(a) && this.values.hasOwnProperty(a) || this.ia.has(a)
    };
    k.Wa = function() {
        this.Ja = !0;
        Object.freeze(this.values)
    };
    k.Hb = function() {
        return this.Ja
    };

    function Md(a) {
        for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
        return b
    };
    var Nd = function(a, b) {
        this.functionName = a;
        this.Wd = b;
        this.ia = new Va;
        this.Ja = !1
    };
    k = Nd.prototype;
    k.toString = function() {
        return this.functionName
    };
    k.getName = function() {
        return this.functionName
    };
    k.getKeys = function() {
        return new Ld(this.Aa())
    };
    k.invoke = function(a) {
        return this.Wd.call.apply(this.Wd, [new Od(this, a)].concat(Aa(Qa.apply(1, arguments))))
    };
    k.apply = function(a, b) {
        return this.Wd.apply(new Od(this, a), b)
    };
    k.Sb = function(a) {
        var b = Qa.apply(1, arguments);
        try {
            return this.invoke.apply(this, [a].concat(Aa(b)))
        } catch (c) {}
    };
    k.get = function(a) {
        return this.ia.get(a)
    };
    k.set = function(a, b) {
        this.Ja || this.ia.set(a, b)
    };
    k.has = function(a) {
        return this.ia.has(a)
    };
    k.remove = function(a) {
        this.Ja || this.ia.remove(a)
    };
    k.Aa = function() {
        return this.ia.Aa()
    };
    k.Hc = function() {
        return this.ia.Hc()
    };
    k.kc = function() {
        return this.ia.kc()
    };
    k.Wa = function() {
        this.Ja = !0
    };
    k.Hb = function() {
        return this.Ja
    };
    var Pd = function(a, b) {
        Nd.call(this, a, b)
    };
    xa(Pd, Nd);
    var Qd = function(a, b) {
        Nd.call(this, a, b)
    };
    xa(Qd, Nd);
    var Od = function(a, b) {
        this.Wd = a;
        this.M = b
    };
    Od.prototype.evaluate = function(a) {
        var b = this.M;
        return Array.isArray(a) ? lb(b, a) : a
    };
    Od.prototype.getName = function() {
        return this.Wd.getName()
    };
    Od.prototype.Xd = function() {
        return this.M.Xd()
    };
    var Rd = function() {
        this.map = new Map
    };
    Rd.prototype.set = function(a, b) {
        this.map.set(a, b)
    };
    Rd.prototype.get = function(a) {
        return this.map.get(a)
    };
    var Sd = function() {
        this.keys = [];
        this.values = []
    };
    Sd.prototype.set = function(a, b) {
        this.keys.push(a);
        this.values.push(b)
    };
    Sd.prototype.get = function(a) {
        var b = this.keys.indexOf(a);
        if (b > -1) return this.values[b]
    };

    function Td() {
        try {
            return Map ? new Rd : new Sd
        } catch (a) {
            return new Sd
        }
    };
    var Ud = function(a) {
        if (a instanceof Ud) return a;
        var b;
        a: if (a == void 0 || Array.isArray(a) || Id(a)) b = !0;
            else {
                switch (typeof a) {
                    case "boolean":
                    case "number":
                    case "string":
                    case "function":
                        b = !0;
                        break a
                }
                b = !1
            }
        if (b) throw Error("Type of given value has an equivalent Pixie type.");
        this.value = a
    };
    Ud.prototype.getValue = function() {
        return this.value
    };
    Ud.prototype.toString = function() {
        return String(this.value)
    };
    var Wd = function(a) {
        this.promise = a;
        this.Ja = !1;
        this.ia = new Va;
        this.ia.set("then", Vd(this));
        this.ia.set("catch", Vd(this, !0));
        this.ia.set("finally", Vd(this, !1, !0))
    };
    k = Wd.prototype;
    k.get = function(a) {
        return this.ia.get(a)
    };
    k.set = function(a, b) {
        this.Ja || this.ia.set(a, b)
    };
    k.has = function(a) {
        return this.ia.has(a)
    };
    k.remove = function(a) {
        this.Ja || this.ia.remove(a)
    };
    k.Aa = function() {
        return this.ia.Aa()
    };
    k.Hc = function() {
        return this.ia.Hc()
    };
    k.kc = function() {
        return this.ia.kc()
    };
    var Vd = function(a, b, c) {
        b = b === void 0 ? !1 : b;
        c = c === void 0 ? !1 : c;
        return new Pd("", function(d, e) {
            b && (e = d, d = void 0);
            c && (e = d);
            d instanceof Pd || (d = void 0);
            e instanceof Pd || (e = void 0);
            var f = this.M.ub(),
                g = function(l) {
                    return function(n) {
                        try {
                            return c ? (l.invoke(f), a.promise) : l.invoke(f, n)
                        } catch (p) {
                            return Promise.reject(p instanceof Error ? new Ud(p) : String(p))
                        }
                    }
                },
                h = a.promise.then(d && g(d), e && g(e));
            return new Wd(h)
        })
    };
    Wd.prototype.Wa = function() {
        this.Ja = !0
    };
    Wd.prototype.Hb = function() {
        return this.Ja
    };

    function B(a, b, c) {
        var d = Td(),
            e = function(g, h) {
                for (var l = g.Aa(), n = 0; n < l.length; n++) h[l[n]] = f(g.get(l[n]))
            },
            f = function(g) {
                if (g === null || g === void 0) return g;
                var h = d.get(g);
                if (h) return h;
                if (g instanceof Ld) {
                    var l = [];
                    d.set(g, l);
                    for (var n = g.Aa(), p = 0; p < n.length; p++) l[n[p]] = f(g.get(n[p]));
                    return l
                }
                if (g instanceof Wd) return g.promise.then(function(u) {
                    return B(u, b, 1)
                }, function(u) {
                    return Promise.reject(B(u, b, 1))
                });
                if (g instanceof nb) {
                    var q = {};
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                if (g instanceof Pd) {
                    var r = function() {
                        for (var u = [], v = 0; v < arguments.length; v++) u[v] = Xd(arguments[v], b, c);
                        var x = new Za(b ? b.Xd() : new Xa);
                        b && x.he(b.xb());
                        return f(ib(17) ? g.apply(x, u) : g.invoke.apply(g, [x].concat(Aa(u))))
                    };
                    d.set(g, r);
                    e(g, r);
                    return r
                }
                var t = !1;
                switch (c) {
                    case 1:
                        t = !0;
                        break;
                    case 2:
                        t = !1;
                        break;
                    case 3:
                        t = !1;
                        break;
                    default:
                }
                if (g instanceof Ud && t) return g.getValue();
                switch (typeof g) {
                    case "boolean":
                    case "number":
                    case "string":
                    case "undefined":
                        return g;
                    case "object":
                        if (g === null) return null
                }
            };
        return f(a)
    }

    function Xd(a, b, c) {
        var d = Td(),
            e = function(g, h) {
                for (var l in g) g.hasOwnProperty(l) && h.set(l, f(g[l]))
            },
            f = function(g) {
                var h = d.get(g);
                if (h) return h;
                if (Array.isArray(g) || Mb(g)) {
                    var l = new Ld;
                    d.set(g, l);
                    for (var n in g) g.hasOwnProperty(n) && l.set(n, f(g[n]));
                    return l
                }
                if (Id(g)) {
                    var p = new nb;
                    d.set(g, p);
                    e(g, p);
                    return p
                }
                if (typeof g === "function") {
                    var q = new Pd("", function() {
                        for (var u = Qa.apply(0, arguments), v = [], x = 0; x < u.length; x++) v[x] = B(this.evaluate(u[x]), b, c);
                        return f(this.M.Dj()(g, g, v))
                    });
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                var r = typeof g;
                if (g === null || r === "string" || r === "number" || r === "boolean") return g;
                var t = !1;
                switch (c) {
                    case 1:
                        t = !0;
                        break;
                    case 2:
                        t = !1;
                        break;
                    default:
                }
                if (g !== void 0 && t) return new Ud(g)
            };
        return f(a)
    };
    var Yd = {
        supportedMethods: "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(" "),
        concat: function(a) {
            for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
            for (var d = 1; d < arguments.length; d++)
                if (arguments[d] instanceof Ld)
                    for (var e = arguments[d], f = 0; f < e.length(); f++) b.push(e.get(f));
                else b.push(arguments[d]);
            return new Ld(b)
        },
        every: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() &&
                d < c; d++)
                if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
            return !0
        },
        filter: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
            return new Ld(d)
        },
        forEach: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++) this.has(d) && b.invoke(a, this.get(d), d, this)
        },
        hasOwnProperty: function(a, b) {
            return this.has(b)
        },
        indexOf: function(a, b, c) {
            var d = this.length(),
                e = c === void 0 ? 0 : Number(c);
            e < 0 && (e = Math.max(d + e, 0));
            for (var f =
                    e; f < d; f++)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        join: function(a, b) {
            for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
            return c.join(b)
        },
        lastIndexOf: function(a, b, c) {
            var d = this.length(),
                e = d - 1;
            c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
            for (var f = e; f >= 0; f--)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        map: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
            return new Ld(d)
        },
        pop: function() {
            return this.pop()
        },
        push: function(a) {
            return this.push.apply(this,
                Aa(Qa.apply(1, arguments)))
        },
        reduce: function(a, b, c) {
            var d = this.length(),
                e, f = 0;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw gb(Error("TypeError: Reduce on List with no elements."));
                for (var g = 0; g < d; g++)
                    if (this.has(g)) {
                        e = this.get(g);
                        f = g + 1;
                        break
                    }
                if (g === d) throw gb(Error("TypeError: Reduce on List with no elements."));
            }
            for (var h = f; h < d; h++) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reduceRight: function(a, b, c) {
            var d = this.length(),
                e, f = d - 1;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw gb(Error("TypeError: ReduceRight on List with no elements."));
                for (var g = 1; g <= d; g++)
                    if (this.has(d - g)) {
                        e = this.get(d - g);
                        f = d - (g + 1);
                        break
                    }
                if (g > d) throw gb(Error("TypeError: ReduceRight on List with no elements."));
            }
            for (var h = f; h >= 0; h--) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reverse: function() {
            for (var a = Md(this), b = a.length - 1, c = 0; b >= 0; b--, c++) a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
            return this
        },
        shift: function() {
            return this.shift()
        },
        slice: function(a, b, c) {
            var d = this.length();
            b === void 0 && (b = 0);
            b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
            c = c ===
                void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
            c = Math.max(b, c);
            for (var e = [], f = b; f < c; f++) e.push(this.get(f));
            return new Ld(e)
        },
        some: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
                if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
            return !1
        },
        sort: function(a, b) {
            var c = Md(this);
            b === void 0 ? c.sort() : c.sort(function(e, f) {
                return Number(b.invoke(a, e, f))
            });
            for (var d = 0; d < c.length; d++) c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
            return this
        },
        splice: function(a, b, c) {
            return this.splice.apply(this, [b, c].concat(Aa(Qa.apply(3, arguments))))
        },
        toString: function() {
            return this.toString()
        },
        unshift: function(a) {
            return this.unshift.apply(this, Aa(Qa.apply(1, arguments)))
        }
    };
    var Zd = {
            charAt: 1,
            concat: 1,
            indexOf: 1,
            lastIndexOf: 1,
            match: 1,
            replace: 1,
            search: 1,
            slice: 1,
            split: 1,
            substring: 1,
            toLowerCase: 1,
            toLocaleLowerCase: 1,
            toString: 1,
            toUpperCase: 1,
            toLocaleUpperCase: 1,
            trim: 1
        },
        $d = new Ua("break"),
        ae = new Ua("continue");

    function be(a, b) {
        return this.evaluate(a) + this.evaluate(b)
    }

    function ce(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function de(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!(f instanceof Ld)) throw Error("Error: Non-List argument given to Apply instruction.");
        if (d === null || d === void 0) throw gb(Error("TypeError: Can't read property " + e + " of " + d + "."));
        var g = typeof d === "number";
        if (typeof d === "boolean" || g) {
            if (e === "toString") {
                if (g && f.length()) {
                    var h = B(f.get(0));
                    try {
                        return d.toString(h)
                    } catch (u) {}
                }
                return d.toString()
            }
            throw gb(Error("TypeError: " + d + "." + e + " is not a function."));
        }
        if (typeof d ===
            "string") {
            if (Zd.hasOwnProperty(e)) {
                var l = B(f, void 0, 1);
                return Xd(d[e].apply(d, l), this.M)
            }
            throw gb(Error("TypeError: " + e + " is not a function"));
        }
        if (d instanceof Ld) {
            if (d.has(e)) {
                var n = d.get(String(e));
                if (n instanceof Pd) {
                    var p = Md(f);
                    return ib(17) ? n.apply(this.M, p) : n.invoke.apply(n, [this.M].concat(Aa(p)))
                }
                throw gb(Error("TypeError: " + e + " is not a function"));
            }
            if (Yd.supportedMethods.indexOf(e) >= 0) {
                var q = Md(f);
                return Yd[e].call.apply(Yd[e], [d, this.M].concat(Aa(q)))
            }
        }
        if (d instanceof Pd || d instanceof nb ||
            d instanceof Wd) {
            if (d.has(e)) {
                var r = d.get(e);
                if (r instanceof Pd) {
                    var t = Md(f);
                    return ib(17) ? r.apply(this.M, t) : r.invoke.apply(r, [this.M].concat(Aa(t)))
                }
                throw gb(Error("TypeError: " + e + " is not a function"));
            }
            if (e === "toString") return d instanceof Pd ? d.getName() : d.toString();
            if (e === "hasOwnProperty") return d.has(f.get(0))
        }
        if (d instanceof Ud && e === "toString") return d.toString();
        throw gb(Error("TypeError: Object has no '" + e + "' property."));
    }

    function ee(a, b) {
        a = this.evaluate(a);
        if (typeof a !== "string") throw Error("Invalid key name given for assignment.");
        var c = this.M;
        if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
        var d = this.evaluate(b);
        c.set(a, d);
        return d
    }

    function fe() {
        var a = Qa.apply(0, arguments),
            b = this.M.ub(),
            c = kb(b, a);
        if (c instanceof Ua) return c
    }

    function ge() {
        return $d
    }

    function he(a) {
        for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
            var d = this.evaluate(b[c]);
            if (d instanceof Ua) return d
        }
    }

    function ke() {
        for (var a = this.M, b = 0; b < arguments.length - 1; b += 2) {
            var c = arguments[b];
            if (typeof c === "string") {
                var d = this.evaluate(arguments[b + 1]);
                a.Qh(c, d)
            }
        }
    }

    function le() {
        return ae
    }

    function me(a, b) {
        return new Ua(a, this.evaluate(b))
    }

    function ne(a, b) {
        var c = Qa.apply(2, arguments),
            d;
        d = new Ld;
        for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
        var g = [51, a, d].concat(Aa(c));
        this.M.add(a, this.evaluate(g))
    }

    function oe(a, b) {
        return this.evaluate(a) / this.evaluate(b)
    }

    function pe(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b),
            e = c instanceof Ud,
            f = d instanceof Ud;
        return e || f ? e && f ? c.getValue() === d.getValue() : !1 : c == d
    }

    function qe() {
        for (var a, b = 0; b < arguments.length; b++) a = this.evaluate(arguments[b]);
        return a
    }

    function re(a, b, c, d) {
        for (var e = 0; e < b(); e++) {
            var f = a(c(e)),
                g = kb(f, d);
            if (g instanceof Ua) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
        }
    }

    function se(a, b, c) {
        if (typeof b === "string") return re(a, function() {
            return b.length
        }, function(f) {
            return f
        }, c);
        if (b instanceof nb || b instanceof Wd || b instanceof Ld || b instanceof Pd) {
            var d = b.Aa(),
                e = d.length;
            return re(a, function() {
                return e
            }, function(f) {
                return d[f]
            }, c)
        }
    }

    function te(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.M;
        return se(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function ue(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.M;
        return se(function(h) {
            var l = g.ub();
            l.Qh(d, h);
            return l
        }, e, f)
    }

    function ve(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.M;
        return se(function(h) {
            var l = g.ub();
            l.add(d, h);
            return l
        }, e, f)
    }

    function we(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.M;
        return xe(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function ye(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.M;
        return xe(function(h) {
            var l = g.ub();
            l.Qh(d, h);
            return l
        }, e, f)
    }

    function ze(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.M;
        return xe(function(h) {
            var l = g.ub();
            l.add(d, h);
            return l
        }, e, f)
    }

    function xe(a, b, c) {
        if (typeof b === "string") return re(a, function() {
            return b.length
        }, function(d) {
            return b[d]
        }, c);
        if (b instanceof Ld) return re(a, function() {
            return b.length()
        }, function(d) {
            return b.get(d)
        }, c);
        throw gb(Error("The value is not iterable."));
    }

    function Ae(a, b, c, d) {
        function e(q, r) {
            for (var t = 0; t < f.length(); t++) {
                var u = f.get(t);
                r.add(u, q.get(u))
            }
        }
        var f = this.evaluate(a);
        if (!(f instanceof Ld)) throw Error("TypeError: Non-List argument given to ForLet instruction.");
        var g = this.M,
            h = this.evaluate(d),
            l = g.ub();
        for (e(g, l); lb(l, b);) {
            var n = kb(l, h);
            if (n instanceof Ua) {
                if (n.type === "break") break;
                if (n.type === "return") return n
            }
            var p = g.ub();
            e(l, p);
            lb(p, c);
            l = p
        }
    }

    function Be(a, b) {
        var c = Qa.apply(2, arguments),
            d = this.M,
            e = this.evaluate(b);
        if (!(e instanceof Ld)) throw Error("Error: non-List value given for Fn argument names.");
        return new Pd(a, function() {
            return function() {
                var f = Qa.apply(0, arguments),
                    g = d.ub();
                g.xb() === void 0 && g.he(this.M.xb());
                for (var h = [], l = 0; l < f.length; l++) {
                    var n = this.evaluate(f[l]);
                    h[l] = n
                }
                for (var p = e.get("length"), q = 0; q < p; q++) q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
                g.add("arguments", new Ld(h));
                var r = kb(g, c);
                if (r instanceof Ua) return r.type ===
                    "return" ? r.data : r
            }
        }())
    }

    function Ce(a) {
        var b = this.evaluate(a),
            c = this.M;
        if (De && !c.has(b)) throw new ReferenceError(b + " is not defined.");
        return c.get(b)
    }

    function Ee(a, b) {
        var c, d = this.evaluate(a),
            e = this.evaluate(b);
        if (d === void 0 || d === null) throw gb(Error("TypeError: Cannot read properties of " + d + " (reading '" + e + "')"));
        if (d instanceof nb || d instanceof Wd || d instanceof Ld || d instanceof Pd) c = d.get(e);
        else if (typeof d === "string") e === "length" ? c = d.length : Kd(e) && (c = d[e]);
        else if (d instanceof Ud) return;
        return c
    }

    function Fe(a, b) {
        return this.evaluate(a) > this.evaluate(b)
    }

    function Ge(a, b) {
        return this.evaluate(a) >= this.evaluate(b)
    }

    function He(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        c instanceof Ud && (c = c.getValue());
        d instanceof Ud && (d = d.getValue());
        return c === d
    }

    function Ie(a, b) {
        return !He.call(this, a, b)
    }

    function Je(a, b, c) {
        var d = [];
        this.evaluate(a) ? d = this.evaluate(b) : c && (d = this.evaluate(c));
        var e = kb(this.M, d);
        if (e instanceof Ua) return e
    }
    var De = !1;

    function Ke(a, b) {
        return this.evaluate(a) < this.evaluate(b)
    }

    function Le(a, b) {
        return this.evaluate(a) <= this.evaluate(b)
    }

    function Me() {
        for (var a = new Ld, b = 0; b < arguments.length; b++) {
            var c = this.evaluate(arguments[b]);
            a.push(c)
        }
        return a
    }

    function Ne() {
        for (var a = new nb, b = 0; b < arguments.length - 1; b += 2) {
            var c = String(this.evaluate(arguments[b])),
                d = this.evaluate(arguments[b + 1]);
            a.set(c, d)
        }
        return a
    }

    function Oe(a, b) {
        return this.evaluate(a) % this.evaluate(b)
    }

    function Pe(a, b) {
        return this.evaluate(a) * this.evaluate(b)
    }

    function Qe(a) {
        return -this.evaluate(a)
    }

    function Se(a) {
        return !this.evaluate(a)
    }

    function Te(a, b) {
        return !pe.call(this, a, b)
    }

    function Ue() {
        return null
    }

    function Ve(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function We(a, b) {
        var c = this.evaluate(a);
        this.evaluate(b);
        return c
    }

    function Xe(a) {
        return this.evaluate(a)
    }

    function Ye() {
        return Qa.apply(0, arguments)
    }

    function Ze(a) {
        return new Ua("return", this.evaluate(a))
    }

    function $e(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (d === null || d === void 0) throw gb(Error("TypeError: Can't set property " + e + " of " + d + "."));
        (d instanceof Pd || d instanceof Ld || d instanceof nb) && d.set(String(e), f);
        return f
    }

    function af(a, b) {
        return this.evaluate(a) - this.evaluate(b)
    }

    function bf(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!Array.isArray(e) || !Array.isArray(f)) throw Error("Error: Malformed switch instruction.");
        for (var g, h = !1, l = 0; l < e.length; l++)
            if (h || d === this.evaluate(e[l]))
                if (g = this.evaluate(f[l]), g instanceof Ua) {
                    var n = g.type;
                    if (n === "break") return;
                    if (n === "return" || n === "continue") return g
                } else h = !0;
        if (f.length === e.length + 1 && (g = this.evaluate(f[f.length - 1]), g instanceof Ua && (g.type === "return" || g.type === "continue"))) return g
    }

    function cf(a, b, c) {
        return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c)
    }

    function df(a) {
        var b = this.evaluate(a);
        return b instanceof Pd ? "function" : typeof b
    }

    function ef() {
        for (var a = this.M, b = 0; b < arguments.length; b++) {
            var c = arguments[b];
            typeof c !== "string" || a.add(c, void 0)
        }
    }

    function ff(a, b, c, d) {
        var e = this.evaluate(d);
        if (this.evaluate(c)) {
            var f = kb(this.M, e);
            if (f instanceof Ua) {
                if (f.type === "break") return;
                if (f.type === "return") return f
            }
        }
        for (; this.evaluate(a);) {
            var g = kb(this.M, e);
            if (g instanceof Ua) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
            this.evaluate(b)
        }
    }

    function gf(a) {
        return ~Number(this.evaluate(a))
    }

    function hf(a, b) {
        return Number(this.evaluate(a)) << Number(this.evaluate(b))
    }

    function jf(a, b) {
        return Number(this.evaluate(a)) >> Number(this.evaluate(b))
    }

    function kf(a, b) {
        return Number(this.evaluate(a)) >>> Number(this.evaluate(b))
    }

    function lf(a, b) {
        return Number(this.evaluate(a)) & Number(this.evaluate(b))
    }

    function mf(a, b) {
        return Number(this.evaluate(a)) ^ Number(this.evaluate(b))
    }

    function nf(a, b) {
        return Number(this.evaluate(a)) | Number(this.evaluate(b))
    }

    function of () {}

    function pf(a, b, c) {
        try {
            var d = this.evaluate(b);
            if (d instanceof Ua) return d
        } catch (h) {
            if (!(h instanceof fb && h.Dn)) throw h;
            var e = this.M.ub();
            a !== "" && (h instanceof fb && (h = h.eo), e.add(a, new Ud(h)));
            var f = this.evaluate(c),
                g = kb(e, f);
            if (g instanceof Ua) return g
        }
    }

    function qf(a, b) {
        var c, d;
        try {
            d = this.evaluate(a)
        } catch (f) {
            if (!(f instanceof fb && f.Dn)) throw f;
            c = f
        }
        var e = this.evaluate(b);
        if (e instanceof Ua) return e;
        if (c) throw c;
        if (d instanceof Ua) return d
    };
    var sf = function() {
        this.D = new mb;
        rf(this)
    };
    sf.prototype.execute = function(a) {
        return this.D.gk(a)
    };
    var rf = function(a) {
        var b = function(c, d) {
            var e = new Qd(String(c), d);
            e.Wa();
            var f = String(c);
            a.D.D.set(f, e);
            jb.set(f, e)
        };
        b("map", Ne);
        b("and", zd);
        b("contains", Cd);
        b("equals", Ad);
        b("or", Bd);
        b("startsWith", Dd);
        b("variable", Ed)
    };
    sf.prototype.Tb = function(a) {
        this.D.Tb(a)
    };
    var uf = function() {
        this.J = !1;
        this.D = new mb;
        tf(this);
        this.J = !0
    };
    uf.prototype.execute = function(a) {
        return vf(this.D.gk(a))
    };
    var wf = function(a, b, c) {
        return vf(a.D.kq(b, c))
    };
    uf.prototype.Wa = function() {
        this.D.Wa()
    };
    var tf = function(a) {
        var b = function(c, d) {
            var e = String(c),
                f = new Qd(e, d);
            f.Wa();
            a.D.D.set(e, f);
            jb.set(e, f)
        };
        b(0, be);
        b(1, ce);
        b(2, de);
        b(3, ee);
        b(56, lf);
        b(57, hf);
        b(58, gf);
        b(59, nf);
        b(60, jf);
        b(61, kf);
        b(62, mf);
        b(53, fe);
        b(4, ge);
        b(5, he);
        b(68, pf);
        b(52, ke);
        b(6, le);
        b(49, me);
        b(7, Me);
        b(8, Ne);
        b(9, he);
        b(50, ne);
        b(10, oe);
        b(12, pe);
        b(13, qe);
        b(67, qf);
        b(51, Be);
        b(47, te);
        b(54, ue);
        b(55, ve);
        b(63, Ae);
        b(64, we);
        b(65, ye);
        b(66, ze);
        b(15, Ce);
        b(16, Ee);
        b(17, Ee);
        b(18, Fe);
        b(19, Ge);
        b(20, He);
        b(21, Ie);
        b(22, Je);
        b(23, Ke);
        b(24, Le);
        b(25, Oe);
        b(26,
            Pe);
        b(27, Qe);
        b(28, Se);
        b(29, Te);
        b(45, Ue);
        b(30, Ve);
        b(32, We);
        b(33, We);
        b(34, Xe);
        b(35, Xe);
        b(46, Ye);
        b(36, Ze);
        b(43, $e);
        b(37, af);
        b(38, bf);
        b(39, cf);
        b(40, df);
        b(44, of );
        b(41, ef);
        b(42, ff)
    };
    uf.prototype.Xd = function() {
        return this.D.Xd()
    };
    uf.prototype.Tb = function(a) {
        this.D.Tb(a)
    };
    uf.prototype.kd = function(a) {
        this.D.kd(a)
    };

    function vf(a) {
        if (a instanceof Ua || a instanceof Pd || a instanceof Ld || a instanceof nb || a instanceof Wd || a instanceof Ud || a === null || a === void 0 || typeof a === "string" || typeof a === "number" || typeof a === "boolean") return a
    };
    var xf = function(a) {
        this.message = a
    };

    function yf(a) {
        a.Du = !0;
        return a
    };
    var zf = yf(function(a) {
        return typeof a === "string"
    });

    function Af(a) {
        var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [a];
        return b === void 0 ? new xf("Value " + a + " can not be encoded in web-safe base64 dictionary.") : b
    };

    function Bf(a) {
        switch (a) {
            case 1:
                return "1";
            case 2:
            case 4:
                return "0";
            default:
                return "-"
        }
    };
    var Cf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;

    function Df(a, b) {
        for (var c = "", d = !0; a > 7;) {
            var e = a & 31;
            a >>= 5;
            d ? d = !1 : e |= 32;
            c = "" + Af(e) + c
        }
        a <<= 2;
        d || (a |= 32);
        return c = "" + Af(a | b) + c
    }

    function Ef(a, b) {
        var c;
        var d = a.hi,
            e = a.Rj;
        d === void 0 ? c = "" : (e || (e = 0), c = "" + Df(1, 1) + Af(d << 2 | e));
        var f = a.Oq,
            g = "4" + c + (f ? "" + Df(2, 1) + Af(f) : ""),
            h, l = a.uo;
        h = l && Cf.test(l) ? "" + Df(3, 2) + l : "";
        var n, p = a.po;
        n = p ? "" + Df(4, 1) + Af(p) : "";
        var q;
        var r = a.ctid;
        if (r && b) {
            var t = Df(5, 3),
                u = r.split("-"),
                v = u[0].toUpperCase();
            if (v !== "GTM" && v !== "OPT") q = "";
            else {
                var x = u[1];
                q = "" + t + Af(1 + x.length) + (a.Zr || 0) + x
            }
        } else q = "";
        var y = a.Ps,
            z = a.canonicalId,
            C = a.Sa,
            D = a.Pu,
            G = g + h + n + q + (y ? "" + Df(6, 1) + Af(y) : "") + (z ? "" + Df(7, 3) + Af(z.length) + z : "") + (C ? "" + Df(8, 3) +
                Af(C.length) + C : "") + (D ? "" + Df(9, 3) + Af(D.length) + D : ""),
            J;
        var L = a.Uq;
        L = L === void 0 ? {} : L;
        for (var da = [], aa = m(Object.keys(L)), N = aa.next(); !N.done; N = aa.next()) {
            var R = N.value;
            da[Number(R)] = L[R]
        }
        if (da.length) {
            var ja = Df(10, 3),
                la;
            if (da.length === 0) la = Af(0);
            else {
                for (var Z = [], V = 0, ha = !1, ua = 0; ua < da.length; ua++) {
                    ha = !0;
                    var ma = ua % 6;
                    da[ua] && (V |= 1 << ma);
                    ma === 5 && (Z.push(Af(V)), V = 0, ha = !1)
                }
                ha && Z.push(Af(V));
                la = Z.join("")
            }
            var Ea = la;
            J = "" + ja + Af(Ea.length) + Ea
        } else J = "";
        var Ya = a.qs,
            Rb = a.Gs,
            Jb = a.Qs;
        return G + J + (Ya ? "" + Df(11, 3) + Af(Ya.length) +
            Ya : "") + (Rb ? "" + Df(13, 3) + Af(Rb.length) + Rb : "") + (Jb ? "" + Df(14, 1) + Af(Jb) : "")
    };

    function Ff(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        return b
    };

    function Gf(a, b) {
        for (var c = tb(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++) d[e] = c.charCodeAt(e);
        if (d.length !== 32) throw Error("Key is not 32 bytes.");
        return Hf(a, d)
    }

    function Hf(a, b) {
        if (a === "") return "";
        var c = dc(a),
            d = b.slice(-2),
            e = [].concat(Aa(d), Aa(c)).map(function(g, h) {
                return g ^ b[h % b.length]
            }),
            f = new Uint8Array([].concat(Aa(e), Aa(d)));
        return sb(String.fromCharCode.apply(String, Aa(f))).replace(/\.+$/, "")
    };
    var Kf = function() {
        function a(b) {
            return {
                toString: function() {
                    return b
                }
            }
        }
        return {
            Lo: a("consent"),
            Ik: a("convert_case_to"),
            Jk: a("convert_false_to"),
            Kk: a("convert_null_to"),
            Lk: a("convert_true_to"),
            Mk: a("convert_undefined_to"),
            nt: a("debug_mode_metadata"),
            ab: a("function"),
            Si: a("instance_name"),
            oq: a("live_only"),
            qq: a("malware_disabled"),
            METADATA: a("metadata"),
            tq: a("original_activity_id"),
            iu: a("original_vendor_template_id"),
            hu: a("once_on_load"),
            sq: a("once_per_event"),
            Sm: a("once_per_load"),
            ku: a("priority_override"),
            nu: a("respected_consent_types"),
            dn: a("setup_tags"),
            Ph: a("tag_id"),
            sn: a("teardown_tags")
        }
    }();
    var fg;
    var gg = [],
        hg = [],
        ig = [],
        jg = [],
        kg = [],
        lg, mg, ng;

    function og(a) {
        ng = ng || a
    }

    function pg() {
        for (var a = data.resource || {}, b = a.macros || [], c = 0; c < b.length; c++) gg.push(b[c]);
        for (var d = a.tags || [], e = 0; e < d.length; e++) jg.push(d[e]);
        for (var f = a.predicates || [], g = 0; g < f.length; g++) ig.push(f[g]);
        for (var h = a.rules || [], l = 0; l < h.length; l++) {
            for (var n = h[l], p = {}, q = 0; q < n.length; q++) {
                var r = n[q][0];
                p[r] = Array.prototype.slice.call(n[q], 1);
                r !== "if" && r !== "unless" || qg(p[r])
            }
            hg.push(p)
        }
    }

    function qg(a) {}
    var rg;

    function sg(a, b) {
        var c = {};
        c[Kf.ab] = "__" + a;
        for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
        return c
    }

    function tg(a, b, c) {
        try {
            return mg(ug(a, b, c))
        } catch (d) {
            JSON.stringify(a)
        }
        return 2
    }
    var ug = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = vg(a[e], b, c));
            return d
        },
        vg = function(a, b, c) {
            if (Array.isArray(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e < a.length; e++) d.push(vg(a[e], b, c));
                        return d;
                    case "macro":
                        var f = a[1];
                        if (c[f]) return;
                        var g = gg[f];
                        if (!g || b.isBlocked(g)) return;
                        c[f] = !0;
                        var h = String(g[Kf.Si]);
                        try {
                            var l = ug(g, b, c);
                            l.vtp_gtmEventId = b.id;
                            b.priorityId && (l.vtp_gtmPriorityId = b.priorityId);
                            d = wg(l, {
                                event: b,
                                index: f,
                                type: 2,
                                name: h
                            });
                            rg && (d = rg.Vq(d, l))
                        } catch (z) {
                            b.logMacroError && b.logMacroError(z, Number(f), h), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var n = 1; n < a.length; n += 2) d[vg(a[n], b, c)] = vg(a[n + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var p = !1, q = 1; q < a.length; q++) {
                            var r = vg(a[q], b, c);
                            ng && (p = p || ng.Vr(r));
                            d.push(r)
                        }
                        return ng && p ? ng.ar(d) : d.join("");
                    case "escape":
                        d = vg(a[1], b, c);
                        if (ng && Array.isArray(a[1]) && a[1][0] === "macro" && ng.Wr(a)) return ng.ws(d);
                        d = String(d);
                        for (var t = 2; t < a.length; t++) Rf[a[t]] && (d = Rf[a[t]](d));
                        return d;
                    case "tag":
                        var u = a[1];
                        if (!jg[u]) throw Error("Unable to resolve tag reference " + u + ".");
                        return {
                            Ln: a[2],
                            index: u
                        };
                    case "zb":
                        var v = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        v[Kf.ab] = a[1];
                        var x = tg(v, b, c),
                            y = !!a[4];
                        return y || x !== 2 ? y !== (x === 1) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
                }
            }
            return a
        },
        wg = function(a, b) {
            var c = a[Kf.ab],
                d = b && b.event;
            if (!c) throw Error("Error: No function name given for function call.");
            var e = lg[c],
                f = {},
                g;
            for (g in a) a.hasOwnProperty(g) && Yb(g, "vtp_") &&
                (f[e !== void 0 ? g : g.substring(4)] = a[g]);
            e && d && d.cachedModelValues && (f.vtp_gtmCachedValues = d.cachedModelValues);
            if (b) {
                if (b.name == null) {
                    var h;
                    a: {
                        var l = b.type,
                            n = b.index;
                        if (n == null) h = "";
                        else {
                            var p;
                            switch (l) {
                                case 2:
                                    p = gg[n];
                                    break;
                                case 1:
                                    p = jg[n];
                                    break;
                                default:
                                    h = "";
                                    break a
                            }
                            var q = p && p[Kf.Si];
                            h = q ? String(q) : ""
                        }
                    }
                    b.name = h
                }
                e && (f.vtp_gtmEntityIndex = b.index, f.vtp_gtmEntityName = b.name)
            }
            return e !== void 0 ? e(f) : fg(c, f, b)
        };

    function xg(a) {
        var b;
        b = b === void 0 ? !1 : b;
        var c, d;
        return ((c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)) ? !!data.blob[a] : b
    }

    function E(a) {
        var b;
        b = b === void 0 ? "" : b;
        var c, d;
        return ((c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)) ? String(data.blob[a]) : b
    }

    function yg(a) {
        var b, c;
        return ((b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)) ? Number(data.blob[a]) : 0
    }

    function zg(a) {
        var b;
        b = b === void 0 ? [] : b;
        var c, d, e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[a];
        return Array.isArray(e) ? e : b
    }

    function Ag(a) {
        var b;
        b = b === void 0 ? "" : b;
        var c = Bg(46);
        return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b
    }

    function Cg(a, b) {
        var c = Bg(46);
        return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b
    }

    function Bg(a) {
        var b, c;
        return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a]
    };
    var Dg = function(a, b, c) {
        var d;
        d = Error.call(this, c);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.permissionId = a;
        this.parameters = b;
        this.name = "PermissionError"
    };
    xa(Dg, Error);
    Dg.prototype.getMessage = function() {
        return this.message
    };

    function Eg(a, b) {
        if (Array.isArray(a)) {
            Object.defineProperty(a, "context", {
                value: {
                    line: b[0]
                }
            });
            for (var c = 1; c < a.length; c++) Eg(a[c], b[c])
        }
    };

    function Gg() {
        return function(a, b) {
            var c;
            var d = Hg;
            a instanceof fb ? (a.D = d, c = a) : c = new fb(a, d);
            var e = c;
            b && e.debugInfo.push(b);
            throw e;
        }
    }

    function Hg(a) {
        if (!a.length) return a;
        a.push({
            id: "main",
            line: 0
        });
        for (var b = a.length - 1; b > 0; b--) Eb(a[b].id) && a.splice(b++, 1);
        for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
        a.splice(0, 1);
        return a
    };

    function Ig(a) {
        function b(r) {
            for (var t = 0; t < r.length; t++) d[r[t]] = !0
        }
        for (var c = [], d = [], e = Jg(a), f = 0; f < hg.length; f++) {
            var g = hg[f],
                h = Kg(g, e);
            if (h) {
                for (var l = g.add || [], n = 0; n < l.length; n++) c[l[n]] = !0;
                b(g.block || [])
            } else h === null && b(g.block || []);
        }
        for (var p = [], q = 0; q < jg.length; q++) c[q] && !d[q] && (p[q] = !0);
        return p
    }

    function Kg(a, b) {
        for (var c = a["if"] || [], d = 0; d < c.length; d++) {
            var e = b(c[d]);
            if (e === 0) return !1;
            if (e === 2) return null
        }
        for (var f = a.unless || [], g = 0; g < f.length; g++) {
            var h = b(f[g]);
            if (h === 2) return null;
            if (h === 1) return !1
        }
        return !0
    }

    function Jg(a) {
        var b = [];
        return function(c) {
            b[c] === void 0 && (b[c] = tg(ig[c], a));
            return b[c]
        }
    };

    function Lg(a, b) {
        b[Kf.Ik] && typeof a === "string" && (a = b[Kf.Ik] === 1 ? a.toLowerCase() : a.toUpperCase());
        b.hasOwnProperty(Kf.Kk) && a === null && (a = b[Kf.Kk]);
        b.hasOwnProperty(Kf.Mk) && a === void 0 && (a = b[Kf.Mk]);
        b.hasOwnProperty(Kf.Lk) && a === !0 && (a = b[Kf.Lk]);
        b.hasOwnProperty(Kf.Jk) && a === !1 && (a = b[Kf.Jk]);
        return a
    };
    var Mg = function() {
            this.D = {}
        },
        Ng = function(a, b, c) {
            var d;
            (d = a.D)[b] != null || (d[b] = []);
            a.D[b].push(function() {
                return c.apply(null, Aa(Qa.apply(0, arguments)))
            })
        };

    function Og(a, b, c, d) {
        if (a)
            for (var e = 0; e < a.length; e++) {
                var f = void 0,
                    g = "A policy function denied the permission request";
                try {
                    f = a[e](b, c, d), g += "."
                } catch (h) {
                    g = typeof h === "string" ? g + (": " + h) : h instanceof Error ? g + (": " + h.message) : g + "."
                }
                if (!f) throw new Dg(c, d, g);
            }
    }

    function Pg(a, b, c) {
        return function(d) {
            if (d) {
                var e = a.D[d],
                    f = a.D.all;
                if (e || f) {
                    var g = c.apply(void 0, [d].concat(Aa(Qa.apply(1, arguments))));
                    Og(e, b, d, g);
                    Og(f, b, d, g)
                }
            }
        }
    };
    var Sg = function(a, b) {
            var c = this;
            this.J = {};
            this.D = new Mg;
            var d = {},
                e = {},
                f = Pg(this.D, a, function(g) {
                    return g && d[g] ? d[g].apply(void 0, [g].concat(Aa(Qa.apply(1, arguments)))) : {}
                });
            Lb(b, function(g, h) {
                function l(p) {
                    var q = Qa.apply(1, arguments);
                    if (!n[p]) throw Qg(p, {}, "The requested additional permission " + p + " is not configured.");
                    f.apply(null, [p].concat(Aa(q)))
                }
                var n = {};
                Lb(h, function(p, q) {
                    var r = Rg(p, q);
                    n[p] = r.assert;
                    d[p] || (d[p] = r.W);
                    r.Bn && !e[p] && (e[p] = r.Bn)
                });
                c.J[g] = function(p, q) {
                    var r = n[p];
                    if (!r) throw Qg(p, {}, "The requested permission " + p + " is not configured.");
                    var t = Array.prototype.slice.call(arguments, 0);
                    r.apply(void 0, t);
                    f.apply(void 0, t);
                    var u = e[p];
                    u && u.apply(null, [l].concat(Aa(t.slice(1))))
                }
            })
        },
        Ug = function(a) {
            return Tg.J[a] || function() {}
        };

    function Rg(a, b) {
        var c = sg(a, b);
        c.vtp_permissionName = a;
        c.vtp_createPermissionError = Qg;
        try {
            return wg(c)
        } catch (d) {
            return {
                assert: function(e) {
                    throw new Dg(e, {}, "Permission " + e + " is unknown.");
                },
                W: function() {
                    throw new Dg(a, {}, "Permission " + a + " is unknown.");
                }
            }
        }
    }

    function Qg(a, b, c) {
        return new Dg(a, b, c)
    };
    var Vg = E(5),
        Wg = E(20),
        Xg = E(1),
        Yg = !1;
    var Zg = {};
    Zg.Ao = xg(29);
    Zg.kr = xg(28);
    var F = {
        P: {
            Po: 1,
            So: 2,
            tn: 3,
            Vm: 4,
            Tk: 5,
            Uk: 6,
            gq: 7,
            To: 8,
            fq: 9,
            Oo: 10,
            No: 11,
            ln: 12,
            fn: 13,
            Ck: 14,
            Eo: 15,
            Go: 16,
            Qm: 17,
            Vk: 18,
            Nm: 19,
            Qo: 20,
            rq: 21,
            Jo: 22,
            Fo: 23,
            Ho: 24,
            Rk: 25,
            Bk: 26,
            Bq: 27,
            wm: 28,
            Em: 29,
            Dm: 30,
            Cm: 31,
            zm: 32,
            xm: 33,
            ym: 34,
            sm: 35,
            rm: 36,
            tm: 37,
            vm: 38,
            cq: 39
        }
    };
    F.P[F.P.Po] = "CREATE_EVENT_SOURCE";
    F.P[F.P.So] = "EDIT_EVENT";
    F.P[F.P.tn] = "TRAFFIC_TYPE";
    F.P[F.P.Vm] = "REFERRAL_EXCLUSION";
    F.P[F.P.Tk] = "ECOMMERCE_FROM_GTM_TAG";
    F.P[F.P.Uk] = "ECOMMERCE_FROM_GTM_UA_SCHEMA";
    F.P[F.P.gq] = "GA_SEND";
    F.P[F.P.To] = "EM_FORM";
    F.P[F.P.fq] = "GA_GAM_LINK";
    F.P[F.P.Oo] = "CREATE_EVENT_AUTO_PAGE_PATH";
    F.P[F.P.No] = "CREATED_EVENT";
    F.P[F.P.ln] = "SIDELOADED";
    F.P[F.P.fn] = "SGTM_LEGACY_CONFIGURATION";
    F.P[F.P.Ck] = "CCD_EM_EVENT";
    F.P[F.P.Eo] = "AUTO_REDACT_EMAIL";
    F.P[F.P.Go] = "AUTO_REDACT_QUERY_PARAM";
    F.P[F.P.Qm] = "MULTIPLE_PAGEVIEW_FROM_CONFIG";
    F.P[F.P.Vk] = "EM_EVENT_SENT_BEFORE_CONFIG";
    F.P[F.P.Nm] = "LOADED_VIA_CST_OR_SIDELOADING";
    F.P[F.P.Qo] = "DECODED_PARAM_MATCH";
    F.P[F.P.rq] = "NON_DECODED_PARAM_MATCH";
    F.P[F.P.Jo] = "CCD_EVENT_SGTM";
    F.P[F.P.Fo] = "AUTO_REDACT_EMAIL_SGTM";
    F.P[F.P.Ho] = "AUTO_REDACT_QUERY_PARAM_SGTM";
    F.P[F.P.Rk] = "DAILY_LIMIT_REACHED";
    F.P[F.P.Bk] = "BURST_LIMIT_REACHED";
    F.P[F.P.Bq] = "SHARED_USER_ID_SET_AFTER_REQUEST";
    F.P[F.P.wm] = "GA4_MULTIPLE_SESSION_COOKIES";
    F.P[F.P.Em] = "INVALID_GA4_SESSION_COUNT";
    F.P[F.P.Dm] = "INVALID_GA4_LAST_EVENT_TIMESTAMP";
    F.P[F.P.Cm] = "INVALID_GA4_JOIN_TIMER";
    F.P[F.P.zm] = "GA4_STALE_SESSION_COOKIE_SELECTED";
    F.P[F.P.xm] = "GA4_SESSION_COOKIE_GS1_READ";
    F.P[F.P.ym] = "GA4_SESSION_COOKIE_GS2_READ";
    F.P[F.P.sm] = "GA4_DL_PARAM_RECOVERY_AVAILABLE";
    F.P[F.P.rm] = "GA4_DL_PARAM_RECOVERY_APPLIED";
    F.P[F.P.tm] = "GA4_GOOGLE_SIGNALS_ALLOWED";
    F.P[F.P.vm] = "GA4_GOOGLE_SIGNALS_ENABLED";
    F.P[F.P.cq] = "GA4_FALLBACK_REQUEST";
    var eh = {},
        fh = (eh.uaa = !0, eh.uab = !0, eh.uafvl = !0, eh.uamb = !0, eh.uam = !0, eh.uap = !0, eh.uapv = !0, eh.uaw = !0, eh);
    var nh = function(a, b) {
            for (var c = 0; c < b.length; c++) {
                var d = a,
                    e = b[c];
                if (!lh.exec(e)) throw Error("Invalid key wildcard");
                var f = e.indexOf(".*"),
                    g = f !== -1 && f === e.length - 2,
                    h = g ? e.slice(0, e.length - 2) : e,
                    l;
                a: if (d.length === 0) l = !1;
                    else {
                        for (var n = d.split("."), p = 0; p < n.length; p++)
                            if (!mh.exec(n[p])) {
                                l = !1;
                                break a
                            }
                        l = !0
                    }
                if (!l || h.length > d.length || !g && d.length !== e.length ? 0 : g ? Yb(d, h) && (d === h || d.charAt(h.length) === ".") : d === h) return !0
            }
            return !1
        },
        mh = /^[a-z$_][\w-$]*$/i,
        lh = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
    var oh = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"];

    function ph(a, b) {
        var c = String(a),
            d = String(b),
            e = c.length - d.length;
        return e >= 0 && c.indexOf(d, e) === e
    }

    function qh(a, b) {
        return String(a).split(",").indexOf(String(b)) >= 0
    }
    var rh = new Kb;

    function sh(a, b, c) {
        var d = c ? "i" : void 0;
        try {
            var e = String(b) + String(d),
                f = rh.get(e);
            f || (f = new RegExp(b, d), rh.set(e, f));
            return f.test(a)
        } catch (g) {
            return !1
        }
    }

    function th(a, b) {
        return String(a).indexOf(String(b)) >= 0
    }

    function uh(a, b) {
        return String(a) === String(b)
    }

    function vh(a, b) {
        return Number(a) >= Number(b)
    }

    function wh(a, b) {
        return Number(a) <= Number(b)
    }

    function xh(a, b) {
        return Number(a) > Number(b)
    }

    function yh(a, b) {
        return Number(a) < Number(b)
    }

    function zh(a, b) {
        return Yb(String(a), String(b))
    };
    var Ah = function(a, b) {
            return a.length && b.length && a.lastIndexOf(b) === a.length - b.length
        },
        Bh = function(a, b) {
            var c = b.charAt(b.length - 1) === "*" || b === "/" || b === "/*";
            Ah(b, "/*") && (b = b.slice(0, -2));
            Ah(b, "?") && (b = b.slice(0, -1));
            var d = b.split("*");
            if (!c && d.length === 1) return a === d[0];
            for (var e = -1, f = 0; f < d.length; f++) {
                var g = d[f];
                if (g) {
                    e = a.indexOf(g, e);
                    if (e === -1 || f === 0 && e !== 0) return !1;
                    e += g.length
                }
            }
            if (c || e === a.length) return !0;
            var h = d[d.length - 1];
            return a.lastIndexOf(h) === a.length - h.length
        },
        Ch = function(a) {
            return a.protocol ===
                "https:" && (!a.port || a.port === "443")
        },
        Fh = function(a, b) {
            var c;
            if (!(c = !Ch(a))) {
                var d;
                a: {
                    var e = a.hostname.split(".");
                    if (e.length < 2) d = !1;
                    else {
                        for (var f = 0; f < e.length; f++)
                            if (!Dh.exec(e[f])) {
                                d = !1;
                                break a
                            }
                        d = !0
                    }
                }
                c = !d
            }
            if (c) return !1;
            for (var g = 0; g < b.length; g++) {
                var h;
                var l = a,
                    n = b[g];
                if (!Eh.exec(n)) throw Error("Invalid Wildcard");
                var p = n.slice(8),
                    q = p.slice(0, p.indexOf("/")),
                    r;
                var t = l.hostname,
                    u = q;
                if (Yb(u, "*.")) {
                    u = u.slice(2);
                    var v = t.toLowerCase().indexOf(u.toLowerCase());
                    r = v === -1 ? !1 : t.length === u.length ? !0 : t.length !==
                        u.length + v ? !1 : t[v - 1] === "."
                } else r = t.toLowerCase() === u.toLowerCase();
                if (r) {
                    var x = p.slice(p.indexOf("/"));
                    h = Bh(l.pathname + l.search, x) ? !0 : !1
                } else h = !1;
                if (h) return !0
            }
            return !1
        },
        Dh = /^[a-z0-9-]+$/i,
        Eh = /^https:\/\/(\*\.|)((?:[a-z0-9-]+\.)+[a-z0-9-]+)\/(.*)$/i;
    var Gh = /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
        Hh = {
            Fn: "function",
            PixieMap: "Object",
            List: "Array"
        };

    function Ih(a, b) {
        for (var c = ["input:!*"], d = 0; d < c.length; d++) {
            var e = Gh.exec(c[d]);
            if (!e) throw Error("Internal Error in " + a);
            var f = e[1],
                g = e[2] === "!",
                h = e[3],
                l = b[d];
            if (l == null) {
                if (g) throw Error("Error in " + a + ". Required argument " + f + " not supplied.");
            } else if (h !== "*") {
                var n = typeof l;
                l instanceof Pd ? n = "Fn" : l instanceof Ld ? n = "List" : l instanceof nb ? n = "PixieMap" : l instanceof Wd ? n = "PixiePromise" : l instanceof Ud && (n = "OpaqueValue");
                if (n !== h) throw Error("Error in " + a + ". Argument " + f + " has type " + ((Hh[n] || n) + ", which does not match required type ") +
                    ((Hh[h] || h) + "."));
            }
        }
    }

    function H(a, b, c) {
        for (var d = [], e = m(c), f = e.next(); !f.done; f = e.next()) {
            var g = f.value;
            g instanceof Pd ? d.push("function") : g instanceof Ld ? d.push("Array") : g instanceof nb ? d.push("Object") : g instanceof Wd ? d.push("Promise") : g instanceof Ud ? d.push("OpaqueValue") : d.push(typeof g)
        }
        return Error("Argument error in " + a + ". Expected argument types [" + (b.join(",") + "], but received [") + (d.join(",") + "]."))
    }

    function Jh(a) {
        return a instanceof nb
    }

    function Kh(a) {
        return Jh(a) || a === null || Lh(a)
    }

    function Mh(a) {
        return a instanceof Pd
    }

    function Nh(a) {
        return Mh(a) || a === null || Lh(a)
    }

    function Oh(a) {
        return a instanceof Ld
    }

    function Ph(a) {
        return a instanceof Ud
    }

    function Qh(a) {
        return typeof a === "string"
    }

    function Rh(a) {
        return Qh(a) || a === null || Lh(a)
    }

    function Sh(a) {
        return typeof a === "boolean"
    }

    function Th(a) {
        return Sh(a) || Lh(a)
    }

    function Uh(a) {
        return Sh(a) || a === null || Lh(a)
    }

    function Vh(a) {
        return typeof a === "number"
    }

    function Lh(a) {
        return a === void 0
    };

    function Wh(a) {
        return "" + a
    }

    function Xh(a, b) {
        var c = [];
        return c
    };

    function Yh(a, b) {
        var c = new Pd(a, function() {
            for (var d = Array.prototype.slice.call(arguments, 0), e = 0; e < d.length; e++) d[e] = this.evaluate(d[e]);
            try {
                return b.apply(this, d)
            } catch (g) {
                throw gb(g);
            }
        });
        c.Wa();
        return c
    }

    function Zh(a, b) {
        var c = new nb,
            d;
        for (d in b)
            if (b.hasOwnProperty(d)) {
                var e = b[d];
                Cb(e) ? c.set(d, Yh(a + "_" + d, e)) : Id(e) ? c.set(d, Zh(a + "_" + d, e)) : (Eb(e) || Db(e) || typeof e === "boolean") && c.set(d, e)
            }
        c.Wa();
        return c
    };

    function $h(a, b) {
        if (!Qh(a)) throw H(this.getName(), ["string"], arguments);
        if (!Rh(b)) throw H(this.getName(), ["string", "undefined"], arguments);
        var c = {},
            d = new nb;
        return d = Zh("AssertApiSubject",
            c)
    };

    function ai(a, b) {
        if (!Rh(b)) throw H(this.getName(), ["string", "undefined"], arguments);
        if (a instanceof Wd) throw Error("Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported.");
        var c = {},
            d = new nb;
        return d = Zh("AssertThatSubject", c)
    };

    function bi(a) {
        return function() {
            for (var b = Qa.apply(0, arguments), c = [], d = this.M, e = 0; e < b.length; ++e) c.push(B(b[e], d));
            return Xd(a.apply(null, c))
        }
    }

    function ci() {
        for (var a = Math, b = di, c = {}, d = 0; d < b.length; d++) {
            var e = b[d];
            a.hasOwnProperty(e) && (c[e] = bi(a[e].bind(a)))
        }
        return c
    };

    function ei(a) {
        return a != null && Yb(a, "__cvt_")
    };

    function fi(a) {
        var b;
        return b
    };

    function gi(a) {
        var b;
        if (!Qh(a)) throw H(this.getName(), ["string"], arguments);
        try {
            b = decodeURIComponent(a)
        } catch (c) {}
        return b
    };

    function hi(a) {
        try {
            return encodeURI(a)
        } catch (b) {}
    };

    function ii(a) {
        try {
            return encodeURIComponent(String(a))
        } catch (b) {}
    };

    function ni(a) {
        if (!Rh(a)) throw H(this.getName(), ["string|undefined"], arguments);
    };

    function oi(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; d >= 0; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = c !== 0 ? b ^ c >> 21 : b;
        return b
    };

    function pi(a) {
        var b = B(a);
        return oi(b ? "" + b : "")
    };

    function qi(a, b) {
        if (!Vh(a) || !Vh(b)) throw H(this.getName(), ["number", "number"], arguments);
        return Hb(a, b)
    };

    function ri() {
        return (new Date).getTime()
    };

    function si(a) {
        if (a === null) return "null";
        if (a instanceof Ld) return "array";
        if (a instanceof Pd) return "function";
        if (a instanceof Ud) {
            var b = a.getValue();
            if ((b == null ? void 0 : b.constructor) === void 0 || b.constructor.name === void 0) {
                var c = String(b);
                return c.substring(8, c.length - 1)
            }
            return String(b.constructor.name)
        }
        return typeof a
    };

    function ti(a) {
        function b(c) {
            return function(d) {
                try {
                    return c(d)
                } catch (e) {
                    (Yg || Zg.Ao) && a.call(this, e.message)
                }
            }
        }
        return {
            parse: b(function(c) {
                return Xd(JSON.parse(c))
            }),
            stringify: b(function(c) {
                return JSON.stringify(B(c))
            }),
            publicName: "JSON"
        }
    };

    function ui(a) {
        return Nb(B(a, this.M))
    };

    function vi(a) {
        return Number(B(a, this.M))
    };

    function wi(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a.toString()
    };

    function xi(a, b, c) {
        var d = null,
            e = !1;
        if (!Oh(a) || !Qh(b) || !Qh(c)) throw H(this.getName(), ["Array", "string", "string"], arguments);
        d = new nb;
        for (var f = 0; f < a.length(); f++) {
            var g = a.get(f);
            g instanceof nb && g.has(b) && g.has(c) && (d.set(g.get(b), g.get(c)), e = !0)
        }
        return e ? d : null
    };
    var di = "floor ceil round max min abs pow sqrt".split(" ");

    function yi() {
        var a = {};
        return {
            yr: function(b) {
                return a.hasOwnProperty(b) ? a[b] : void 0
            },
            xo: function(b, c) {
                a[b] = c
            },
            reset: function() {
                a = {}
            }
        }
    }

    function zi(a, b) {
        return function() {
            return Pd.prototype.invoke.apply(a, [b].concat(Aa(Qa.apply(0, arguments))))
        }
    }

    function Ai(a, b) {
        if (!Qh(a)) throw H(this.getName(), ["string", "any"], arguments);
    }

    function Ei(a, b) {
        if (!Qh(a) || !Jh(b)) throw H(this.getName(), ["string", "PixieMap"], arguments);
    };
    var Fi = {};
    Fi.keys = function(a) {
        return new Ld
    };
    Fi.values = function(a) {
        return new Ld
    };
    Fi.entries = function(a) {
        return new Ld
    };
    Fi.freeze = function(a) {
        return a
    };
    Fi.delete = function(a, b) {
        return !1
    };

    function I(a, b) {
        var c = Qa.apply(2, arguments),
            d = a.M.xb();
        if (!d) throw Error("Missing program state.");
        if (d.Ds) {
            try {
                d.Cn.apply(null, [b].concat(Aa(c)))
            } catch (e) {
                throw vb("TAGGING", 21), e;
            }
            return
        }
        d.Cn.apply(null, [b].concat(Aa(c)))
    };
    var Hi = function() {
        this.J = {};
        this.D = {};
        this.O = !0;
    };
    Hi.prototype.get = function(a, b) {
        var c = this.contains(a) ? this.J[a] : void 0;
        return c
    };
    Hi.prototype.contains = function(a) {
        return this.J.hasOwnProperty(a)
    };
    Hi.prototype.add = function(a, b, c) {
        if (this.contains(a)) throw Error("Attempting to add a function which already exists: " + a + ".");
        if (this.D.hasOwnProperty(a)) throw Error("Attempting to add an API with an existing private API name: " + a + ".");
        this.J[a] = c ? void 0 : Cb(b) ? Yh(a, b) : Zh(a, b)
    };

    function Ii(a, b) {
        var c = void 0;
        return c
    };

    function Ji() {
        var a = {};
        return a
    };
    var K = {
        m: {
            Ka: "ad_personalization",
            X: "ad_storage",
            aa: "ad_user_data",
            la: "analytics_storage",
            rc: "region",
            ka: "consent_updated",
            Yg: "wait_for_update",
            Vo: "app_remove",
            Wo: "app_store_refund",
            Xo: "app_store_subscription_cancel",
            Yo: "app_store_subscription_convert",
            Zo: "app_store_subscription_renew",
            ap: "consent_update",
            bp: "conversion",
            Xk: "add_payment_info",
            Yk: "add_shipping_info",
            qe: "add_to_cart",
            se: "remove_from_cart",
            Zk: "view_cart",
            sd: "begin_checkout",
            vt: "generate_lead",
            te: "select_item",
            sc: "view_item_list",
            Mc: "select_promotion",
            uc: "view_promotion",
            Ib: "purchase",
            ue: "refund",
            vc: "view_item",
            al: "add_to_wishlist",
            cp: "exception",
            ep: "first_open",
            fp: "first_visit",
            na: "gtag.config",
            Jb: "gtag.get",
            hp: "in_app_purchase",
            wc: "page_view",
            jp: "screen_view",
            kp: "session_start",
            lp: "source_update",
            mp: "timing_complete",
            np: "track_social",
            qf: "user_engagement",
            op: "user_id_update",
            rf: "gclid_link_decoration_source",
            tf: "gclid_storage_source",
            xc: "gclgb",
            Ab: "gclid",
            bl: "gclid_len",
            ve: "gclgs",
            we: "gcllp",
            xe: "gclst",
            La: "ads_data_redaction",
            uf: "gad_source",
            vf: "gad_source_src",
            ud: "gclid_url",
            fl: "gclsrc",
            wf: "gbraid",
            ye: "wbraid",
            Vb: "allow_ad_personalization_signals",
            xf: "allow_custom_scripts",
            yf: "allow_direct_google_requests",
            fh: "allow_display_features",
            wi: "allow_enhanced_conversions",
            yc: "allow_google_signals",
            xi: "allow_interest_groups",
            pp: "app_id",
            qp: "app_installer_id",
            rp: "app_name",
            tp: "app_version",
            vd: "auid",
            wt: "auto_detection_enabled",
            il: "auto_event",
            jl: "aw_remarketing",
            gh: "aw_remarketing_only",
            zf: "discount",
            Af: "aw_feed_country",
            Bf: "aw_feed_language",
            wa: "items",
            Cf: "aw_merchant_id",
            yi: "aw_basket_type",
            Df: "campaign_content",
            Ef: "campaign_id",
            Ff: "campaign_medium",
            Gf: "campaign_name",
            Hf: "campaign",
            If: "campaign_source",
            Jf: "campaign_term",
            Wb: "client_id",
            kl: "rnd",
            zi: "consent_update_type",
            up: "content_group",
            vp: "content_type",
            Kb: "conversion_cookie_prefix",
            hh: "conversion_id",
            Bb: "conversion_linker",
            ih: "conversion_linker_disabled",
            wd: "conversion_api",
            jh: "cookie_deprecation",
            Lb: "cookie_domain",
            Cb: "cookie_expires",
            Xb: "cookie_flags",
            xd: "cookie_name",
            zc: "cookie_path",
            hb: "cookie_prefix",
            yd: "cookie_update",
            Nc: "country",
            nb: "currency",
            kh: "customer_buyer_stage",
            Ae: "customer_lifetime_value",
            mh: "customer_loyalty",
            nh: "customer_ltv_bucket",
            Be: "custom_map",
            oh: "gcldc",
            zd: "dclid",
            ml: "debug_mode",
            Ga: "developer_id",
            wp: "disable_merchant_reported_purchases",
            Oc: "dc_custom_params",
            nl: "dc_natural_search",
            xp: "dynamic_event_settings",
            ol: "affiliation",
            ph: "checkout_option",
            Ai: "checkout_step",
            pl: "coupon",
            Kf: "item_list_name",
            Bi: "list_name",
            yp: "promotions",
            Bd: "shipping",
            ql: "tax",
            qh: "engagement_time_msec",
            rh: "enhanced_client_id",
            zp: "enhanced_conversions",
            xt: "enhanced_conversions_automatic_settings",
            Ce: "estimated_delivery_date",
            De: "event_callback",
            Ap: "event_category",
            Pc: "event_developer_id_string",
            Bp: "event_label",
            Qc: "event",
            Ci: "event_settings",
            sh: "event_timeout",
            Cp: "description",
            Dp: "fatal",
            Ep: "experiments",
            Di: "firebase_id",
            Lf: "first_party_collection",
            Mf: "_x_20",
            Yb: "_x_19",
            Fp: "flight_error_code",
            Gp: "flight_error_message",
            rl: "fl_activity_category",
            sl: "fl_activity_group",
            Ei: "fl_advertiser_id",
            tl: "fl_ar_dedupe",
            Nf: "match_id",
            vl: "fl_random_number",
            wl: "tran",
            xl: "u",
            th: "gac_gclid",
            Ee: "gac_wbraid",
            yl: "gac_wbraid_multiple_conversions",
            Hp: "ga_restrict_domain",
            zl: "ga_temp_client_id",
            Ip: "ga_temp_ecid",
            Fe: "gdpr_applies",
            Al: "geo_granularity",
            Of: "value_callback",
            Pf: "value_key",
            Db: "google_analysis_params",
            Ge: "_google_ng",
            Qf: "google_signals",
            Jp: "google_tld",
            uh: "gpp_sid",
            wh: "gpp_string",
            Dd: "groups",
            Bl: "gsa_experiment_id",
            Rf: "gtag_event_feature_usage",
            Cl: "gtm_up",
            Ed: "iframe_state",
            Sf: "ignore_referrer",
            Dl: "internal_traffic_results",
            El: "_is_fpm",
            Sc: "is_legacy_converted",
            Ac: "is_legacy_loaded",
            Fi: "is_passthrough",
            He: "_lps",
            ob: "language",
            xh: "legacy_developer_id_string",
            ib: "linker",
            Tf: "accept_incoming",
            Tc: "decorate_forms",
            xa: "domains",
            Fd: "url_position",
            Bc: "merchant_feed_label",
            Cc: "merchant_feed_language",
            Dc: "merchant_id",
            Fl: "method",
            Kp: "name",
            Gl: "navigation_type",
            Ie: "new_customer",
            Gi: "non_interaction",
            Lp: "optimize_id",
            Hl: "page_hostname",
            Uf: "page_path",
            Za: "page_referrer",
            Mb: "page_title",
            Mp: "passengers",
            Il: "phone_conversion_callback",
            Np: "phone_conversion_country_code",
            Jl: "phone_conversion_css_class",
            Op: "phone_conversion_ids",
            Kl: "phone_conversion_number",
            Ll: "phone_conversion_options",
            Pp: "_platinum_request_status",
            Qp: "_protected_audience_enabled",
            Uc: "quantity",
            yh: "redact_device_info",
            Ml: "referral_exclusion_definition",
            zt: "_request_start_time",
            Zb: "restricted_data_processing",
            Rp: "retoken",
            Sp: "sample_rate",
            Hi: "screen_name",
            Vc: "screen_resolution",
            Nl: "_script_source",
            Tp: "search_term",
            Gd: "send_page_view",
            Hd: "send_to",
            Id: "server_container_url",
            Up: "session_attributes_encoded",
            zh: "session_duration",
            Ah: "session_engaged",
            Ii: "session_engaged_time",
            pb: "session_id",
            Bh: "session_number",
            Vf: "_shared_user_id",
            Jd: "delivery_postal_code",
            At: "_tag_firing_delay",
            Bt: "_tag_firing_time",
            Ct: "temporary_client_id",
            Ol: "testonly",
            Vp: "_timezone",
            Ji: "topmost_url",
            Ch: "tracking_id",
            Ki: "traffic_type",
            Da: "transaction_id",
            Pl: "transaction_id_source",
            Wc: "transport_url",
            Wp: "trip_type",
            Nb: "update",
            Ob: "url_passthrough",
            Ql: "uptgs",
            Wf: "_user_agent_architecture",
            Xf: "_user_agent_bitness",
            Yf: "_user_agent_full_version_list",
            Zf: "_user_agent_mobile",
            cg: "_user_agent_model",
            dg: "_user_agent_platform",
            eg: "_user_agent_platform_version",
            fg: "_user_agent_wow64",
            Pb: "user_data",
            Rl: "user_data_auto_latency",
            Sl: "user_data_auto_meta",
            Tl: "user_data_auto_multi",
            Ul: "user_data_auto_selectors",
            Vl: "user_data_auto_status",
            Kd: "user_data_mode",
            Wl: "user_data_settings",
            Oa: "user_id",
            Ec: "user_properties",
            Xl: "_user_region",
            gg: "us_privacy_string",
            Ea: "value",
            Yl: "wbraid_multiple_conversions",
            Xc: "_fpm_parameters",
            Ri: "_host_name",
            Fm: "_in_page_command",
            Ui: "_ip_override",
            Jm: "_is_passthrough_cid",
            Lh: "_measurement_type",
            Rd: "non_personalized_ads",
            gj: "_sst_parameters",
            Aq: "sgtm_geo_user_country",
            ze: "conversion_label",
            za: "page_location",
            Cd: "_extracted_data",
            Rc: "global_developer_id_string",
            Je: "tc_privacy_string"
        }
    };
    var Ki = {},
        Li = (Ki[K.m.ka] = "gcu", Ki[K.m.xc] = "gclgb", Ki[K.m.Ab] = "gclaw", Ki[K.m.bl] = "gclid_len", Ki[K.m.ve] = "gclgs", Ki[K.m.we] = "gcllp", Ki[K.m.xe] = "gclst", Ki[K.m.vd] = "auid", Ki[K.m.il] = "ae", Ki[K.m.zf] = "dscnt", Ki[K.m.Af] = "fcntr", Ki[K.m.Bf] = "flng", Ki[K.m.Cf] = "mid", Ki[K.m.yi] = "bttype", Ki[K.m.Wb] = "gacid", Ki[K.m.ze] = "label", Ki[K.m.wd] = "capi", Ki[K.m.jh] = "pscdl", Ki[K.m.nb] = "currency_code", Ki[K.m.kh] = "clobs", Ki[K.m.Ae] = "vdltv", Ki[K.m.mh] = "clolo", Ki[K.m.nh] = "clolb", Ki[K.m.ml] = "_dbg", Ki[K.m.Ce] = "oedeld", Ki[K.m.Pc] =
            "edid", Ki[K.m.th] = "gac", Ki[K.m.Ee] = "gacgb", Ki[K.m.yl] = "gacmcov", Ki[K.m.Fe] = "gdpr", Ki[K.m.Rc] = "gdid", Ki[K.m.Ge] = "_ng", Ki[K.m.uh] = "gpp_sid", Ki[K.m.wh] = "gpp", Ki[K.m.Bl] = "gsaexp", Ki[K.m.Rf] = "_tu", Ki[K.m.Ed] = "frm", Ki[K.m.Fi] = "gtm_up", Ki[K.m.He] = "lps", Ki[K.m.xh] = "did", Ki[K.m.Bc] = "fcntr", Ki[K.m.Cc] = "flng", Ki[K.m.Dc] = "mid", Ki[K.m.Ie] = void 0, Ki[K.m.Mb] = "tiba", Ki[K.m.Zb] = "rdp", Ki[K.m.pb] = "ecsid", Ki[K.m.Vf] = "ga_uid", Ki[K.m.Jd] = "delopc", Ki[K.m.Je] = "gdpr_consent", Ki[K.m.Da] = "oid", Ki[K.m.Pl] = "oidsrc", Ki[K.m.Ql] =
            "uptgs", Ki[K.m.Wf] = "uaa", Ki[K.m.Xf] = "uab", Ki[K.m.Yf] = "uafvl", Ki[K.m.Zf] = "uamb", Ki[K.m.cg] = "uam", Ki[K.m.dg] = "uap", Ki[K.m.eg] = "uapv", Ki[K.m.fg] = "uaw", Ki[K.m.Rl] = "ec_lat", Ki[K.m.Sl] = "ec_meta", Ki[K.m.Tl] = "ec_m", Ki[K.m.Ul] = "ec_sel", Ki[K.m.Vl] = "ec_s", Ki[K.m.Kd] = "ec_mode", Ki[K.m.Oa] = "userId", Ki[K.m.gg] = "us_privacy", Ki[K.m.Ea] = "value", Ki[K.m.Yl] = "mcov", Ki[K.m.Ri] = "hn", Ki[K.m.Fm] = "gtm_ee", Ki[K.m.Ui] = "uip", Ki[K.m.Lh] = "mt", Ki[K.m.Rd] = "npa", Ki[K.m.Aq] = "sg_uc", Ki[K.m.hh] = null, Ki[K.m.Vc] = null, Ki[K.m.ob] = null, Ki[K.m.wa] =
            null, Ki[K.m.za] = null, Ki[K.m.Za] = null, Ki[K.m.Ji] = null, Ki[K.m.Xc] = null, Ki[K.m.rf] = null, Ki[K.m.tf] = null, Ki[K.m.Db] = null, Ki[K.m.Cd] = null, Ki);

    function Mi(a, b) {
        if (a) {
            var c = a.split("x");
            c.length === 2 && (Ni(b, "u_w", c[0]), Ni(b, "u_h", c[1]))
        }
    }

    function Oi(a) {
        var b = Pi;
        b = b === void 0 ? Qi : b;
        return Ri(Si(a, b))
    }

    function Ri(a) {
        return (a || []).filter(function(b) {
            return !!b
        }).map(function(b) {
            return "(" + [Ti(b.value), Ti(b.quantity), Ti(b.item_id), Ti(b.start_date), Ti(b.end_date)].join("*") + ")"
        }).join("")
    }

    function Si(a, b) {
        return (a || []).filter(function(c) {
            return !!c
        }).map(function(c) {
            return {
                item_id: b(c),
                quantity: c.quantity,
                value: c.price,
                start_date: c.start_date,
                end_date: c.end_date
            }
        })
    }

    function Qi(a) {
        return [a.item_id, a.id, a.item_name].find(function(b) {
            return b != null
        })
    }

    function Ui(a) {
        if (a && a.length) return a.map(function(b) {
            return b && b.estimated_delivery_date ? b.estimated_delivery_date : ""
        }).join(",")
    }

    function Ni(a, b, c) {
        c === void 0 || c === null || c === "" && !fh[b] || (a[b] = c)
    }

    function Ti(a) {
        return typeof a !== "number" && typeof a !== "string" ? "" : a.toString()
    };

    function Vi(a) {
        switch (a) {
            case 0:
                break;
            case 9:
                return "e4";
            case 6:
                return "e5";
            case 14:
                return "e6";
            default:
                return "e7"
        }
    };

    function Wi() {
        this.blockSize = -1
    };

    function Xi(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.O = Sa.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.T = this.J = 0;
        this.D = [];
        this.fa = a;
        this.V = b;
        this.ma = Sa.Int32Array ? new Int32Array(64) : Array(64);
        Yi === void 0 && (Sa.Int32Array ? Yi = new Int32Array(Zi) : Yi = Zi);
        this.reset()
    }
    Ta(Xi, Wi);
    for (var $i = [], aj = 0; aj < 63; aj++) $i[aj] = 0;
    var bj = [].concat(128, $i);
    Xi.prototype.reset = function() {
        this.T = this.J = 0;
        var a;
        if (Sa.Int32Array) a = new Int32Array(this.V);
        else {
            var b = this.V,
                c = b.length;
            if (c > 0) {
                for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
                a = d
            } else a = []
        }
        this.D = a
    };
    var cj = function(a) {
        for (var b = a.O, c = a.ma, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (var f = 16; f < 64; f++) {
            var g = c[f - 15] | 0,
                h = c[f - 2] | 0;
            c[f] = ((c[f - 16] | 0) + ((g >>> 7 | g << 25) ^ (g >>> 18 | g << 14) ^ g >>> 3) | 0) + ((c[f - 7] | 0) + ((h >>> 17 | h << 15) ^ (h >>> 19 | h << 13) ^ h >>> 10) | 0) | 0
        }
        for (var l = a.D[0] | 0, n = a.D[1] | 0, p = a.D[2] | 0, q = a.D[3] | 0, r = a.D[4] | 0, t = a.D[5] | 0, u = a.D[6] | 0, v = a.D[7] | 0, x = 0; x < 64; x++) {
            var y = ((l >>> 2 | l << 30) ^ (l >>> 13 | l << 19) ^ (l >>> 22 | l << 10)) + (l & n ^ l & p ^ n & p) | 0,
                z = (v + ((r >>> 6 | r << 26) ^ (r >>> 11 | r << 21) ^ (r >>> 25 | r << 7)) |
                    0) + (((r & t ^ ~r & u) + (Yi[x] | 0) | 0) + (c[x] | 0) | 0) | 0;
            v = u;
            u = t;
            t = r;
            r = q + z | 0;
            q = p;
            p = n;
            n = l;
            l = z + y | 0
        }
        a.D[0] = a.D[0] + l | 0;
        a.D[1] = a.D[1] + n | 0;
        a.D[2] = a.D[2] + p | 0;
        a.D[3] = a.D[3] + q | 0;
        a.D[4] = a.D[4] + r | 0;
        a.D[5] = a.D[5] + t | 0;
        a.D[6] = a.D[6] + u | 0;
        a.D[7] = a.D[7] + v | 0
    };
    Xi.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.J;
        if (typeof a === "string")
            for (; c < b;) this.O[d++] = a.charCodeAt(c++), d == this.blockSize && (cj(this), d = 0);
        else {
            var e, f = typeof a;
            e = f != "object" ? f : a ? Array.isArray(a) ? "array" : f : "null";
            if (e == "array" || e == "object" && typeof a.length == "number")
                for (; c < b;) {
                    var g = a[c++];
                    if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0))) throw Error("message must be a byte array");
                    this.O[d++] = g;
                    d == this.blockSize && (cj(this), d = 0)
                } else throw Error("message must be string or array");
        }
        this.J = d;
        this.T += b
    };
    Xi.prototype.digest = function() {
        var a = [],
            b = this.T * 8;
        this.J < 56 ? this.update(bj, 56 - this.J) : this.update(bj, this.blockSize - (this.J - 56));
        for (var c = 63; c >= 56; c--) this.O[c] = b & 255, b /= 256;
        cj(this);
        for (var d = 0, e = 0; e < this.fa; e++)
            for (var f = 24; f >= 0; f -= 8) a[d++] = this.D[e] >> f & 255;
        return a
    };
    var Zi = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        Yi;

    function dj() {
        Xi.call(this, 8, ej)
    }
    Ta(dj, Xi);
    var ej = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var fj = /^[0-9A-Fa-f]{64}$/;

    function gj(a) {
        try {
            return (new TextEncoder).encode(a)
        } catch (b) {
            return dc(a)
        }
    }

    function hj(a) {
        var b = w;
        if (a === "" || a === "e0") return Promise.resolve(a);
        var c;
        if ((c = b.crypto) == null ? 0 : c.subtle) {
            if (fj.test(a)) return Promise.resolve(a);
            try {
                var d = gj(a);
                return b.crypto.subtle.digest("SHA-256", d).then(function(e) {
                    return ij(e, b)
                }).catch(function() {
                    return "e2"
                })
            } catch (e) {
                return Promise.resolve("e2")
            }
        } else return Promise.resolve("e1")
    }

    function jj(a) {
        try {
            var b = new dj;
            b.update(gj(a));
            return b.digest()
        } catch (c) {
            return "e2"
        }
    }

    function kj(a) {
        var b = w;
        if (a === "" || a === "e0" || fj.test(a)) return a;
        var c = jj(a);
        if (c === "e2") return "e2";
        try {
            return ij(c, b)
        } catch (d) {
            return "e2"
        }
    }

    function ij(a, b) {
        var c = Array.from(new Uint8Array(a)).map(function(d) {
            return String.fromCharCode(d)
        }).join("");
        return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
    };
    var lj = {},
        mj = function() {
            for (var a = !1, b = !1, c = 0; a === b;)
                if (a = Hb(0, 1) === 0, b = Hb(0, 1) === 0, c++, c > 30) return;
            return a
        },
        oj = {
            Js: nj
        };

    function nj(a, b, c) {
        var d = lj[b];
        if (!((c === void 0 ? Hb(0, 9999) : c % 1E4) < d.probability * (d.controlId2 ? 4 : 2) * 1E4)) return a;
        a: {
            var e = d.studyId,
                f = d.experimentId,
                g = d.controlId,
                h = d.controlId2;
            if (!((a.exp || {})[f] || (a.exp || {})[g] || h && (a.exp || {})[h])) {
                var l = c !== void 0 ? c % 2 === 0 : mj();
                if (l !== void 0) {
                    var n = l ? 0 : 1;
                    if (h) {
                        var p = c !== void 0 ? (c >> 1) % 2 === 0 : mj();
                        if (p === void 0) break a;
                        n |= (p ? 0 : 1) << 1
                    }
                    n === 0 ? pj(a, f, e) : n === 1 ? pj(a, g, e) : n === 2 && pj(a, h, e)
                }
            }
        }
        return a
    }

    function qj(a, b) {
        return lj[b] ? !!lj[b].active || lj[b].probability > .5 || !!(a.exp || {})[lj[b].experimentId] : !1
    }

    function rj(a, b) {
        for (var c = a.exp || {}, d = m(Object.keys(c).map(Number)), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (c[f] === b) return f
        }
    }

    function pj(a, b, c) {
        var d = a.exp || {};
        d[b] = c;
        a.exp = d
    };
    var M = {
        N: {
            li: "call_conversion",
            oe: "ccm_conversion",
            ni: "common_aw",
            Ca: "conversion",
            Eh: "floodlight",
            Me: "ga_conversion",
            Md: "gcp_remarketing",
            Yi: "landing_page",
            Ha: "page_view",
            Re: "fpm_test_hit",
            Se: "shw_test_hit",
            Eb: "remarketing",
            Qb: "user_data_lead",
            Fb: "user_data_web"
        }
    };
    var sj = function() {
            this.D = new Set;
            this.J = new Set
        },
        uj = function(a) {
            var b = tj.D;
            a = a === void 0 ? [] : a;
            var c = [].concat(Aa(b.D)).concat([].concat(Aa(b.J))).concat(a);
            c.sort(function(d, e) {
                return d - e
            });
            return c
        },
        vj = function() {
            var a = [].concat(Aa(tj.D.D));
            a.sort(function(b, c) {
                return b - c
            });
            return a
        },
        wj = function() {
            var a = tj.D,
                b = E(44);
            a.D = new Set;
            if (b !== "")
                for (var c = m(b.split("~")), d = c.next(); !d.done; d = c.next()) {
                    var e = Number(d.value);
                    isNaN(e) || a.D.add(e)
                }
        };
    var xj = {},
        yj = {
            __cl: 1,
            __ecl: 1,
            __ehl: 1,
            __evl: 1,
            __fal: 1,
            __fil: 1,
            __fsl: 1,
            __hl: 1,
            __jel: 1,
            __lcl: 1,
            __sdl: 1,
            __tl: 1,
            __ytl: 1
        },
        zj = {
            __paused: 1,
            __tg: 1
        },
        Aj;
    for (Aj in yj) yj.hasOwnProperty(Aj) && (zj[Aj] = 1);
    var Bj = xg(45),
        Cj, Dj = !1;
    Cj = Dj;
    var Ej = null,
        Fj = {},
        Gj = "";
    xj.ij = Gj;
    var tj = new function() {
        this.D = new sj;
        this.J = !1
    };
    var Hj = /:[0-9]+$/,
        Ij = /^\d+\.fls\.doubleclick\.net$/;

    function Jj(a, b, c, d) {
        var e = Kj(a, !!d, b),
            f, g;
        return c ? (g = e[b]) != null ? g : [] : (f = e[b]) == null ? void 0 : f[0]
    }

    function Kj(a, b, c) {
        for (var d = {}, e = m(a.split("&")), f = e.next(); !f.done; f = e.next()) {
            var g = m(f.value.split("=")),
                h = g.next().value,
                l = za(g),
                n = decodeURIComponent(h.replace(/\+/g, " "));
            if (c === void 0 || n === c) {
                var p = l.join("=");
                d[n] || (d[n] = []);
                d[n].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")))
            }
        }
        return d
    }

    function Lj(a) {
        try {
            return decodeURIComponent(a)
        } catch (b) {}
    }

    function Mj(a, b, c, d, e) {
        b && (b = String(b).toLowerCase());
        if (b === "protocol" || b === "port") a.protocol = Nj(a.protocol) || Nj(w.location.protocol);
        b === "port" ? a.port = String(Number(a.hostname ? a.port : w.location.port) || (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")) : b === "host" && (a.hostname = (a.hostname || w.location.hostname).replace(Hj, "").toLowerCase());
        return Oj(a, b, c, d, e)
    }

    function Oj(a, b, c, d, e) {
        var f, g = Nj(a.protocol);
        b && (b = String(b).toLowerCase());
        switch (b) {
            case "url_no_fragment":
                f = Pj(a);
                break;
            case "protocol":
                f = g;
                break;
            case "host":
                f = a.hostname.replace(Hj, "").toLowerCase();
                if (c) {
                    var h = /^www\d*\./.exec(f);
                    h && h[0] && (f = f.substring(h[0].length))
                }
                break;
            case "port":
                f = String(Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || vb("TAGGING", 1);
                f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
                var l = f.split("/");
                (d || []).indexOf(l[l.length -
                    1]) >= 0 && (l[l.length - 1] = "");
                f = l.join("/");
                break;
            case "query":
                f = a.search.replace("?", "");
                e && (f = Jj(f, e, !1));
                break;
            case "extension":
                var n = a.pathname.split(".");
                f = n.length > 1 ? n[n.length - 1] : "";
                f = f.split("/")[0];
                break;
            case "fragment":
                f = a.hash.replace("#", "");
                break;
            default:
                f = a && a.href
        }
        return f
    }

    function Nj(a) {
        return a ? a.replace(":", "").toLowerCase() : ""
    }

    function Pj(a) {
        var b = "";
        if (a && a.href) {
            var c = a.href.indexOf("#");
            b = c < 0 ? a.href : a.href.substring(0, c)
        }
        return b
    }
    var Qj = {},
        Rj = 0;

    function Sj(a) {
        var b = Qj[a];
        if (!b) {
            var c = A.createElement("a");
            a && (c.href = a);
            var d = c.pathname;
            d[0] !== "/" && (a || vb("TAGGING", 1), d = "/" + d);
            var e = c.hostname.replace(Hj, "");
            b = {
                href: c.href,
                protocol: c.protocol,
                host: c.host,
                hostname: e,
                pathname: d,
                search: c.search,
                hash: c.hash,
                port: c.port
            };
            Rj < 5 && (Qj[a] = b, Rj++)
        }
        return b
    }

    function Tj(a, b, c) {
        var d = Sj(a);
        return hc(b, d, c)
    }

    function Uj(a) {
        var b = Sj(w.location.href),
            c = Mj(b, "host", !1);
        if (c && c.match(Ij)) {
            var d = Mj(b, "path");
            if (d) {
                var e = d.split(a + "=");
                if (e.length > 1) return e[1].split(";")[0].split("?")[0]
            }
        }
    };
    var Vj = {
            "https://www.google.com": "/g",
            "https://www.googleadservices.com": "/as",
            "https://pagead2.googlesyndication.com": "/gs"
        },
        Wj = ["/as/d/ccm/conversion", "/g/d/ccm/conversion", "/gs/ccm/conversion", "/d/ccm/form-data"];

    function Xj() {
        return xg(47) ? yg(54) !== 1 : !1
    }

    function Yj() {
        var a = E(18),
            b = a.length;
        return a[b - 1] === "/" ? a.substring(0, b - 1) : a
    }

    function Zj(a, b) {
        if (a) {
            var c = "" + a;
            c.indexOf("http://") !== 0 && c.indexOf("https://") !== 0 && (c = "https://" + c);
            c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
            return Sj("" + c + b).href
        }
    }

    function ak(a, b) {
        if (bk()) return Zj(a, b)
    }

    function bk() {
        return Xj() || xg(50)
    }

    function ck() {
        return !!xj.ij && xj.ij.split("@@").join("") !== "SGTM_TOKEN"
    }

    function dk(a) {
        for (var b = m([K.m.Id, K.m.Wc]), c = b.next(); !c.done; c = b.next()) {
            var d = O(a, c.value);
            if (d) return d
        }
    }

    function ek(a, b, c) {
        c = c === void 0 ? "" : c;
        if (!Xj()) return a;
        var d = b ? Vj[a] || "" : "";
        d === "/gs" && (c = "");
        return "" + Yj() + d + c
    }

    function fk(a) {
        if (Xj())
            for (var b = m(Wj), c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                if (Yb(a, "" + Yj() + d)) return "::"
            }
    };
    var gk = /gtag[.\/]js/,
        hk = /gtm[.\/]js/,
        ik = !1;

    function jk(a) {
        if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
            var b;
            a: {
                var c, d = (c = a.scriptElement) == null ? void 0 : c.src;
                if (d) {
                    for (var e = xg(47), f = Sj(d), g = e ? f.pathname : "" + f.hostname + f.pathname, h = A.scripts, l = "", n = 0; n < h.length; ++n) {
                        var p = h[n];
                        if (!(p.innerHTML.length === 0 || !e && p.innerHTML.indexOf(a.scriptContainerId || "SHOULD_NOT_BE_SET") < 0 || p.innerHTML.indexOf(g) < 0)) {
                            if (p.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                                b = String(n);
                                break a
                            }
                            l = String(n)
                        }
                    }
                    if (l) {
                        b = l;
                        break a
                    }
                }
                b = void 0
            }
            var q = b;
            if (q) return ik = !0,
                q
        }
        var r = [].slice.call(A.scripts);
        return a.scriptElement ? String(r.indexOf(a.scriptElement)) : "-1"
    }

    function kk(a) {
        if (ik) return "1";
        var b, c = (b = a.scriptElement) == null ? void 0 : b.src;
        if (c) {
            if (gk.test(c)) return "3";
            if (hk.test(c)) return "2"
        }
        return "0"
    };
    var lk = [];

    function mk(a) {
        switch (a) {
            case 1:
                return 0;
            case 480:
                return 21;
            case 421:
                return 20;
            case 235:
                return 18;
            case 38:
                return 13;
            case 287:
                return 11;
            case 288:
                return 12;
            case 285:
                return 9;
            case 286:
                return 10;
            case 219:
                return 7;
            case 220:
                return 8;
            case 53:
                return 1;
            case 54:
                return 2;
            case 52:
                return 5;
            case 203:
                return 17;
            case 75:
                return 3;
            case 103:
                return 14;
            case 197:
                return 15;
            case 109:
                return 19;
            case 116:
                return 4
        }
    }

    function nk(a) {
        lk[a] = !0;
        var b = mk(a);
        b !== void 0 && (hb[b] = !0)
    }
    nk(132);
    nk(20);
    nk(72);
    nk(113);
    nk(116);
    nk(24);
    Cg(6, 6E4);
    Cg(7, 1);
    Cg(35, 50);
    nk(37);
    nk(162);
    nk(263);
    nk(123);
    nk(158);
    nk(71);
    nk(38);
    nk(103);
    nk(101);
    nk(435);
    nk(21);
    nk(160);
    nk(141);
    nk(185);
    nk(197);
    nk(200);
    nk(206);
    nk(218);
    nk(232);

    function P(a) {
        return !!lk[a]
    };

    function Q(a) {
        vb("GTM", a)
    };

    function ok(a) {
        var b = pk().destinationArray[a],
            c = pk().destination[a];
        return b && b.length > 0 ? b[0] : c
    }

    function qk(a, b) {
        var c = pk();
        c.pending || (c.pending = []);
        Gb(c.pending, function(d) {
            return d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
        }) || c.pending.push({
            target: a,
            onLoad: b
        })
    }

    function rk() {
        var a = w.google_tags_first_party;
        Array.isArray(a) || (a = []);
        for (var b = {}, c = m(a), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return Object.freeze(b)
    }
    var sk = function() {
        this.container = {};
        this.destination = {};
        this.destinationArray = {};
        this.canonical = {};
        this.pending = [];
        this.injectedFirstPartyContainers = {};
        this.injectedFirstPartyContainers = rk()
    };

    function pk() {
        var a = Vc("google_tag_data", {}),
            b = a.tidr;
        b && typeof b === "object" || (b = new sk, a.tidr = b);
        var c = b;
        c.container || (c.container = {});
        c.destination || (c.destination = {});
        c.destinationArray || (c.destinationArray = {});
        c.canonical || (c.canonical = {});
        c.pending || (c.pending = []);
        c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = rk());
        return c
    };

    function tk() {
        return xg(7) && uk().some(function(a) {
            return a === E(5)
        })
    }

    function vk() {
        if (P(461)) return uk();
        var a;
        return (a = zg(55)) != null ? a : []
    }

    function wk() {
        return E(6) || "_" + E(5)
    }

    function xk() {
        var a = E(10);
        return a ? a.split("|") : [E(5)]
    }

    function uk() {
        var a = zg(59);
        return Array.isArray(a) ? a.filter(function(b) {
            return typeof b === "string"
        }).filter(function(b) {
            return b.indexOf("GTM-") !== 0
        }) : []
    }

    function yk() {
        var a = zk(Ak()),
            b = a && a.parent;
        if (b) return zk(b)
    }

    function Bk() {
        var a = zk(Ak());
        if (a) {
            for (; a.parent;) {
                var b = zk(a.parent);
                if (!b) break;
                a = b
            }
            return a
        }
    }

    function zk(a) {
        var b = pk();
        return a.isDestination ? ok(a.ctid) : b.container[a.ctid]
    }

    function Ck() {
        var a = pk();
        if (a.pending) {
            for (var b, c = [], d = !1, e = xk(), f = uk(), g = {}, h = 0; h < a.pending.length; g = {
                    Sg: void 0
                }, h++) g.Sg = a.pending[h], Gb(g.Sg.target.isDestination ? f : e, function(l) {
                return function(n) {
                    return n === l.Sg.target.ctid
                }
            }(g)) ? d || (b = g.Sg.onLoad, d = !0) : c.push(g.Sg);
            a.pending = c;
            if (b) try {
                b(wk())
            } catch (l) {}
        }
    }

    function Dk() {
        for (var a = E(5), b = xk(), c = uk(), d = vk(), e = function(q, r) {
                var t = {
                    canonicalContainerId: E(6),
                    scriptContainerId: a,
                    state: 2,
                    containers: b.slice(),
                    destinations: c.slice()
                };
                Tc && (t.scriptElement = Tc);
                Uc && (t.scriptSource = Uc);
                yk() === void 0 && (t.htmlLoadOrder = jk(t), t.loadScriptType = kk(t));
                var u, v;
                switch (r) {
                    case 0:
                        u = function(z) {
                            f.container[q] = z
                        };
                        v = f.container[q];
                        break;
                    case 1:
                        u = function(z) {
                            f.destinationArray[q] = f.destinationArray[q] || [];
                            f.destinationArray[q].unshift(z)
                        };
                        var x, y = ((x = f.destinationArray[q]) ==
                            null ? void 0 : x[0]) || f.destination[q];
                        !y || y.state !== 0 && y.state !== 1 || (v = y);
                        break;
                    case 2:
                        u = function(z) {
                            f.destinationArray[q] = f.destinationArray[q] || [];
                            f.destinationArray[q].push(z)
                        }, v = void 0
                }
                u && (v ? (v.state === 0 && Q(93), pa(Object, "assign").call(Object, v, t)) : u(t))
            }, f = pk(), g = m(b), h = g.next(); !h.done; h = g.next()) e(h.value, 0);
        for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
            var p = n.value;
            d.includes(p) ? e(p, 1) : e(p, 2)
        }
        f.canonical[wk()] = {};
        Ck()
    }

    function Ek() {
        var a = wk();
        return !!pk().canonical[a]
    }

    function Fk(a) {
        return !!pk().container[a]
    }

    function Gk() {
        var a = Ak(),
            b = zk(a);
        return b && b.context
    }

    function Hk(a) {
        var b = ok(a);
        return b ? b.state !== 0 : !1
    }

    function Ak() {
        return {
            ctid: E(5),
            isDestination: xg(7)
        }
    }

    function Ik(a, b, c) {
        var d = Ak(),
            e = pk().container[a];
        e && e.state !== 3 || (pk().container[a] = {
            state: 1,
            context: b,
            parent: d
        }, qk({
            ctid: a,
            isDestination: !1
        }, c))
    }

    function Jk() {
        var a = pk().container,
            b;
        for (b in a)
            if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
        return !1
    }

    function Kk() {
        var a = {};
        Lb(pk().destination, function(b, c) {
            (c == null ? void 0 : c.state) === 0 && (a[b] = c)
        });
        Lb(pk().destinationArray, function(b, c) {
            var d = c[0];
            (d == null ? void 0 : d.state) === 0 && (a[b] = d)
        });
        return a
    }

    function Lk(a) {
        return !!(a && a.parent && a.context && a.context.source === 1 && a.parent.ctid.indexOf("GTM-") !== 0)
    }

    function Mk() {
        for (var a = pk(), b = m(xk()), c = b.next(); !c.done; c = b.next())
            if (a.injectedFirstPartyContainers[c.value]) return !0;
        return !1
    };
    var Nk = {},
        Ok = (Nk.tdp = 1, Nk.exp = 1, Nk.gtm = 1, Nk.pid = 1, Nk.dl = 1, Nk.seq = 1, Nk.t = 1, Nk.v = 1, Nk),
        Pk = {};

    function Qk() {
        return Object.keys(Pk).filter(function(a) {
            return Pk[a]
        })
    }
    var Rk = {};

    function Sk(a, b, c) {
        Rk[a] = b;
        (c === void 0 || c) && Tk(a)
    }

    function Tk(a, b) {
        Pk[a] !== void 0 && (b === void 0 || !b) || Yb(E(5), "GTM-") && a === "mcc" || (Pk[a] = !0)
    }

    function Uk(a) {
        a.forEach(function(b) {
            Ok[b] || (Pk[b] = !1)
        })
    };

    function Vk(a) {
        a = a === void 0 ? [] : a;
        return uj(a).join("~")
    };
    var Wk = {
        UA: 1,
        AW: 2,
        DC: 3,
        G: 4,
        GF: 5,
        GT: 12,
        GTM: 14,
        HA: 6,
        MC: 7
    };

    function Xk(a) {
        a = a === void 0 ? {} : a;
        var b = E(5).split("-")[0].toUpperCase(),
            c, d = {
                ctid: E(5),
                po: yg(15),
                uo: E(14),
                Zr: xg(7) ? 2 : 1,
                Ps: a.wo,
                canonicalId: E(6),
                Gs: (c = Bk()) == null ? void 0 : c.canonicalContainerId,
                Qs: a.je === void 0 ? void 0 : a.je ? 10 : 12
            };
        d.canonicalId !== a.Sa && (d.Sa = a.Sa);
        var e = yk();
        d.qs = e ? e.canonicalContainerId : void 0;
        Bj ? (d.hi = Wk[b], d.hi || (d.hi = 0)) : d.hi = Cj ? 13 : 10;
        xg(47) ? (d.Rj = 0, d.Oq = 2) : xg(50) ? d.Rj = 1 : d.Rj = 3;
        var f = a,
            g = {
                6: !1
            };
        yg(54) === 2 ? g[7] = !0 : yg(54) === 1 && (g[2] = !0);
        if (Uc) {
            var h = Mj(Sj(Uc), "host");
            h && (g[8] = h.match(/^(www\.)?googletagmanager\.com$/) ===
                null)
        }
        if (P(417)) {
            var l;
            g[9] = (l = f.qc) != null ? l : !1
        }
        if (P(420)) {
            var n = Gk(),
                p;
            g[10] = (p = n == null ? void 0 : n.fromContainerExecution) != null ? p : !1
        }
        d.Uq = g;
        return Ef(d, a.Rh)
    };

    function cl() {
        return {
            total: 0,
            lb: 0,
            cf: {}
        }
    }

    function dl(a, b, c, d) {
        var e = Object.keys(a.df).sort(function(f, g) {
            return Number(f) - Number(g)
        }).map(function(f) {
            return [f, b(a.df[f])]
        }).filter(function(f) {
            return f[1] !== void 0
        }).map(function(f) {
            return f.join(c)
        }).join(d);
        return e ? e : void 0
    }

    function el(a, b) {
        var c, d, e;
        c = c === void 0 ? "_" : c;
        d = d === void 0 ? ";" : d;
        e = e === void 0 ? "~" : e;
        for (var f = [], g = m(Object.keys(a.cf).sort()), h = g.next(); !h.done; h = g.next()) {
            var l = h.value,
                n = dl(a.cf[l], b, c, d);
            if (n) {
                var p = void 0;
                f.push("" + ((p = l) != null ? p : "") + d + n)
            }
        }
        return f.length ? f.join(e) : void 0
    }

    function fl(a) {
        a.lb = 0;
        for (var b = m(Object.keys(a.cf)), c = b.next(); !c.done; c = b.next()) {
            var d = a.cf[c.value];
            d.lb = 0;
            for (var e = m(Object.keys(d.df)), f = e.next(); !f.done; f = e.next()) d.df[f.value].lb = 0
        }
    }

    function gl(a, b, c) {
        var d;
        d = d === void 0 ? 1 : d;
        a.total += d;
        a.lb += d;
        var e, f = b === void 0 ? "" : b;
        e = a.cf[f] || (a.cf[f] = {
            total: 0,
            lb: 0,
            df: {}
        });
        e.total += d;
        e.lb += d;
        var g, h = String(c);
        g = e.df[h] || (e.df[h] = {
            total: 0,
            lb: 0
        });
        g.total += d;
        g.lb += d
    };
    var hl = cl();

    function il(a) {
        var b = String(a[Kf.ab] || "").replace(/_/g, "");
        return Yb(b, "cvt") ? "cvt" : b
    }
    var jl = w.location.search.indexOf("?gtm_latency=") >= 0 || w.location.search.indexOf("&gtm_latency=") >= 0;
    var kl = Math.random(),
        ll, ml = yg(27);
    ll = jl || kl < ml;
    var nl, ol = yg(42);
    nl = jl || kl >= 1 - ol;
    var pl = {},
        ql = (pl[1] = {}, pl[2] = {}, pl[3] = {}, pl[4] = {}, pl);

    function rl(a, b, c) {
        if (nl) {
            var d = sl(b, c);
            if (d) {
                var e = ql[b][d];
                e || (e = ql[b][d] = []);
                e.push(pa(Object, "assign").call(Object, {}, a));
                gl(hl, a.destinationId, a.endpoint);
                a.endpoint !== 56 && a.endpoint !== 61 && Tk("mde", !0)
            }
        }
    }

    function tl(a, b) {
        var c = sl(a, b);
        if (c) {
            var d = ql[a][c];
            d && (ql[a][c] = d.filter(function(e) {
                return !e.qo
            }))
        }
    }

    function ul(a) {
        switch (a) {
            case "script-src":
            case "script-src-elem":
                return 1;
            case "frame-src":
                return 4;
            case "connect-src":
                return 2;
            case "img-src":
                return 3
        }
    }

    function sl(a, b) {
        var c = b;
        if (b[0] === "/") {
            var d;
            c = ((d = w.location) == null ? void 0 : d.origin) + b
        }
        try {
            var e = new URL(c);
            return a === 4 ? e.origin : e.origin + e.pathname
        } catch (f) {}
    };

    function vl(a, b, c) {
        var d, e = a.GooglebQhCsO;
        e || (e = {}, a.GooglebQhCsO = e);
        d = e;
        if (d[b]) return !1;
        d[b] = [];
        d[b][0] = c;
        return !0
    };
    var wl, xl;
    a: {
        for (var yl = ["CLOSURE_FLAGS"], zl = Sa, Al = 0; Al < yl.length; Al++)
            if (zl = zl[yl[Al]], zl == null) {
                xl = null;
                break a
            }
        xl = zl
    }
    var Bl = xl && xl[610401301];
    wl = Bl != null ? Bl : !1;

    function Cl() {
        var a = Sa.navigator;
        if (a) {
            var b = a.userAgent;
            if (b) return b
        }
        return ""
    }
    var Dl, El = Sa.navigator;
    Dl = El ? El.userAgentData || null : null;

    function Fl(a) {
        if (!wl || !Dl) return !1;
        for (var b = 0; b < Dl.brands.length; b++) {
            var c = Dl.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function Gl(a) {
        return Cl().indexOf(a) != -1
    };

    function Hl() {
        return wl ? !!Dl && Dl.brands.length > 0 : !1
    }

    function Il() {
        return Hl() ? !1 : Gl("Opera")
    }

    function Jl() {
        return Gl("Firefox") || Gl("FxiOS")
    }

    function Kl() {
        return Hl() ? Fl("Chromium") : (Gl("Chrome") || Gl("CriOS")) && !(Hl() ? 0 : Gl("Edge")) || Gl("Silk")
    };

    function Ll() {
        return wl ? !!Dl && !!Dl.platform : !1
    }

    function Ml() {
        return Gl("iPhone") && !Gl("iPod") && !Gl("iPad")
    }

    function Nl() {
        Ml() || Gl("iPad") || Gl("iPod")
    };
    var Ol = function(a) {
        Ol[" "](a);
        return a
    };
    Ol[" "] = function() {};
    Il();
    Hl() || Gl("Trident") || Gl("MSIE");
    Gl("Edge");
    !Gl("Gecko") || Cl().toLowerCase().indexOf("webkit") != -1 && !Gl("Edge") || Gl("Trident") || Gl("MSIE") || Gl("Edge");
    Cl().toLowerCase().indexOf("webkit") != -1 && !Gl("Edge") && Gl("Mobile");
    Ll() || Gl("Macintosh");
    Ll() || Gl("Windows");
    (Ll() ? Dl.platform === "Linux" : Gl("Linux")) || Ll() || Gl("CrOS");
    Ll() || Gl("Android");
    Ml();
    Gl("iPad");
    Gl("iPod");
    Nl();
    Cl().toLowerCase().indexOf("kaios");
    Jl();
    Ml() || Gl("iPod");
    Gl("iPad");
    !Gl("Android") || Kl() || Jl() || Il() || Gl("Silk");
    Kl();
    !Gl("Safari") || Kl() || (Hl() ? 0 : Gl("Coast")) || Il() || (Hl() ? 0 : Gl("Edge")) || (Hl() ? Fl("Microsoft Edge") : Gl("Edg/")) || (Hl() ? Fl("Opera") : Gl("OPR")) || Jl() || Gl("Silk") || Gl("Android") || Nl();
    var Pl = {},
        Ql = null;

    function Rl(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e > 255 && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        var f = 4;
        f === void 0 && (f = 0);
        if (!Ql) {
            Ql = {};
            for (var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), h = ["+/=", "+/", "-_=", "-_.", "-_"], l = 0; l < 5; l++) {
                var n = g.concat(h[l].split(""));
                Pl[l] = n;
                for (var p = 0; p < n.length; p++) {
                    var q = n[p];
                    Ql[q] === void 0 && (Ql[q] = p)
                }
            }
        }
        for (var r = Pl[f], t = Array(Math.floor(b.length / 3)), u = r[64] || "", v = 0, x = 0; v < b.length - 2; v += 3) {
            var y = b[v],
                z = b[v + 1],
                C = b[v + 2],
                D = r[y >> 2],
                G = r[(y & 3) << 4 | z >> 4],
                J = r[(z & 15) << 2 | C >> 6],
                L = r[C & 63];
            t[x++] = "" + D + G + J + L
        }
        var da = 0,
            aa = u;
        switch (b.length - v) {
            case 2:
                da = b[v + 1], aa = r[(da & 15) << 2] || u;
            case 1:
                var N = b[v];
                t[x] = "" + r[N >> 2] + r[(N & 3) << 4 | da >> 4] + aa + u
        }
        return t.join("")
    };
    var Sl = function(a) {
        return decodeURIComponent(a.replace(/\+/g, " "))
    };
    var Tl = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Ul(a, b, c, d) {
        for (var e = b, f = c.length;
            (e = a.indexOf(c, e)) >= 0 && e < d;) {
            var g = a.charCodeAt(e - 1);
            if (g == 38 || g == 63) {
                var h = a.charCodeAt(e + f);
                if (!h || h == 61 || h == 38 || h == 35) return e
            }
            e += f + 1
        }
        return -1
    }
    var Vl = /#|$/;

    function Wl(a, b) {
        var c = a.search(Vl),
            d = Ul(a, 0, b, c);
        if (d < 0) return null;
        var e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return Sl(a.slice(d, e !== -1 ? e : 0))
    }
    var Xl = /[?&]($|#)/;

    function Yl(a, b, c) {
        for (var d, e = a.search(Vl), f = 0, g, h = [];
            (g = Ul(a, f, b, e)) >= 0;) h.push(a.substring(f, g)), f = Math.min(a.indexOf("&", g) + 1 || e, e);
        h.push(a.slice(f));
        d = h.join("").replace(Xl, "$1");
        var l, n = c != null ? "=" + encodeURIComponent(String(c)) : "";
        var p = b + n;
        if (p) {
            var q, r = d.indexOf("#");
            r < 0 && (r = d.length);
            var t = d.indexOf("?"),
                u;
            t < 0 || t > r ? (t = r, u = "") : u = d.substring(t + 1, r);
            q = [d.slice(0, t), u, d.slice(r)];
            var v = q[1];
            q[1] = p ? v ? v + "&" + p : p : v;
            l = q[0] + (q[1] ? "?" + q[1] : "") + q[2]
        } else l = d;
        return l
    };

    function Zl(a, b, c, d, e, f, g, h) {
        var l = Wl(c, "fmt");
        if (d) {
            var n = Wl(c, "random"),
                p = Wl(c, "label") || "";
            if (!n) return;
            var q = Rl(Sl(p) + ":" + Sl(n));
            if (!vl(a, q, d)) return
        }
        l && Number(l) !== 4 && (c = Yl(c, "rfmt", l));
        var r = Yl(c, "fmt", 4),
            t = b.getElementsByTagName("script")[0].parentElement;
        g == null || $l(g);
        cd(r, function() {
            g == null || am(g);
            h == null || bm(h, c);
            a.google_noFurtherRedirects && d && (a.google_noFurtherRedirects = null, d())
        }, function() {
            g == null || am(g);
            h == null || bm(h, c);
            e == null || e()
        }, f, t || void 0);
        return r
    };

    function cm(a) {
        var b = Qa.apply(1, arguments);
        rl(a, 2, b[0]);
        od.apply(null, Aa(b))
    }

    function dm(a) {
        var b = Qa.apply(1, arguments);
        rl(a, 2, b[0]);
        return pd.apply(null, Aa(b))
    }

    function em(a) {
        var b = Qa.apply(1, arguments);
        rl(a, 3, b[0]);
        fd.apply(null, Aa(b))
    }

    function fm(a) {
        var b = Qa.apply(1, arguments);
        rl(a, 2, b[0]);
        return rd.apply(null, Aa(b))
    }

    function gm(a) {
        var b = Qa.apply(1, arguments);
        rl(a, 1, b[0]);
        cd.apply(null, Aa(b))
    }

    function hm(a) {
        var b = Qa.apply(1, arguments);
        b[0] && rl(a, 4, b[0]);
        ed.apply(null, Aa(b))
    }

    function im(a) {
        var b = Zl.apply(null, Aa(Qa.apply(1, arguments)));
        b && rl(a, 1, b);
        return b
    };
    var jm = {
        Na: {
            Le: 0,
            Qe: 1,
            aj: 2
        }
    };
    jm.Na[jm.Na.Le] = "FULL_TRANSMISSION";
    jm.Na[jm.Na.Qe] = "LIMITED_TRANSMISSION";
    jm.Na[jm.Na.aj] = "NO_TRANSMISSION";
    var km = {
        ba: {
            Yc: 0,
            Ya: 1,
            nd: 2,
            Gc: 3
        }
    };
    km.ba[km.ba.Yc] = "NO_QUEUE";
    km.ba[km.ba.Ya] = "ADS";
    km.ba[km.ba.nd] = "ANALYTICS";
    km.ba[km.ba.Gc] = "MONITORING";

    function lm() {
        var a = Vc("google_tag_data", {});
        return a.ics = a.ics || new mm
    }
    var mm = function() {
        this.entries = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.D = []
    };
    mm.prototype.default = function(a, b, c, d, e, f, g) {
        this.usedDefault || this.usedDeclare || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        vb("TAGGING", 19);
        b == null ? vb("TAGGING", 18) : nm(this, a, b === "granted", c, d, e, f, g)
    };
    mm.prototype.waitForUpdate = function(a, b, c) {
        for (var d = 0; d < a.length; d++) nm(this, a[d], void 0, void 0, "", "", b, c)
    };
    var nm = function(a, b, c, d, e, f, g, h) {
        var l = a.entries,
            n = l[b] || {},
            p = n.region,
            q = d && Db(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
            var r = !!(g && g > 0 && n.update === void 0),
                t = {
                    region: q,
                    declare_region: n.declare_region,
                    implicit: n.implicit,
                    default: c !== void 0 ? c : n.default,
                    declare: n.declare,
                    update: n.update,
                    quiet: r
                };
            if (e !== "" || n.default !== !1) l[b] = t;
            r && w.setTimeout(function() {
                l[b] === t && t.quiet && (vb("TAGGING", 2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0, h),
                    a.notifyListeners())
            }, g)
        }
    };
    k = mm.prototype;
    k.clearTimeout = function(a, b, c) {
        var d = [a],
            e = c.delegatedConsentTypes,
            f;
        for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
        var g = this.entries[a] || {},
            h = this.getConsentState(a, c);
        if (g.quiet) {
            g.quiet = !1;
            for (var l = m(d), n = l.next(); !n.done; n = l.next()) om(this, n.value)
        } else if (b !== void 0 && h !== b)
            for (var p = m(d), q = p.next(); !q.done; q = p.next()) om(this, q.value)
    };
    k.update = function(a, b, c) {
        this.usedDefault || this.usedDeclare || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (b != null) {
            var d = this.getConsentState(a, c),
                e = this.entries;
            (e[a] = e[a] || {}).update = b === "granted";
            this.clearTimeout(a, d, c)
        }
    };
    k.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = this.entries,
            g = f[a] || {},
            h = g.declare_region,
            l = c && Db(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        if (d === "" || l === e || (l === d ? h !== e : !l && !h)) {
            var n = {
                region: g.region,
                declare_region: l,
                declare: b === "granted",
                implicit: g.implicit,
                default: g.default,
                update: g.update,
                quiet: g.quiet
            };
            if (d !== "" || g.declare !== !1) f[a] = n
        }
    };
    k.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = this.entries,
            d = c[a] = c[a] || {};
        d.implicit !== !1 && (d.implicit = b === "granted")
    };
    k.getConsentState = function(a, b) {
        var c = this.entries,
            d = c[a] || {},
            e = d.update;
        if (e !== void 0) return e ? 1 : 2;
        if (b.usedContainerScopedDefaults) {
            var f = b.containerScopedDefaults[a];
            if (f === 3) return 1;
            if (f === 2) return 2
        } else if (e = d.default, e !== void 0) return e ? 1 : 2;
        if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
            var g = b.delegatedConsentTypes[a],
                h = c[g] || {};
            e = h.update;
            if (e !== void 0) return e ? 1 : 2;
            if (b.usedContainerScopedDefaults) {
                var l = b.containerScopedDefaults[g];
                if (l === 3) return 1;
                if (l === 2) return 2
            } else if (e =
                h.default, e !== void 0) return e ? 1 : 2
        }
        e = d.declare;
        if (e !== void 0) return e ? 1 : 2;
        e = d.implicit;
        return e !== void 0 ? e ? 3 : 4 : 0
    };
    k.addListener = function(a, b) {
        this.D.push({
            consentTypes: a,
            Wd: b
        })
    };
    var om = function(a, b) {
        for (var c = 0; c < a.D.length; ++c) {
            var d = a.D[c];
            Array.isArray(d.consentTypes) && d.consentTypes.indexOf(b) !== -1 && (d.lo = !0)
        }
    };
    mm.prototype.notifyListeners = function(a, b) {
        for (var c = 0; c < this.D.length; ++c) {
            var d = this.D[c];
            if (d.lo) {
                d.lo = !1;
                try {
                    d.Wd({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };
    var pm = !1,
        qm = !1,
        rm = {},
        sm = {
            delegatedConsentTypes: {},
            corePlatformServices: {},
            usedCorePlatformServices: !1,
            selectedAllCorePlatformServices: !1,
            containerScopedDefaults: (rm.ad_storage = 1, rm.analytics_storage = 1, rm.ad_user_data = 1, rm.ad_personalization = 1, rm),
            usedContainerScopedDefaults: !1
        };

    function tm(a) {
        var b = lm();
        b.accessedAny = !0;
        return (Db(a) ? [a] : a).every(function(c) {
            switch (b.getConsentState(c, sm)) {
                case 1:
                case 3:
                    return !0;
                case 2:
                case 4:
                    return !1;
                default:
                    return !0
            }
        })
    }

    function um(a) {
        var b = lm();
        b.accessedAny = !0;
        return b.getConsentState(a, sm)
    }

    function vm(a) {
        var b = lm();
        b.accessedAny = !0;
        return !(b.entries[a] || {}).quiet
    }

    function wm() {
        if (!ib(6)) return !1;
        var a = lm();
        a.accessedAny = !0;
        if (a.active) return !0;
        if (!sm.usedContainerScopedDefaults) return !1;
        for (var b = m(Object.keys(sm.containerScopedDefaults)), c = b.next(); !c.done; c = b.next())
            if (sm.containerScopedDefaults[c.value] !== 1) return !0;
        return !1
    }

    function xm(a, b) {
        lm().addListener(a, b)
    }

    function ym(a, b) {
        lm().notifyListeners(a, b)
    }

    function zm(a, b) {
        function c() {
            for (var e = 0; e < b.length; e++)
                if (!vm(b[e])) return !0;
            return !1
        }
        if (c()) {
            var d = !1;
            xm(b, function(e) {
                d || c() || (d = !0, a(e))
            })
        } else a({})
    }

    function Am(a, b) {
        function c() {
            for (var h = [], l = 0; l < e.length; l++) {
                var n = e[l];
                tm(n) && !f[n] && h.push(n)
            }
            return h
        }

        function d(h) {
            for (var l = 0; l < h.length; l++) f[h[l]] = !0
        }
        var e = Db(b) ? [b] : b,
            f = {},
            g = c();
        g.length !== e.length && (d(g), xm(e, function(h) {
            function l(q) {
                q.length !== 0 && (d(q), h.consentTypes = q, a(h))
            }
            var n = c();
            if (n.length !== 0) {
                var p = Object.keys(f).length;
                n.length + p >= e.length ? l(n) : w.setTimeout(function() {
                    l(c())
                }, 500)
            }
        }))
    };
    var Bm = {},
        Cm = (Bm[km.ba.Yc] = jm.Na.Le, Bm[km.ba.Ya] = jm.Na.Le, Bm[km.ba.nd] = jm.Na.Le, Bm[km.ba.Gc] = jm.Na.Le, Bm),
        Dm = function(a, b) {
            this.D = a;
            this.consentTypes = b
        };
    Dm.prototype.isConsentGranted = function() {
        switch (this.D) {
            case 0:
                return this.consentTypes.every(function(a) {
                    return tm(a)
                });
            case 1:
                return this.consentTypes.some(function(a) {
                    return tm(a)
                });
            default:
                Gc(this.D, "consentsRequired had an unknown type")
        }
    };
    var Em = {},
        Fm = (Em[km.ba.Yc] = new Dm(0, []), Em[km.ba.Ya] = new Dm(0, ["ad_storage"]), Em[km.ba.nd] = new Dm(0, ["analytics_storage"]), Em[km.ba.Gc] = new Dm(1, ["ad_storage", "analytics_storage"]), Em);
    var Hm = function(a) {
        var b = this;
        this.type = a;
        this.D = [];
        xm(Fm[a].consentTypes, function() {
            Gm(b) || b.flush()
        })
    };
    Hm.prototype.flush = function() {
        for (var a = m(this.D), b = a.next(); !b.done; b = a.next()) {
            var c = b.value;
            c()
        }
        this.D = []
    };
    var Gm = function(a) {
            return Cm[a.type] === jm.Na.aj && !Fm[a.type].isConsentGranted()
        },
        Im = function(a, b) {
            Gm(a) ? a.D.push(b) : b()
        },
        Jm = new Map;

    function Km(a) {
        Jm.has(a) || Jm.set(a, new Hm(a));
        return Jm.get(a)
    };
    var Lm = {
        Z: {
            ct: "aw_user_data_cache",
            si: "cookie_deprecation_label",
            eh: "diagnostics_page_id",
            st: "em_registry",
            Li: "eab",
            Ht: "fl_user_data_cache",
            It: "ga4_user_data_cache",
            au: "idc_pv_claim",
            Oe: "ip_geo_data_cache",
            Ti: "ip_geo_fetch_in_progress",
            Rm: "nb_data",
            wq: "page_experiment_ids",
            Tm: "pld",
            Te: "pt_data",
            Um: "pt_listener_set",
            bn: "service_worker_endpoint",
            gn: "shared_user_id",
            hn: "shared_user_id_requested",
            Nh: "shared_user_id_source",
            jn: "awh",
            Eq: "universal_claim_registry"
        }
    };
    var Mm = function(a) {
        return yf(function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        })
    }(Lm.Z);

    function Nm(a, b) {
        b = b === void 0 ? !1 : b;
        if (Mm(a)) {
            var c, d, e = (d = (c = Vc("google_tag_data", {})).xcd) != null ? d : c.xcd = {};
            if (e[a]) return e[a];
            if (b) {
                var f = void 0,
                    g = 1,
                    h = {},
                    l = {
                        set: function(n) {
                            f = n;
                            l.notify()
                        },
                        get: function() {
                            return f
                        },
                        subscribe: function(n) {
                            h[String(g)] = n;
                            return g++
                        },
                        unsubscribe: function(n) {
                            var p = String(n);
                            return h.hasOwnProperty(p) ? (delete h[p], !0) : !1
                        },
                        notify: function() {
                            for (var n = m(Object.keys(h)), p = n.next(); !p.done; p = n.next()) {
                                var q = p.value;
                                try {
                                    h[q](a, f)
                                } catch (r) {}
                            }
                        }
                    };
                return e[a] = l
            }
        }
    }

    function Om(a, b) {
        var c = Nm(a, !0);
        c && c.set(b)
    }

    function Pm(a) {
        var b;
        return (b = Nm(a)) == null ? void 0 : b.get()
    }

    function Qm(a, b) {
        var c = Nm(a);
        if (!c) {
            c = Nm(a, !0);
            if (!c) return;
            c.set(b)
        }
        return c.get()
    }

    function Rm(a, b) {
        if (typeof b === "function") {
            var c;
            return (c = Nm(a, !0)) == null ? void 0 : c.subscribe(b)
        }
    }

    function Sm(a, b) {
        var c = Nm(a);
        return c ? c.unsubscribe(b) : !1
    };
    var Tm = ["fin", "fs", "mcc", "wft"],
        Um = !1;

    function Vm(a) {
        a = a === void 0 ? !1 : a;
        var b = Qk().filter(function(c) {
            return Rk[c] !== void 0 && (a || !Tm.includes(c))
        });
        Uk(b);
        return b.map(function(c) {
            var d = Rk[c];
            typeof d === "function" && (d = d());
            return d ? "&" + c + "=" + d : ""
        }).join("") + "&z=0"
    }

    function Wm(a) {
        var b = "https://" + E(21),
            c = "/td?id=" + E(5);
        return "" + ek(b) + c + a
    }

    function Xm(a) {
        a = a === void 0 ? !1 : a;
        if (tj.J && nl && E(5)) {
            var b = Km(km.ba.Gc);
            if (Gm(b)) Um || (Um = !0, Im(b, Xm));
            else {
                a && Sk("fin", "1");
                var c = Vm(a),
                    d = Wm(c),
                    e = {
                        destinationId: E(5),
                        endpoint: 61
                    };
                a ? fm(e, d, void 0, {
                    Rg: !0
                }, void 0, function() {
                    em(e, d + "&img=1")
                }) : em(e, d);
                Um = !1;
                Ym(c)
            }
        }
    }

    function Ym(a) {
        if (P(426) && Uc && (Yb(Uc, "https://www.googletagmanager.com/") || xg(47)) && !(a.indexOf("&csp=") < 0 && a.indexOf("&mde=") < 0)) {
            var b;
            a: {
                try {
                    if (Uc) {
                        b = new URL(Uc);
                        break a
                    }
                } catch (c) {}
                b = void 0
            }
            b && cd("" + Uc + (Uc.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + a)
        }
    }

    function Zm() {
        Qk().some(function(a) {
            return !Ok[a]
        }) && Xm(!0)
    }
    var $m;

    function an() {
        if (Pm(Lm.Z.eh) === void 0) {
            var a = function() {
                Om(Lm.Z.eh, Hb());
                $m = 0
            };
            a();
            w.setInterval(a, 864E5)
        } else Rm(Lm.Z.eh, function() {
            $m = 0
        });
        $m = 0
    }

    function bn() {
        an();
        Sk("v", "3");
        Sk("t", "t");
        Sk("pid", function() {
            return String(Pm(Lm.Z.eh))
        });
        Sk("gtm", function() {
            return Xk()
        });
        Sk("seq", function() {
            return String(++$m)
        });
        Sk("exp", Vk());
        hd(w, "pagehide", Zm)
    };
    var cn = ["ad_storage", "analytics_storage", "ad_user_data", "ad_personalization"],
        dn = [K.m.Id, K.m.Wc, K.m.Lf, K.m.Wb, K.m.pb, K.m.Oa, K.m.ib, K.m.hb, K.m.Lb, K.m.zc],
        en = !1,
        fn = !1,
        gn = {},
        hn = {};

    function jn() {
        !fn && en && (cn.some(function(a) {
            return sm.containerScopedDefaults[a] !== 1
        }) || kn("mbc"));
        fn = !0
    }

    function kn(a) {
        nl && (Sk(a, "1"), Xm())
    }

    function ln(a, b) {
        if (!gn[b] && (gn[b] = !0, hn[b]))
            for (var c = m(dn), d = c.next(); !d.done; d = c.next())
                if (O(a, d.value)) {
                    kn("erc");
                    break
                }
    };

    function mn(a) {
        vb("HEALTH", a)
    };
    var nn = {},
        on = !1;

    function pn() {
        function a() {
            c !== void 0 && Sm(Lm.Z.Oe, c);
            try {
                var e = Pm(Lm.Z.Oe);
                nn = JSON.parse(e)
            } catch (f) {
                Q(123), mn(2), nn = {}
            }
            on = !0;
            b()
        }
        var b = qn,
            c = void 0,
            d = Pm(Lm.Z.Oe);
        d ? a(d) : (c = Rm(Lm.Z.Oe, a), rn())
    }

    function rn() {
        function a(b) {
            Om(Lm.Z.Oe, b || "{}");
            Om(Lm.Z.Ti, !1)
        }
        if (!Pm(Lm.Z.Ti)) {
            Om(Lm.Z.Ti, !0);
            try {
                w.fetch("https://www.google.com/ccm/geo", {
                    method: "GET",
                    cache: "no-store",
                    mode: "cors",
                    credentials: "omit"
                }).then(function(b) {
                    b.ok ? b.text().then(function(c) {
                        a(c)
                    }, function() {
                        a()
                    }) : a()
                }, function() {
                    a()
                })
            } catch (b) {
                a()
            }
        }
    }

    function sn() {
        var a = E(22);
        try {
            return JSON.parse(tb(a))
        } catch (b) {
            return Q(123), mn(2), {}
        }
    }

    function tn() {
        return nn["0"] || ""
    }

    function un() {
        return nn["1"] || ""
    }

    function vn() {
        var a = !1;
        return a
    }

    function wn() {
        return nn["6"] !== !1
    }

    function xn() {
        var a = "";
        return a
    }

    function yn() {
        var a = "";
        return a
    };
    var zn = {},
        An = Object.freeze((zn[K.m.Vb] = 1, zn[K.m.fh] = 1, zn[K.m.wi] = 1, zn[K.m.yc] = 1, zn[K.m.wa] = 1, zn[K.m.Lb] = 1, zn[K.m.Cb] = 1, zn[K.m.Xb] = 1, zn[K.m.xd] = 1, zn[K.m.zc] = 1, zn[K.m.hb] = 1, zn[K.m.yd] = 1, zn[K.m.Be] = 1, zn[K.m.Ga] = 1, zn[K.m.xp] = 1, zn[K.m.De] = 1, zn[K.m.Ci] = 1, zn[K.m.sh] = 1, zn[K.m.Cd] = 1, zn[K.m.Lf] = 1, zn[K.m.Hp] = 1, zn[K.m.Db] = 1, zn[K.m.Qf] = 1, zn[K.m.Jp] = 1, zn[K.m.Dd] = 1, zn[K.m.Dl] = 1, zn[K.m.Sc] = 1, zn[K.m.Ac] = 1, zn[K.m.ib] = 1, zn[K.m.Ml] = 1, zn[K.m.Zb] = 1, zn[K.m.Gd] = 1, zn[K.m.Hd] = 1, zn[K.m.Id] = 1, zn[K.m.zh] = 1, zn[K.m.Ii] = 1, zn[K.m.Jd] =
            1, zn[K.m.Wc] = 1, zn[K.m.Nb] = 1, zn[K.m.Wl] = 1, zn[K.m.Ec] = 1, zn[K.m.Xc] = 1, zn[K.m.gj] = 1, zn));
    Object.freeze([K.m.za, K.m.Za, K.m.Mb, K.m.ob, K.m.Hi, K.m.Oa, K.m.Di, K.m.up]);
    var Bn = {},
        Cn = Object.freeze((Bn[K.m.Vo] = 1, Bn[K.m.Wo] = 1, Bn[K.m.Xo] = 1, Bn[K.m.Yo] = 1, Bn[K.m.Zo] = 1, Bn[K.m.ep] = 1, Bn[K.m.fp] = 1, Bn[K.m.hp] = 1, Bn[K.m.kp] = 1, Bn[K.m.qf] = 1, Bn)),
        Dn = {},
        En = Object.freeze((Dn[K.m.Xk] = 1, Dn[K.m.Yk] = 1, Dn[K.m.qe] = 1, Dn[K.m.se] = 1, Dn[K.m.Zk] = 1, Dn[K.m.sd] = 1, Dn[K.m.te] = 1, Dn[K.m.sc] = 1, Dn[K.m.Mc] = 1, Dn[K.m.uc] = 1, Dn[K.m.Ib] = 1, Dn[K.m.ue] = 1, Dn[K.m.vc] = 1, Dn[K.m.al] = 1, Dn)),
        Fn = Object.freeze([K.m.Vb, K.m.yf, K.m.yc, K.m.yd, K.m.Lf, K.m.Sf, K.m.Gd, K.m.Nb]),
        Gn = Object.freeze([].concat(Aa(Fn))),
        Hn = Object.freeze([K.m.Cb,
            K.m.sh, K.m.zh, K.m.Ii, K.m.qh
        ]),
        In = Object.freeze([].concat(Aa(Hn))),
        Jn = {},
        Kn = (Jn[K.m.X] = "1", Jn[K.m.la] = "2", Jn[K.m.aa] = "3", Jn[K.m.Ka] = "4", Jn),
        Ln = {},
        Mn = Object.freeze((Ln.search = "s", Ln.youtube = "y", Ln.playstore = "p", Ln.shopping = "h", Ln.ads = "a", Ln.maps = "m", Ln));

    function Nn(a) {
        return typeof a !== "object" || a === null ? {} : a
    }

    function On(a) {
        return a === void 0 || a === null ? "" : typeof a === "object" ? a.toString() : String(a)
    }

    function Pn(a) {
        if (a !== void 0 && a !== null) return On(a)
    };

    function Qn(a) {
        return a && a.indexOf("pending:") === 0 ? Rn(a.substr(8)) : !1
    }

    function Rn(a) {
        if (a == null || a.length === 0) return !1;
        var b = Number(a),
            c = Tb();
        return b < c + 3E5 && b > c - 9E5
    };
    var Sn = !1,
        Tn = !1,
        Un = !1,
        Vn = 0,
        Wn = !1,
        Xn = [];

    function Yn(a) {
        if (Vn === 0) Wn && Xn && (Xn.length >= 100 && Xn.shift(), Xn.push(a));
        else if (Zn()) {
            var b = E(41),
                c = Vc(b, []);
            c.length >= 50 && c.shift();
            c.push(a)
        }
    }

    function $n() {
        ao();
        id(A, "TAProdDebugSignal", $n)
    }

    function ao() {
        if (!Tn) {
            Tn = !0;
            bo();
            var a = Xn;
            Xn = void 0;
            a == null || a.forEach(function(b) {
                Yn(b)
            })
        }
    }

    function bo() {
        var a = A.documentElement.getAttribute("data-tag-assistant-prod-present");
        Rn(a) ? Vn = 1 : !Qn(a) || Sn || Un ? Vn = 2 : (Un = !0, hd(A, "TAProdDebugSignal", $n, !1), w.setTimeout(function() {
            ao();
            Sn = !0
        }, 200))
    }

    function Zn() {
        if (!Wn) return !1;
        switch (Vn) {
            case 1:
            case 0:
                return !0;
            case 2:
                return !1;
            default:
                return !1
        }
    };
    var co = !1;

    function eo(a, b) {
        var c = xk(),
            d = uk();
        E(26);
        var e = xg(47) ? 0 : xg(50) ? 1 : 3,
            f = Yj();
        if (Zn()) {
            var g = fo("INIT");
            g.containerLoadSource = a != null ? a : 0;
            b && (g.parentTargetReference = b);
            g.aliases = c;
            g.destinations = d;
            e !== void 0 && (g.gtg = {
                source: e,
                mPath: f != null ? f : ""
            });
            Yn(g)
        }
    }

    function go(a) {
        var b, c, d, e;
        b = a.targetId;
        c = a.request;
        d = a.cb;
        e = a.isBatched;
        var f;
        if (f = Zn()) {
            var g;
            a: switch (c.endpoint) {
                case 68:
                case 69:
                case 19:
                case 47:
                    g = !0;
                    break a;
                default:
                    g = !1
            }
            f = !g
        }
        if (f) {
            var h = fo("GTAG_HIT", {
                eventId: d.eventId,
                priorityId: d.priorityId
            });
            h.target = b;
            h.url = c.url;
            c.postBody && (h.postBody = c.postBody);
            h.parameterEncoding = c.parameterEncoding;
            h.endpoint = c.endpoint;
            e !== void 0 && (h.isBatched = e);
            Yn(h)
        }
    }

    function ho(a) {
        Zn() && go(a())
    }

    function fo(a, b) {
        b = b === void 0 ? {} : b;
        b.groupId = io;
        var c, d = b,
            e = jo,
            f = {
                publicId: ko
            };
        d.eventId != null && (f.eventId = d.eventId);
        d.priorityId != null && (f.priorityId = d.priorityId);
        d.eventName && (f.eventName = d.eventName);
        d.groupId && (f.groupId = d.groupId);
        d.tagName && (f.tagName = d.tagName);
        c = {
            containerProduct: "GTM",
            key: f,
            version: e,
            messageType: a
        };
        c.containerProduct = co ? "OGT" : "GTM";
        c.key.targetRef = lo;
        return c
    }
    var ko = "",
        jo = "",
        lo = {
            ctid: "",
            isDestination: !1
        },
        io;

    function mo(a) {
        var b = E(5),
            c = tk(),
            d = E(6),
            e = E(1);
        E(23);
        Vn = 0;
        Wn = !0;
        bo();
        io = a;
        ko = b;
        jo = e;
        co = Bj;
        lo = {
            ctid: b,
            isDestination: c,
            canonicalId: d
        }
    };
    var no = [K.m.X, K.m.la, K.m.aa, K.m.Ka],
        oo, po;

    function qo(a) {
        var b = a[K.m.rc];
        b || (b = [""]);
        for (var c = {
                Fg: 0
            }; c.Fg < b.length; c = {
                Fg: c.Fg
            }, ++c.Fg) Lb(a, function(d) {
            return function(e, f) {
                if (e !== K.m.rc) {
                    var g = On(f),
                        h = b[d.Fg],
                        l = tn(),
                        n = un();
                    qm = !0;
                    pm && vb("TAGGING", 20);
                    lm().declare(e, g, h, l, n)
                }
            }
        }(c))
    }

    function ro(a) {
        jn();
        !po && oo && kn("crc");
        po = !0;
        var b = a[K.m.Yg];
        b && Q(41);
        var c = a[K.m.rc];
        c ? Q(40) : c = [""];
        for (var d = {
                Gg: 0
            }; d.Gg < c.length; d = {
                Gg: d.Gg
            }, ++d.Gg) Lb(a, function(e) {
            return function(f, g) {
                if (f !== K.m.rc && f !== K.m.Yg) {
                    var h = Pn(g),
                        l = c[e.Gg],
                        n = Number(b),
                        p = tn(),
                        q = un();
                    n = n === void 0 ? 0 : n;
                    pm = !0;
                    qm && vb("TAGGING", 20);
                    lm().default(f, h, l, p, q, n, sm)
                }
            }
        }(d))
    }

    function so(a) {
        sm.usedContainerScopedDefaults = !0;
        var b = a[K.m.rc];
        if (b) {
            var c = Array.isArray(b) ? b : [b];
            if (!c.includes(un()) && !c.includes(tn())) return
        }
        Lb(a, function(d, e) {
            switch (d) {
                case "ad_storage":
                case "analytics_storage":
                case "ad_user_data":
                case "ad_personalization":
                    break;
                default:
                    return
            }
            sm.usedContainerScopedDefaults = !0;
            sm.containerScopedDefaults[d] = e === "granted" ? 3 : 2
        })
    }

    function to(a, b) {
        jn();
        oo = !0;
        Lb(a, function(c, d) {
            var e = On(d);
            pm = !0;
            qm && vb("TAGGING", 20);
            lm().update(c, e, sm)
        });
        ym(b.eventId, b.priorityId)
    }

    function uo(a) {
        a.hasOwnProperty("all") && (sm.selectedAllCorePlatformServices = !0, Lb(Mn, function(b) {
            sm.corePlatformServices[b] = a.all === "granted";
            sm.usedCorePlatformServices = !0
        }));
        Lb(a, function(b, c) {
            b !== "all" && (sm.corePlatformServices[b] = c === "granted", sm.usedCorePlatformServices = !0)
        })
    }

    function vo(a) {
        Array.isArray(a) || (a = [a]);
        return a.every(function(b) {
            return tm(b)
        })
    }

    function wo() {
        var a = xo;
        Array.isArray(a) || (a = [a]);
        return a.some(function(b) {
            return tm(b)
        })
    }

    function yo(a, b) {
        xm(a, b)
    }

    function zo(a, b) {
        Am(a, b)
    }

    function Ao(a, b) {
        zm(a, b)
    }

    function Bo() {
        var a = [K.m.X, K.m.Ka, K.m.aa];
        lm().waitForUpdate(a, 500, sm)
    }

    function Co(a) {
        for (var b = m(a), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            lm().clearTimeout(d, void 0, sm)
        }
        ym()
    }

    function Do() {
        if (!Cj)
            for (var a = wn() ? Eo(Ag(5)) : Eo(Ag(4)), b = 0; b < no.length; b++) {
                var c = no[b],
                    d = c,
                    e = a[c] ? "granted" : "denied";
                lm().implicit(d, e)
            }
    }

    function Eo(a) {
        for (var b = {}, c = m(a.split("|")), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return b
    };
    var S = {
        C: {
            ji: "accept_by_default",
            rk: "add_tag_timing",
            ne: "ads_event_page_view",
            ki: "ads_hit_param_overrides",
            md: "allow_ad_personalization",
            et: "auto_event",
            zk: "batch_on_navigation",
            Ak: "biscotti_join_id",
            Dk: "client_id_source",
            lf: "consent_event_id",
            nf: "consent_priority_id",
            ht: "consent_state",
            ka: "consent_updated",
            pd: "conversion_linker_enabled",
            ya: "cookie_options",
            rd: "create_dc_join",
            ah: "create_fpm_geo_join",
            bh: "create_fpm_signals_join",
            pe: "create_google_join",
            Sk: "dc_random",
            Lc: "em_event",
            rt: "endpoint_for_debug",
            Wk: "enhanced_client_id_source",
            Uo: "enhanced_match_result",
            Zl: "euid_logged_in_state",
            Ke: "euid_mode_enabled",
            qb: "event_start_timestamp_ms",
            fm: "event_usage",
            Ni: "extra_tag_experiment_ids",
            Ft: "add_parameter",
            Oi: "attribution_reporting_experiment",
            Pi: "counting_method",
            Fh: "send_as_iframe",
            Gt: "parameter_order",
            hg: "parsed_target",
            bq: "ga4_collection_subdomain",
            Qi: "ga4_request_flags",
            Am: "gbraid_cookie_marked",
            rb: "handle_internally",
            Jt: "has_ga_conversion_consents",
            da: "hit_type",
            ac: "hit_type_override",
            Ne: "ignore_hit_success_failure",
            du: "is_config_command",
            Hh: "is_consent_update",
            ig: "is_conversion",
            Gm: "is_ecommerce",
            Hm: "is_ec_cm_split",
            Fc: "is_external_event",
            Vi: "is_fallback_aw_conversion_ping_allowed",
            jg: "is_first_visit",
            Im: "is_first_visit_conversion",
            Ih: "is_fl_fallback_conversion_flow_allowed",
            Nd: "is_fpm_encryption",
            Wi: "is_fpm_split",
            Pa: "is_gcp_conversion",
            kg: "is_google_signals_allowed",
            Jh: "is_google_signals_enabled",
            Od: "is_merchant_center",
            Kh: "is_new_to_site",
            Pd: "is_personalization",
            Km: "is_server_side_destination",
            Pe: "is_session_start",
            Lm: "is_session_start_conversion",
            eu: "is_sgtm_ga_ads_conversion_study_control_group",
            fu: "is_sgtm_prehit",
            Mm: "is_sgtm_service_worker",
            lg: "is_split_conversion",
            jq: "is_syn",
            mg: "is_test_event",
            ng: "join_id",
            Xi: "join_elapsed",
            og: "join_timer_sec",
            Om: "local_storage_aw_conversion_counters",
            Ue: "tunnel_updated",
            ju: "prehit_for_retry",
            lu: "promises",
            mu: "record_aw_latency",
            bd: "redact_ads_data",
            Ve: "redact_click_ids",
            Xm: "remarketing_only",
            dj: "send_ccm_parallel_ping",
            ou: "send_ccm_parallel_test_ping",
            rg: "send_to_destinations",
            ej: "send_to_targets",
            Zm: "send_user_data_hit",
            Oh: "shw_rnd",
            Ua: "source_canonical_id",
            Ia: "speculative",
            mn: "speculative_in_message",
            pn: "suppress_script_load",
            qn: "syn_or_mod",
            oj: "transient_ecsid",
            sg: "transmission_type",
            Qa: "user_data",
            ru: "user_data_from_automatic",
            su: "user_data_from_automatic_getter",
            un: "user_data_from_code",
            Fq: "user_data_from_manual",
            tu: "user_data_mode",
            ug: "user_id_updated"
        }
    };

    function Fo(a) {
        var b = a.location.href;
        if (a === a.top) return {
            url: b,
            Xr: !0
        };
        var c = !1,
            d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        var e = a.location.ancestorOrigins;
        if (e) {
            var f = e[e.length - 1],
                g;
            f && ((g = b) == null ? void 0 : g.indexOf(f)) === -1 && (c = !1, b = f)
        }
        return {
            url: b,
            Xr: c
        }
    }

    function Go(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Ol(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    }

    function Ho() {
        for (var a = w, b = a; a && a != a.parent;) a = a.parent, Go(a) && (b = a);
        return b
    };
    var Io = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        Jo = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };

    function Ko(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Lo(a) {
        var b = Qa.apply(1, arguments);
        if (b.length === 0) return pc(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return pc(c)
    };
    var Mo = function(a, b) {
            for (var c = a, d = 0; d < 50; ++d) {
                var e;
                try {
                    e = !(!c.frames || !c.frames[b])
                } catch (h) {
                    e = !1
                }
                if (e) return c;
                var f;
                a: {
                    try {
                        var g = c.parent;
                        if (g && g != c) {
                            f = g;
                            break a
                        }
                    } catch (h) {}
                    f = null
                }
                if (!(c = f)) break
            }
            return null
        },
        No = function(a) {
            var b = w;
            if (b.top == b) return 0;
            if (a === void 0 ? 0 : a) {
                var c = b.location.ancestorOrigins;
                if (c) return c[c.length - 1] == b.location.origin ? 1 : 2
            }
            return Go(b.top) ? 1 : 2
        },
        Oo = function(a, b) {
            b = b === void 0 ? document : b;
            return b.createElement(String(a).toLowerCase())
        };
    var Po;

    function Qo() {
        function a(g) {
            c(g.target || g.srcElement || {})
        }

        function b(g) {
            d(g.target || g.srcElement || {})
        }
        var c = Ro,
            d = So,
            e = To();
        if (!e.init) {
            hd(A, "mousedown", a);
            hd(A, "keyup", a);
            hd(A, "submit", b);
            var f = HTMLFormElement.prototype.submit;
            HTMLFormElement.prototype.submit = function() {
                d(this);
                f.call(this)
            };
            e.init = !0
        }
    }

    function Uo(a, b, c, d, e) {
        var f = {
            callback: a,
            domains: b,
            fragment: c === 2,
            placement: c,
            forms: d,
            sameHost: e
        };
        To().decorators.push(f)
    }

    function Vo(a, b, c) {
        for (var d = To().decorators, e = {}, f = 0; f < d.length; ++f) {
            var g = d[f],
                h;
            if (h = !c || g.forms) a: {
                var l = g.domains,
                    n = a,
                    p = !!g.sameHost;
                if (l && (p || n !== A.location.hostname))
                    for (var q = 0; q < l.length; q++)
                        if (l[q] instanceof RegExp) {
                            if (l[q].test(n)) {
                                h = !0;
                                break a
                            }
                        } else if (n.indexOf(l[q]) >= 0 || p && l[q].indexOf(n) >= 0) {
                    h = !0;
                    break a
                }
                h = !1
            }
            if (h) {
                var r = g.placement;
                r === void 0 && (r = g.fragment ? 2 : 1);
                r === b && Wb(e, g.callback())
            }
        }
        return e
    }

    function To() {
        var a = Vc("google_tag_data", {}),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var Wo = /(.*?)\*(.*?)\*(.*)/,
        Xo = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        Yo = /^(?:www\.|m\.|amp\.)+/,
        Zo = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function $o(a) {
        var b = Zo.exec(a);
        if (b) return {
            Yj: b[1],
            query: b[2],
            fragment: b[3]
        }
    }

    function ap(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }

    function bp(a, b) {
        var c = [Rc.userAgent, (new Date).getTimezoneOffset(), Rc.userLanguage || Rc.language, Math.floor(Tb() / 60 / 1E3) - (b === void 0 ? 0 : b), a].join("*"),
            d;
        if (!(d = Po)) {
            for (var e = Array(256), f = 0; f < 256; f++) {
                for (var g = f, h = 0; h < 8; h++) g = g & 1 ? g >>> 1 ^ 3988292384 : g >>> 1;
                e[f] = g
            }
            d = e
        }
        Po = d;
        for (var l = 4294967295, n = 0; n < c.length; n++) l = l >>> 8 ^ Po[(l ^ c.charCodeAt(n)) & 255];
        return ((l ^ -1) >>> 0).toString(36)
    }

    function cp(a) {
        return function(b) {
            var c = Sj(w.location.href),
                d = c.search.replace("?", ""),
                e = Jj(d, "_gl", !1, !0) || "";
            b.query = dp(e) || {};
            var f = Mj(c, "fragment"),
                g;
            var h = -1;
            if (Yb(f, "_gl=")) h = 4;
            else {
                var l = f.indexOf("&_gl=");
                l > 0 && (h = l + 3 + 2)
            }
            if (h < 0) g = void 0;
            else {
                var n = f.indexOf("&", h);
                g = n < 0 ? f.substring(h) : f.substring(h, n)
            }
            b.fragment = dp(g || "") || {};
            a && ep(c, d, f)
        }
    }

    function lp(a, b) {
        var c = ap(a).exec(b),
            d = b;
        if (c) {
            var e = c[2],
                f = c[4];
            d = c[1];
            f && (d = d + e + f)
        }
        return d
    }

    function ep(a, b, c) {
        function d(g, h) {
            var l = lp("_gl", g);
            l.length && (l = h + l);
            return l
        }
        if (Qc && Qc.replaceState) {
            var e = ap("_gl");
            if (e.test(b) || e.test(c)) {
                var f = Mj(a, "path");
                b = d(b, "?");
                c = d(c, "#");
                Qc.replaceState({}, "", "" + f + b + c)
            }
        }
    }

    function mp(a, b) {
        var c = cp(!!b),
            d = To();
        d.data || (d.data = {
            query: {},
            fragment: {}
        }, c(d.data));
        var e = {},
            f = d.data;
        f && (Wb(e, f.query), a && Wb(e, f.fragment));
        return e
    }
    var dp = function(a) {
        try {
            var b = np(a, 3);
            if (b !== void 0) {
                for (var c = {}, d = b ? b.split("*") : [], e = 0; e + 1 < d.length; e += 2) {
                    var f = d[e],
                        g = tb(d[e + 1]);
                    c[f] = g
                }
                vb("TAGGING", 6);
                return c
            }
        } catch (h) {
            vb("TAGGING", 8)
        }
    };

    function np(a, b) {
        if (a) {
            var c;
            a: {
                for (var d = a, e = 0; e < 3; ++e) {
                    var f = Wo.exec(d);
                    if (f) {
                        c = f;
                        break a
                    }
                    d = Lj(d) || ""
                }
                c = void 0
            }
            var g = c;
            if (g && g[1] === "1") {
                var h = g[3],
                    l;
                a: {
                    for (var n = g[2], p = 0; p < b; ++p)
                        if (n === bp(h, p)) {
                            l = !0;
                            break a
                        }
                    l = !1
                }
                if (l) return h;
                vb("TAGGING", 7)
            }
        }
    }

    function op(a, b, c, d, e) {
        function f(p) {
            p = lp(a, p);
            var q = p.charAt(p.length - 1);
            p && q !== "&" && (p += "&");
            return p + n
        }
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var g = $o(c);
        if (!g) return "";
        var h = g.query || "",
            l = g.fragment || "",
            n = a + "=" + b;
        d ? l.substring(1).length !== 0 && e || (l = "#" + f(l.substring(1))) : h = "?" + f(h.substring(1));
        return "" + g.Yj + h + l
    }

    function pp(a, b) {
        function c(n, p, q) {
            var r;
            a: {
                for (var t in n)
                    if (n.hasOwnProperty(t)) {
                        r = !0;
                        break a
                    }
                r = !1
            }
            if (r) {
                var u, v = [],
                    x;
                for (x in n)
                    if (n.hasOwnProperty(x)) {
                        var y = n[x];
                        y !== void 0 && y === y && y !== null && y.toString() !== "[object Object]" && (v.push(x), v.push(sb(String(y))))
                    }
                var z = v.join("*");
                u = ["1", bp(z), z].join("*");
                d ? (ib(3) || ib(1) || !p) && qp("_gl", u, a, p, q) : rp("_gl", u, a, p, q)
            }
        }
        var d = (a.tagName || "").toUpperCase() === "FORM",
            e = Vo(b, 1, d),
            f = Vo(b, 2, d),
            g = Vo(b, 4, d),
            h = Vo(b, 3, d);
        c(e, !1, !1);
        c(f, !0, !1);
        ib(1) && c(g, !0, !0);
        for (var l in h) h.hasOwnProperty(l) &&
            sp(l, h[l], a)
    }

    function sp(a, b, c) {
        c.tagName.toLowerCase() === "a" ? rp(a, b, c) : c.tagName.toLowerCase() === "form" && qp(a, b, c)
    }

    function rp(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var f;
        if (f = c.href) {
            var g;
            if (!(g = !ib(4) || d)) {
                var h = w.location.href,
                    l = $o(c.href),
                    n = $o(h);
                g = !(l && n && l.Yj === n.Yj && l.query === n.query && l.fragment)
            }
            f = g
        }
        if (f) {
            var p = op(a, b, c.href, d, e);
            Cc.test(p) && (c.href = p)
        }
    }

    function qp(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        if (c) {
            var f = c.getAttribute("action") || "";
            if (f) {
                var g = (c.method || "").toLowerCase();
                if (g !== "get" || d) {
                    if (g === "get" || g === "post") {
                        var h = op(a, b, f, d, e);
                        Cc.test(h) && (c.action = h)
                    }
                } else {
                    for (var l = c.childNodes || [], n = !1, p = 0; p < l.length; p++) {
                        var q = l[p];
                        if (q.name === a) {
                            q.setAttribute("value", b);
                            n = !0;
                            break
                        }
                    }
                    if (!n) {
                        var r = A.createElement("input");
                        r.setAttribute("type", "hidden");
                        r.setAttribute("name", a);
                        r.setAttribute("value", b);
                        c.appendChild(r)
                    }
                }
            }
        }
    }

    function Ro(a) {
        try {
            var b;
            a: {
                for (var c = a, d = 100; c && d > 0;) {
                    if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                        b = c;
                        break a
                    }
                    c = c.parentNode;
                    d--
                }
                b = null
            }
            var e = b;
            if (e) {
                var f = e.protocol;
                f !== "http:" && f !== "https:" || pp(e, e.hostname)
            }
        } catch (g) {}
    }

    function So(a) {
        try {
            var b = a.getAttribute("action");
            if (b) {
                var c = Mj(Sj(b), "host");
                pp(a, c)
            }
        } catch (d) {}
    }

    function tp(a, b, c, d) {
        Qo();
        var e = c === "fragment" ? 2 : 1;
        d = !!d;
        Uo(a, b, e, d, !1);
        e === 2 && vb("TAGGING", 23);
        d && vb("TAGGING", 24)
    }

    function up(a, b) {
        Qo();
        Uo(a, [Oj(w.location, "host", !0)], b, !0, !0)
    }

    function vp() {
        var a = A.location.hostname,
            b = Xo.exec(A.referrer);
        if (!b) return !1;
        var c = b[2],
            d = b[1],
            e = "";
        if (c) {
            var f = c.split("/"),
                g = f[1];
            e = g === "s" ? Lj(f[2]) || "" : Lj(g) || ""
        } else if (d) {
            if (d.indexOf("xn--") === 0) return !1;
            e = d.replace(/-/g, ".").replace(/\.\./g, "-")
        }
        var h = a.replace(Yo, ""),
            l = e.replace(Yo, "");
        return h === l || Zb(h, "." + l)
    }

    function wp(a, b) {
        return a === !1 ? !1 : a || b || vp()
    };

    function xp(a) {
        for (var b = [], c = A.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                ke: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return b
    }

    function yp(a, b) {
        var c = xp(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!(f[0] !== "1" || b && f.length < 3 || !b && f.length !== 3) && Number(f[1])) {
                d[c[e].ke] || (d[c[e].ke] = []);
                var g = {
                    version: f[0],
                    timestamp: Number(f[1]) * 1E3,
                    gclid: f[2]
                };
                b && f.length > 3 && (g.labels = f.slice(3));
                d[c[e].ke].push(g)
            }
        }
        return d
    };

    function zp(a) {
        return a.origin !== "null"
    };
    var Ap = {},
        Bp = (Ap.k = {
            ja: /^[\w-]+$/
        }, Ap.b = {
            ja: /^[\w-]+$/,
            ek: !0
        }, Ap.i = {
            ja: /^[1-9]\d*$/
        }, Ap.h = {
            ja: /^\d+$/
        }, Ap.t = {
            ja: /^[1-9]\d*$/
        }, Ap.d = {
            ja: /^[A-Za-z0-9_-]+$/
        }, Ap.j = {
            ja: /^\d+$/
        }, Ap.u = {
            ja: /^[1-9]\d*$/
        }, Ap.l = {
            ja: /^[01]$/
        }, Ap.o = {
            ja: /^[1-9]\d*$/
        }, Ap.g = {
            ja: /^[01]$/
        }, Ap.s = {
            ja: /^.+$/
        }, Ap);
    var Cp = {},
        Gp = (Cp[5] = {
            ii: {
                2: Dp
            },
            Qj: "2",
            Sh: ["k", "i", "b", "u"]
        }, Cp[4] = {
            ii: {
                2: Dp,
                GCL: Ep
            },
            Qj: "2",
            Sh: ["k", "i", "b"]
        }, Cp[2] = {
            ii: {
                GS2: Dp,
                GS1: Fp
            },
            Qj: "GS2",
            Sh: "sogtjlhd".split("")
        }, Cp);

    function Hp(a, b, c) {
        var d = Gp[b];
        if (d) {
            var e = a.split(".")[0];
            c == null || c(e);
            if (e) {
                var f = d.ii[e];
                if (f) return f(a, b)
            }
        }
    }

    function Dp(a, b) {
        var c = a.split(".");
        if (c.length === 3) {
            var d = c[2];
            if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1) try {
                d = decodeURIComponent(d)
            } catch (t) {}
            var e = {},
                f = Gp[b];
            if (f) {
                for (var g = f.Sh, h = m(d.split("$")), l = h.next(); !l.done; l = h.next()) {
                    var n = l.value,
                        p = n[0];
                    if (g.indexOf(p) !== -1) try {
                        var q = decodeURIComponent(n.substring(1)),
                            r = Bp[p];
                        r && (r.ek ? (e[p] = e[p] || [], e[p].push(q)) : e[p] = q)
                    } catch (t) {}
                }
                return e
            }
        }
    }

    function Ip(a, b, c) {
        var d = Gp[b];
        if (d) return [d.Qj, c || "1", Jp(a, b)].join(".")
    }

    function Jp(a, b) {
        var c = Gp[b];
        if (c) {
            for (var d = [], e = m(c.Sh), f = e.next(); !f.done; f = e.next()) {
                var g = f.value,
                    h = Bp[g];
                if (h) {
                    var l = a[g];
                    if (l !== void 0)
                        if (h.ek && Array.isArray(l))
                            for (var n = m(l), p = n.next(); !p.done; p = n.next()) d.push(encodeURIComponent("" + g + p.value));
                        else d.push(encodeURIComponent("" + g + l))
                }
            }
            return d.join("$")
        }
    }

    function Ep(a) {
        var b = a.split(".");
        b.shift();
        var c = b.shift(),
            d = b.shift(),
            e = {};
        return e.k = d, e.i = c, e.b = b, e
    }

    function Fp(a) {
        var b = a.split(".").slice(2);
        if (!(b.length < 5 || b.length > 7)) {
            var c = {};
            return c.s = b[0], c.o = b[1], c.g = b[2], c.t = b[3], c.j = b[4], c.l = b[5], c.h = b[6], c
        }
    };
    var Kp = {
        R: {
            yq: 0,
            tk: 1,
            Zg: 2,
            Gk: 3,
            oi: 4,
            Ek: 5,
            Fk: 6,
            Hk: 7,
            ri: 8,
            bm: 9,
            am: 10,
            Mi: 11,
            dm: 12,
            Dh: 13,
            qm: 14,
            pg: 15,
            uq: 16,
            We: 17,
            kj: 18,
            lj: 19,
            mj: 20,
            rn: 21,
            nj: 22,
            ui: 23,
            Qk: 24
        }
    };
    Kp.R[Kp.R.yq] = "RESERVED_ZERO";
    Kp.R[Kp.R.tk] = "ADS_CONVERSION_HIT";
    Kp.R[Kp.R.Zg] = "CONTAINER_EXECUTE_START";
    Kp.R[Kp.R.Gk] = "CONTAINER_SETUP_END";
    Kp.R[Kp.R.oi] = "CONTAINER_SETUP_START";
    Kp.R[Kp.R.Ek] = "CONTAINER_BLOCKING_END";
    Kp.R[Kp.R.Fk] = "CONTAINER_EXECUTE_END";
    Kp.R[Kp.R.Hk] = "CONTAINER_YIELD_END";
    Kp.R[Kp.R.ri] = "CONTAINER_YIELD_START";
    Kp.R[Kp.R.bm] = "EVENT_EXECUTE_END";
    Kp.R[Kp.R.am] = "EVENT_EVALUATION_END";
    Kp.R[Kp.R.Mi] = "EVENT_EVALUATION_START";
    Kp.R[Kp.R.dm] = "EVENT_SETUP_END";
    Kp.R[Kp.R.Dh] = "EVENT_SETUP_START";
    Kp.R[Kp.R.qm] = "GA4_CONVERSION_HIT";
    Kp.R[Kp.R.pg] = "PAGE_LOAD";
    Kp.R[Kp.R.uq] = "PAGEVIEW";
    Kp.R[Kp.R.We] = "SNIPPET_LOAD";
    Kp.R[Kp.R.kj] = "TAG_CALLBACK_ERROR";
    Kp.R[Kp.R.lj] = "TAG_CALLBACK_FAILURE";
    Kp.R[Kp.R.mj] = "TAG_CALLBACK_SUCCESS";
    Kp.R[Kp.R.rn] = "TAG_EXECUTE_END";
    Kp.R[Kp.R.nj] = "TAG_EXECUTE_START";
    Kp.R[Kp.R.ui] = "CUSTOM_PERFORMANCE_START";
    Kp.R[Kp.R.Qk] = "CUSTOM_PERFORMANCE_END";
    var Lp = [],
        Mp = {},
        Np = {};

    function Op(a) {
        if (ib(19) && Lp.includes(a)) {
            var b;
            (b = xd()) == null || b.mark(a + "-" + Kp.R.ui + "-" + (Np[a] || 0))
        }
    }

    function Pp(a) {
        if (ib(19) && Lp.includes(a)) {
            var b = a + "-" + Kp.R.Qk + "-" + (Np[a] || 0),
                c = {
                    start: a + "-" + Kp.R.ui + "-" + (Np[a] || 0),
                    end: b
                },
                d;
            (d = xd()) == null || d.mark(b);
            var e, f, g = (f = (e = xd()) == null ? void 0 : e.measure(b, c)) == null ? void 0 : f.duration;
            g !== void 0 && (Np[a] = (Np[a] || 0) + 1, Mp[a] = g + (Mp[a] || 0))
        }
    };
    var Qp = ["3", "4"];

    function Rp(a, b, c, d) {
        try {
            Op("3");
            var e;
            return (e = Sp(function(f) {
                return f === a
            }, b, c, d)[a]) != null ? e : []
        } finally {
            Pp("3")
        }
    }

    function Sp(a, b, c, d) {
        var e;
        if (Tp(d)) {
            for (var f = {}, g = String(b || Up()).split(";"), h = 0; h < g.length; h++) {
                var l = g[h].split("="),
                    n = l[0].trim();
                if (n && a(n)) {
                    var p = l.slice(1).join("=").trim();
                    p && c && (p = decodeURIComponent(p));
                    var q = void 0,
                        r = void 0;
                    ((q = f)[r = n] || (q[r] = [])).push(p)
                }
            }
            e = f
        } else e = {};
        return e
    }

    function Vp(a, b, c, d, e) {
        if (Tp(e)) {
            var f = Wp(a, d, e);
            if (f.length === 1) return f[0];
            if (f.length !== 0) {
                f = Xp(f, function(g) {
                    return g.ir
                }, b);
                if (f.length === 1) return f[0];
                f = Xp(f, function(g) {
                    return g.rs
                }, c);
                return f[0]
            }
        }
    }

    function Yp(a, b, c, d) {
        var e = Up(),
            f = window;
        zp(f) && (f.document.cookie = a);
        var g = Up();
        return e !== g || c !== void 0 && Rp(b, g, !1, d).indexOf(c) >= 0
    }

    function Zp(a, b, c, d) {
        function e(x, y, z) {
            if (z == null) return delete h[y], x;
            h[y] = z;
            return x + "; " + y + "=" + z
        }

        function f(x, y) {
            if (y == null) return x;
            h[y] = !0;
            return x + "; " + y
        }
        if (!Tp(c.Kc)) return 2;
        var g;
        b == null ? g = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = $p(b), g = a + "=" + b);
        var h = {};
        g = e(g, "path", c.path);
        var l;
        c.expires instanceof Date ? l = c.expires.toUTCString() : c.expires != null && (l = "" + c.expires);
        g = e(g, "expires", l);
        g = e(g, "max-age", c.es);
        g = e(g, "samesite", c.Is);
        c.secure &&
            (g = f(g, "secure"));
        var n = c.domain;
        if (n && n.toLowerCase() === "auto") {
            for (var p = aq(), q = void 0, r = !1, t = 0; t < p.length; ++t) {
                var u = p[t] !== "none" ? p[t] : void 0,
                    v = e(g, "domain", u);
                v = f(v, c.flags);
                try {
                    d && d(a, h)
                } catch (x) {
                    q = x;
                    continue
                }
                r = !0;
                if (!bq(u, c.path) && Yp(v, a, b, c.Kc)) return 0
            }
            if (q && !r) throw q;
            return 1
        }
        n && n.toLowerCase() !== "none" && (g = e(g, "domain", n));
        g = f(g, c.flags);
        d && d(a, h);
        return bq(n, c.path) ? 1 : Yp(g, a, b, c.Kc) ? 0 : 1
    }

    function cq(a, b, c) {
        c.path == null && (c.path = "/");
        c.domain || (c.domain = "auto");
        Op("2");
        var d = Zp(a, b, c);
        Pp("2");
        return d
    }

    function Xp(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var h = a[g],
                l = b(h);
            l === c ? d.push(h) : f === void 0 || l < f ? (e = [h], f = l) : l === f && e.push(h)
        }
        return d.length > 0 ? d : e
    }

    function Wp(a, b, c) {
        for (var d = [], e = Rp(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var g = e[f].split("."),
                h = g.shift();
            if (!b || !h || b.indexOf(h) !== -1) {
                var l = g.shift();
                if (l) {
                    var n = l.split("-");
                    d.push({
                        Wq: e[f],
                        Xq: g.join("."),
                        ir: Number(n[0]) || 1,
                        rs: Number(n[1]) || 1
                    })
                }
            }
        }
        return d
    }

    function $p(a) {
        a && a.length > 1200 && (a = a.substring(0, 1200));
        return a
    }
    var dq = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        eq = /(^|\.)doubleclick\.net$/i;

    function bq(a, b) {
        return a !== void 0 && (eq.test(window.document.location.hostname) || b === "/" && dq.test(a))
    }

    function fq(a) {
        if (!a) return 1;
        var b = a;
        ib(5) && a === "none" && (b = window.document.location.hostname);
        b = b.indexOf(".") === 0 ? b.substring(1) : b;
        return b.split(".").length
    }

    function gq(a) {
        if (!a || a === "/") return 1;
        a[0] !== "/" && (a = "/" + a);
        a[a.length - 1] !== "/" && (a += "/");
        return a.split("/").length - 1
    }

    function hq(a, b) {
        var c = "" + fq(a),
            d = gq(b);
        d > 1 && (c += "-" + d);
        return c
    }
    var Up = function() {
            return zp(window) ? window.document.cookie : ""
        },
        Tp = function(a) {
            return a && ib(6) ? (Array.isArray(a) ? a : [a]).every(function(b) {
                return vm(b) && tm(b)
            }) : !0
        },
        aq = function() {
            var a = [],
                b = window.document.location.hostname.split(".");
            if (b.length === 4) {
                var c = b[b.length - 1];
                if (Number(c).toString() === c) return ["none"]
            }
            for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
            var e = window.document.location.hostname;
            eq.test(e) || dq.test(e) || a.push("none");
            return a
        };

    function iq(a, b, c, d) {
        var e, f = Number(a.hd != null ? a.hd : void 0);
        f !== 0 && (e = new Date((b || Tb()) + 1E3 * (f || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: e,
            Kc: d
        }
    };
    var jq = new Map([
        [5, "ad_storage"],
        [4, ["ad_storage", "ad_user_data"]],
        [2, "analytics_storage"]
    ]);

    function kq(a, b, c) {
        if (Gp[b]) {
            for (var d = [], e = Rp(a, void 0, void 0, jq.get(b)), f = m(e), g = f.next(); !g.done; g = f.next()) {
                var h = Hp(g.value, b, c);
                h && d.push(lq(h))
            }
            return d
        }
    }

    function mq(a) {
        var b = nq;
        if (Gp[2]) {
            for (var c = {}, d = Sp(a, void 0, void 0, jq.get(2)), e = Object.keys(d).sort(), f = m(e), g = f.next(); !g.done; g = f.next())
                for (var h = g.value, l = m(d[h]), n = l.next(); !n.done; n = l.next()) {
                    var p = Hp(n.value, 2, b);
                    p && (c[h] || (c[h] = []), c[h].push(lq(p)))
                }
            return c
        }
    }

    function oq(a, b, c, d, e) {
        d = d || {};
        var f = hq(d.domain, d.path),
            g = Ip(b, c, f);
        if (!g) return 1;
        var h = iq(d, e, void 0, jq.get(c));
        return cq(a, g, h)
    }

    function pq(a, b) {
        var c = b.ja;
        return typeof c === "function" ? c(a) : c.test(a)
    }

    function lq(a) {
        for (var b = m(Object.keys(a)), c = b.next(), d = {}; !c.done; d = {
                yg: void 0
            }, c = b.next()) {
            var e = c.value,
                f = a[e];
            d.yg = Bp[e];
            d.yg ? d.yg.ek ? a[e] = Array.isArray(f) ? f.filter(function(g) {
                return function(h) {
                    return pq(h, g.yg)
                }
            }(d)) : void 0 : typeof f === "string" && pq(f, d.yg) || (a[e] = void 0) : a[e] = void 0
        }
        return a
    };
    var qq = function(a) {
        this.value = 0;
        this.value = a === void 0 ? 0 : a
    };
    qq.prototype.set = function(a) {
        return this.value |= 1 << a
    };
    var rq = function(a, b) {
        b <= 0 || (a.value |= 1 << b - 1)
    };
    qq.prototype.get = function() {
        return this.value
    };
    qq.prototype.clear = function(a) {
        this.value &= ~(1 << a)
    };
    qq.prototype.clearAll = function() {
        this.value = 0
    };
    qq.prototype.equals = function(a) {
        return this.value === a.value
    };

    function sq(a) {
        if (a) try {
            return new Uint8Array(atob(a.replace(/-/g, "+").replace(/_/g, "/")).split("").map(function(b) {
                return b.charCodeAt(0)
            }))
        } catch (b) {}
    }

    function tq(a, b) {
        var c = 0,
            d = 0,
            e, f = b;
        do {
            if (f >= a.length) return;
            e = a[f++];
            c |= (e & 127) << d;
            d += 7
        } while (e & 128);
        return [c, f]
    };

    function uq() {
        var a = String,
            b = w.location.hostname,
            c = w.location.pathname,
            d = b = ic(b);
        d.split(".").length > 2 && (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
        b = d;
        c = ic(c);
        var e = c.split(";")[0];
        e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
        return a(oi(("" + b + e).toLowerCase()))
    };
    var vq = ["ad_storage", "ad_user_data"];

    function wq(a, b) {
        if (!a) return vb("TAGGING", 32), 10;
        if (b === null || b === void 0 || b === "") return vb("TAGGING", 33), 11;
        var c = xq(!1);
        if (c.error !== 0) return vb("TAGGING", 34), c.error;
        if (!c.value) return vb("TAGGING", 35), 2;
        c.value[a] = b;
        var d = yq(c);
        d !== 0 && vb("TAGGING", 36);
        return d
    }

    function zq(a) {
        if (!a) return vb("TAGGING", 27), {
            error: 10
        };
        var b = xq();
        if (b.error !== 0) return vb("TAGGING", 29), b;
        if (!b.value) return vb("TAGGING", 30), {
            error: 2
        };
        if (!(a in b.value)) return vb("TAGGING", 31), {
            value: void 0,
            error: 15
        };
        var c = b.value[a];
        return c === null || c === void 0 || c === "" ? (vb("TAGGING", 28), {
            value: void 0,
            error: 11
        }) : {
            value: c,
            error: 0
        }
    }

    function xq(a) {
        a = a === void 0 ? !0 : a;
        if (!tm(vq)) return vb("TAGGING", 43), {
            error: 3
        };
        try {
            if (!w.localStorage) return vb("TAGGING", 44), {
                error: 1
            }
        } catch (f) {
            return vb("TAGGING", 45), {
                error: 14
            }
        }
        var b = {
                schema: "gcl",
                version: 1
            },
            c = void 0;
        try {
            c = w.localStorage.getItem("_gcl_ls")
        } catch (f) {
            return vb("TAGGING", 46), {
                error: 13
            }
        }
        try {
            if (c) {
                var d = JSON.parse(c);
                if (d && typeof d === "object") b = d;
                else return vb("TAGGING", 47), {
                    error: 12
                }
            }
        } catch (f) {
            return vb("TAGGING", 48), {
                error: 8
            }
        }
        if (b.schema !== "gcl") return vb("TAGGING", 49), {
            error: 4
        };
        if (b.version !== 1) return vb("TAGGING", 50), {
            error: 5
        };
        try {
            var e = Aq(b);
            a && e && yq({
                value: b,
                error: 0
            })
        } catch (f) {
            return vb("TAGGING", 48), {
                error: 8
            }
        }
        return {
            value: b,
            error: 0
        }
    }

    function Aq(a) {
        if (!a || typeof a !== "object") return !1;
        if ("expires" in a && "value" in a) {
            var b;
            typeof a.expires === "number" ? b = a.expires : b = typeof a.expires === "string" ? Number(a.expires) : NaN;
            if (isNaN(b) || !(Date.now() <= b)) return a.value = null, a.error = 9, vb("TAGGING", 54), !0
        } else {
            for (var c = !1, d = m(Object.keys(a)), e = d.next(); !e.done; e = d.next()) c = Aq(a[e.value]) || c;
            return c
        }
        return !1
    }

    function yq(a) {
        if (a.error) return a.error;
        if (!a.value) return vb("TAGGING", 42), 2;
        var b = a.value,
            c;
        try {
            c = JSON.stringify(b)
        } catch (d) {
            return vb("TAGGING", 52), 6
        }
        try {
            w.localStorage.setItem("_gcl_ls", c)
        } catch (d) {
            return vb("TAGGING", 53), 7
        }
        return 0
    };
    var Bq = {},
        Cq = (Bq.gclid = !0, Bq.dclid = !0, Bq.gbraid = !0, Bq.wbraid = !0, Bq),
        Dq = /^\w+$/,
        Eq = /^[\w-]+$/,
        Fq = {},
        Gq = (Fq.aw = "_aw", Fq.dc = "_dc", Fq.gf = "_gf", Fq.gp = "_gp", Fq.gs = "_gs", Fq.ha = "_ha", Fq.ag = "_ag", Fq.gb = "_gb", Fq),
        Hq = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
        Iq = /^www\.googleadservices\.com$/;

    function Jq() {
        return ["ad_storage", "ad_user_data"]
    }

    function Kq(a) {
        return !ib(6) || tm(a)
    }

    function Lq(a, b) {
        function c() {
            var d = Kq(b);
            d && a();
            return d
        }
        zm(function() {
            c() || Am(c, b)
        }, b)
    }

    function Mq(a) {
        return Nq(a).map(function(b) {
            return b.gclid
        })
    }

    function Oq(a) {
        return Pq(a).filter(function(b) {
            return b.gclid
        }).map(function(b) {
            return b.gclid
        })
    }

    function Pq(a) {
        var b = Qq(a.prefix),
            c = Rq("gb", b),
            d = Rq("ag", b);
        if (!d || !c) return [];
        var e = function(h) {
                return function(l) {
                    l.type = h;
                    return l
                }
            },
            f = Nq(c).map(e("gb")),
            g = Sq(d).map(e("ag"));
        return f.concat(g).sort(function(h, l) {
            return l.timestamp - h.timestamp
        })
    }

    function Tq(a, b, c, d, e) {
        var f = Gb(a, function(g) {
            return g.gclid === b
        });
        f ? (f.timestamp < c && (f.timestamp = c, f.gd = e), f.labels = Uq(f.labels || [], d || [])) : a.push({
            version: "2",
            gclid: b,
            timestamp: c,
            labels: d,
            gd: e
        })
    }

    function Sq(a) {
        for (var b = kq(a, 5) || [], c = [], d = m(b), e = d.next(); !e.done; e = d.next()) {
            var f = e.value,
                g = f,
                h = Vq(f);
            h && Tq(c, g.k, h, g.b || [], f.u)
        }
        return c.sort(function(l, n) {
            return n.timestamp - l.timestamp
        })
    }

    function Nq(a) {
        for (var b = [], c = Rp(a, A.cookie, void 0, Jq()), d = m(c), e = d.next(); !e.done; e = d.next()) {
            var f = Wq(e.value);
            f != null && (f.gd = void 0, f.Ba = new qq, f.eb = [1], Xq(b, f))
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return Yq(b)
    }

    function Zq(a, b) {
        for (var c = [], d = m(a), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            c.includes(f) || c.push(f)
        }
        for (var g = m(b), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            c.includes(l) || c.push(l)
        }
        return c
    }

    function Xq(a, b, c) {
        c = c === void 0 ? !1 : c;
        for (var d, e, f = m(a), g = f.next(); !g.done; g = f.next()) {
            var h = g.value;
            if (h.gclid === b.gclid) {
                d = h;
                break
            }
            h.Ba && b.Ba && h.Ba.equals(b.Ba) && (e = h)
        }
        if (d) {
            var l, n, p = (l = d.Ba) != null ? l : new qq,
                q = (n = b.Ba) != null ? n : new qq;
            p.value |= q.value;
            d.Ba = p;
            d.timestamp < b.timestamp && (d.timestamp = b.timestamp, d.gd = b.gd);
            d.labels = Zq(d.labels || [], b.labels || []);
            d.eb = Zq(d.eb || [], b.eb || [])
        } else c && e ? pa(Object, "assign").call(Object, e, b) : a.push(b)
    }

    function $q(a) {
        if (!a) return new qq;
        var b = new qq;
        if (a === 1) return rq(b, 2), rq(b, 3), b;
        rq(b, a);
        return b
    }

    function ar() {
        var a = zq("gclid");
        if (!a || a.error || !a.value || typeof a.value !== "object") return null;
        var b = a.value;
        try {
            if (!("value" in b && b.value) || typeof b.value !== "object") return null;
            var c = b.value,
                d = c.value;
            if (!d || !d.match(Eq)) return null;
            var e = c.linkDecorationSource,
                f = c.linkDecorationSources,
                g = new qq;
            typeof e === "number" ? g = $q(e) : typeof f === "number" && (g.value = f);
            return {
                version: "",
                gclid: d,
                timestamp: Number(c.creationTimeMs) || 0,
                labels: [],
                Ba: g,
                eb: [2]
            }
        } catch (h) {
            return null
        }
    }

    function br() {
        var a = zq("gcl_aw");
        if (a.error !== 0) return null;
        try {
            return a.value.reduce(function(b, c) {
                if (!c.value || typeof c.value !== "object") return b;
                var d = c.value,
                    e = d.value;
                if (!e || !e.match(Eq)) return b;
                var f = new qq,
                    g = d.linkDecorationSources;
                typeof g === "number" && (f.value = g);
                b.push({
                    version: "",
                    gclid: e,
                    timestamp: Number(d.creationTimeMs) || 0,
                    expires: Number(c.expires) || 0,
                    labels: [],
                    Ba: f,
                    eb: [2]
                });
                return b
            }, [])
        } catch (b) {
            return null
        }
    }

    function cr(a) {
        for (var b = [], c = Rp(a, A.cookie, void 0, Jq()), d = m(c), e = d.next(); !e.done; e = d.next()) {
            var f = Wq(e.value);
            f != null && (f.gd = void 0, f.Ba = new qq, f.eb = [1], Xq(b, f))
        }
        var g = ar();
        g && (g.gd = void 0, g.eb = g.eb || [2], Xq(b, g));
        if (ib(14)) {
            var h = br();
            if (h)
                for (var l = m(h), n = l.next(); !n.done; n = l.next()) {
                    var p = n.value;
                    p.gd = void 0;
                    p.eb = p.eb || [2];
                    Xq(b, p)
                }
        }
        b.sort(function(q, r) {
            return r.timestamp - q.timestamp
        });
        return Yq(b)
    }

    function Uq(a, b) {
        if (!a.length) return b;
        if (!b.length) return a;
        var c = {};
        return a.concat(b).filter(function(d) {
            return c.hasOwnProperty(d) ? !1 : c[d] = !0
        })
    }

    function Qq(a) {
        return a && typeof a === "string" && a.match(Dq) ? a : "_gcl"
    }

    function dr(a, b) {
        if (a) {
            var c = {
                value: a,
                Ba: new qq
            };
            rq(c.Ba, b);
            return c
        }
    }

    function er(a, b, c) {
        var d = Sj(a),
            e = Mj(d, "query", !1, void 0, "gclsrc"),
            f = dr(Mj(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
        if (b && (!f || !e)) {
            var g = d.hash.replace("#", "");
            f || (f = dr(Jj(g, "gclid", !1), 3));
            e || (e = Jj(g, "gclsrc", !1))
        }
        return f && (e === void 0 || e === "aw" || e === "aw.ds" || ib(18) && e === "aw.dv") ? [f] : []
    }

    function fr(a, b) {
        var c = Sj(a),
            d = Mj(c, "query", !1, void 0, "gclid"),
            e = Mj(c, "query", !1, void 0, "gclsrc"),
            f = Mj(c, "query", !1, void 0, "wbraid");
        f = fc(f);
        var g = Mj(c, "query", !1, void 0, "gbraid"),
            h = Mj(c, "query", !1, void 0, "gad_source"),
            l = Mj(c, "query", !1, void 0, "dclid");
        if (b && !(d && e && f && g)) {
            var n = c.hash.replace("#", "");
            d = d || Jj(n, "gclid", !1);
            e = e || Jj(n, "gclsrc", !1);
            f = f || Jj(n, "wbraid", !1);
            g = g || Jj(n, "gbraid", !1);
            h = h || Jj(n, "gad_source", !1)
        }
        return gr(d, e, l, f, g, h)
    }

    function hr() {
        return fr(w.location.href, !0)
    }

    function gr(a, b, c, d, e, f) {
        var g = {},
            h = function(l, n) {
                g[n] || (g[n] = []);
                g[n].push(l)
            };
        g.gclid = a;
        g.gclsrc = b;
        g.dclid = c;
        if (a !== void 0 && a.match(Eq)) switch (b) {
            case void 0:
                h(a, "aw");
                break;
            case "aw.ds":
                h(a, "aw");
                h(a, "dc");
                break;
            case "aw.dv":
                ib(18) && (h(a, "aw"), h(a, "dc"));
                break;
            case "ds":
                h(a, "dc");
                break;
            case "3p.ds":
                h(a, "dc");
                break;
            case "gf":
                h(a, "gf");
                break;
            case "ha":
                h(a, "ha")
        }
        c && h(c, "dc");
        d !== void 0 && Eq.test(d) && (g.wbraid = d, h(d, "gb"));
        e !== void 0 && Eq.test(e) && (g.gbraid = e, h(e, "ag"));
        f !== void 0 && Eq.test(f) && (g.gad_source =
            f, h(f, "gs"));
        return g
    }

    function ir(a) {
        for (var b = hr(), c = !0, d = m(Object.keys(b)), e = d.next(); !e.done; e = d.next())
            if (b[e.value] !== void 0) {
                c = !1;
                break
            }
        c && (b = fr(w.document.referrer, !1), b.gad_source = void 0);
        jr(b, !1, a)
    }

    function kr(a) {
        ir(a);
        var b = er(w.location.href, !0, !1);
        b.length || (b = er(w.document.referrer, !1, !0));
        a = a || {};
        lr(a);
        if (b.length) {
            var c = b[0],
                d = Tb(),
                e = iq(a, d, !0),
                f = Jq(),
                g = function() {
                    Kq(f) && e.expires !== void 0 && wq("gclid", {
                        value: {
                            value: c.value,
                            creationTimeMs: d,
                            linkDecorationSources: c.Ba.get()
                        },
                        expires: Number(e.expires)
                    })
                };
            zm(function() {
                g();
                Kq(f) || Am(g, f)
            }, f)
        }
    }

    function lr(a) {
        var b;
        if (b = ib(15)) {
            var c = mr();
            b = Hq.test(c) || Iq.test(c) || nr()
        }
        if (b) {
            var d;
            a: {
                for (var e = Sj(w.location.href), f = Kj(Mj(e, "query")), g = m(Object.keys(f)), h = g.next(); !h.done; h = g.next()) {
                    var l = h.value;
                    if (!Cq[l]) {
                        var n = f[l][0] || "",
                            p;
                        if (!n || n.length < 50 || n.length > 200) p = !1;
                        else {
                            var q = sq(n),
                                r;
                            if (q) c: {
                                var t = q;
                                if (t && t.length !== 0) {
                                    var u = 0;
                                    try {
                                        for (var v = 10; u < t.length && !(v-- <= 0);) {
                                            var x = tq(t, u);
                                            if (x === void 0) break;
                                            var y = m(x),
                                                z = y.next().value,
                                                C = y.next().value,
                                                D = z,
                                                G = C,
                                                J = D & 7;
                                            if (D >> 3 === 16382) {
                                                if (J !== 0) break;
                                                var L = tq(t, G);
                                                if (L === void 0) break;
                                                r = m(L).next().value === 1;
                                                break c
                                            }
                                            var da;
                                            d: {
                                                var aa = void 0,
                                                    N = t,
                                                    R = G;
                                                switch (J) {
                                                    case 0:
                                                        da = (aa = tq(N, R)) == null ? void 0 : aa[1];
                                                        break d;
                                                    case 1:
                                                        da = R + 8;
                                                        break d;
                                                    case 2:
                                                        var ja = tq(N, R);
                                                        if (ja === void 0) break;
                                                        var la = m(ja),
                                                            Z = la.next().value;
                                                        da = la.next().value + Z;
                                                        break d;
                                                    case 5:
                                                        da = R + 4;
                                                        break d
                                                }
                                                da = void 0
                                            }
                                            if (da === void 0 || da > t.length || da <= u) break;
                                            u = da
                                        }
                                    } catch (ha) {}
                                }
                                r = !1
                            }
                            else r = !1;
                            p = r
                        }
                        if (p) {
                            d = n;
                            break a
                        }
                    }
                }
                d = void 0
            }
            var V = d;
            V && or(V, 7, a)
        }
    }

    function or(a, b, c) {
        c = c || {};
        var d = Tb(),
            e = iq(c, d, !0),
            f = Jq(),
            g = function() {
                if (Kq(f) && e.expires !== void 0) {
                    var h = br() || [];
                    Xq(h, {
                        version: "",
                        gclid: a,
                        timestamp: d,
                        expires: Number(e.expires),
                        Ba: $q(b)
                    }, !0);
                    wq("gcl_aw", h.map(function(l) {
                        return {
                            value: {
                                value: l.gclid,
                                creationTimeMs: l.timestamp,
                                linkDecorationSources: l.Ba ? l.Ba.get() : 0
                            },
                            expires: Number(l.expires)
                        }
                    }))
                }
            };
        zm(function() {
            Kq(f) ? g() : Am(g, f)
        }, f)
    }

    function jr(a, b, c, d, e) {
        c = c || {};
        e = e || [];
        var f = Qq(c.prefix),
            g = d || Tb(),
            h = Math.round(g / 1E3),
            l = Jq(),
            n = !1,
            p = !1,
            q = ib(20),
            r = function() {
                if (Kq(l)) {
                    var t = iq(c, g, !0);
                    t.Kc = l;
                    for (var u = function(aa, N) {
                            var R = Rq(aa, f);
                            R && (cq(R, N, t), aa !== "gb" && (n = !0))
                        }, v = function(aa) {
                            var N = ["GCL", h, aa];
                            e.length > 0 && N.push(e.join("."));
                            return N.join(".")
                        }, x = m(["aw", "dc", "gf", "ha", "gp"]), y = x.next(); !y.done; y = x.next()) {
                        var z = y.value;
                        a[z] && u(z, v(a[z][0]))
                    }
                    if ((!n || q) && a.gb) {
                        var C = a.gb[0],
                            D = Rq("gb", f);
                        !b && Nq(D).some(function(aa) {
                            return aa.gclid ===
                                C && aa.labels && aa.labels.length > 0
                        }) || u("gb", v(C))
                    }
                }
                if (!p && a.gbraid && Kq("ad_storage") && (p = !0, !n || q)) {
                    var G = a.gbraid,
                        J = Rq("ag", f);
                    if (b || !Sq(J).some(function(aa) {
                            return aa.gclid === G && aa.labels && aa.labels.length > 0
                        })) {
                        var L = {},
                            da = (L.k = G, L.i = "" + h, L.b = e, L);
                        oq(J, da, 5, c, g)
                    }
                }
                pr(a, f, g, c)
            };
        zm(function() {
            r();
            Kq(l) || Am(r, l)
        }, l)
    }

    function pr(a, b, c, d) {
        if (a.gad_source !== void 0 && Kq("ad_storage")) {
            var e = wd();
            if (e !== "r" && e !== "h") {
                var f = a.gad_source,
                    g = Rq("gs", b);
                if (g) {
                    var h = Math.floor((Tb() - (vd() || 0)) / 1E3),
                        l, n = uq(),
                        p = {};
                    l = (p.k = f, p.i = "" + h, p.u = n, p);
                    oq(g, l, 5, d, c)
                }
            }
        }
    }

    function qr(a, b) {
        var c = mp(!0);
        Lq(function() {
            for (var d = Qq(b.prefix), e = 0; e < a.length; ++e) {
                var f = a[e];
                if (Gq[f] !== void 0) {
                    var g = Rq(f, d),
                        h = c[g];
                    if (h) {
                        var l = Math.min(rr(h), Tb()),
                            n;
                        b: {
                            for (var p = l, q = Rp(g, A.cookie, void 0, Jq()), r = 0; r < q.length; ++r)
                                if (rr(q[r]) > p) {
                                    n = !0;
                                    break b
                                }
                            n = !1
                        }
                        if (!n) {
                            var t = iq(b, l, !0);
                            t.Kc = Jq();
                            cq(g, h, t)
                        }
                    }
                }
            }
            jr(gr(c.gclid, c.gclsrc), !1, b)
        }, Jq())
    }

    function sr(a) {
        var b = ["ag"],
            c = mp(!0),
            d = Qq(a.prefix);
        Lq(function() {
            for (var e = 0; e < b.length; ++e) {
                var f = Rq(b[e], d);
                if (f) {
                    var g = c[f];
                    if (g) {
                        var h = Hp(g, 5);
                        if (h) {
                            var l = Vq(h);
                            l || (l = Tb());
                            var n;
                            a: {
                                for (var p = l, q = kq(f, 5), r = 0; r < q.length; ++r)
                                    if (Vq(q[r]) > p) {
                                        n = !0;
                                        break a
                                    }
                                n = !1
                            }
                            if (n) break;
                            h.i = "" + Math.round(l / 1E3);
                            oq(f, h, 5, a, l)
                        }
                    }
                }
            }
        }, ["ad_storage"])
    }

    function Rq(a, b) {
        var c = Gq[a];
        if (c !== void 0) return b + c
    }

    function rr(a) {
        return tr(a.split(".")).length !== 0 ? (Number(a.split(".")[1]) || 0) * 1E3 : 0
    }

    function Vq(a) {
        return a ? (Number(a.i) || 0) * 1E3 : 0
    }

    function Wq(a) {
        var b = tr(a.split("."));
        return b.length === 0 ? null : {
            version: b[0],
            gclid: b[2],
            timestamp: (Number(b[1]) || 0) * 1E3,
            labels: b.slice(3)
        }
    }

    function tr(a) {
        return a.length < 3 || a[0] !== "GCL" && a[0] !== "1" || !/^\d+$/.test(a[1]) || !Eq.test(a[2]) ? [] : a
    }

    function ur(a, b, c, d, e) {
        if (Array.isArray(b) && zp(w)) {
            var f = Qq(e),
                g = function() {
                    for (var h = {}, l = 0; l < a.length; ++l) {
                        var n = Rq(a[l], f);
                        if (n) {
                            var p = Rp(n, A.cookie, void 0, Jq());
                            p.length && (h[n] = p.sort()[p.length - 1])
                        }
                    }
                    return h
                };
            Lq(function() {
                tp(g, b, c, d)
            }, Jq())
        }
    }

    function vr(a, b, c, d) {
        if (Array.isArray(a) && zp(w)) {
            var e = ["ag"],
                f = Qq(d),
                g = function() {
                    for (var h = {}, l = 0; l < e.length; ++l) {
                        var n = Rq(e[l], f);
                        if (!n) return {};
                        var p = kq(n, 5);
                        if (p.length) {
                            var q = p.sort(function(r, t) {
                                return Vq(t) - Vq(r)
                            })[0];
                            h[n] = Ip(q, 5)
                        }
                    }
                    return h
                };
            Lq(function() {
                tp(g, a, b, c)
            }, ["ad_storage"])
        }
    }

    function Yq(a) {
        return a.filter(function(b) {
            return Eq.test(b.gclid)
        })
    }

    function wr(a, b) {
        if (zp(w)) {
            for (var c = Qq(b.prefix), d = {}, e = 0; e < a.length; e++) Gq[a[e]] && (d[a[e]] = Gq[a[e]]);
            Lq(function() {
                Lb(d, function(f, g) {
                    var h = Rp(c + g, A.cookie, void 0, Jq());
                    h.sort(function(t, u) {
                        return rr(u) - rr(t)
                    });
                    if (h.length) {
                        var l = h[0],
                            n = rr(l),
                            p = tr(l.split(".")).length !== 0 ? l.split(".").slice(3) : [],
                            q = {},
                            r;
                        r = tr(l.split(".")).length !== 0 ? l.split(".")[2] : void 0;
                        q[f] = [r];
                        jr(q, !0, b, n, p)
                    }
                })
            }, Jq())
        }
    }

    function xr(a) {
        var b = ["ag"],
            c = ["gbraid"];
        Lq(function() {
            for (var d = Qq(a.prefix), e = 0; e < b.length; ++e) {
                var f = Rq(b[e], d);
                if (!f) break;
                var g = kq(f, 5);
                if (g.length) {
                    var h = g.sort(function(q, r) {
                            return Vq(r) - Vq(q)
                        })[0],
                        l = Vq(h),
                        n = h.b,
                        p = {};
                    p[c[e]] = h.k;
                    jr(p, !0, a, l, n)
                }
            }
        }, ["ad_storage"])
    }

    function yr(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }

    function zr(a) {
        function b(h, l, n) {
            n && (h[l] = n)
        }
        if (wm()) {
            var c = hr(),
                d;
            a.includes("gad_source") && (d = c.gad_source !== void 0 ? c.gad_source : mp(!1)._gs);
            if (yr(c, a) || d) {
                var e = {};
                b(e, "gclid", c.gclid);
                b(e, "dclid", c.dclid);
                b(e, "gclsrc", c.gclsrc);
                b(e, "wbraid", c.wbraid);
                b(e, "gbraid", c.gbraid);
                up(function() {
                    return e
                }, 3);
                var f = {},
                    g = (f._up = "1", f);
                b(g, "_gs", d);
                up(function() {
                    return g
                }, 1)
            }
        }
    }

    function nr() {
        var a = Sj(w.location.href);
        return Mj(a, "query", !1, void 0, "gad_source")
    }

    function Ar(a) {
        if (!ib(1)) return null;
        var b = mp(!0).gad_source;
        if (b != null) return w.location.hash = "", b;
        if (ib(2)) {
            b = nr();
            if (b != null) return b;
            var c = hr();
            if (yr(c, a)) return "0"
        }
        return null
    }

    function Br(a) {
        var b = Ar(a);
        b != null && up(function() {
            var c = {};
            return c.gad_source = b, c
        }, 4)
    }

    function Cr(a, b, c) {
        var d = [];
        if (b.length === 0) return d;
        for (var e = {}, f = 0; f < b.length; f++) {
            var g = b[f],
                h = g.type ? g.type : "gcl";
            (g.labels || []).indexOf(c) === -1 ? (a.push(0), e[h] || d.push(g)) : a.push(1);
            e[h] = !0
        }
        return d
    }

    function Dr(a, b, c, d) {
        var e = [];
        c = c || {};
        if (!Kq(Jq())) return e;
        var f = Nq(a),
            g = Cr(e, f, b);
        if (g.length && !d)
            for (var h = m(g), l = h.next(); !l.done; l = h.next()) {
                var n = l.value,
                    p = n.timestamp,
                    q = [n.version, Math.round(p / 1E3), n.gclid].concat(n.labels || [], [b]).join("."),
                    r = iq(c, p, !0);
                r.Kc = Jq();
                cq(a, q, r)
            }
        return e
    }

    function Er(a, b) {
        var c = [];
        b = b || {};
        var d = Pq(b),
            e = Cr(c, d, a);
        if (e.length)
            for (var f = m(e), g = f.next(); !g.done; g = f.next()) {
                var h = g.value,
                    l = Qq(b.prefix),
                    n = Rq(h.type, l);
                if (!n) break;
                var p = h,
                    q = p.version,
                    r = p.gclid,
                    t = p.labels,
                    u = p.timestamp,
                    v = Math.round(u / 1E3);
                if (h.type === "ag") {
                    var x = {},
                        y = (x.k = r, x.i = "" + v, x.b = (t || []).concat([a]), x);
                    oq(n, y, 5, b, u)
                } else if (h.type === "gb") {
                    var z = [q, v, r].concat(t || [], [a]).join("."),
                        C = iq(b, u, !0);
                    C.Kc = Jq();
                    cq(n, z, C)
                }
            }
        return c
    }

    function Fr(a, b) {
        var c = Qq(b),
            d = Rq(a, c);
        if (!d) return 0;
        var e;
        e = a === "ag" ? Sq(d) : Nq(d);
        for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
        return f
    }

    function Gr(a) {
        for (var b = 0, c = m(Object.keys(a)), d = c.next(); !d.done; d = c.next())
            for (var e = a[d.value], f = 0; f < e.length; f++) b = Math.max(b, Number(e[f].timestamp));
        return b
    }

    function Hr(a) {
        var b = Math.max(Fr("aw", a), Gr(Kq(Jq()) ? yp() : {})),
            c = Math.max(Fr("gb", a), Gr(Kq(Jq()) ? yp("_gac_gb", !0) : {}));
        c = Math.max(c, Fr("ag", a));
        return c > b
    }

    function mr() {
        return A.referrer ? Mj(Sj(A.referrer), "host") : ""
    };
    var Ir = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        Jr = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        Kr = /^\d+\.fls\.doubleclick\.net$/,
        Lr = /;gac=([^;?]+)/,
        Mr = /;gacgb=([^;?]+)/;

    function Nr(a, b) {
        if (Kr.test(A.location.host)) {
            var c = A.location.href.match(b);
            return c && c.length === 2 && c[1].match(Ir) ? Lj(c[1]) || "" : ""
        }
        for (var d = [], e = m(Object.keys(a)), f = e.next(); !f.done; f = e.next()) {
            for (var g = f.value, h = [], l = a[g], n = 0; n < l.length; n++) h.push(l[n].gclid);
            d.push(g + ":" + h.join(","))
        }
        return d.length > 0 ? d.join(";") : ""
    }

    function Or(a, b, c) {
        for (var d = Kq(Jq()) ? yp("_gac_gb", !0) : {}, e = [], f = !1, g = m(Object.keys(d)), h = g.next(); !h.done; h = g.next()) {
            var l = h.value,
                n = Dr("_gac_gb_" + l, a, b, c);
            f = f || n.length !== 0 && n.some(function(p) {
                return p === 1
            });
            e.push(l + ":" + n.join(","))
        }
        return {
            vr: f ? e.join(";") : "",
            ur: Nr(d, Mr)
        }
    }

    function Pr(a) {
        var b = A.location.href.match(new RegExp(";" + a + "=([^;?]+)"));
        return b && b.length === 2 && b[1].match(Jr) ? b[1] : void 0
    }

    function Qr(a) {
        var b = {},
            c, d, e;
        Kr.test(A.location.host) && (c = Pr("gclgs"), d = Pr("gclst"), e = Pr("gcllp"));
        if (c && d && e) b.Dg = c, b.Wh = d, b.Vh = e;
        else {
            var f = Tb(),
                g = Sq((a || "_gcl") + "_gs"),
                h = g.map(function(p) {
                    return p.gclid
                }),
                l = g.map(function(p) {
                    return f - p.timestamp
                }),
                n = g.map(function(p) {
                    return p.gd
                });
            h.length > 0 && l.length > 0 && n.length > 0 && (b.Dg = h.join("."), b.Wh = l.join("."), b.Vh = n.join("."))
        }
        return b
    }

    function Rr(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (Kr.test(A.location.host)) {
            var e = Pr(c);
            if (e) {
                if (d) {
                    var f = new qq;
                    rq(f, 2);
                    rq(f, 3);
                    return e.split(".").map(function(h) {
                        return {
                            gclid: h,
                            Ba: f,
                            eb: [1]
                        }
                    })
                }
                return e.split(".").map(function(h) {
                    return {
                        gclid: h,
                        Ba: new qq,
                        eb: [1]
                    }
                })
            }
        } else {
            if (b === "gclid") {
                var g = (a || "_gcl") + "_aw";
                return d ? cr(g) : Nq(g)
            }
            if (b === "wbraid") return Nq((a || "_gcl") + "_gb");
            if (b === "braids") return Pq({
                prefix: a
            })
        }
        return []
    }

    function Sr(a) {
        return Kr.test(A.location.host) ? !(Pr("gclaw") || Pr("gac")) : Hr(a)
    }

    function Tr(a, b, c) {
        var d;
        d = c ? Er(a, b) : Dr((b && b.prefix || "_gcl") + "_gb", a, b);
        return d.length === 0 || d.every(function(e) {
            return e === 0
        }) ? "" : d.join(".")
    };

    function ds() {
        var a = [],
            b = Number('') || 0,
            c = Number('') || 0;
        c || (c = b / 100);
        var d = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 21,
            studyId: 21,
            experimentId: 105102050,
            controlId: 105102051,
            controlId2: 105102052,
            probability: c,
            active: d,
            oa: 0
        });
        var e =
            Number('') || 0,
            f = Number('') || 0;
        f || (f = e / 100);
        var g = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 265,
            studyId: 265,
            experimentId: 115691063,
            controlId: 115691064,
            controlId2: 115691065,
            probability: f,
            active: g,
            oa: 0
        });
        var h = Number('') || 0,
            l = Number('') || 0;
        l || (l = h / 100);
        var n = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 228,
            studyId: 228,
            experimentId: 105177154,
            controlId: 105177155,
            controlId2: 105255245,
            probability: l,
            active: n,
            oa: 0
        });
        var p = Number('') ||
            0,
            q = Number('0') || 0;
        q || (q = p / 100);
        var r = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 287,
            studyId: 287,
            experimentId: 116133312,
            controlId: 116133313,
            controlId2: 116133314,
            probability: q,
            active: r,
            oa: 0
        });
        var t = Number('') ||
            0,
            u = Number('0') || 0;
        u || (u = t / 100);
        var v = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 288,
            studyId: 288,
            experimentId: 116133315,
            controlId: 116133316,
            controlId2: 116133317,
            probability: u,
            active: v,
            oa: 0
        });
        var x =
            Number('') || 0,
            y = Number('') || 0;
        y || (y = x / 100);
        var z = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 285,
            studyId: 285,
            experimentId: 115495938,
            controlId: 115495939,
            controlId2: 115495940,
            probability: y,
            active: z,
            oa: 0
        });
        var C = Number('') || 0,
            D = Number('') || 0;
        D || (D = C / 100);
        var G = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 286,
            studyId: 286,
            experimentId: 115495941,
            controlId: 115495942,
            controlId2: 115495943,
            probability: D,
            active: G,
            oa: 0
        });
        var J = Number('') || 0,
            L = Number('') || 0;
        L || (L = J / 100);
        var da = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 219,
            studyId: 219,
            experimentId: 104948811,
            controlId: 104948812,
            controlId2: 0,
            probability: L,
            active: da,
            oa: 0
        });
        var aa = Number('') || 0,
            N = Number('') || 0;
        N || (N = aa / 100);
        var R = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 220,
            studyId: 220,
            experimentId: 104948813,
            controlId: 104948814,
            controlId2: 0,
            probability: N,
            active: R,
            oa: 0
        });
        var ja = Number('') || 0,
            la = Number('') || 0;
        la || (la = ja / 100);
        var Z = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 235,
            studyId: 235,
            experimentId: 105357150,
            controlId: 105357151,
            controlId2: 0,
            probability: la,
            active: Z,
            oa: 1
        });
        var V = Number('') || 0,
            ha = Number('0.001') || 0;
        ha || (ha = V / 100);
        var ua = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 170,
            studyId: 170,
            experimentId: 116024733,
            controlId: 116024734,
            controlId2: 116024735,
            probability: ha,
            active: ua,
            oa: 0
        });
        var ma = Number('') || 0,
            Ea = Number('') || 0;
        Ea || (Ea = ma / 100);
        var Ya = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 203,
            studyId: 203,
            experimentId: 115480710,
            controlId: 115480709,
            controlId2: 115489982,
            probability: Ea,
            active: Ya,
            oa: 0
        });
        var Rb = Number('') || 0,
            Jb = Number('') || 0;
        Jb || (Jb = Rb / 100);
        var yb = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 178,
            studyId: 178,
            experimentId: 115958700,
            controlId: 115958701,
            controlId2: 115958702,
            probability: Jb,
            active: yb,
            oa: 0
        });
        var uc = Number('') || 0,
            Ec = Number('') || 0;
        Ec || (Ec = uc / 100);
        var ie = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 197,
            studyId: 197,
            experimentId: 105113532,
            controlId: 105113531,
            controlId2: 0,
            probability: Ec,
            active: ie,
            oa: 0
        });
        var Re = Number('') ||
            0,
            je = Number('0.2') || 0;
        je || (je = Re / 100);
        var Yk = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 243,
            studyId: 243,
            experimentId: 115616985,
            controlId: 115616986,
            controlId2: 0,
            probability: je,
            active: Yk,
            oa: 0
        });
        var Zk = Number('') || 0,
            If = Number('') ||
            0;
        If || (If = Zk / 100);
        var Bi = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 277,
            studyId: 277,
            experimentId: 116130039,
            controlId: 116130040,
            controlId2: 0,
            probability: If,
            active: Bi,
            oa: 0
        });
        var $k = Number('') || 0,
            Jf = Number('0') ||
            0;
        Jf || (Jf = $k / 100);
        var al = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 254,
            studyId: 254,
            experimentId: 115583767,
            controlId: 115583768,
            controlId2: 115583769,
            probability: Jf,
            active: al,
            oa: 0
        });
        var Ci = Number('') || 0,
            Di = Number('') ||
            0;
        Di || (Di = Ci / 100);
        var fp = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 253,
            studyId: 253,
            experimentId: 115583770,
            controlId: 115583771,
            controlId2: 115583772,
            probability: Di,
            active: fp,
            oa: 0
        });
        var bl = Number('') || 0,
            Fg = Number('') ||
            0;
        Fg || (Fg = bl / 100);
        var eK = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 266,
            studyId: 266,
            experimentId: 115718529,
            controlId: 115718530,
            controlId2: 115718531,
            probability: Fg,
            active: eK,
            oa: 0
        });
        var fK = Number('') || 0,
            gp = Number('') ||
            0;
        gp || (gp = fK / 100);
        var gK = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 267,
            studyId: 267,
            experimentId: 115718526,
            controlId: 115718527,
            controlId2: 115718528,
            probability: gp,
            active: gK,
            oa: 0
        });
        var hK = Number('') || 0,
            hp = Number('') || 0;
        hp || (hp = hK / 100);
        var iK = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 249,
            studyId: 249,
            experimentId: 105440521,
            controlId: 105440522,
            controlId2: 0,
            focused: !0,
            probability: hp,
            active: iK,
            oa: 0
        });
        var jK = Number('') || 0,
            ip = Number('0.5') || 0;
        ip || (ip = jK / 100);
        var kK = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 195,
            studyId: 195,
            experimentId: 104527906,
            controlId: 104527907,
            controlId2: 104898015,
            probability: ip,
            active: kK,
            oa: 1
        });
        var lK = Number('') || 0,
            jp = Number('0.5') || 0;
        jp || (jp = lK / 100);
        var mK = function() {
            var na = !1;
            return na
        }();
        a.push({
            qa: 196,
            studyId: 196,
            experimentId: 104528500,
            controlId: 104528501,
            controlId2: 104898016,
            probability: jp,
            active: mK,
            oa: 0
        });
        var nK = Number('') || 0,
            kp = Number('') || 0;
        kp || (kp = nK / 100);
        var oK = function() {
            var na = !1;
            na = !0;
            return na
        }();
        a.push({
            qa: 229,
            studyId: 229,
            experimentId: 105359938,
            controlId: 105359937,
            controlId2: 105359936,
            probability: kp,
            active: oK,
            oa: 0
        });
        return a
    };
    var es = {};

    function fs(a) {
        var b = a,
            c = a = gs[b.studyId] ? pa(Object, "assign").call(Object, {}, b, {
                active: !0
            }) : b;
        c.controlId2 && c.probability <= .25 || (c = pa(Object, "assign").call(Object, {}, c, {
            controlId2: 0
        }));
        lj[c.studyId] = c;
        a.focused && (es[a.studyId] = !0);
        if (a.oa === 1) {
            var d = a.studyId;
            hs(is(), d);
            js(d) && nk(d)
        } else if (a.oa === 0) {
            var e = a.studyId;
            hs(ks, e);
            js(e) && nk(e)
        }
    }

    function hs(a, b, c) {
        if (lj[b]) {
            var d = lj[b],
                e = d.experimentId,
                f = d.probability;
            if (!(a.studies || {})[b]) {
                var g = a.studies || {};
                g[b] = !0;
                a.studies = g;
                if (!lj[b].active)
                    if (lj[b].probability > .5) pj(a, e, b);
                    else if (!(f <= 0 || f > 1)) {
                    var h = void 0;
                    if (c) {
                        var l = jj(c + "~" + b);
                        if (l === "e2") h = -1;
                        else {
                            for (var n = new Uint8Array(l), p = BigInt(0), q = m(n), r = q.next(); !r.done; r = q.next()) p = p << BigInt(8) | BigInt(r.value);
                            h = Number(p % BigInt(Number.MAX_SAFE_INTEGER))
                        }
                    }
                    oj.Js(a, b, h)
                }
            }
        }
        if (!es[b]) {
            var t = rj(a, b);
            t && tj.D.J.add(t)
        }
    }

    function is() {
        return Qm(Lm.Z.wq, {})
    }
    var ks = {};

    function ls(a, b) {
        var c = js(a);
        if (es[a]) {
            var d;
            if (d = rj(is(), a) || rj(ks, a)) {
                var e = T(b, S.C.Ni) || [];
                e.includes(d) || e.push(d);
                U(b, S.C.Ni, e)
            }
        }
        return c
    }

    function js(a) {
        return qj(is(), a) || qj(ks, a)
    }

    function ms(a) {
        var b = T(a, S.C.Ni) || [];
        return Vk(b)
    }
    var gs = {};

    function ns(a) {
        var b = {
                studyId: a[1],
                active: !!a[2],
                probability: a[3] || 0,
                experimentId: a[4] || 0,
                controlId: a[5] || 0,
                controlId2: a[6] || 0
            },
            c = 0;
        switch (a[7]) {
            case 2:
                c = 1;
                break;
            case 3:
                c = 2;
                break;
            case 1:
            case 4:
            case 5:
            case 0:
                c = 0
        }
        var d;
        a: switch (b.studyId) {
            case 451:
            case 249:
                d = !0;
                break a;
            default:
                d = !1
        }
        return pa(Object, "assign").call(Object, {}, b, {
            oa: c,
            focused: d
        })
    }

    function os() {
        var a, b, c = ((a = w) == null ? void 0 : (b = a.location) == null ? void 0 : b.hash) || "";
        if (c[0] === "#" && c[1] === "_" && c[2] === "t" && c[3] === "e" && c[4] === "=") {
            var d = c.substring(5);
            if (d)
                for (var e = m(d.split("~")), f = e.next(); !f.done; f = e.next()) {
                    var g = Number(f.value);
                    g && (gs[g] = !0, nk(g))
                }
        }
        for (var h = m(ds()), l = h.next(); !l.done; l = h.next()) fs(l.value);
        for (var n = ns, p = [], q = m(Bg(56) || []), r = q.next(); !r.done; r = q.next()) {
            var t = n(r.value);
            (t.active || t.experimentId && t.controlId) && p.push(t)
        }
        for (var u = m(p), v = u.next(); !v.done; v =
            u.next()) fs(v.value)
    };

    function ps(a, b) {
        b && Lb(b, function(c, d) {
            typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d))
        })
    };
    var qs = w.google_tag_manager = w.google_tag_manager || {};

    function rs(a, b) {
        return qs[a] = qs[a] || b()
    }

    function ss() {
        var a = E(5),
            b = ts;
        qs[a] = qs[a] || b
    }

    function us() {
        var a = E(19);
        return qs[a] = qs[a] || {}
    }

    function vs() {
        var a = E(19);
        return qs[a]
    }

    function ws() {
        var a = qs.sequence || 1;
        qs.sequence = a + 1;
        return a
    }
    w.google_tag_data = w.google_tag_data || {};
    var xs = !1,
        ys = [];

    function zs() {
        if (!xs) {
            xs = !0;
            for (var a = ys.length - 1; a >= 0; a--) ys[a]();
            ys = []
        }
    };
    var As = /^(?:AW|DC|G|GF|GT|HA|MC|UA)$/,
        Bs = /\s/;

    function Cs(a, b) {
        if (Db(a)) {
            a = Qb(a);
            var c = a.indexOf("-");
            if (!(c < 0)) {
                var d = a.substring(0, c);
                if (As.test(d)) {
                    var e = a.substring(c + 1),
                        f;
                    if (b) {
                        var g = function(n) {
                            var p = n.indexOf("/");
                            return p < 0 ? [n] : [n.substring(0, p), n.substring(p + 1)]
                        };
                        f = g(e);
                        if (d === "DC" && f.length === 2) {
                            var h = g(f[1]);
                            h.length === 2 && (f[1] = h[0], f.push(h[1]))
                        }
                    } else {
                        f = e.split("/");
                        for (var l = 0; l < f.length; l++)
                            if (!f[l] || Bs.test(f[l]) && (d !== "AW" || l !== 1)) return
                    }
                    return {
                        id: a,
                        prefix: d,
                        destinationId: d + "-" + f[0],
                        ids: f
                    }
                }
            }
        }
    }

    function Ds(a, b) {
        for (var c = {}, d = 0; d < a.length; ++d) {
            var e = Cs(a[d], b);
            e && (c[e.id] = e)
        }
        var f = [],
            g;
        for (g in c)
            if (c.hasOwnProperty(g)) {
                var h = c[g];
                h.prefix === "AW" && h.ids[Es[1]] && f.push(h.destinationId)
            }
        for (var l = 0; l < f.length; ++l) delete c[f[l]];
        for (var n = [], p = m(Object.keys(c)), q = p.next(); !q.done; q = p.next()) n.push(c[q.value]);
        return n
    }
    var Fs = {},
        Es = (Fs[0] = 0, Fs[1] = 1, Fs[2] = 2, Fs[3] = 0, Fs[4] = 1, Fs[5] = 0, Fs[6] = 0, Fs[7] = 0, Fs);
    var Gs = Cg(34, 500),
        Hs = {},
        Is = {},
        Js = {
            initialized: 11,
            complete: 12,
            interactive: 13
        },
        Ks = {},
        Ls = Object.freeze((Ks[K.m.Gd] = !0, Ks)),
        Ms = void 0;

    function Ns(a, b) {
        if (b.length && nl) {
            var c;
            (c = Hs)[a] != null || (c[a] = []);
            Is[a] != null || (Is[a] = []);
            var d = b.filter(function(e) {
                return !Is[a].includes(e)
            });
            Hs[a].push.apply(Hs[a], Aa(d));
            Is[a].push.apply(Is[a], Aa(d));
            !Ms && d.length > 0 && (Tk("tdc", !0), Ms = w.setTimeout(function() {
                Xm();
                Hs = {};
                Ms = void 0
            }, Gs))
        }
    }

    function Os(a, b) {
        var c = {},
            d;
        for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
        for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
        return c
    }

    function Ps(a, b, c, d) {
        c = c === void 0 ? {} : c;
        d = d === void 0 ? "" : d;
        if (a === b) return [];
        var e = function(r, t) {
                var u;
                Gd(t) === "object" ? u = t[r] : Gd(t) === "array" && (u = t[r]);
                return u === void 0 ? Ls[r] : u
            },
            f = Os(a, b),
            g;
        for (g in f)
            if (f.hasOwnProperty(g)) {
                var h = (d ? d + "." : "") + g,
                    l = e(g, a),
                    n = e(g, b),
                    p = Gd(l) === "object" || Gd(l) === "array",
                    q = Gd(n) === "object" || Gd(n) === "array";
                if (p && q) Ps(l, n, c, h);
                else if (p || q || l !== n) c[h] = !0
            }
        return Object.keys(c)
    }

    function Qs() {
        Sk("tdc", function() {
            Ms && (w.clearTimeout(Ms), Ms = void 0);
            var a = [],
                b;
            for (b in Hs) Hs.hasOwnProperty(b) && a.push(b + "*" + Hs[b].join("."));
            return a.length ? a.join("!") : void 0
        }, !1)
    };
    var Rs = {
        U: {
            yk: 1,
            fj: 2,
            uk: 3,
            Pk: 4,
            vk: 5,
            od: 6,
            Ok: 7,
            nq: 8,
            Ym: 9,
            wk: 10,
            xk: 11,
            Gh: 12,
            om: 13,
            jm: 14,
            lm: 15,
            im: 16,
            km: 17,
            hm: 18,
            Do: 19,
            Yp: 20,
            Zp: 21,
            Zi: 22
        }
    };
    Rs.U[Rs.U.yk] = "ALLOW_INTEREST_GROUPS";
    Rs.U[Rs.U.fj] = "SERVER_CONTAINER_URL";
    Rs.U[Rs.U.uk] = "ADS_DATA_REDACTION";
    Rs.U[Rs.U.Pk] = "CUSTOMER_LIFETIME_VALUE";
    Rs.U[Rs.U.vk] = "ALLOW_CUSTOM_SCRIPTS";
    Rs.U[Rs.U.od] = "ANY_COOKIE_PARAMS";
    Rs.U[Rs.U.Ok] = "COOKIE_EXPIRES";
    Rs.U[Rs.U.nq] = "LEGACY_ENHANCED_CONVERSION_JS_VARIABLE";
    Rs.U[Rs.U.Ym] = "RESTRICTED_DATA_PROCESSING";
    Rs.U[Rs.U.wk] = "ALLOW_DISPLAY_FEATURES";
    Rs.U[Rs.U.xk] = "ALLOW_GOOGLE_SIGNALS";
    Rs.U[Rs.U.Gh] = "GENERATED_TRANSACTION_ID";
    Rs.U[Rs.U.om] = "FLOODLIGHT_COUNTING_METHOD_UNKNOWN";
    Rs.U[Rs.U.jm] = "FLOODLIGHT_COUNTING_METHOD_STANDARD";
    Rs.U[Rs.U.lm] = "FLOODLIGHT_COUNTING_METHOD_UNIQUE";
    Rs.U[Rs.U.im] = "FLOODLIGHT_COUNTING_METHOD_PER_SESSION";
    Rs.U[Rs.U.km] = "FLOODLIGHT_COUNTING_METHOD_TRANSACTIONS";
    Rs.U[Rs.U.hm] = "FLOODLIGHT_COUNTING_METHOD_ITEMS_SOLD";
    Rs.U[Rs.U.Do] = "ADS_OGT_V1_USAGE";
    Rs.U[Rs.U.Yp] = "FORM_INTERACTION_PERMISSION_DENIED";
    Rs.U[Rs.U.Zp] = "FORM_SUBMIT_PERMISSION_DENIED";
    Rs.U[Rs.U.Zi] = "MICROTASK_NOT_SUPPORTED";
    var Ss = {},
        Ts = (Ss[K.m.xi] = Rs.U.yk, Ss[K.m.Id] = Rs.U.fj, Ss[K.m.Wc] = Rs.U.fj, Ss[K.m.La] = Rs.U.uk, Ss[K.m.Ae] = Rs.U.Pk, Ss[K.m.xf] = Rs.U.vk, Ss[K.m.yd] = Rs.U.od, Ss[K.m.hb] = Rs.U.od, Ss[K.m.Lb] = Rs.U.od, Ss[K.m.xd] = Rs.U.od, Ss[K.m.zc] = Rs.U.od, Ss[K.m.Xb] = Rs.U.od, Ss[K.m.Cb] = Rs.U.Ok, Ss[K.m.Zb] = Rs.U.Ym, Ss[K.m.fh] = Rs.U.wk, Ss[K.m.yc] = Rs.U.xk, Ss),
        Us = {},
        Vs = (Us.unknown = Rs.U.om, Us.standard = Rs.U.jm, Us.unique = Rs.U.lm, Us.per_session = Rs.U.im, Us.transactions = Rs.U.km, Us.items_sold = Rs.U.hm, Us);
    var Ws = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            vb("GTAG_EVENT_FEATURE_CHANNEL", b);
            c && (a.D[b] = !0)
        },
        zb = new function() {
            this.D = []
        };

    function Xs(a, b) {
        var c = b === void 0 ? !1 : b,
            d = zb;
        c = c === void 0 ? !1 : c;
        for (var e = Object.keys(a), f = m(Object.keys(Ts)), g = f.next(); !g.done; g = f.next()) {
            var h = g.value;
            e.includes(h) && Ws(d, Ts[h], c)
        }
    };

    function Ys(a, b) {
        return arguments.length === 1 ? Zs("set", a) : Zs("set", a, b)
    }

    function $s(a, b) {
        return arguments.length === 1 ? Zs("config", a) : Zs("config", a, b)
    }

    function at(a, b, c) {
        c = c || {};
        c[K.m.Hd] = a;
        return Zs("event", b, c)
    }

    function Zs() {
        return arguments
    };
    var bt = function(a, b, c, d, e, f, g, h, l, n, p) {
            this.eventId = a;
            this.priorityId = b;
            this.D = c;
            this.V = d;
            this.J = e;
            this.T = f;
            this.O = g;
            this.eventMetadata = h;
            this.onSuccess = l;
            this.onFailure = n;
            this.isGtmEvent = p
        },
        ct = function(a, b) {
            var c = [];
            switch (b) {
                case 3:
                    c.push(a.D);
                    c.push(a.V);
                    c.push(a.J);
                    c.push(a.T);
                    c.push(a.O);
                    break;
                case 2:
                    c.push(a.D);
                    break;
                case 1:
                    c.push(a.V);
                    c.push(a.J);
                    c.push(a.T);
                    c.push(a.O);
                    break;
                case 4:
                    c.push(a.D), c.push(a.V), c.push(a.J), c.push(a.T)
            }
            return c
        },
        O = function(a, b, c, d) {
            for (var e = m(ct(a, d === void 0 ? 3 :
                    d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                if (g[b] !== void 0) return g[b]
            }
            return c
        },
        dt = function(a) {
            for (var b = {}, c = ct(a, 4), d = m(c), e = d.next(); !e.done; e = d.next())
                for (var f = Object.keys(e.value), g = m(f), h = g.next(); !h.done; h = g.next()) b[h.value] = 1;
            return Object.keys(b)
        };
    bt.prototype.getMergedValues = function(a, b, c) {
        function d(n) {
            Id(n) && Lb(n, function(p, q) {
                f = !0;
                e[p] = q
            })
        }
        b = b === void 0 ? 3 : b;
        var e = {},
            f = !1;
        c && d(c);
        var g = ct(this, b);
        g.reverse();
        for (var h = m(g), l = h.next(); !l.done; l = h.next()) d(l.value[a]);
        return f ? e : void 0
    };
    var et = function(a) {
            for (var b = [K.m.Hf, K.m.Df, K.m.Ef, K.m.Ff, K.m.Gf, K.m.If, K.m.Jf], c = ct(a, 3), d = m(c), e = d.next(); !e.done; e = d.next()) {
                for (var f = e.value, g = {}, h = !1, l = m(b), n = l.next(); !n.done; n = l.next()) {
                    var p = n.value;
                    f[p] !== void 0 && (g[p] = f[p], h = !0)
                }
                var q = h ? g : void 0;
                if (q) return q
            }
            return {}
        },
        ft = function(a, b) {
            this.eventId = a;
            this.priorityId = b;
            this.J = {};
            this.V = {};
            this.D = {};
            this.O = {};
            this.fa = {};
            this.T = {};
            this.eventMetadata = {};
            this.isGtmEvent = !1;
            this.onSuccess = function() {};
            this.onFailure = function() {}
        },
        gt = function(a,
            b) {
            a.J = b;
            return a
        },
        ht = function(a, b) {
            a.V = b;
            return a
        },
        it = function(a, b) {
            a.D = b;
            return a
        },
        jt = function(a, b) {
            a.O = b;
            return a
        },
        kt = function(a, b) {
            a.fa = b;
            return a
        },
        lt = function(a, b) {
            a.T = b;
            return a
        },
        mt = function(a, b) {
            a.eventMetadata = b || {};
            return a
        },
        nt = function(a, b) {
            a.onSuccess = b;
            return a
        },
        ot = function(a, b) {
            a.onFailure = b;
            return a
        },
        pt = function(a, b) {
            a.isGtmEvent = b;
            return a
        };
    ft.prototype.tb = function() {
        return new bt(this.eventId, this.priorityId, this.J, this.V, this.D, this.O, this.T, this.eventMetadata, this.onSuccess, this.onFailure, this.isGtmEvent)
    };

    function qt(a, b) {
        Lb(a, function(c) {
            var d;
            if (d = c.charAt(0) === "_") {
                var e;
                a: switch (c) {
                    case K.m.Yb:
                    case K.m.Mf:
                        e = !0;
                        break a;
                    default:
                        e = !1
                }
                d = !e
            }
            d && (b && b(c), delete a[c])
        })
    };
    var rt = new Kb,
        st = {},
        tt = {},
        wt = {
            name: E(19),
            set: function(a, b) {
                Jd(ac(a, b), st);
                ut()
            },
            get: function(a) {
                return vt(a, 2)
            },
            reset: function() {
                rt = new Kb;
                st = {};
                ut()
            }
        };

    function vt(a, b) {
        return b != 2 ? rt.get(a) : xt(a)
    }

    function xt(a, b) {
        var c = a.split(".");
        b = b || [];
        for (var d = st, e = 0; e < c.length; e++) {
            if (d === null) return !1;
            if (d === void 0) break;
            d = d[c[e]];
            if (b.indexOf(d) !== -1) return
        }
        return d
    }

    function zt(a, b) {
        tt.hasOwnProperty(a) || (rt.set(a, b), Jd(ac(a, b), st), ut())
    }

    function At() {
        for (var a = ["gtm.allowlist", "gtm.blocklist", "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"], b = 0; b < a.length; b++) {
            var c = a[b],
                d = vt(c, 1);
            if (Array.isArray(d) || Id(d)) d = Jd(d, null);
            tt[c] = d
        }
    }

    function ut(a) {
        Lb(tt, function(b, c) {
            rt.set(b, c);
            Jd(ac(b), st);
            Jd(ac(b, c), st);
            a && delete tt[b]
        })
    }

    function Bt(a, b) {
        var c, d = (b === void 0 ? 2 : b) !== 1 ? xt(a) : rt.get(a);
        Gd(d) === "array" || Gd(d) === "object" ? c = Jd(d, null) : c = d;
        return c
    };
    var Ct = {
            Co: Cg(3, 0)
        },
        Dt = [],
        Et = !1;

    function Ft(a) {
        Dt.push(a)
    }
    var Gt = void 0,
        Ht = {},
        It = void 0,
        Jt = new function() {
            var a = 5;
            Ct.Co > 0 && (a = Ct.Co);
            this.J = a;
            this.D = 0;
            this.O = []
        },
        Kt = 1E3;

    function Lt(a, b) {
        var c = Gt;
        if (c === void 0)
            if (b) c = ws();
            else return "";
        for (var d = [ek("https://" + E(21)), "/a", "?id=" + E(5)], e = m(Dt), f = e.next(); !f.done; f = e.next())
            for (var g = f.value, h = g({
                    eventId: c,
                    me: !!a
                }), l = m(h), n = l.next(); !n.done; n = l.next()) {
                var p = m(n.value),
                    q = p.next().value,
                    r = p.next().value;
                d.push("&" + q + "=" + r)
            }
        d.push("&z=0");
        return d.join("")
    }

    function Mt() {
        if (tj.J && (It && (w.clearTimeout(It), It = void 0), Gt !== void 0 && Nt)) {
            var a = Km(km.ba.Gc);
            if (Gm(a)) Et || (Et = !0, Im(a, Mt));
            else {
                var b;
                if (!(b = Ht[Gt])) {
                    var c = Jt;
                    b = c.D < c.J ? !1 : Tb() - c.O[c.D % c.J] < 1E3
                }
                if (b || Kt-- <= 0) Q(1), Ht[Gt] = !0;
                else {
                    var d = Jt,
                        e = d.D++ % d.J;
                    d.O[e] = Tb();
                    var f = Lt(!0);
                    em({
                        destinationId: E(5),
                        endpoint: 56,
                        eventId: Gt
                    }, f);
                    Et = Nt = !1
                }
            }
        }
    }

    function Ot() {
        if (ll && tj.J) {
            var a = Lt(!0, !0);
            em({
                destinationId: E(5),
                endpoint: 56,
                eventId: Gt
            }, a)
        }
    }
    var Nt = !1;

    function Pt(a) {
        Ht[a] || (a !== Gt && (Mt(), Gt = a), Nt = !0, It || (It = w.setTimeout(Mt, 500)), Lt().length >= 2022 && Mt())
    }
    var Qt = Hb();

    function Rt() {
        Qt = Hb()
    }

    function St() {
        var a = [
                ["v", "3"],
                ["t", "t"],
                ["pid", String(Qt)]
            ],
            b = Xk();
        b && a.push(["gtm", b]);
        return a
    };
    var Tt = {};

    function Ut(a, b, c) {
        ll && a !== void 0 && (Tt[a] = Tt[a] || [], Tt[a].push(c + b), Pt(a))
    }

    function Vt(a) {
        var b = a.eventId,
            c = a.me,
            d = [],
            e = Tt[b] || [];
        e.length && d.push(["epr", e.join(".")]);
        c && delete Tt[b];
        return d
    };
    var Wt = !1;

    function Xt(a, b, c, d) {
        var e = Cs(c, d.isGtmEvent);
        e && (Wt && (d.deferrable = !0), Yt.push("event", [b, a], e, d))
    }

    function Zt(a, b, c, d) {
        var e = Cs(c, d.isGtmEvent);
        e && Yt.push("get", [a, b], e, d)
    }

    function $t(a, b, c) {
        var d = Cs(a, c.isGtmEvent);
        d && Yt.push("container_config", [b], d, c)
    }

    function au(a, b, c) {
        var d = Cs(a, c.isGtmEvent);
        d && Yt.push("destination_config", [b], d, c)
    }

    function bu(a) {
        var b = Cs(a, !0);
        b && Yt.push("reset_container_config", [], b, {})
    }

    function cu(a) {
        var b = Cs(a, !0);
        b && Yt.push("reset_target_config", [], b, {})
    }

    function du(a) {
        var b = Cs(a, !0),
            c;
        b ? c = eu(Yt, b).T : c = {};
        return c
    }
    var fu = function() {
            this.D = {};
            this.T = {};
            this.V = {};
            this.fa = null;
            this.O = {};
            this.J = !1;
            this.status = 1
        },
        gu = function(a, b, c, d) {
            this.J = Tb();
            this.D = b;
            this.args = c;
            this.messageContext = d;
            this.type = a
        };

    function hu(a, b) {
        var c = {};
        Lb(a, function(d, e) {
            Jd(ac(d, e), c)
        });
        P(411) && qt(c, b);
        return c
    }
    var iu = function() {
            this.destinations = {};
            this.D = {};
            this.commands = []
        },
        eu = function(a, b) {
            return a.destinations[b.destinationId] = a.destinations[b.destinationId] || new fu
        },
        ju = function(a, b, c, d) {
            if (d.D) {
                var e = eu(a, d.D),
                    f = e.fa;
                if (f) {
                    var g = Jd(c, null),
                        h = Jd(e.D[d.D.destinationId], null),
                        l = Jd(e.O, null),
                        n = Jd(e.T, null),
                        p = Jd(a.D, null),
                        q = {};
                    if (ll) try {
                        q = Jd(st, null)
                    } catch (x) {
                        Q(72)
                    }
                    var r = d.D.prefix,
                        t = function(x) {
                            Ut(d.messageContext.eventId, r, x)
                        },
                        u = pt(ot(nt(mt(kt(jt(lt(it(ht(gt(new ft(d.messageContext.eventId, d.messageContext.priorityId),
                            g), h), l), n), p), q), d.messageContext.eventMetadata), function() {
                            if (t) {
                                var x = t;
                                t = void 0;
                                x("2");
                                if (d.messageContext.onSuccess) d.messageContext.onSuccess()
                            }
                        }), function() {
                            if (t) {
                                var x = t;
                                t = void 0;
                                x("3");
                                if (d.messageContext.onFailure) d.messageContext.onFailure()
                            }
                        }), !!d.messageContext.isGtmEvent).tb(),
                        v = function() {
                            try {
                                Ut(d.messageContext.eventId, r, "1");
                                var x = d.D.id;
                                if (nl && b === K.m.na) {
                                    var y, z = (y = Cs(x)) == null ? void 0 : y.ids;
                                    if (!(z && z.length > 1)) {
                                        var C, D = Vc("google_tag_data", {});
                                        D.td || (D.td = {});
                                        C = D.td;
                                        var G = Jd(u.T);
                                        Jd(u.D, G);
                                        var J = [],
                                            L;
                                        for (L in C) C.hasOwnProperty(L) && Ps(C[L], G).length && J.push(L);
                                        J.length && (Ns(x, J), vb("TAGGING", Js[A.readyState] || 14));
                                        C[x] = G
                                    }
                                }
                                f(d.D.id, b, d.J, u)
                            } catch (da) {
                                Ut(d.messageContext.eventId, r, "4")
                            }
                        };
                    b === "gtag.get" ? v() : Im(e.ma, v)
                }
            }
        },
        ku = function(a, b) {
            if (b.type !== "require") {
                var c = void 0;
                b.type === "event" && (c = b.args[1]);
                if (b.D)
                    for (var d = eu(a, b.D).V[b.type] || [], e = 0; e < d.length; e++) d[e](c);
                else
                    for (var f in a.destinations)
                        if (a.destinations.hasOwnProperty(f)) {
                            var g = a.destinations[f];
                            if (g && g.V)
                                for (var h =
                                        g.V[b.type] || [], l = 0; l < h.length; l++) h[l](c)
                        }
            }
        };
    iu.prototype.register = function(a, b, c, d) {
        var e = eu(this, a);
        e.status !== 3 && (e.fa = b, e.status = 3, e.ma = Km(c), lu(this, a, d || {}), this.flush())
    };
    iu.prototype.push = function(a, b, c, d) {
        c !== void 0 && (eu(this, c).status === 1 && (eu(this, c).status = 2, this.push("require", [{}], c, {})), eu(this, c).J && (d.deferrable = !1), d.eventMetadata || (d.eventMetadata = {}), d.eventMetadata[S.C.rg] || (d.eventMetadata[S.C.rg] = [c.destinationId]), d.eventMetadata[S.C.ej] || (d.eventMetadata[S.C.ej] = [c.id]));
        this.commands.push(new gu(a, c, b, d));
        d.deferrable || this.flush()
    };
    iu.prototype.flush = function(a) {
        for (var b = this, c = [], d = !1, e = {}; this.commands.length; e = {
                Jn: void 0
            }) {
            var f = this.commands[0],
                g = f.D;
            if (f.messageContext.deferrable) !g || eu(this, g).J ? (f.messageContext.deferrable = !1, this.commands.push(f)) : c.push(f), this.commands.shift();
            else {
                switch (f.type) {
                    case "require":
                        if (eu(this, g).status !== 3 && !a) {
                            this.commands.push.apply(this.commands, c);
                            return
                        }
                        break;
                    case "set":
                        var h = f.args[0];
                        P(411) && qt(h);
                        Lb(h, function(C, D) {
                            Jd(ac(C, D), b.D)
                        });
                        Xs(h, !0);
                        break;
                    case "config":
                        var l = eu(this,
                                g),
                            n = hu(f.args[0], function() {}),
                            p = !!n[K.m.Nb];
                        delete n[K.m.Nb];
                        var q = g.destinationId === g.id;
                        Xs(n, !0);
                        p || (q ? l.O = {} : l.D[g.id] = {});
                        l.J && p || ju(this, K.m.na, n, f);
                        l.J = !0;
                        q ? Jd(n, l.O) : (Jd(n, l.D[g.id]), Q(70));
                        d = !0;
                        break;
                    case "event":
                        e.Jn = f.args[1];
                        var r = hu(f.args[0], function() {
                            return function() {}
                        }(e));
                        Xs(r);
                        ju(this, e.Jn, r, f);
                        break;
                    case "get":
                        var t = {},
                            u = (t[K.m.Pf] = f.args[0], t[K.m.Of] = f.args[1], t);
                        ju(this, K.m.Jb, u, f);
                        break;
                    case "container_config":
                        var v = eu(this, g),
                            x = hu(f.args[0], function() {});
                        Xs(x, !0);
                        v.J = !0;
                        Jd(x, v.O);
                        d = !0;
                        break;
                    case "destination_config":
                        var y = eu(this, g),
                            z = hu(f.args[0], function() {});
                        Xs(z, !0);
                        y.D[g.id] || (y.D[g.id] = {});
                        y.J = !0;
                        Jd(z, y.D[g.id]);
                        d = !0;
                        break;
                    case "reset_container_config":
                        eu(this, g).O = {};
                        break;
                    case "reset_target_config":
                        eu(this, g).D[g.id] = {}
                }
                this.commands.shift();
                ku(this, f)
            }
        }
        this.commands.push.apply(this.commands, c);
        d && this.flush()
    };
    var lu = function(a, b, c) {
            var d = Jd(c, null);
            Jd(eu(a, b).T, d);
            eu(a, b).T = d
        },
        Yt = new iu;

    function mu(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };

    function nu(a, b, c) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, !1), !0) : !1
    }

    function ou(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
    };

    function pu(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = Oo("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Nc(g, e);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                ou(e, "load", f);
                ou(e, "error", f)
            };
            nu(e, "load", f);
            nu(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function qu(a) {
        var b;
        b = b === void 0 ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
        Ko(a, function(d, e) {
            if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d))
        });
        ru(c, b)
    }

    function ru(a, b) {
        var c = window,
            d;
        b = b === void 0 ? !1 : b;
        d = d === void 0 ? !1 : d;
        if (c.fetch) {
            var e = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            };
            d && (e.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? e.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : e.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            });
            c.fetch(a, e)
        } else pu(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d)
    };
    var su = function() {
        this.fa = this.fa;
        this.T = this.T
    };
    su.prototype.fa = !1;
    su.prototype.dispose = function() {
        this.fa || (this.fa = !0, this.O())
    };
    su.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    su.prototype.addOnDisposeCallback = function(a, b) {
        this.fa ? b !== void 0 ? a.call(b) : a() : (this.T || (this.T = []), b && (a = a.bind(b)), this.T.push(a))
    };
    su.prototype.O = function() {
        if (this.T)
            for (; this.T.length;) this.T.shift()()
    };

    function tu(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }
    var uu = function(a, b) {
        b = b === void 0 ? {} : b;
        su.call(this);
        this.D = null;
        this.ma = {};
        this.Ta = 0;
        this.V = null;
        this.J = a;
        var c;
        this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
        var d;
        this.vj = (d = b.vj) != null ? d : !1
    };
    xa(uu, su);
    uu.prototype.O = function() {
        this.ma = {};
        this.V && (ou(this.J, "message", this.V), delete this.V);
        delete this.ma;
        delete this.J;
        delete this.D;
        su.prototype.O.call(this)
    };
    var wu = function(a) {
        return typeof a.J.__tcfapi === "function" || vu(a) != null
    };
    uu.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.vj
            },
            d = Jo(function() {
                a(c)
            }),
            e = 0;
        this.timeoutMs !== -1 && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.timeoutMs));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = tu(c), c.internalBlockOnErrors = b.vj, h && c.internalErrorState === 0 || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            xu(this, "addEventListener",
                f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    uu.prototype.removeEventListener = function(a) {
        a && a.listenerId && xu(this, "removeEventListener", null, a.listenerId)
    };
    var zu = function(a, b, c) {
            var d;
            d = d === void 0 ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (f !== void 0) {
                        e = f[d === void 0 ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var g = e;
            if (g === 0) return !1;
            var h = c;
            c === 2 ? (h = 0, g === 2 && (h = 1)) : c === 3 && (h = 1, g === 1 && (h = 0));
            var l;
            if (h === 0)
                if (a.purpose && a.vendor) {
                    var n = yu(a.vendor.consents, d === void 0 ? "755" : d);
                    l = n && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : n && yu(a.purpose.consents, b)
                } else l = !0;
            else l = h === 1 ? a.purpose && a.vendor ? yu(a.purpose.legitimateInterests,
                b) && yu(a.vendor.legitimateInterests, d === void 0 ? "755" : d) : !0 : !0;
            return l
        },
        yu = function(a, b) {
            return !(!a || !a[b])
        },
        xu = function(a, b, c, d) {
            c || (c = function() {});
            var e = a.J;
            if (typeof e.__tcfapi === "function") {
                var f = e.__tcfapi;
                f(b, 2, c, d)
            } else if (vu(a)) {
                Au(a);
                var g = ++a.Ta;
                a.ma[g] = c;
                if (a.D) {
                    var h = {};
                    a.D.postMessage((h.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: g,
                        parameter: d
                    }, h), "*")
                }
            } else c({}, !1)
        },
        vu = function(a) {
            if (a.D) return a.D;
            a.D = Mo(a.J, "__tcfapiLocator");
            return a.D
        },
        Au = function(a) {
            if (!a.V) {
                var b = function(c) {
                    try {
                        var d;
                        d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                        a.ma[d.callId](d.returnValue, d.success)
                    } catch (e) {}
                };
                a.V = b;
                nu(a.J, "message", b)
            }
        },
        Bu = function(a) {
            if (a.gdprApplies === !1) return !0;
            a.internalErrorState === void 0 && (a.internalErrorState = tu(a));
            return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (qu({
                e: String(a.internalErrorState)
            }), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
        };
    var Cu = {
        1: 0,
        3: 0,
        4: 0,
        7: 3,
        9: 3,
        10: 3
    };
    Cg(32, 500);

    function Du() {
        return rs("tcf", function() {
            return {}
        })
    }
    var Eu = function() {
        return new uu(w, {
            timeoutMs: -1
        })
    };

    function Fu() {
        var a = Du(),
            b = Eu();
        wu(b) && !Gu() && !Hu() && Q(124);
        if (!a.active && wu(b)) {
            Gu() && (a.active = !0, a.purposes = {}, a.cmpId = 0, a.tcfPolicyVersion = 0, lm().active = !0, a.tcString = "tcunavailable");
            Bo();
            try {
                b.addEventListener(function(c) {
                    if (c.internalErrorState !== 0) Iu(a), Co([K.m.X, K.m.Ka, K.m.aa]), lm().active = !0;
                    else if (a.gdprApplies = c.gdprApplies, a.cmpId = c.cmpId, a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode, Hu() && (a.active = !0), !Ju(c) || Gu() || Hu()) {
                        a.tcfPolicyVersion = c.tcfPolicyVersion;
                        var d;
                        if (c.gdprApplies ===
                            !1) {
                            var e = {},
                                f;
                            for (f in Cu) Cu.hasOwnProperty(f) && (e[f] = !0);
                            d = e;
                            b.removeEventListener(c)
                        } else if (Ju(c)) {
                            var g = {},
                                h;
                            for (h in Cu)
                                if (Cu.hasOwnProperty(h))
                                    if (h === "1") {
                                        var l, n = c,
                                            p = {
                                                xr: !0
                                            };
                                        p = p === void 0 ? {} : p;
                                        l = Bu(n) ? n.gdprApplies === !1 ? !0 : n.tcString === "tcunavailable" ? !p.idpcApplies : (p.idpcApplies || n.gdprApplies !== void 0 || p.xr) && (p.idpcApplies || typeof n.tcString === "string" && n.tcString.length) ? zu(n, "1", 0) : !0 : !1;
                                        g["1"] = l
                                    } else g[h] = zu(c, h, Cu[h]);
                            d = g
                        }
                        if (d) {
                            a.tcString = c.tcString || "tcempty";
                            a.purposes = d;
                            var q = {},
                                r = (q[K.m.X] = a.purposes["1"] ? "granted" : "denied", q);
                            a.gdprApplies !== !0 ? (Co([K.m.X, K.m.Ka, K.m.aa]), lm().active = !0) : (r[K.m.Ka] = a.purposes["3"] && a.purposes["4"] ? "granted" : "denied", typeof a.tcfPolicyVersion === "number" && a.tcfPolicyVersion >= 4 ? r[K.m.aa] = a.purposes["1"] && a.purposes["7"] ? "granted" : "denied" : Co([K.m.aa]), to(r, {
                                eventId: 0
                            }, {
                                gdprApplies: a ? a.gdprApplies : void 0,
                                tcString: Ku() || ""
                            }))
                        }
                    } else Co([K.m.X, K.m.Ka, K.m.aa])
                })
            } catch (c) {
                Iu(a), Co([K.m.X, K.m.Ka, K.m.aa]), lm().active = !0
            }
        }
    }

    function Iu(a) {
        a.type = "e";
        a.tcString = "tcunavailable"
    }

    function Ju(a) {
        return a.eventStatus === "tcloaded" || a.eventStatus === "useractioncomplete" || a.eventStatus === "cmpuishown"
    }

    function Gu() {
        return w.gtag_enable_tcf_support === !0
    }

    function Hu() {
        return Du().enableAdvertiserConsentMode === !0
    }

    function Ku() {
        var a = Du();
        if (a.active) return a.tcString
    }

    function Lu() {
        var a = Du();
        if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0"
    }

    function Mu(a) {
        if (!Cu.hasOwnProperty(String(a))) return !0;
        var b = Du();
        return b.active && b.purposes ? !!b.purposes[String(a)] : !0
    };
    var Nu = [K.m.X, K.m.la, K.m.aa, K.m.Ka],
        Ou = {},
        Pu = (Ou[K.m.X] = 1, Ou[K.m.la] = 2, Ou);

    function Qu(a) {
        if (a === void 0) return 0;
        switch (O(a, K.m.Vb)) {
            case void 0:
                return 1;
            case !1:
                return 3;
            default:
                return 2
        }
    }

    function Ru() {
        return (P(183) ? Ag(16).split("~") : Ag(17).split("~")).indexOf(un()) !== -1 && Rc.globalPrivacyControl === !0
    }

    function Su(a) {
        if (Ru()) return !1;
        var b = Qu(a);
        if (b === 3) return !1;
        switch (um(K.m.Ka)) {
            case 1:
            case 3:
                return !0;
            case 2:
                return !1;
            case 4:
                return b === 2;
            case 0:
                return !0;
            default:
                return !1
        }
    }

    function Tu() {
        return wm() || !tm(K.m.X) || !tm(K.m.la)
    }

    function Uu() {
        var a = {},
            b;
        for (b in Pu) Pu.hasOwnProperty(b) && (a[Pu[b]] = um(b));
        return "G1" + Bf(a[1] || 0) + Bf(a[2] || 0)
    }
    var Vu = {},
        Wu = (Vu[K.m.X] = 0, Vu[K.m.la] = 1, Vu[K.m.aa] = 2, Vu[K.m.Ka] = 3, Vu);

    function Xu(a) {
        switch (a) {
            case void 0:
                return 1;
            case !0:
                return 3;
            case !1:
                return 2;
            default:
                return 0
        }
    }

    function Yu(a) {
        for (var b = "1", c = 0; c < Nu.length; c++) {
            var d = b,
                e, f = Nu[c],
                g = sm.delegatedConsentTypes[f];
            e = g === void 0 ? 0 : Wu.hasOwnProperty(g) ? 12 | Wu[g] : 8;
            var h = lm();
            h.accessedAny = !0;
            var l = h.entries[f] || {};
            e = e << 2 | Xu(l.implicit);
            b = d + ("" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [e] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [Xu(l.declare) << 4 | Xu(l.default) << 2 | Xu(l.update)])
        }
        var n = b,
            p = (Ru() ? 1 : 0) << 3,
            q = (wm() ? 1 : 0) << 2,
            r = Qu(a);
        b = n + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [p |
            q | r
        ];
        return b += "" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [sm.containerScopedDefaults.ad_storage << 4 | sm.containerScopedDefaults.analytics_storage << 2 | sm.containerScopedDefaults.ad_user_data] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [(sm.usedContainerScopedDefaults ? 1 : 0) << 2 | sm.containerScopedDefaults.ad_personalization]
    }

    function Zu() {
        if (!tm(K.m.aa)) return "-";
        if (P(170)) return "a";
        for (var a = Object.keys(Mn), b = {}, c = m(a), d = c.next(); !d.done; d = c.next()) {
            var e = d.value;
            b[e] = sm.corePlatformServices[e] !== !1
        }
        for (var f = "", g = m(a), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            b[l] && (f += Mn[l])
        }(sm.usedCorePlatformServices ? sm.selectedAllCorePlatformServices : 1) && (f += "o");
        return f || "-"
    }

    function $u() {
        return wn() || (Gu() || Hu()) && Lu() === "1" ? "1" : "0"
    }

    function av() {
        return (wn() ? !0 : !(!Gu() && !Hu()) && Lu() === "1") || !tm(K.m.aa)
    }

    function bv() {
        var a = "0",
            b = "0",
            c;
        var d = Du();
        c = d.active ? d.cmpId : void 0;
        typeof c === "number" && c >= 0 && c <= 4095 && (a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c >> 6 & 63], b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c & 63]);
        var e = "0",
            f;
        var g = Du();
        f = g.active ? g.tcfPolicyVersion : void 0;
        typeof f === "number" && f >= 0 && f <= 63 && (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [f]);
        var h = 0;
        wn() && (h |= 1);
        Lu() === "1" && (h |= 2);
        Gu() && (h |= 4);
        var l;
        var n = Du();
        l = n.enableAdvertiserConsentMode !==
            void 0 ? n.enableAdvertiserConsentMode ? "1" : "0" : void 0;
        l === "1" && (h |= 8);
        lm().waitPeriodTimedOut && (h |= 16);
        return "1" + a + b + e + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [h]
    }

    function cv() {
        return un() === "US-CO"
    };
    var dv = {
            Og: "value",
            jb: "conversionCount",
            Pg: 1
        },
        ev = {
            ai: 7,
            gi: 8,
            Og: "timeouts",
            jb: "timeouts",
            Pg: 0
        },
        fv = {
            ai: 11,
            gi: 12,
            Og: "eopCount",
            jb: "endOfPageCount",
            Pg: 0
        },
        gv = {
            ai: 9,
            gi: 10,
            Og: "errors",
            jb: "errors",
            Pg: 0
        },
        hv = [dv, ev, gv, fv];

    function iv(a, b) {
        b = b === void 0 ? 1 : b;
        if (!jv(a)) return {};
        var c = kv(hv),
            d = c[a.jb];
        if (d === void 0 || d === -1) return c;
        var e = {},
            f = pa(Object, "assign").call(Object, {}, c, (e[a.jb] = d + b, e));
        return lv(f) ? f : c
    }

    function kv(a) {
        var b;
        a: {
            var c = zq("gcl_ctr");
            if (c.error === 0 && c.value && typeof c.value === "object") {
                var d = c.value;
                try {
                    b = "value" in d && typeof d.value === "object" ? d.value : void 0;
                    break a
                } catch (p) {}
            }
            b = void 0
        }
        for (var e = b, f = {}, g = m(a), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            if (e && jv(l)) {
                var n = e[l.Og];
                n === void 0 || Number.isNaN(n) ? f[l.jb] = -1 : f[l.jb] = Number(n)
            } else f[l.jb] = -1
        }
        return f
    }

    function lv(a, b) {
        b = b || {};
        for (var c = Tb(), d = iq(b, c, !0), e = {}, f = m(hv), g = f.next(); !g.done; g = f.next()) {
            var h = g.value,
                l = a[h.jb];
            l !== void 0 && l !== -1 && (e[h.Og] = l)
        }
        e.creationTimeMs = c;
        return wq("gcl_ctr", {
            value: e,
            expires: Number(d.expires)
        }) === 0 ? !0 : !1
    }

    function jv(a) {
        return tm(["ad_storage", "ad_user_data"]) ? !a.gi || ib(a.gi) : !1
    }

    function mv(a) {
        return tm(["ad_storage", "ad_user_data"]) ? !a.ai || ib(a.ai) : !1
    };

    function nv(a) {
        var b = Math.round(Math.random() * 2147483647);
        return a ? String(b ^ oi(a) & 2147483647) : String(b)
    }

    function ov(a) {
        return [nv(a), Math.round(Tb() / 1E3)].join(".")
    }

    function pv(a, b, c, d, e) {
        var f = fq(b),
            g;
        return (g = Vp(a, f, gq(c), d, e)) == null ? void 0 : g.Xq
    };
    var qv = ["1"],
        rv = {},
        sv = {};

    function tv(a, b) {
        b = b === void 0 ? !0 : b;
        var c = uv(a.prefix);
        if (rv[c]) vv(a);
        else if (wv(c, a.path, a.domain)) {
            var d = sv[uv(a.prefix)] || {
                id: void 0,
                di: void 0
            };
            b && xv(a, d.id, d.di);
            vv(a)
        } else {
            var e = Uj("auiddc");
            if (e) vb("TAGGING", 17), rv[c] = e;
            else if (b) {
                var f = uv(a.prefix),
                    g = ov();
                yv(f, g, a);
                wv(c, a.path, a.domain);
                vv(a, !0)
            }
        }
    }

    function vv(a, b) {
        if ((b === void 0 ? 0 : b) && jv(dv)) {
            var c = xq(!1);
            c.error !== 0 ? vb("TAGGING", 38) : c.value ? "gcl_ctr" in c.value ? (delete c.value.gcl_ctr, yq(c) !== 0 && vb("TAGGING", 41)) : vb("TAGGING", 40) : vb("TAGGING", 39)
        }
        if (mv(dv) && kv([dv])[dv.jb] === -1) {
            for (var d = {}, e = (d[dv.jb] = 0, d), f = m(hv), g = f.next(); !g.done; g = f.next()) {
                var h = g.value;
                h !== dv && mv(h) && (e[h.jb] = 0)
            }
            lv(e, a)
        }
    }

    function xv(a, b, c) {
        var d = uv(a.prefix),
            e = rv[d];
        if (e) {
            var f = e.split(".");
            if (f.length === 2) {
                var g = Number(f[1]) || 0;
                if (g) {
                    var h = e;
                    b && (h = e + "." + b + "." + (c ? c : Math.floor(Tb() / 1E3)));
                    yv(d, h, a, g * 1E3)
                }
            }
        }
    }

    function yv(a, b, c, d) {
        var e;
        e = ["1", hq(c.domain, c.path), b].join(".");
        var f = iq(c, d);
        f.Kc = zv();
        cq(a, e, f)
    }

    function wv(a, b, c) {
        var d = pv(a, b, c, qv, zv());
        if (!d) return !1;
        Av(a, d);
        return !0
    }

    function Av(a, b) {
        var c = b.split(".");
        c.length === 5 ? (rv[a] = c.slice(0, 2).join("."), sv[a] = {
            id: c.slice(2, 4).join("."),
            di: Number(c[4]) || 0
        }) : c.length === 3 ? sv[a] = {
            id: c.slice(0, 2).join("."),
            di: Number(c[2]) || 0
        } : rv[a] = b
    }

    function uv(a) {
        return (a || "_gcl") + "_au"
    }

    function Bv(a) {
        function b() {
            tm(c) && a()
        }
        var c = zv();
        zm(function() {
            b();
            tm(c) || Am(b, c)
        }, c)
    }

    function Cv(a) {
        var b = mp(!0),
            c = uv(a.prefix);
        Bv(function() {
            var d = b[c];
            if (d) {
                Av(c, d);
                var e = Number(rv[c].split(".")[1]) * 1E3;
                if (e) {
                    vb("TAGGING", 16);
                    var f = iq(a, e);
                    f.Kc = zv();
                    var g = ["1", hq(a.domain, a.path), d].join(".");
                    cq(c, g, f)
                }
            }
        })
    }

    function Dv(a, b, c, d, e) {
        e = e || {};
        var f = function() {
            var g = {},
                h = pv(a, e.path, e.domain, qv, zv());
            h && (g[a] = h);
            return g
        };
        Bv(function() {
            tp(f, b, c, d)
        })
    }

    function zv() {
        return ["ad_storage", "ad_user_data"]
    };

    function Pv(a, b) {
        var c = Vr(a, K.m.Db);
        if (c && typeof c === "object")
            for (var d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
                var f = e.value,
                    g = c[f];
                g !== void 0 && (g === null && (g = ""), b["gap." + f] = String(g))
            }
    };

    function $v(a, b) {
        var c = !!Xj();
        switch (a) {
            case 45:
                return "https://www.google.com/ccm/collect";
            case 46:
                return c ? Yj() + "/gs/ccm/collect" : "https://pagead2.googlesyndication.com/ccm/collect";
            case 69:
                return "https://ad.doubleclick.net/ccm/s/collect";
            case 51:
                return "https://www.google.com/travel/flights/click/conversion";
            case 9:
                return "https://googleads.g.doubleclick.net/pagead/viewthroughconversion";
            case 68:
                return "https://www.google.com/rmkt/collect";
            case 17:
                return c && !xn() ? "" + Yj() + "/ag/g/c" : Yv();
            case 16:
                return c &&
                    !xn() ? "" + Yj() + "/ga/g/c" : Zv();
            case 67:
                var d;
                d = d === void 0 ? "g/collect" : d;
                return xn() ? "" : "https://www.google.com/" + d;
            case 55:
                return xn() ? Zv("measurement/conversion") : c ? Yj() + "/gs/measurement/conversion" : "https://pagead2.googlesyndication.com/measurement/conversion";
            case 54:
                return xn() ? Yv("measurement/conversion") : c ? Yj() + "/g/measurement/conversion" : "https://www.google.com/measurement/conversion";
            case 1:
                return "https://ad.doubleclick.net/activity;";
            case 2:
                return (c ? Yj() : "https://ade.googlesyndication.com") +
                    "/ddm/activity" + (P(467) ? ";" : "/");
            case 33:
                return "https://ad.doubleclick.net/activity;register_conversion=1;";
            case 11:
                return c ? Yj() + "/d/pagead/form-data" : P(141) ? "https://www.google.com/pagead/form-data" : "https://google.com/pagead/form-data";
            case 3:
                return "https://" + b.Kq + ".fls.doubleclick.net/activityi;";
            case 5:
                return "https://www.googleadservices.com/pagead/conversion";
            case 6:
                return c ? Yj() + "/gs/pagead/conversion" : "https://pagead2.googlesyndication.com/pagead/conversion";
            case 66:
                return "https://www.google.com/pagead/uconversion";
            case 8:
                return "https://www.google.com/pagead/1p-conversion";
            case 63:
                return "https://www.googleadservices.com/pagead/conversion";
            case 64:
                return c ? Yj() + "/gs/pagead/conversion" : "https://pagead2.googlesyndication.com/pagead/conversion";
            case 65:
                return "https://www.google.com/pagead/1p-conversion";
            case 22:
                return c ? Yj() + "/as/d/ccm/conversion" : "https://www.googleadservices.com/ccm/conversion";
            case 60:
                return c ? Yj() + "/gs/ccm/conversion" : "https://pagead2.googlesyndication.com/ccm/conversion";
            case 23:
                return c ? Yj() +
                    "/g/d/ccm/conversion" : "https://www.google.com/ccm/conversion";
            case 21:
                return c ? Yj() + "/d/ccm/form-data" : P(141) ? "https://www.google.com/ccm/form-data" : "https://google.com/ccm/form-data";
            case 7:
            case 52:
            case 53:
            case 39:
            case 38:
            case 40:
            case 37:
            case 49:
            case 48:
            case 14:
            case 24:
            case 19:
            case 27:
            case 30:
            case 36:
            case 62:
            case 26:
            case 29:
            case 32:
            case 35:
            case 57:
            case 58:
            case 50:
            case 12:
            case 13:
            case 20:
            case 18:
            case 59:
            case 47:
            case 15:
            case 0:
            case 61:
            case 56:
            case 25:
            case 28:
            case 31:
            case 34:
                throw Error("Unsupported endpoint");
            default:
                Gc(a, "Unknown endpoint")
        }
    };
    var aw = [K.m.X, K.m.aa];
    var bw = Object.freeze({
        gcp: 1,
        sscte: 1,
        ct_cookie_present: 1
    });

    function cw(a, b) {
        return $v(a) + "/" + b + "/"
    }

    function dw(a, b) {
        var c, d = (c = T(a, S.C.Om)) == null ? void 0 : c[b.jb];
        return d !== void 0 && d >= b.Pg
    };

    function ew(a, b, c) {
        var d = b.F;
        go({
            targetId: b.target.destinationId,
            request: {
                url: a,
                parameterEncoding: 3,
                endpoint: c
            },
            cb: {
                eventId: d.eventId,
                priorityId: d.priorityId
            },
            Th: {
                eventId: T(b, S.C.lf),
                priorityId: T(b, S.C.nf)
            }
        })
    };

    function fw(a) {
        return vo(aw) ? T(a, S.C.Pd) ? T(a, S.C.Pa) ? 65 : 63 : T(a, S.C.Pa) ? 8 : 5 : 6
    }

    function gw(a, b, c) {
        return {
            baseUrl: cw(9, b),
            Gb: a,
            format: c != null ? c : 3,
            mb: !0,
            endpoint: 9
        }
    }

    function hw(a, b, c, d) {
        var e = T(a, S.C.qb),
            f = b.data || "";
        return d.map(function(g, h) {
            var l, n = Uv(g);
            l = "" + f + (f && n ? ";" : "") + n;
            var p = e + h,
                q = gw(b, c);
            q.nc = pa(Object, "assign").call(Object, {}, q.nc, {
                random: p,
                data: l
            });
            return q
        })
    }
    var iw = {},
        jw = (iw[M.N.li] = void 0, iw[M.N.oe] = function(a, b, c) {
                if (T(a, S.C.dj)) {
                    var d = vo(aw) ? T(a, S.C.Pa) ? 23 : 22 : 60,
                        e = {};
                    T(a, S.C.Wi) && (e.item = void 0);
                    T(a, S.C.Pa) && pa(Object, "assign").call(Object, e, bw);
                    var f = cw(d, c),
                        g = fk(f);
                    g && (e._uip = g);
                    return {
                        baseUrl: f,
                        Gb: b,
                        nc: e,
                        format: 2,
                        mb: !0,
                        endpoint: d
                    }
                }
            }, iw[M.N.ni] = void 0, iw[M.N.Ca] = function(a, b, c) {
                var d = vo(aw),
                    e = T(a, S.C.Pa) ? pa(Object, "assign").call(Object, {}, bw) : {},
                    f = {};
                if (Xj() && P(148) && vo(aw)) e.exp_1p = 1, f.exp_ph = 1;
                else {
                    var g = T(a, S.C.Oh);
                    g && (e["gap.shw"] = 1, e["gap.shw_rnd"] =
                        g, f.exp_ph = 1)
                }
                var h;
                d && T(a, S.C.Vi) ? (h = 8, pa(Object, "assign").call(Object, f, bw)) : !d && P(263) && (h = 66, f.gcp = 4);
                var l = fw(a),
                    n = cw(l, c),
                    p;
                if (d)
                    if (P(37)) {
                        var q = !T(a, S.C.Pa);
                        p = sd() ? q ? 5 : 4 : 2
                    } else p = 3;
                else p = P(162) ? sd() ? 4 : 2 : 3;
                var r = {
                    baseUrl: n,
                    Gb: b,
                    nc: e,
                    format: p,
                    mb: !0,
                    endpoint: l
                };
                vo(K.m.aa) && (r.attributes = {
                    attributionsrc: ""
                });
                h !== void 0 && (r.Ye = pa(Object, "assign").call(Object, {}, r, {
                    baseUrl: cw(h, c),
                    Gb: b,
                    nc: f,
                    format: 4,
                    endpoint: h
                }));
                if (T(a, S.C.Pd) ? 0 : dw(a, gv)) r.options = {
                    Rr: !0
                };
                return r
            }, iw[M.N.Eh] = void 0, iw[M.N.Me] =
            function(a, b) {
                var c = vo(aw) ? 54 : 55;
                return {
                    baseUrl: $v(c),
                    Gb: b,
                    format: 4,
                    mb: !0,
                    endpoint: c
                }
            }, iw[M.N.Md] = function(a, b, c) {
                if (T(a, S.C.Pa) && vo(aw)) {
                    var d = sd() ? 4 : 2,
                        e = gw(pa(Object, "assign").call(Object, {}, b, {
                            gcp: "1",
                            ct_cookie_present: 1
                        }), c, d);
                    d === 4 && (e.Ye = pa(Object, "assign").call(Object, {}, e, {
                        format: 2
                    }));
                    return e
                }
            }, iw[M.N.Yi] = void 0, iw[M.N.Ha] = void 0, iw[M.N.Re] = function(a, b, c) {
                if (Xj() && P(148) && vo(aw)) {
                    var d = fw(a),
                        e = {
                            random: T(a, S.C.qb) + 1,
                            adtest: "on",
                            exp_1p: "1"
                        };
                    T(a, S.C.Pa) && pa(Object, "assign").call(Object, e, bw);
                    var f;
                    a: {
                        switch (d) {
                            case 5:
                            case 63:
                                f = Yj() + "/as/d/pagead/conversion";
                                break a;
                            case 6:
                                f = Yj() + "/gs/pagead/conversion";
                                break a;
                            case 8:
                            case 65:
                                f = Yj() + "/g/d/pagead/1p-conversion";
                                break a;
                            default:
                                Gc(d, "Unknown endpoint")
                        }
                        f = void 0
                    }
                    return {
                        baseUrl: f + "/" + c + "/",
                        Gb: b,
                        nc: e,
                        format: 3,
                        mb: !0,
                        endpoint: d
                    }
                }
            }, iw[M.N.Se] = function(a, b, c) {
                var d = T(a, S.C.Oh);
                if (d) {
                    var e = fw(a),
                        f = {
                            adtest: "on",
                            "gap.shw": "1",
                            "gap.shw_rnd": d
                        };
                    T(a, S.C.Pa) && pa(Object, "assign").call(Object, f, bw);
                    return {
                        baseUrl: cw(e, c),
                        Gb: b,
                        nc: f,
                        format: 6,
                        mb: !0,
                        endpoint: e
                    }
                }
            },
            iw[M.N.Eb] = function(a, b, c) {
                var d = Qv(Rv(a));
                return d.length ? hw(a, b, c, d) : [gw(b, c)]
            }, iw[M.N.Qb] = function(a, b, c) {
                return {
                    baseUrl: cw(11, c).slice(0, -1),
                    Gb: b,
                    format: 4,
                    mb: !0,
                    endpoint: 11
                }
            }, iw[M.N.Fb] = function(a, b, c) {
                var d = cw(21, c).slice(0, -1),
                    e = fk(d);
                return {
                    baseUrl: d,
                    Gb: b,
                    nc: e ? {
                        _uip: e
                    } : void 0,
                    format: P(455) || P(477) ? 4 : 1,
                    mb: !0,
                    endpoint: 21
                }
            }, iw);

    function kw(a, b) {
        var c = T(a, S.C.da),
            d = Vr(a, K.m.hh),
            e, f = (e = jw[c]) == null ? void 0 : e.call(jw, a, b, d);
        return (Array.isArray(f) ? f : [f]).filter(function(g) {
            return g !== void 0
        })
    };
    var lw = function(a) {
            this.D = 1;
            this.D > 0 || (this.D = 1);
            this.onSuccess = a.F.onSuccess
        },
        mw = function(a, b) {
            return ec(function() {
                a.D--;
                if (Cb(a.onSuccess) && a.D === 0) a.onSuccess()
            }, b > 0 ? b : 1)
        };
    var nw = function(a) {
        this.methodName = a
    };
    nw.prototype.getName = function() {
        return this.methodName
    };
    nw.prototype.sendRequest = function(a, b, c, d, e, f, g, h) {
        if (this.isSupported())
            if (c === void 0 || this.D()) try {
                this.J(a, b, d, e, f, g, h)
            } catch (l) {
                console.error(">>> sendRequestImplementation threw exception:\n", l), e(l)
            } else e("Request method " + this.getName() + " does not support a request body.");
            else e("Request method " + this.getName() + " is not supported.")
    };
    var ow = function() {
        this.methodName = "ImagePixel"
    };
    xa(ow, nw);
    ow.prototype.isSupported = function() {
        return !0
    };
    ow.prototype.D = function() {
        return !1
    };
    ow.prototype.J = function(a, b, c, d, e, f, g) {
        em(a, b, function() {
            g()
        }, function() {
            e(void 0)
        })
    };
    var pw = function() {
        this.methodName = "InjectAdsScript"
    };
    xa(pw, nw);
    pw.prototype.isSupported = function() {
        return !0
    };
    pw.prototype.D = function() {
        return !1
    };
    pw.prototype.J = function(a, b, c, d, e, f, g) {
        im(a, w, A, b, function() {
            g()
        }, function() {
            d(void 0)
        }) || d(void 0)
    };
    var qw = function() {
        this.methodName = "Fetch";
        var a = w;
        typeof a.fetch === "function" ? this.fetch = a.fetch.bind(a) : this.fetch = void 0
    };
    xa(qw, nw);
    qw.prototype.isSupported = function() {
        return this.fetch !== void 0
    };
    qw.prototype.D = function() {
        return !0
    };
    qw.prototype.J = function(a, b, c, d, e, f, g) {
        rl(a, 2, b);
        this.fetch(b, c).then(function(h) {
            h.ok ? f(h) : h.status === 0 ? g() : e("Fetch failed with status code " + h.status + ".")
        }).catch(function(h) {
            d(h)
        })
    };
    var rw = new ow,
        sw = new pw,
        tw = new qw;

    function uw(a, b) {
        var c = Vr(a, K.m.hh);
        return b + "/" + c + "/"
    }
    var vw = {
            tb: function(a, b, c, d, e) {
                var f = Xv(a);
                b !== 68 && delete f.gclaw;
                T(a, S.C.Pa) ? (f.gcp = 1, f.ct_cookie_present = 1) : b === 68 && (f.gcp = 5, d === tw && (f.fmt = 8));
                var g = "?" + Vv(a, f);
                e(g)
            }
        },
        ww = {
            endpoint: 9,
            Es: ["ad_storage", "ad_user_data"],
            Bs: !0,
            In: !0,
            parameterEncoding: 3,
            isSupported: function() {
                return !0
            },
            Rn: function() {
                return "googleads.g.doubleclick.net/pagead/viewthroughconversion"
            },
            Sn: function(a) {
                return T(a, S.C.Pa) ? [tw, rw] : [sw, rw]
            },
            Qn: function() {
                return vw
            },
            En: function(a, b, c) {
                return uw(a, c)
            }
        },
        xw = {
            endpoint: 68,
            Es: ["ad_storage",
                "ad_user_data"
            ],
            Bs: !0,
            In: !1,
            parameterEncoding: 3,
            isSupported: function(a) {
                return P(458) && !T(a, S.C.Pa)
            },
            Rn: function() {
                return "www.google.com/rmkt/collect"
            },
            Sn: function() {
                return [tw, rw]
            },
            Qn: function() {
                return vw
            },
            En: function(a, b, c) {
                return uw(a, c)
            }
        },
        yw = {
            Ar: function() {
                return [ww]
            },
            zr: function() {
                return [xw]
            }
        };
    var zw = 0,
        Aw = void 0;

    function Bw(a, b) {
        P(462) && nl && b === "gtm.formSubmit" && (zw = a, a !== 5 ? Tk("fs") : (Pk.fs = !1, Pk.ftnw = !1))
    }

    function Cw() {
        P(462) && (Sk("fs", function() {
            return zw > 0 && zw < 5 ? String(zw) : void 0
        }, !1), Sk("ftnw", function() {
            return zw > 0 && zw < 5 && Aw !== void 0 ? Aw : void 0
        }, !1), Sk("wft", function() {}, !1))
    };
    var Fw = "email email_address sha256_email_address phone_number sha256_phone_number first_name last_name".split(" "),
        Gw = "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(" ");

    function Hw(a, b) {
        if (!b._tag_metadata) {
            for (var c = {}, d = 0, e = 0; e < a.length; e++) d += Iw(a[e], b, c) ? 1 : 0;
            d > 0 && (b._tag_metadata = c)
        }
    }

    function Iw(a, b, c) {
        var d = b[a];
        if (d === void 0 || d === null) return !1;
        c[a] = Array.isArray(d) ? d.map(function() {
            return {
                mode: "c"
            }
        }) : {
            mode: "c"
        };
        return !0
    }

    function Jw(a) {
        if (P(178) && a) {
            Hw(Fw, a);
            for (var b = Fb(a.address), c = 0; c < b.length; c++) {
                var d = b[c];
                d && Hw(Gw, d)
            }
            var e = a.home_address;
            e && Hw(Gw, e)
        }
    }

    function Kw(a, b, c) {
        function d(f, g) {
            g = String(g).substring(0, 100);
            e.push("" + f + encodeURIComponent(g))
        }
        if (!c) return "";
        var e = [];
        d("i", String(a));
        d("f", b);
        c.mode && d("m", c.mode);
        c.isPreHashed && d("p", "1");
        c.rawLength && d("r", String(c.rawLength));
        c.normalizedLength && d("n", String(c.normalizedLength));
        c.location && d("l", c.location);
        c.selector && d("s", c.selector);
        return e.join(".")
    };

    function rx(a, b, c, d) {
        if (Zn()) {
            var e = b.F;
            go({
                targetId: d || [b.target.destinationId],
                request: {
                    url: a,
                    parameterEncoding: 2,
                    endpoint: c
                },
                cb: {
                    eventId: e.eventId,
                    priorityId: e.priorityId
                },
                Th: {
                    eventId: T(b, S.C.lf),
                    priorityId: T(b, S.C.nf)
                }
            })
        }
    };
    var Ix = {};
    Ix.R = Kp.R;
    var Jx = {
            gu: "L",
            zq: "S",
            uu: "Y",
            ft: "B",
            Et: "E",
            bu: "I",
            qu: "TC",
            Kt: "HTC"
        },
        Kx = {
            zq: "S",
            Dt: "V",
            ot: "E",
            pu: "tag"
        },
        Lx = {},
        Mx = (Lx[Ix.R.lj] = "6", Lx[Ix.R.mj] = "5", Lx[Ix.R.kj] = "7", Lx);

    function Nx() {
        function a(c, d) {
            var e = Ab(ub[d] || []);
            e && b.push([c, e])
        }
        var b = [];
        a("u", "GTM");
        a("ut", "TAGGING");
        a("h", "HEALTH");
        return b
    };
    var Ox = !1;

    function gy(a) {}

    function hy(a) {}

    function iy() {}

    function jy(a) {}

    function ky(a) {}

    function ly(a) {}

    function my() {}

    function ny(a, b) {}

    function oy(a, b, c) {}

    function py() {};

    function qy(a) {
        return Promise.allSettled(a).then(function(b) {
            return b.filter(function(c) {
                return c.status === "fulfilled"
            }).map(function(c) {
                return c.value
            })
        })
    }

    function ry() {
        var a, b;
        return {
            promise: new Promise(function(c, d) {
                a = c;
                b = d
            }),
            resolve: a,
            reject: b
        }
    };
    var sy = Object.freeze({
        cache: "no-store",
        credentials: "include",
        method: "GET",
        keepalive: !0,
        redirect: "follow"
    });

    function ty(a, b, c, d, e, f, g, h) {
        var l = pa(Object, "assign").call(Object, {}, sy);
        b && (l.body = b, l.method = "POST");
        pa(Object, "assign").call(Object, l, d);
        g == null || $l(g);
        w.fetch(a, l).then(function(n) {
            g == null || am(g);
            h == null || bm(h, a);
            if (!n.ok) f == null || f();
            else if (n.body) {
                var p = n.body.getReader(),
                    q = new TextDecoder;
                return new Promise(function(r) {
                    function t() {
                        p.read().then(function(u) {
                            var v;
                            v = u.done;
                            var x = q.decode(u.value, {
                                stream: !v
                            });
                            uy(c, x);
                            v ? (e == null || e(), r()) : t()
                        }).catch(function() {
                            r()
                        })
                    }
                    t()
                })
            }
        }).catch(function() {
            g ==
                null || am(g);
            h == null || bm(h, a);
            f && f()
        })
    };
    var vy = function(a) {
            this.O = a;
            this.D = ""
        },
        wy = function(a, b) {
            a.J = b;
            return a
        },
        uy = function(a, b) {
            b = a.D + b;
            for (var c = b.indexOf("\n\n"); c !== -1;) {
                var d = a,
                    e;
                a: {
                    var f = m(b.substring(0, c).split("\n")),
                        g = f.next().value,
                        h = f.next().value;
                    if (g.indexOf("event: message") === 0 && h.indexOf("data: ") === 0) try {
                        e = JSON.parse(h.substring(h.indexOf(":") + 1));
                        break a
                    } catch (l) {}
                    e = void 0
                }
                xy(d, e);
                b = b.substring(c + 2);
                c = b.indexOf("\n\n")
            }
            a.D = b
        },
        yy = function(a, b) {
            return function() {
                if (b.fallback_url && b.fallback_url_method) {
                    var c = {};
                    xy(a, (c[b.fallback_url_method] = [b.fallback_url], c.options = {}, c))
                }
            }
        },
        xy = function(a, b) {
            b && (zy(b.send_pixel, b.options, a.O), zy(b.create_iframe, b.options, a.T), zy(b.fetch, b.options, a.J))
        };

    function Ay(a) {
        var b = a.search;
        return a.protocol + "//" + a.hostname + a.pathname + (b ? b + "&richsstsse" : "?richsstsse")
    }

    function zy(a, b, c) {
        if (a && c) {
            var d = a || [];
            if (Array.isArray(d))
                for (var e = Id(b) ? b : {}, f = m(d), g = f.next(); !g.done; g = f.next()) c(g.value, e)
        }
    };
    var Tg;

    function By() {
        var a = data.permissions || {};
        Tg = new Sg(E(5), a)
    }

    function Cy(a, b) {
        var c;
        (c = Tg) == null || Ng(c.D, a, b)
    };
    var Dy = Cg(57, 5),
        Ey = Cg(58, 50),
        Fy = Hb();
    var Hy = function(a, b) {
            a && (Gy("sid", a.targetId, b), Gy("cc", a.clientCount, b), Gy("tl", a.totalLifeMs, b), Gy("hc", a.heartbeatCount, b), Gy("cl", a.clientLifeMs, b))
        },
        Gy = function(a, b, c) {
            b != null && c.push(a + "=" + b)
        },
        Iy = function() {
            var a = A.referrer;
            if (a) {
                var b;
                return Mj(Sj(a), "host") === ((b = w.location) == null ? void 0 : b.host) ? 1 : 2
            }
            return 0
        },
        Jy = "https://" + E(21) + "/a?",
        Ly = function() {
            this.V = Ky;
            this.O = 0
        };
    Ly.prototype.J = function(a, b, c, d) {
        var e = Iy(),
            f, g = [];
        f = w === w.top && e !== 0 && b ?
            (b == null ? void 0 : b.clientCount) > 1 ? e === 2 ? 1 : 2 : e === 2 ? 0 : 3 : 4;
        a && Gy("si", a.Lg, g);
        Gy("m", 0, g);
        Gy("iss", f, g);
        Gy("if", c, g);
        Hy(b, g);
        d && Gy("fm", encodeURIComponent(d.substring(0, Ey)), g);
        this.T(g);
    };
    Ly.prototype.D = function(a, b, c, d, e) {
        var f = [];
        Gy("m", 1, f);
        Gy("s", a, f);
        Gy("po", Iy(), f);
        b && (Gy("st", b.state, f), Gy("si", b.Lg, f), Gy("sm", b.Ug, f));
        Hy(c, f);
        Gy("c", d, f);
        e && Gy("fm", encodeURIComponent(e.substring(0, Ey)), f);
        this.T(f);
    };
    Ly.prototype.T = function(a) {
        a = a === void 0 ? [] : a;
        !ll || this.O >= Dy || (Gy("pid", Fy, a), Gy("bc", ++this.O, a), a.unshift("ctid=" + E(5) + "&t=s"), this.V("" + Jy + a.join("&")))
    };

    function My(a) {
        return a.performance && a.performance.now() || Date.now()
    }
    var Oy = function(a, b) {
        var c = w,
            d = Ny,
            e;
        var f = function(g, h, l) {
            l = l === void 0 ? {
                Zn: function() {},
                co: function() {},
                Yn: function() {},
                onFailure: function() {}
            } : l;
            this.rj = g;
            this.D = h;
            this.O = l;
            this.fa = this.ma = this.heartbeatCount = this.qj = 0;
            this.Zc = !1;
            this.J = {};
            this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
            this.state = 0;
            this.Lg = My(this.D);
            this.Ug = My(this.D);
            this.V = 10
        };
        f.prototype.init = function() {
            this.T(1);
            this.Ta()
        };
        f.prototype.getState = function() {
            return {
                state: this.state,
                Lg: Math.round(My(this.D) - this.Lg),
                Ug: Math.round(My(this.D) - this.Ug)
            }
        };
        f.prototype.T = function(g) {
            this.state !== g && (this.state = g, this.Ug = My(this.D))
        };
        f.prototype.Ud = function() {
            return String(this.qj++)
        };
        f.prototype.Ta = function() {
            var g = this;
            this.heartbeatCount++;
            this.wg({
                type: 0,
                clientId: this.id,
                requestId: this.Ud(),
                maxDelay: this.Td()
            }, function(h) {
                if (h.type === 0) {
                    var l;
                    if (((l = h.failure) == null ? void 0 : l.failureType) != null)
                        if (h.stats && (g.stats = h.stats), g.fa++, h.isDead || g.fa > d.Pm) {
                            var n = h.isDead && h.failure.failureType;
                            g.V = n || 10;
                            g.T(4);
                            g.pj();
                            var p, q;
                            (q = (p = g.O).Yn) == null || q.call(p, {
                                failureType: n || 10,
                                data: h.failure.data
                            })
                        } else g.T(3), g.tg();
                    else {
                        if (g.heartbeatCount > h.stats.heartbeatCount + d.Pm) {
                            g.heartbeatCount = h.stats.heartbeatCount;
                            var r, t;
                            (t = (r = g.O).onFailure) == null || t.call(r, {
                                failureType: 13
                            })
                        }
                        g.stats = h.stats;
                        var u = g.state;
                        g.T(2);
                        if (u !== 2)
                            if (g.Zc) {
                                var v, x;
                                (x = (v = g.O).co) == null || x.call(v)
                            } else {
                                g.Zc = !0;
                                var y, z;
                                (z = (y = g.O).Zn) == null || z.call(y)
                            }
                        g.fa = 0;
                        g.sj();
                        g.tg()
                    }
                }
            })
        };
        f.prototype.Td = function() {
            return this.state ===
                2 ? d.iq : d.Dq
        };
        f.prototype.tg = function() {
            var g = this;
            this.D.setTimeout(function() {
                g.Ta()
            }, Math.max(0, this.Td() - (My(this.D) - this.ma)))
        };
        f.prototype.Iq = function(g, h, l) {
            var n = this;
            this.wg({
                type: 1,
                clientId: this.id,
                requestId: this.Ud(),
                command: g
            }, function(p) {
                if (p.type === 1)
                    if (p.result) h(p.result);
                    else {
                        var q, r, t, u = {
                                failureType: (t = (q = p.failure) == null ? void 0 : q.failureType) != null ? t : 12,
                                data: (r = p.failure) == null ? void 0 : r.data
                            },
                            v, x;
                        (x = (v = n.O).onFailure) == null || x.call(v, u);
                        l(u)
                    }
            })
        };
        f.prototype.wg = function(g, h) {
            var l =
                this;
            if (this.state === 4) g.failure = {
                failureType: this.V
            }, h(g);
            else {
                var n = this.state !== 2 && g.type !== 0,
                    p = g.requestId,
                    q, r = this.D.setTimeout(function() {
                        var u = l.J[p];
                        u && (mn(6), l.bc(u, 7))
                    }, (q = g.maxDelay) != null ? q : d.Ro),
                    t = {
                        request: g,
                        so: h,
                        mo: n,
                        bs: r
                    };
                this.J[p] = t;
                n || this.sendRequest(t)
            }
        };
        f.prototype.sendRequest = function(g) {
            this.ma = My(this.D);
            g.mo = !1;
            this.rj(g.request)
        };
        f.prototype.sj = function() {
            for (var g = m(Object.keys(this.J)), h = g.next(); !h.done; h = g.next()) {
                var l = this.J[h.value];
                l.mo && this.sendRequest(l)
            }
        };
        f.prototype.pj =
            function() {
                for (var g = m(Object.keys(this.J)), h = g.next(); !h.done; h = g.next()) this.bc(this.J[h.value], this.V)
            };
        f.prototype.bc = function(g, h) {
            this.sb(g);
            var l = g.request;
            l.failure = {
                failureType: h
            };
            g.so(l)
        };
        f.prototype.sb = function(g) {
            delete this.J[g.request.requestId];
            this.D.clearTimeout(g.bs)
        };
        f.prototype.Ir = function(g) {
            this.ma = My(this.D);
            var h = this.J[g.requestId];
            if (h) this.sb(h), h.so(g);
            else {
                var l, n;
                (n = (l = this.O).onFailure) == null || n.call(l, {
                    failureType: 14
                })
            }
        };
        e = new f(a, c, b);
        return e
    };
    var Py;
    var Qy = function() {
            Py || (Py = new Ly);
            return Py
        },
        Ky = function(a) {
            Im(Km(km.ba.Gc), function() {
                gd(a)
            })
        },
        Ry = function(a) {
            var b = a.substring(0, a.indexOf("/_/service_worker"));
            return "&1p=1" + (b ? "&path=" + encodeURIComponent(b) : "")
        },
        Sy = function(a) {
            var b = a,
                c, d = Ag(11);
            d = Ag(10);
            c = d;
            b ? (b.charAt(b.length - 1) !== "/" && (b += "/"), a = b + c) : a = "https://www.googletagmanager.com/static/service_worker/" + c + "/";
            var e;
            try {
                e = new URL(a)
            } catch (f) {
                return null
            }
            return e.protocol !==
                "https:" ? null : e
        },
        Ty = function(a) {
            var b = w.location.origin;
            if (!b) return null;
            (P(432) ? Xj() : Xj() && !a) && (a = "" + b + Yj() + "/_/service_worker");
            return Sy(a)
        },
        Uy = function(a) {
            var b = Pm(Lm.Z.bn);
            return b && b[a]
        },
        Ny = {
            Dq: Cg(53, 500),
            iq: Cg(54, 5E3),
            Pm: Cg(8, 20),
            Ro: Cg(55, 5E3)
        },
        Vy = function(a) {
            var b = this;
            this.J = Qy();
            this.V = this.T = !1;
            this.fa = null;
            this.initTime = Math.round(Tb());
            this.D = 15;
            this.O = this.Zq(a);
            w.setTimeout(function() {
                b.initialize()
            }, 1E3);
            jd(function() {
                b.Sr(a)
            })
        };
    k = Vy.prototype;
    k.delegate = function(a, b, c) {
        this.getState() !==
            2 ? (this.J.D(this.D, {
                state: this.getState(),
                Lg: this.initTime,
                Ug: Math.round(Tb()) - this.initTime
            }, void 0, a.commandType), c({
                failureType: this.D
            })) : this.O.Iq(a, b, c)
    };
    k.getState = function() {
        return this.O.getState().state
    };
    k.Sr = function(a) {
        var b = w.location.origin,
            c = this,
            d = ed();
        try {
            var e = d.contentDocument.createElement("iframe"),
                f = a.pathname,
                g = f[f.length - 1] === "/" ? a.toString() : a.toString() + "/",
                h = a.origin !== "https://www.googletagmanager.com" ? Ry(f) : "",
                l;
            P(133) && (l = {
                sandbox: "allow-same-origin allow-scripts"
            });
            ed(g +
                "sw_iframe.html?origin=" + encodeURIComponent(b) + h, void 0, l, void 0, e);
            var n = function() {
                d.contentDocument.body.appendChild(e);
                e.addEventListener("load", function() {
                    c.fa = e.contentWindow;
                    d.contentWindow.addEventListener("message", function(p) {
                        p.origin === a.origin && c.O.Ir(p.data)
                    });
                    c.initialize()
                })
            };
            d.contentDocument.readyState === "complete" ? n() : d.contentWindow.addEventListener("load", function() {
                n()
            })
        } catch (p) {
            d.parentElement.removeChild(d), this.D = 11, this.J.J(void 0, void 0, this.D, p.toString())
        }
    };
    k.Zq = function(a) {
        var b =
            this,
            c = Oy(function(d) {
                var e;
                (e = b.fa) == null || e.postMessage(d, a.origin)
            }, {
                Zn: function() {
                    b.T = !0;
                    b.J.J(c.getState(), c.stats)
                },
                co: function() {},
                Yn: function(d) {
                    b.T ? (b.D = (d == null ? void 0 : d.failureType) || 10, b.J.D(b.D, c.getState(), c.stats, void 0, d == null ? void 0 : d.data)) : (b.D = (d == null ? void 0 : d.failureType) || 4, b.J.J(c.getState(), c.stats, b.D, d == null ? void 0 : d.data))
                },
                onFailure: function(d) {
                    b.D = d.failureType;
                    b.J.D(b.D, c.getState(), c.stats, d.command, d.data)
                }
            });
        return c
    };
    k.initialize = function() {
        this.V || this.O.init();
        this.V = !0
    };

    function Wy() {
        var a = Pg(Tg.D, "", function() {
            return {}
        });
        try {
            return a("internal_sw_allowed"), !0
        } catch (b) {
            return !1
        }
    }

    function Xy(a) {
        var b;
        b = (a === void 0 ? {} : a).Hs;
        var c = Ty(b);
        if (c === null || !Wy() || Uy(c.origin)) return;
        if (!Sc()) {
            Qy().J(void 0, void 0, 6);
            return
        }
        var d = new Vy(c);
        Qm(Lm.Z.bn, {})[c.origin] = d;
    }
    var Yy = function(a, b, c, d) {
        var e;
        if ((e = Uy(a)) == null || !e.delegate) {
            var f = Sc() ? 16 : 6;
            Qy().D(f, void 0, void 0, b.commandType);
            d({
                failureType: f
            });
            return
        }
        Uy(a).delegate(b, c, d);
    };

    function Zy(a, b, c, d, e) {
        var f = P(277) ? Ty() : Sy();
        if (f === null) {
            d(Sc() ? 16 : 6);
            return
        }
        var g, h = (g = Uy(f.origin)) == null ? void 0 : g.initTime,
            l = Math.round(Tb());
        Yy(f.origin, {
            commandType: 0,
            params: {
                url: a,
                method: 0,
                templates: b,
                body: "",
                processResponse: !1,
                sinceInit: h ? l - h : void 0,
                encryptionKeyString: e,
                reportEarlySuccess: P(441)
            }
        }, function(n) {
            c(n)
        }, function(n) {
            d(n.failureType)
        });
    }

    function $y(a, b, c, d) {
        var e = Ty(a);
        if (e === null) {
            d("_is_sw=f" + (Sc() ? 16 : 6) + "te");
            return
        }
        var f = b ? 1 : 0,
            g = Math.round(Tb()),
            h, l = (h = Uy(e.origin)) == null ? void 0 : h.initTime,
            n = l ? g - l : void 0,
            p = P(412),
            q;
        P(432) ? q = Xj() ? void 0 : w.location.href : q = w.location.href;
        Yy(e.origin, {
            commandType: 0,
            params: {
                url: a,
                method: f,
                templates: c,
                body: b || "",
                processResponse: !0,
                reportEarlySuccess: p,
                sinceInit: n,
                attributionReporting: !0,
                referer: q
            }
        }, function() {}, function(r) {
            var t = "_is_sw=f" + r.failureType,
                u, v = (u = Uy(e.origin)) == null ? void 0 : u.getState();
            v !== void 0 && (t += "s" + v);
            d(n ? t + ("t" + n) : t + "te")
        });
    };
    var az = Ba(['\n\'use strict\';const g=Object.freeze({cache:"no-store",credentials:"include",method:"GET",keepalive:!0,redirect:"follow"});async function h(b,a){const c=a.data?.url;if(c){a=[0,...(a.data.retryIntervals||[])];for(let d=0;d<a.length;++d){const e=a[d];e>0&&await new Promise(f=>{setTimeout(f,e)});try{await b.fetch(k(c,d),g);break}catch(f){}}}}function k(b,a){if(a===0)return b;b=new URL(b);b.searchParams.set("gap.shw_rt",`${a}`);return b.toString()}(function(b){b.onconnect=a=>{a=a.ports[0];a.onmessage=c=>h(b,c);a.start()}})(self);\n\n'], ['\n\'use strict\';const g=Object.freeze({cache:"no-store",credentials:"include",method:"GET",keepalive:!0,redirect:"follow"});async function h(b,a){const c=a.data?.url;if(c){a=[0,...(a.data.retryIntervals||[])];for(let d=0;d<a.length;++d){const e=a[d];e>0&&await new Promise(f=>{setTimeout(f,e)});try{await b.fetch(k(c,d),g);break}catch(f){}}}}function k(b,a){if(a===0)return b;b=new URL(b);b.searchParams.set("gap.shw_rt",\\`\\${a}\\`);return b.toString()}(function(b){b.onconnect=a=>{a=a.ports[0];a.onmessage=c=>h(b,c);a.start()}})(self);\n\n']),
        bz, cz = az.join(""),
        dz = nc(),
        Ic = dz ? dz.createScript(cz) : cz;
    bz = new Jc;
    var ez = Ca(["about:blank"]),
        fz = Object.freeze([500, 1500, 5E3, 3E4]);

    function gz(a) {
        if (P(460)) {
            var b = hz().instance;
            b && b.port.postMessage({
                url: a,
                retryIntervals: fz
            })
        }
    }

    function hz() {
        var a = Pm(Lm.Z.jn);
        return a ? a : Qm(Lm.Z.jn, iz())
    }

    function iz() {
        try {
            if (!("SharedWorker" in w)) return {};
            var a = Ag(62),
                b;
            if (a && A.head) {
                var c = Oo("META");
                A.head.appendChild(c);
                c.httpEquiv = "origin-trial";
                c.content = a;
                b = c
            } else b = null;
            if (!b || !jz()) return {};
            var d, e;
            if (bz instanceof Jc) e = bz.D;
            else throw Error("");
            d = pc(URL.createObjectURL(new Blob([e.toString()], {
                type: "text/javascript"
            })));
            var f = Oc(d, {
                name: "gtm",
                extendedLifetime: !0
            });
            f.port.start();
            return {
                instance: f
            }
        } catch (g) {
            return {}
        }
    }

    function jz() {
        var a = !1;
        try {
            Oc(Lo(ez), {
                get extendedLifetime() {
                    return a = !0
                }
            })
        } catch (b) {}
        return a
    };

    function kz(a, b, c, d, e) {
        var f = ry(),
            g = f.promise,
            h = f.resolve,
            l = [],
            n = function() {
                h(l)
            },
            p = c.slice(),
            q = function() {
                var r = p.shift();
                if (r) {
                    var t = r.Sn(a).filter(function(v) {
                            return v.isSupported()
                        }),
                        u = function() {
                            var v = t.shift();
                            v ? lz(a, b, r, d, l, v, e, u, n) : q()
                        };
                    u()
                } else n()
            };
        q();
        return g
    }

    function lz(a, b, c, d, e, f, g, h, l) {
        var n = c.Rn(a),
            p = !1,
            q = function(r, t, u) {
                if (p) Q(187);
                else if (p = !0, t && !f.D()) h();
                else {
                    var v = mz(r),
                        x, y = (x = c.yu) == null ? void 0 : x.call(c, a, c.endpoint, n, f, r);
                    y != null && (v = mz(y));
                    var z, C = "https://" + (((z = c.En) == null ? void 0 : z.call(c, a, c.endpoint, n, f, v)) || n) + v,
                        D = {
                            ik: b,
                            endpoint: c,
                            isPrimary: g,
                            Ou: C,
                            Nu: u,
                            Cu: !!t,
                            Mu: f,
                            status: void 0
                        };
                    e.push(D);
                    var G;
                    d == null || (G = d.Hu) == null || G.call(d, a, b, c, g, f, C, t);
                    var J = {
                        destinationId: a.target.destinationId,
                        endpoint: c.endpoint,
                        eventId: a.F.eventId,
                        priorityId: a.F.priorityId
                    };
                    c.In && go({
                        targetId: a.target.destinationId,
                        request: pa(Object, "assign").call(Object, {}, {
                            url: C,
                            parameterEncoding: c.parameterEncoding,
                            endpoint: c.endpoint
                        }, t ? {
                            postBody: t
                        } : {}),
                        cb: {
                            eventId: a.F.eventId,
                            priorityId: a.F.priorityId
                        },
                        Th: {
                            eventId: T(a, S.C.lf),
                            priorityId: T(a, S.C.nf)
                        }
                    });
                    var L = function(da, aa) {
                        D.status = da;
                        var N;
                        d == null || (N = d.Gu) == null || N.call(d, a, b, c, g, f, C, t, D.status, aa)
                    };
                    f.sendRequest(J, C, t, u, function() {
                        L(3);
                        h()
                    }, function() {
                        L(4);
                        h()
                    }, function(da) {
                        L(da.status === 0 ? 1 : da.ok ? 0 : 4, da);
                        l()
                    }, function() {
                        L(1);
                        l()
                    })
                }
            };
        try {
            c.Qn(a).tb(a, c.endpoint, n, f, q)
        } catch (r) {
            console.error(">>> requestBuilder.build() throw exception:\n", r), Q(188), h()
        }
    }

    function mz(a) {
        return a && a !== "?" ? a[0] !== "?" ? "?".concat(a) : a : ""
    };

    function nz(a, b, c) {
        var d, e = (d = b.Ar(a)) == null ? void 0 : d.filter(function(l) {
            return l.isSupported(a)
        });
        if (e != null && e.length) {
            var f, g, h = ((f = b.zr) == null ? void 0 : (g = f.call(b, a)) == null ? void 0 : g.filter(function(l) {
                return l.isSupported(a)
            })) || [];
            c.push({
                ik: b,
                ko: e,
                ho: h
            })
        } else c.push({
            ik: b,
            ko: void 0,
            ho: void 0
        })
    };

    function oz(a, b) {
        for (var c = Qa.apply(2, arguments), d = [], e = m(c), f = e.next(); !f.done; f = e.next()) nz(a, f.value, d);
        var g;
        b == null || (g = b.Ku) == null || g.call(b, a, d);
        for (var h = [], l = m(d), n = l.next(), p = {}; !n.done; p = {
                ff: void 0
            }, n = l.next()) {
            var q = n.value;
            p.ff = q.ik;
            var r = q.ko,
                t = q.ho,
                u = void 0,
                v = void 0,
                x = void 0;
            (u = b) == null || (x = (v = u).Ju) == null || x.call(v, a, p.ff);
            var y = void 0;
            if ((y = r) != null && y.length) {
                var z = [];
                z.push(kz(a, p.ff, r, b, !0));
                for (var C = m(t || []), D = C.next(); !D.done; D = C.next()) z.push(kz(a, p.ff, [D.value], b, !1));
                h.push.apply(h,
                    Aa(z));
                qy(z).then(function(da) {
                    return function(aa) {
                        for (var N = [], R = m(aa), ja = R.next(); !ja.done; ja = R.next()) N.push.apply(N, Aa(ja.value));
                        var la;
                        b == null || (la = b.ls) == null || la.call(b, a, da.ff, N)
                    }
                }(p))
            } else {
                var G = void 0,
                    J = void 0,
                    L = void 0;
                (G = b) == null || (L = (J = G).ls) == null || L.call(J, a, p.ff, [])
            }
        }
        qy(h).then(function(da) {
            for (var aa = [], N = m(da), R = N.next(); !R.done; R = N.next()) aa.push.apply(aa, Aa(R.value));
            var ja;
            b == null || (ja = b.ks) == null || ja.call(b, a, c, aa)
        })
    };
    var pz = function(a, b) {
            this.ns = a;
            this.timeoutMs = b;
            this.Xa = void 0
        },
        $l = function(a) {
            a.Xa || (a.Xa = setTimeout(function() {
                a.ns();
                a.Xa = void 0
            }, a.timeoutMs))
        },
        am = function(a) {
            a.Xa && (clearTimeout(a.Xa), a.Xa = void 0)
        };
    var qz = function() {
            var a = Cg(66, 0);
            this.bo = [];
            this.ds = a;
            this.ld = bb()
        },
        sz = function(a) {
            var b = rz;
            b.bo.push(a);
            b.fo || (b.fo = function() {
                for (var c = m(b.bo), d = c.next(); !d.done; d = c.next()) {
                    var e = d.value;
                    try {
                        e()
                    } catch (l) {}
                }
                for (var f = m(b.ld.values()), g = f.next(); !g.done; g = f.next()) {
                    var h = void 0;
                    (h = g.value.pk) == null || am(h)
                }
                b.ld.clear()
            }, hd(w, "pagehide", b.fo))
        },
        tz = function(a) {
            var b = a.match(Tl)[3] || null,
                c = (b ? decodeURI(b) : b) || "",
                d = Wl(a, "label") || "",
                e = Wl(a, "random") || "";
            return c + ":" + Sl(d) + ":" + Sl(e)
        };
    qz.prototype.wg = function(a, b, c) {
        var d = tz(a);
        if (!(this.ld.has(d) || this.ld.size >= this.ds)) {
            var e = {};
            b && b > 0 && c && (e.pk = new pz(c, b));
            this.ld.set(d, e);
            var f;
            (f = e.pk) == null || $l(f)
        }
    };
    var bm = function(a, b) {
        var c = tz(b),
            d, e;
        (d = a.ld.get(c)) == null || (e = d.pk) == null || am(e);
        a.ld.delete(c)
    };
    qz.prototype.getSize = function() {
        return this.ld.size
    };

    function Mz() {
        return rs("dedupe_gclid", function() {
            return ov()
        })
    };
    var Rz = {
        bj: {
            Ko: "1",
            Xp: "2",
            xq: "3"
        }
    };

    function Wz(a, b, c, d) {
        var e = dd(),
            f;
        if (e === 1) a: {
            var g = E(3);g = g.toLowerCase();
            for (var h = "https://" + g, l = "http://" + g, n = 1, p = A.getElementsByTagName("script"), q = 0; q < p.length && q < 100; q++) {
                var r = p[q].src;
                if (r) {
                    r = r.toLowerCase();
                    if (r.indexOf(l) === 0) {
                        f = 3;
                        break a
                    }
                    n === 1 && r.indexOf(h) === 0 && (n = 2)
                }
            }
            f = n
        }
        else f = e;
        return (f === 2 || d || "http:" !== w.location.protocol ? a : b) + c
    };

    function Xz(a, b, c, d, e) {
        if (!Fk(a)) {
            d.loadExperiments = vj();
            Ik(a, d, e);
            var f = Yz(a),
                g = function() {
                    pk().container[a] && (pk().container[a].state = 3);
                    Zz()
                },
                h = {
                    destinationId: a,
                    endpoint: 0
                };
            if (Xj()) gm(h, Yj() + "/" + $z(f), void 0, g);
            else {
                var l = Yb(a, "GTM-"),
                    n = ck(),
                    p = c ? "/gtag/js" : "/gtm.js",
                    q = aA(b, p + f);
                if (!q) {
                    var r = E(3) + p;
                    n && Uc && l && (r = Uc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
                    q = Wz("https://", "http://", r + f)
                }
                gm(h, q, void 0, g)
            }
        }
    }

    function Zz() {
        Jk() || Lb(Kk(), function(a, b) {
            bA(a, b.transportUrl, b.context);
            Q(92)
        })
    }

    function bA(a, b, c, d) {
        if (!Hk(a))
            if (c.loadExperiments || (c.loadExperiments = vj()), Jk()) {
                var e = pk(),
                    f = ok(a);
                f ? f.state = 0 : (f = {
                    state: 0,
                    transportUrl: b,
                    context: c,
                    parent: Ak()
                }, e.destinationArray[a] = [f]);
                qk({
                    ctid: a,
                    isDestination: !0
                }, d);
                Q(91)
            } else {
                var g = pk(),
                    h = ok(a);
                h ? h.state = 1 : (h = {
                    context: c,
                    state: 1,
                    parent: Ak()
                }, g.destinationArray[a] = [h]);
                qk({
                    ctid: a,
                    isDestination: !0
                }, d);
                var l = {
                    destinationId: a,
                    endpoint: 0
                };
                if (Xj()) {
                    var n = "gtd" + Yz(a, !0);
                    gm(l, Yj() + "/" + $z(n))
                } else {
                    var p = "/gtag/destination" + Yz(a, !0),
                        q = aA(b, p);
                    q || (q =
                        Wz("https://", "http://", E(3) + p));
                    gm(l, q)
                }
            }
    }

    function Yz(a, b) {
        b = b === void 0 ? !1 : b;
        var c = "?id=" + encodeURIComponent(a),
            d = E(19);
        d !== "dataLayer" && (c += "&l=" + d);
        if (!Yb(a, "GTM-") || b) c += "&cx=c";
        var e = c,
            f, g = {
                po: yg(15),
                uo: E(14)
            };
        f = Ef(g);
        c = e + ("&gtm=" + f);
        ck() && (c += "&sign=" + xj.ij);
        var h = c,
            l = yg(54);
        if (l === 1) {
            if (h += "&fps=fc", P(429)) {
                var n = E(60);
                n && (h += "&gdev=" + n)
            }
        } else l === 2 && (h += "&fps=fe");
        return h
    }

    function $z(a) {
        if (!P(413)) return a;
        var b = E(58);
        if (!b) return Q(182), a;
        try {
            return Gf(a, b)
        } catch (c) {
            return Q(183), a
        }
    }

    function aA(a, b) {
        if (!P(419)) return ak(a, b);
        if (bk() && a) {
            var c = E(58),
                d = E(18);
            if (c && d) try {
                b = d + "/" + Gf(b, c)
            } catch (e) {
                Q(183)
            }
            return Zj(a, b)
        }
    };
    var cA = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        dA = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        eA = {
            cl: ["ecl"],
            customPixels: ["customScripts",
                "html"
            ],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        fA = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");

    function gA() {
        var a = vt("gtm.allowlist") || vt("gtm.whitelist");
        a && Q(9);
        Bj && (P(479) ? a = void 0 : a = ["google", "gtagfl", "lcl", "zone", "cmpPartners"]);
        cA.test(w.location && w.location.hostname) && (Bj ? Q(116) : (Q(117), xg(48) && (a = [], window.console && window.console.log && window.console.log("GTM blocked. See go/13687728."))));
        var b = a && Xb(Pb(a), dA),
            c = vt("gtm.blocklist") || vt("gtm.blacklist");
        c || (c = vt("tagTypeBlacklist")) && Q(3);
        c ? Q(8) : c = [];
        cA.test(w.location && w.location.hostname) && (c = Pb(c), c.push("nonGooglePixels", "nonGoogleScripts",
            "sandboxedScripts"));
        Pb(c).indexOf("google") >= 0 && Q(2);
        var d = c && Xb(Pb(c), eA),
            e = {};
        return function(f) {
            var g = f && f[Kf.ab];
            if (!g || typeof g !== "string") return !0;
            g = g.replace(/^_*/, "");
            if (e[g] !== void 0) return e[g];
            var h = Fj[g] || [],
                l = !0;
            if (a) {
                var n;
                if (n = l) a: {
                    if (b.indexOf(g) < 0) {
                        if (Bj && h.indexOf("cmpPartners") >= 0) {
                            n = !0;
                            break a
                        }
                        if (h && h.length > 0)
                            for (var p = 0; p < h.length; p++) {
                                if (b.indexOf(h[p]) < 0) {
                                    Q(11);
                                    n = !1;
                                    break a
                                }
                            } else {
                                n = !1;
                                break a
                            }
                    }
                    n = !0
                }
                l = n
            }
            var q = !1;
            if (c) {
                var r = d.indexOf(g) >= 0;
                if (r) q = r;
                else {
                    var t = Ib(d, h || []);
                    t &&
                        Q(10);
                    q = t
                }
            }
            var u = !l || q;
            !u && (h.indexOf("sandboxedScripts") === -1 ? 0 : Bj && h.indexOf("cmpPartners") >= 0 ? !hA() : b && b.indexOf("sandboxedScripts") !== -1 ? 0 : Ib(d, fA)) && (u = !0);
            return e[g] = u
        }
    }

    function hA() {
        var a = Pg(Tg.D, E(5), function() {
            return {}
        });
        try {
            return a("inject_cmp_banner"), !0
        } catch (b) {
            return !1
        }
    };
    var iA = function() {
        this.J = 0;
        this.D = {}
    };
    iA.prototype.addListener = function(a, b, c) {
        var d = ++this.J;
        this.D[a] = this.D[a] || {};
        this.D[a][String(d)] = {
            listener: b,
            jf: c
        };
        return d
    };
    iA.prototype.removeListener = function(a, b) {
        var c = this.D[a],
            d = String(b);
        if (!c || !c[d]) return !1;
        delete c[d];
        return !0
    };
    var kA = function(a, b) {
        var c = [];
        Lb(jA.D[a], function(d, e) {
            c.indexOf(e.listener) < 0 && (e.jf === void 0 || b.indexOf(e.jf) >= 0) && c.push(e.listener)
        });
        return c
    };

    function lA(a, b, c) {
        return {
            entityType: a,
            indexInOriginContainer: b,
            nameInOriginContainer: c,
            originContainerId: E(5),
            originCId: wk()
        }
    };

    function mA(a, b) {
        if (data.entities) {
            var c = data.entities[a];
            if (c) return c[b]
        }
    };
    var oA = function(a, b) {
            this.D = !1;
            this.T = [];
            this.eventData = {
                tags: []
            };
            this.V = !1;
            this.J = this.O = 0;
            nA(this, a, b)
        },
        pA = function(a, b, c, d) {
            if (zj.hasOwnProperty(b) || b === "__zone") return -1;
            var e = {};
            Id(d) && (e = Jd(d, e));
            e.id = c;
            e.status = "timeout";
            return a.eventData.tags.push(e) - 1
        },
        qA = function(a, b, c, d) {
            var e = a.eventData.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        rA = function(a) {
            if (!a.D) {
                for (var b = a.T, c = 0; c < b.length; c++) b[c]();
                a.D = !0;
                a.T.length = 0
            }
        },
        nA = function(a, b, c) {
            b !== void 0 && a.vg(b);
            c && w.setTimeout(function() {
                    rA(a)
                },
                Number(c))
        };
    oA.prototype.vg = function(a) {
        var b = this,
            c = Vb(function() {
                jd(function() {
                    a(E(5), b.eventData)
                })
            });
        this.D ? c() : this.T.push(c)
    };
    var sA = function(a) {
            a.O++;
            return Vb(function() {
                a.J++;
                a.V && a.J >= a.O && rA(a)
            })
        },
        tA = function(a) {
            a.V = !0;
            a.J >= a.O && rA(a)
        };
    var uA = {};

    function vA() {
        return w[wA()]
    }

    function wA() {
        return w.GoogleAnalyticsObject || "ga"
    }

    function zA() {
        var a = E(5);
    }

    function AA(a, b) {
        return function() {
            var c = vA(),
                d = c && c.getByName && c.getByName(a);
            if (d) {
                var e = d.get("sendHitTask");
                d.set("sendHitTask", function(f) {
                    var g = f.get("hitPayload"),
                        h = f.get("hitCallback"),
                        l = g.indexOf("&tid=" + b) < 0;
                    l && (f.set("hitPayload", g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                    e(f);
                    l && (f.set("hitPayload", g, !0), f.set("hitCallback", h, !0), f.set("_x_19", void 0, !0), e(f))
                })
            }
        }
    };
    var GA = ["es", "1"],
        HA = {},
        IA = {};

    function JA(a, b) {
        if (ll) {
            var c;
            c = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
            HA[a] = [
                ["e", c],
                ["eid", a]
            ];
            Pt(a)
        }
    }

    function KA(a) {
        var b = a.eventId,
            c = a.me;
        if (!HA[b]) return [];
        var d = [];
        IA[b] || d.push(GA);
        d.push.apply(d, Aa(HA[b]));
        c && (IA[b] = !0);
        return d
    };
    var LA = {};

    function MA(a, b, c) {
        LA[a] != null || (LA[a] = {});
        var d;
        (d = LA[a])[c] != null || (d[c] = {});
        LA[a][c][b] = (LA[a][c][b] || 0) + 1
    };
    var NA = {},
        OA = {};

    function PA(a, b, c) {
        if (ll && b) {
            var d = il(b);
            NA[a] = NA[a] || [];
            NA[a].push(c + d);
            var e = b[Kf.ab];
            if (!e) throw Error("Error: No function name given for function call.");
            var f = (lg[e] ? "1" : "2") + d;
            OA[a] = OA[a] || [];
            OA[a].push(f);
            Pt(a)
        }
    }

    function QA(a) {
        var b = a.eventId,
            c = a.me,
            d = [],
            e = NA[b] || [];
        e.length && d.push(["tr", e.join(".")]);
        var f = OA[b] || [];
        f.length && d.push(["ti", f.join(".")]);
        c && (delete NA[b], delete OA[b]);
        return d
    };

    function RA(a, b, c) {
        c = c === void 0 ? !1 : c;
        SA().addRestriction(0, a, b, c)
    }

    function TA(a, b, c) {
        c = c === void 0 ? !1 : c;
        SA().addRestriction(1, a, b, c)
    }

    function UA() {
        var a = wk();
        return SA().getRestrictions(1, a)
    }
    var VA = function() {
            this.container = {};
            this.D = {}
        },
        WA = function(a, b) {
            var c = a.container[b];
            c || (c = {
                _entity: {
                    internal: [],
                    external: []
                },
                _event: {
                    internal: [],
                    external: []
                }
            }, a.container[b] = c);
            return c
        };
    VA.prototype.addRestriction = function(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (!d || !this.D[b]) {
            var e = WA(this, b);
            a === 0 ? d ? e._entity.external.push(c) : e._entity.internal.push(c) : a === 1 && (d ? e._event.external.push(c) : e._event.internal.push(c))
        }
    };
    VA.prototype.getRestrictions = function(a, b) {
        var c = WA(this, b);
        if (a === 0) {
            var d, e;
            return [].concat(Aa((c == null ? void 0 : (d = c._entity) == null ? void 0 : d.internal) || []), Aa((c == null ? void 0 : (e = c._entity) == null ? void 0 : e.external) || []))
        }
        if (a === 1) {
            var f, g;
            return [].concat(Aa((c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) || []), Aa((c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) || []))
        }
        return []
    };
    VA.prototype.getExternalRestrictions = function(a, b) {
        var c = WA(this, b),
            d, e;
        return a === 0 ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) || [] : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) || []
    };
    VA.prototype.removeExternalRestrictions = function(a) {
        var b = WA(this, a);
        b._event && (b._event.external = []);
        b._entity && (b._entity.external = []);
        this.D[a] = !0
    };

    function SA() {
        return rs("r", function() {
            return new VA
        })
    };

    function XA(a, b, c, d) {
        var e = jg[a],
            f = YA(a, b, c, d);
        if (!f) return null;
        var g = vg(e[Kf.dn], c, []);
        if (g && g.length) {
            var h = g[0];
            f = XA(h.index, {
                onSuccess: f,
                onFailure: h.Ln === 1 ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function YA(a, b, c, d) {
        function e() {
            function x() {
                mn(3);
                var L = Tb() - J;
                lA(1, a, jg[a][Kf.Si]);
                PA(c.id, f, "7");
                qA(c.dd, D, "exception", L);
                P(109) && oy(c, f, Ix.R.kj);
                G || (G = !0, h())
            }
            if (f[Kf.qq]) h();
            else {
                var y = ug(f, c, []),
                    z = y[Kf.Lo];
                if (z != null)
                    for (var C = 0; C < z.length; C++)
                        if (!vo(z[C])) {
                            h();
                            return
                        }
                var D = pA(c.dd, String(f[Kf.ab]), Number(f[Kf.Ph]), y[Kf.METADATA]),
                    G = !1;
                y.vtp_gtmOnSuccess = function() {
                    if (!G) {
                        G = !0;
                        var L = Tb() - J;
                        PA(c.id, jg[a], "5");
                        qA(c.dd, D, "success", L);
                        P(109) && oy(c, f, Ix.R.mj);
                        g()
                    }
                };
                y.vtp_gtmOnFailure = function() {
                    if (!G) {
                        G = !0;
                        var L = Tb() - J;
                        PA(c.id, jg[a], "6");
                        qA(c.dd, D, "failure", L);
                        P(109) && oy(c, f, Ix.R.lj);
                        h()
                    }
                };
                y.vtp_gtmTagId = f.tag_id;
                y.vtp_gtmEventId = c.id;
                c.priorityId && (y.vtp_gtmPriorityId = c.priorityId);
                PA(c.id, f, "1");
                P(109) && ny(c, f);
                var J = Tb();
                try {
                    wg(y, {
                        event: c,
                        index: a,
                        type: 1
                    })
                } catch (L) {
                    x(L)
                }
                P(109) && oy(c, f, Ix.R.rn)
            }
        }
        var f = jg[a],
            g = b.onSuccess,
            h = b.onFailure,
            l = b.terminate;
        if (c.isBlocked(f)) return null;
        var n = vg(f[Kf.sn], c, []);
        if (n && n.length) {
            var p = n[0],
                q = XA(p.index, {
                    onSuccess: g,
                    onFailure: h,
                    terminate: l
                }, c, d);
            if (!q) return null;
            g = q;
            h = p.Ln === 2 ? l : q
        }
        if (f[Kf.Sm] || f[Kf.sq]) {
            var r = f[Kf.Sm] ? kg : c.Ts,
                t = g,
                u = h;
            if (!r[a]) {
                var v = ZA(a, r, Vb(e));
                g = v.onSuccess;
                h = v.onFailure
            }
            return function() {
                r[a](t, u)
            }
        }
        return e
    }

    function ZA(a, b, c) {
        var d = [],
            e = [];
        b[a] = $A(d, e, c);
        return {
            onSuccess: function() {
                b[a] = aB;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = bB;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function $A(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function aB(a) {
        a()
    }

    function bB(a, b) {
        b()
    };
    var eB = function(a, b) {
        for (var c = [], d = 0; d < jg.length; d++)
            if (a[d]) {
                var e = jg[d];
                var f = sA(b.dd);
                try {
                    var g = XA(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (g) {
                        var h = e[Kf.ab];
                        if (!h) throw Error("Error: No function name given for function call.");
                        var l = lg[h];
                        c.push({
                            zo: d,
                            priorityOverride: (l ? l.priorityOverride || 0 : 0) || mA(e[Kf.ab], 1) || 0,
                            execute: g
                        })
                    } else cB(d, b), f()
                } catch (p) {
                    f()
                }
            }
        c.sort(dB);
        for (var n = 0; n < c.length; n++) c[n].execute();
        return c.length > 0
    };

    function fB(a, b) {
        if (!jA) return !1;
        var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
            d = kA(a.event, c ? String(c).split(",") : []);
        if (!d.length) return !1;
        for (var e = 0; e < d.length; ++e) {
            var f = sA(b);
            try {
                d[e](a, f)
            } catch (g) {
                f()
            }
        }
        return !0
    }

    function dB(a, b) {
        var c, d = b.priorityOverride,
            e = a.priorityOverride;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (c !== 0) f = c;
        else {
            var g = a.zo,
                h = b.zo;
            f = g > h ? 1 : g < h ? -1 : 0
        }
        return f
    }

    function cB(a, b) {
        if (ll) {
            var c = function(d) {
                var e = b.isBlocked(jg[d]) ? "3" : "4",
                    f = vg(jg[d][Kf.dn], b, []);
                f && f.length && c(f[0].index);
                PA(b.id, jg[d], e);
                var g = vg(jg[d][Kf.sn], b, []);
                g && g.length && c(g[0].index)
            };
            c(a)
        }
    }
    var gB = !1,
        jA;

    function hB() {
        jA || (jA = new iA);
        return jA
    }

    function iB(a) {
        var b = a["gtm.uniqueEventId"],
            c = a["gtm.priorityId"],
            d = a.event;
        if (P(109)) {}
        if (d === "gtm.js") {
            if (gB) return !1;
            gB = !0
        }
        var e = !1,
            f = UA(),
            g = Jd(a, null);
        if (!f.every(function(t) {
                return t({
                    originalEventData: g
                })
            })) {
            if (d !== "gtm.js" && d !== "gtm.init" && d !== "gtm.init_consent") return !1;
            e = !0
        }
        JA(b, d);
        var h = a.eventCallback,
            l =
            a.eventTimeout,
            n = {
                id: b,
                priorityId: c,
                name: d,
                isBlocked: jB(g, e),
                Ts: [],
                logMacroError: function(t, u, v) {
                    Q(6);
                    mn(4);
                    lA(2, u, v)
                },
                cachedModelValues: kB(),
                dd: new oA(function() {
                    if (P(109)) {}
                    Bw(5, d);
                    h && h.apply(h, Array.prototype.slice.call(arguments,
                        0))
                }, l),
                originalEventData: g
            };
        P(109) && ky(n.id);
        var p = Ig(n);
        P(109) && ly(n.id);
        Bw(2, d);
        e && (p = lB(p));
        P(109) && jy(b);
        var q = eB(p, n);
        q && Bw(4, d);
        var r = fB(a, n.dd);
        tA(n.dd);
        d !== "gtm.js" && d !== "gtm.sync" || zA();
        return mB(p, q) || r
    }

    function kB() {
        var a = {};
        a.event = Bt("event", 1);
        a.ecommerce = Bt("ecommerce", 1);
        a.gtm = Bt("gtm");
        a.eventModel = Bt("eventModel");
        return a
    }

    function jB(a, b) {
        var c = gA();
        return function(d) {
            var e = c(d);
            if ((!Bj || !P(407)) && e) return !0;
            var f = d && d[Kf.ab];
            if (!f || typeof f !== "string") return !0;
            f = f.replace(/^_*/, "");
            e && Bj && P(407) && ll && MA(Number(a["gtm.uniqueEventId"]), f, "bl");
            var g, h = wk();
            g = SA().getRestrictions(0, h);
            var l = a;
            b && (l = Jd(a, null), l["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER);
            for (var n = !1, p = Fj[f] || [], q = m(g), r = q.next(); !r.done; r = q.next()) {
                var t = r.value;
                try {
                    t({
                        entityId: f,
                        securityGroups: p,
                        originalEventData: l
                    }) || (n = !0)
                } catch (u) {
                    n = !0
                }
            }
            return n ||
                e
        }
    }

    function lB(a) {
        for (var b = [], c = 0; c < a.length; c++)
            if (a[c]) {
                var d = String(jg[c][Kf.ab]);
                if (yj[d] || jg[c][Kf.tq] !== void 0 || mA(d, 2)) b[c] = !0
            }
        return b
    }

    function mB(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && jg[c] && !zj[String(jg[c][Kf.ab])]) return !0;
        return !1
    };
    var nB = Cg(61, 2E3),
        xo = ["ad_storage", "analytics_storage"];

    function oB(a) {
        a && (a === 2 && pB() === 3 && (a = 4), qs.gth = {
            l: qB,
            s: a
        }, Ao(function() {
            var b = function() {
                wq("gtg_load_status", {
                    status: a,
                    expires: Date.now() + 864E5
                })
            };
            wo() ? b() : Am(Vb(b), xo)
        }, xo))
    }

    function rB(a) {
        a = a === void 0 ? !1 : a;
        if (P(439) && bk()) {
            var b = zq("gtg_load_status"),
                c = b.value,
                d = a && Eb(c == null ? void 0 : c.expires) && (c == null ? void 0 : c.expires) < Date.now() + 36E5;
            return b.error === 0 && Eb(c == null ? void 0 : c.status) && !d ? c == null ? void 0 : c.status : pB()
        }
    }

    function pB() {
        var a;
        return (a = qs.gth) == null ? void 0 : a.s
    }

    function sB() {
        pB() === 1 && oB(3)
    }

    function qB() {
        oB(2)
    }

    function tB() {
        if (!rB(!0)) {
            qs.gth = {
                l: qB,
                s: 1
            };
            var a = E(5),
                b = Yb(a, "GTM-") ? "/gtm.js" : "/gtag/js",
                c = "https://" + E(3) + b + "?id=" + a + "&gtg_health=1";
            cd(c, sB, sB);
            w.setTimeout(sB, nB)
        }
    };

    function uB() {
        hB().addListener("gtm.init", function(a, b) {
            tj.J = !0;
            if (P(439) && bk()) {
                var c = Km(km.ba.Gc);
                Gm(c) ? Im(c, tB) : tB()
            }
            Xm();
            b()
        })
    };

    function vB() {
        if (qs.pscdl !== void 0) Pm(Lm.Z.si) === void 0 && Om(Lm.Z.si, qs.pscdl);
        else {
            var a = function(c) {
                    qs.pscdl = c;
                    Om(Lm.Z.si, c)
                },
                b = function() {
                    a("error")
                };
            try {
                Rc.cookieDeprecationLabel ? (a("pending"), Rc.cookieDeprecationLabel.getValue().then(a).catch(b)) : a("noapi")
            } catch (c) {
                b(c)
            }
        }
    };
    var wB = !1,
        xB = 0,
        yB = [];

    function zB(a) {
        if (!wB) {
            var b = A.createEventObject,
                c = A.readyState === "complete",
                d = A.readyState === "interactive";
            if (!a || a.type !== "readystatechange" || c || !b && d) {
                wB = !0;
                for (var e = 0; e < yB.length; e++) jd(yB[e])
            }
            yB.push = function() {
                for (var f = Qa.apply(0, arguments), g = 0; g < f.length; g++) jd(f[g]);
                return 0
            }
        }
    }

    function AB() {
        if (!wB && xB < 140) {
            xB++;
            try {
                var a, b;
                (b = (a = A.documentElement).doScroll) == null || b.call(a, "left");
                zB()
            } catch (c) {
                w.setTimeout(AB, 50)
            }
        }
    }

    function BB() {
        var a = w;
        wB = !1;
        xB = 0;
        if (A.readyState === "interactive" && !A.createEventObject || A.readyState === "complete") zB();
        else {
            hd(A, "DOMContentLoaded", zB);
            hd(A, "readystatechange", zB);
            if (A.createEventObject && A.documentElement.doScroll) {
                var b = !0;
                try {
                    b = !a.frameElement
                } catch (c) {}
                b && AB()
            }
            hd(a, "load", zB)
        }
    }

    function CB(a) {
        wB ? a() : yB.push(a)
    };
    var DB = void 0;

    function EB(a, b, c) {
        var d;
        if ((d = DB) == null || !d.qr) {
            var e = Object.keys(b).length > 0 ? 2 : 1,
                f, g, h = (c == null ? void 0 : (g = c.originatingEntity) == null ? void 0 : g.originContainerId) || "";
            f = h ? Yb(h, "GTM-") ? 3 : 2 : 1;
            if (!a) DB = {
                type: e,
                source: f,
                params: b
            };
            else if (DB) {
                Q(184);
                var l = !1;
                DB.source === f || DB.source !== 3 && f !== 3 || (Sk("idcs", "1"), l = !0);
                DB.type !== 2 && e !== 2 || Q(186);
                var n;
                if (n = DB.type === 2 && e === 2) a: {
                    var p = DB.params,
                        q = Object.keys(p),
                        r = Object.keys(b);
                    if (q.length !== r.length) n = !0;
                    else {
                        for (var t = m(q), u = t.next(); !u.done; u = t.next()) {
                            var v =
                                u.value;
                            if (!b.hasOwnProperty(v) || p[v] !== b[v]) {
                                n = !0;
                                break a
                            }
                        }
                        n = !1
                    }
                }
                n && (Sk("idcc", "1"), l = !0);
                l && (Xm(), DB.qr = !0)
            }
        }
    };
    var FB = 0;

    function GB() {
        nl && (FB === 1 && (Pk.mcc = !1), FB = 2)
    }

    function HB(a) {
        nl && a === void 0 && FB === 0 && (Sk("mcc", "1"), FB = 1)
    };

    function IB(a, b) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: ws()
        });
        b.eventId = a["gtm.uniqueEventId"];
        b.priorityId = a["gtm.priorityId"];
        return {
            eventId: b.eventId,
            priorityId: b.priorityId
        }
    }

    function JB(a) {
        for (var b = m([K.m.Id, K.m.Wc]), c = b.next(); !c.done; c = b.next()) {
            var d = c.value,
                e = a && a[d] || Yt.D[d];
            if (e) return e
        }
    }

    function KB(a) {
        return !a.isGtmEvent || a.eventMetadata && a.eventMetadata[S.C.rb] && a.eventMetadata[S.C.Ua] !== wk() ? !1 : !0
    };
    var LB = !1;
    var MB = function() {
        this.messages = [];
        this.D = []
    };
    MB.prototype.enqueue = function(a, b, c) {
        var d = this.messages.length + 1;
        a["gtm.uniqueEventId"] = b;
        a["gtm.priorityId"] = d;
        var e = pa(Object, "assign").call(Object, {}, c, {
                eventId: b,
                priorityId: d,
                fromContainerExecution: !0
            }),
            f = {
                message: a,
                notBeforeEventId: b,
                priorityId: d,
                messageContext: e
            };
        this.messages.push(f);
        for (var g = 0; g < this.D.length; g++) try {
            this.D[g](f)
        } catch (h) {}
    };
    MB.prototype.listen = function(a) {
        this.D.push(a)
    };
    MB.prototype.get = function() {
        for (var a = {}, b = 0; b < this.messages.length; b++) {
            var c = this.messages[b],
                d = a[c.notBeforeEventId];
            d || (d = [], a[c.notBeforeEventId] = d);
            d.push(c)
        }
        return a
    };
    MB.prototype.prune = function(a) {
        for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
            var e = this.messages[d];
            e.notBeforeEventId === a ? b.push(e) : c.push(e)
        }
        this.messages = c;
        return b
    };

    function NB(a, b, c) {
        c.eventMetadata = c.eventMetadata || {};
        c.eventMetadata[S.C.Ua] = E(6);
        OB().enqueue(a, b, c)
    }

    function PB() {
        var a = QB;
        OB().listen(a)
    }

    function OB() {
        return rs("mb", function() {
            return new MB
        })
    };
    var RB = {},
        SB = {};

    function TB(a, b) {
        b = b.toString().split(",");
        for (var c = 0; c < b.length; c++) {
            var d = RB[b[c]] || [];
            RB[b[c]] = d;
            d.indexOf(a) < 0 && d.push(a)
        }
    }

    function UB(a, b) {
        b = String(b).split(",");
        for (var c = 0; c < b.length; c++) {
            var d = SB[b[c]] || [];
            SB[b[c]] = d;
            d.indexOf(a) < 0 && d.push(a)
        }
    }

    function VB(a, b) {
        for (var c = [], d = [], e = {}, f = 0; f < a.length; e = {
                dk: void 0,
                Fj: void 0
            }, f++) {
            var g = a[f];
            if (g.indexOf("-") >= 0) {
                if (e.dk = Cs(g, b), e.dk) {
                    var h = uk();
                    Gb(h, function(r) {
                        return function(t) {
                            return r.dk.destinationId === t
                        }
                    }(e)) ? c.push(g) : d.push(g)
                }
            } else {
                var l = RB[g] || [];
                e.Fj = {};
                l.forEach(function(r) {
                    return function(t) {
                        r.Fj[t] = !0
                    }
                }(e));
                for (var n = xk(), p = 0; p < n.length; p++)
                    if (e.Fj[n[p]]) {
                        c = c.concat(uk());
                        break
                    }
                var q = SB[g] || [];
                q.length && (c = c.concat(q))
            }
        }
        return {
            Uj: c,
            hs: d
        }
    }

    function WB(a) {
        Lb(RB, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    }

    function XB(a) {
        Lb(SB, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    };
    var YB = !1,
        ZB = void 0,
        $B = void 0;

    function aC(a, b, c) {
        var d = Jd(a, null);
        d.eventId = void 0;
        d.inheritParentConfig = void 0;
        Object.keys(b).some(function(f) {
            return b[f] !== void 0
        }) && Q(136);
        var e = Jd(b, null);
        Jd(c, e);
        NB($s(xk()[0], e), a.eventId, d)
    };

    function bC(a, b) {
        var c = {},
            d = (c.event = a, c);
        b && (d.eventModel = Jd(b, null), b[K.m.De] && (d.eventCallback = b[K.m.De]), b[K.m.sh] && (d.eventTimeout = b[K.m.sh]));
        return d
    }

    function cC(a, b) {
        var c = a && a[K.m.Hd];
        c === void 0 && (c = vt(K.m.Hd, 2), c === void 0 && (c = "default"));
        if (Db(c) || Array.isArray(c)) {
            var d;
            d = b.isGtmEvent ? Db(c) ? [c] : c : c.toString().replace(/\s+/g, "").split(",");
            var e = VB(d, b.isGtmEvent),
                f = e.Uj,
                g = e.hs;
            if (g.length)
                for (var h = JB(a), l = 0; l < g.length; l++) {
                    var n = Cs(g[l], b.isGtmEvent);
                    if (n) {
                        var p = n.destinationId,
                            q = void 0;
                        ((q = ok(n.destinationId)) == null ? void 0 : q.state) === 0 || bA(p, h, {
                            source: 3,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
            var r = f.concat(g);
            return {
                Uj: Ds(f, b.isGtmEvent),
                Lq: Ds(r, b.isGtmEvent)
            }
        }
    };
    var dC = !1,
        eC = void 0,
        fC = void 0;

    function gC(a, b, c) {
        var d = Jd(a, null);
        d.eventId = void 0;
        d.inheritParentConfig = void 0;
        Object.keys(b).some(function(f) {
            return b[f] !== void 0
        }) && Q(136);
        var e = Jd(b, null);
        Jd(c, e);
        NB($s(xk()[0], e), a.eventId, d)
    };
    var hC = {},
        iC = (hC.config = function(a, b) {
            var c;
            if (P(411)) {
                var d = IB(a, b),
                    e;
                a: {
                    if (!(a.length < 2) && Db(a[1])) {
                        var f = {};
                        if (a.length > 2) {
                            if (a[2] !== void 0 && !Id(a[2]) || a.length > 3) {
                                e = void 0;
                                break a
                            }
                            f = a[2]
                        }
                        var g = Cs(a[1], b.isGtmEvent);
                        if (g) {
                            e = {
                                target: g,
                                params: f
                            };
                            break a
                        }
                    }
                    e = void 0
                }
                var h = e;
                if (h) {
                    var l = h.target,
                        n = h.params,
                        p;
                    a: {
                        if (!xg(7)) {
                            var q = zk(Ak());
                            if (Lk(q)) {
                                var r = q.parent,
                                    t = r.isDestination;
                                p = {
                                    bk: zk(r),
                                    Sj: t
                                };
                                break a
                            }
                        }
                        p = void 0
                    }
                    var u = p,
                        v = u == null ? void 0 : u.bk,
                        x = u == null ? void 0 : u.Sj;
                    JA(d.eventId, "gtag.config");
                    var y =
                        l.destinationId;
                    if (l.id !== l.destinationId ? uk().indexOf(y) !== -1 : xk().indexOf(y) !== -1) a: {
                        if (v && (Q(128), x && Q(130), b.inheritParentConfig)) {
                            var z;
                            $B ? (aC(b, $B, n), z = !1) : (!n[K.m.Nb] && xg(11) && ZB || (ZB = Jd(n, null)), z = !0);
                            z && v.containers && v.containers.join(",");
                            break a
                        }
                        GB();
                        var C;b: {
                            var D = l.id !== l.destinationId;
                            if (xg(11) && !D && !n[K.m.Nb]) {
                                var G = YB;
                                YB = !0;
                                EB(G, n, b);
                                if (G) {
                                    C = !0;
                                    break b
                                }
                            }
                            C = !1
                        }
                        if (!C) {
                            LB || Q(43);
                            if (!b.noTargetGroup) {
                                var J = l.id;
                                l.id !== l.destinationId ? (XB(J), UB(J, n[K.m.Dd] || "default")) : (WB(J), TB(J, n[K.m.Dd] ||
                                    "default"))
                            }
                            delete n[K.m.Dd];
                            var L = b.eventMetadata || {};
                            L.hasOwnProperty(S.C.Fc) || (L[S.C.Fc] = !b.fromContainerExecution);
                            b.eventMetadata = L;
                            delete n[K.m.De];
                            var da = !!n[K.m.Nb];
                            delete n[K.m.Nb];
                            var aa = uk(),
                                N = bu,
                                R = $t;
                            l.id !== l.destinationId && (aa = [l.id], N = cu, R = au);
                            for (var ja = 0; ja < aa.length; ja++) {
                                da || N(aa[ja]);
                                var la = Cs(aa[ja], !0),
                                    Z = la ? eu(Yt, la).J : !1;
                                R(aa[ja], Jd(n, null), Jd(b, null));
                                Z && da || Xt(K.m.na, Jd(n, null), aa[ja], Jd(b, null))
                            }
                        }
                    }
                    else if (!b.inheritParentConfig && !n[K.m.Ac]) {
                        var V = JB(n),
                            ha = l.destinationId;
                        l.id !== l.destinationId ? bA(ha, V, {
                            source: 2,
                            fromContainerExecution: b.fromContainerExecution
                        }) : v !== void 0 && v.containers.indexOf(ha) !== -1 ? ZB ? aC(b, n, ZB) : $B || ($B = Jd(n, null)) : Xz(ha, V, !0, {
                            source: 2,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
                c = void 0
            } else a: {
                var ua = IB(a, b);
                if (!(a.length < 2) && Db(a[1])) {
                    var ma = {};
                    if (a.length > 2) {
                        if (a[2] !== void 0 && !Id(a[2]) || a.length > 3) {
                            c = void 0;
                            break a
                        }
                        ma = a[2]
                    }
                    var Ea = Cs(a[1], b.isGtmEvent);
                    if (Ea) {
                        var Ya, Rb, Jb;
                        b: {
                            if (!xg(7)) {
                                var yb = zk(Ak());
                                if (Lk(yb)) {
                                    var uc = yb.parent,
                                        Ec = uc.isDestination;
                                    Jb = {
                                        bk: zk(uc),
                                        Sj: Ec
                                    };
                                    break b
                                }
                            }
                            Jb = void 0
                        }
                        var ie = Jb;
                        ie && (Ya = ie.bk, Rb = ie.Sj);
                        JA(ua.eventId, "gtag.config");
                        var Re = Ea.destinationId,
                            je = Ea.id !== Re;
                        if (je ? uk().indexOf(Re) === -1 : xk().indexOf(Re) === -1) {
                            if (!b.inheritParentConfig && !ma[K.m.Ac]) {
                                var Yk = JB(ma);
                                if (je) bA(Re, Yk, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                });
                                else if (Ya !== void 0 && Ya.containers.indexOf(Re) !== -1) {
                                    var Zk = ma;
                                    eC ? gC(b, Zk, eC) : fC || (fC = Jd(Zk, null))
                                } else Xz(Re, Yk, !0, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                })
                            }
                        } else {
                            if (Ya &&
                                (Q(128), Rb && Q(130), b.inheritParentConfig)) {
                                var If;
                                var Bi = ma;
                                fC ? (gC(b, fC, Bi), If = !1) : (!Bi[K.m.Nb] && xg(11) && eC || (eC = Jd(Bi, null)), If = !0);
                                If && Ya.containers && Ya.containers.join(",");
                                c = void 0;
                                break a
                            }
                            GB();
                            if (xg(11) && !je && !ma[K.m.Nb]) {
                                var $k = dC;
                                dC = !0;
                                EB($k, ma, b);
                                if ($k) {
                                    c = void 0;
                                    break a
                                }
                            }
                            LB || Q(43);
                            b.noTargetGroup || (je ? (XB(Ea.id), UB(Ea.id, ma[K.m.Dd] || "default")) : (WB(Ea.id), TB(Ea.id, ma[K.m.Dd] || "default")));
                            delete ma[K.m.Dd];
                            var Jf = b.eventMetadata || {};
                            Jf.hasOwnProperty(S.C.Fc) || (Jf[S.C.Fc] = !b.fromContainerExecution);
                            b.eventMetadata = Jf;
                            delete ma[K.m.De];
                            for (var al = je ? [Ea.id] : uk(), Ci = 0; Ci < al.length; Ci++) {
                                var Di = ma,
                                    fp = al[Ci],
                                    bl = Jd(b, null),
                                    Fg = Cs(fp, bl.isGtmEvent);
                                Fg && Yt.push("config", [Di], Fg, bl)
                            }
                        }
                    }
                }
                c = void 0
            }
            return c
        }, hC.consent = function(a, b) {
            if (a.length === 3) {
                Q(39);
                var c = IB(a, b),
                    d = a[1],
                    e = {},
                    f = Nn(a[2]),
                    g;
                for (g in f)
                    if (f.hasOwnProperty(g)) {
                        var h = f[g];
                        e[g] = g === K.m.Yg ? Array.isArray(h) ? NaN : Number(h) : g === K.m.rc ? (Array.isArray(h) ? h : [h]).map(On) : Pn(h)
                    }
                b.fromContainerExecution || (e[K.m.aa] && Q(139), e[K.m.Ka] && Q(140));
                d === "default" ?
                    ro(e) : d === "update" ? to(e, c) : d === "declare" && b.fromContainerExecution && qo(e)
            }
        }, hC.container_config = function(a, b) {
            if (KB(b) && a.length === 3 && Db(a[1]) && Id(a[2])) {
                var c = a[2],
                    d = Cs(a[1], !0);
                d && $t(d.destinationId, c, Jd(b, null))
            }
        }, hC.destination_config = function(a, b) {
            if (KB(b) && a.length === 3 && Db(a[1]) && Id(a[2])) {
                var c = a[2],
                    d = Cs(a[1], !0);
                d && au(d.destinationId, c, Jd(b, null))
            }
        }, hC.event = function(a, b) {
            var c = a[1];
            if (!(a.length < 2) && Db(c)) {
                var d = void 0;
                if (a.length > 2) {
                    if (!Id(a[2]) && a[2] !== void 0 || a.length > 3) return;
                    d = a[2]
                }
                var e =
                    bC(c, d),
                    f = IB(a, b),
                    g = f.eventId,
                    h = f.priorityId;
                e["gtm.uniqueEventId"] = g;
                h && (e["gtm.priorityId"] = h);
                if (c === "optimize.callback") return e.eventModel = e.eventModel || {}, e;
                var l = cC(d, b);
                if (l) {
                    for (var n = l.Uj, p = l.Lq, q = p.map(function(L) {
                            return L.id
                        }), r = p.map(function(L) {
                            return L.destinationId
                        }), t = n.map(function(L) {
                            return L.id
                        }), u = m(uk()), v = u.next(); !v.done; v = u.next()) {
                        var x = v.value;
                        r.indexOf(x) < 0 && t.push(x)
                    }
                    JA(g, c);
                    for (var y = m(t), z = y.next(); !z.done; z = y.next()) {
                        var C = z.value,
                            D = Jd(b, null),
                            G = Jd(d, null);
                        delete G[K.m.De];
                        var J = D.eventMetadata || {};
                        J.hasOwnProperty(S.C.Fc) || (J[S.C.Fc] = !D.fromContainerExecution);
                        J[S.C.ej] = q.slice();
                        J[S.C.rg] = r.slice();
                        D.eventMetadata = J;
                        Xt(c, G, C, D)
                    }
                    e.eventModel = e.eventModel || {};
                    q.length > 0 ? e.eventModel[K.m.Hd] = q.join(",") : delete e.eventModel[K.m.Hd];
                    LB || Q(43);
                    b.noGtmEvent === void 0 && b.eventMetadata && b.eventMetadata[S.C.qn] && (b.noGtmEvent = !0);
                    e.eventModel[K.m.Sc] && (b.noGtmEvent = !0);
                    return b.noGtmEvent ? void 0 : e
                }
            }
        }, hC.get = function(a, b) {
            Q(53);
            if (a.length === 4 && Db(a[1]) && Db(a[2]) && Cb(a[3])) {
                var c =
                    Cs(a[1], b.isGtmEvent),
                    d = String(a[2]),
                    e = a[3];
                if (c) {
                    LB || Q(43);
                    var f = JB();
                    if (Gb(uk(), function(h) {
                            return c.destinationId === h
                        })) {
                        IB(a, b);
                        var g = {};
                        Jd((g[K.m.Pf] = d, g[K.m.Of] = e, g), null);
                        Zt(d, function(h) {
                            jd(function() {
                                e(h)
                            })
                        }, c.id, b)
                    } else bA(c.destinationId, f, {
                        source: 4,
                        fromContainerExecution: b.fromContainerExecution
                    })
                }
            }
        }, hC.js = function(a, b) {
            if (a.length === 2 && a[1].getTime) {
                LB = !0;
                var c = IB(a, b),
                    d = c.eventId,
                    e = c.priorityId,
                    f = {};
                return f.event = "gtm.js", f["gtm.start"] = a[1].getTime(), f["gtm.uniqueEventId"] = d, f["gtm.priorityId"] =
                    e, f
            }
        }, hC.policy = function(a) {
            if (a.length === 3 && Db(a[1]) && Cb(a[2])) {
                if (Cy(a[1], a[2]), Q(74), a[1] === "all") {
                    Q(75);
                    var b = !1;
                    try {
                        b = a[2](E(5), "unknown", {})
                    } catch (c) {}
                    b || Q(76)
                }
            } else Q(73)
        }, hC.reset_target_config = function(a, b) {
            if (KB(b) && a.length === 2 && Db(a[1])) {
                var c = Cs(a[1], !0);
                c && cu(c.destinationId)
            }
        }, hC.set = function(a, b) {
            var c = void 0;
            a.length === 2 && Id(a[1]) ? c = Jd(a[1], null) : a.length === 3 && Db(a[1]) && (c = {}, Id(a[2]) || Array.isArray(a[2]) ? c[a[1]] = Jd(a[2], null) : c[a[1]] = a[2]);
            if (c) {
                var d = IB(a, b),
                    e = d.eventId,
                    f = d.priorityId;
                Jd(c, null);
                E(5);
                var g = Jd(c, null);
                Yt.push("set", [g], void 0, b);
                c["gtm.uniqueEventId"] = e;
                f && (c["gtm.priorityId"] = f);
                delete c.event;
                b.overwriteModelFields = !0;
                return c
            }
        }, hC),
        jC = {},
        kC = (jC.policy = !0, jC);
    var mC = function(a) {
        if (lC(a)) return a;
        this.value = a
    };
    mC.prototype.getUntrustedMessageValue = function() {
        return this.value
    };
    var lC = function(a) {
        return !a || Gd(a) !== "object" || Id(a) ? !1 : "getUntrustedMessageValue" in a
    };
    mC.prototype.getUntrustedMessageValue = mC.prototype.getUntrustedMessageValue;
    var nC = function() {
        var a = this;
        this.loaded = !1;
        this.D = [];
        if (A.readyState === "complete") this.onLoad();
        else hd(w, "load", function() {
            return void a.onLoad()
        })
    };
    nC.prototype.onLoad = function() {
        if (!this.loaded) {
            this.loaded = !0;
            for (var a = 0; a < this.D.length; a++) jd(this.D[a])
        }
    };
    var pC = function(a) {
            var b = oC;
            b.loaded ? jd(a) : b.D.push(a)
        },
        oC = new nC;
    var qC = 0,
        rC = {},
        sC = [],
        tC = [],
        uC = !1,
        vC = !1;

    function wC(a, b) {
        return a.messageContext.eventId - b.messageContext.eventId || a.messageContext.priorityId - b.messageContext.priorityId
    }

    function xC(a, b, c) {
        a.eventCallback = b;
        c && (a.eventTimeout = c);
        return yC(a)
    }

    function zC(a, b) {
        if (!Eb(b) || b < 0) b = 0;
        var c = vs(),
            d = 0,
            e = !1,
            f = void 0;
        f = w.setTimeout(function() {
            e || (e = !0, a());
            f = void 0
        }, b);
        return function() {
            var g = c ? c.subscribers : 1;
            ++d === g && (f && (w.clearTimeout(f), f = void 0), e || (a(), e = !0))
        }
    }

    function AC(a) {
        if (a == null || typeof a !== "object") return !1;
        if (a.event) return !0;
        if (Mb(a)) {
            var b = a[0];
            if (b === "config" || b === "event" || b === "js" || b === "get") return !0
        }
        return !1
    }

    function BC() {
        var a;
        if (tC.length) a = tC.shift();
        else if (sC.length) a = sC.shift();
        else return;
        var b;
        var c = a;
        if (uC || !AC(c.message)) b = c;
        else {
            uC = !0;
            var d = c.message["gtm.uniqueEventId"],
                e, f;
            typeof d === "number" ? (e = d - 2, f = d - 1) : (e = ws(), f = ws(), c.message["gtm.uniqueEventId"] = ws());
            var g = {},
                h = {
                    message: (g.event = "gtm.init_consent", g["gtm.uniqueEventId"] = e, g),
                    messageContext: {
                        eventId: e
                    }
                },
                l = {},
                n = {
                    message: (l.event = "gtm.init", l["gtm.uniqueEventId"] = f, l),
                    messageContext: {
                        eventId: f
                    }
                };
            sC.unshift(n, c);
            b = h
        }
        return b
    }

    function CC() {
        for (var a = !1, b; !vC && (b = BC());) {
            vC = !0;
            delete st.eventModel;
            ut();
            var c = b,
                d = c.message,
                e = c.messageContext;
            if (d == null) vC = !1;
            else {
                e.fromContainerExecution && At();
                try {
                    if (Cb(d)) try {
                        d.call(wt)
                    } catch (G) {} else if (Array.isArray(d)) {
                        if (Db(d[0])) {
                            var f = d[0].split("."),
                                g = f.pop(),
                                h = d.slice(1),
                                l = vt(f.join("."), 2);
                            if (l != null) try {
                                l[g].apply(l, h)
                            } catch (G) {}
                        }
                    } else {
                        var n = void 0;
                        if (Mb(d)) a: {
                            if (d.length && Db(d[0])) {
                                var p = iC[d[0]];
                                if (p && (!e.fromContainerExecution || !kC[d[0]])) {
                                    n = p(d, e);
                                    break a
                                }
                            }
                            n = void 0
                        }
                        else n =
                            d;
                        if (n) {
                            var q;
                            for (var r = n, t = r._clear || e.overwriteModelFields, u = m(Object.keys(r)), v = u.next(); !v.done; v = u.next()) {
                                var x = v.value;
                                x !== "_clear" && (t && zt(x), zt(x, r[x]))
                            }
                            Ej || (Ej = r["gtm.start"]);
                            var y = r["gtm.uniqueEventId"];
                            r.event ? (typeof y !== "number" && (y = ws(), r["gtm.uniqueEventId"] = y, zt("gtm.uniqueEventId", y)), q = iB(r)) : q = !1;
                            a = q || a
                        }
                    }
                } finally {
                    e.fromContainerExecution && ut(!0);
                    var z = d["gtm.uniqueEventId"];
                    if (typeof z === "number") {
                        for (var C = rC[String(z)] || [], D = 0; D < C.length; D++) tC.push(DC(C[D]));
                        C.length && tC.sort(wC);
                        delete rC[String(z)];
                        z > qC && (qC = z)
                    }
                    vC = !1
                }
            }
        }
        return !a
    }

    function EC() {
        if (P(109)) {
            var a = !xg(51);
        }
        var c = CC();
        if (P(109)) {}
        try {
            var e = w[E(19)],
                f = E(5),
                g = e.hide;
            if (g && g[f] !== void 0 &&
                g.end) {
                g[f] = !1;
                var h = !0,
                    l;
                for (l in g)
                    if (g.hasOwnProperty(l) && g[l] === !0) {
                        h = !1;
                        break
                    }
                h && (g.end(), g.end = null)
            }
        } catch (n) {
            E(5)
        }
        return c
    }

    function QB(a) {
        if (qC < a.notBeforeEventId) {
            var b = String(a.notBeforeEventId);
            rC[b] = rC[b] || [];
            rC[b].push(a)
        } else tC.push(DC(a)), tC.sort(wC), jd(function() {
            vC || CC()
        })
    }

    function DC(a) {
        return {
            message: a.message,
            messageContext: a.messageContext
        }
    }

    function FC() {
        function a(f) {
            var g = {};
            if (lC(f)) {
                var h = f;
                f = lC(h) ? h.getUntrustedMessageValue() : void 0;
                g.fromContainerExecution = !0
            }
            return {
                message: f,
                messageContext: g
            }
        }
        var b = Vc(E(19), []),
            c = us();
        c.pruned === !0 && Q(83);
        rC = OB().get();
        PB();
        CB(function() {
            if (!c.gtmDom) {
                c.gtmDom = !0;
                var f = {};
                b.push((f.event = "gtm.dom", f))
            }
        });
        pC(function() {
            if (!c.gtmLoad) {
                c.gtmLoad = !0;
                var f = {};
                b.push((f.event = "gtm.load", f))
            }
        });
        c.subscribers = (c.subscribers || 0) + 1;
        var d = b.push;
        b.push = function() {
            var f;
            if (qs.SANDBOXED_JS_SEMAPHORE > 0) {
                f = [];
                for (var g = 0; g < arguments.length; g++) f[g] = new mC(arguments[g])
            } else f = [].slice.call(arguments, 0);
            var h = f.map(function(q) {
                return a(q)
            });
            sC.push.apply(sC, h);
            var l = d.apply(b, f),
                n = Math.max(100, Cg(1, 300));
            if (this.length > n)
                for (Q(4), c.pruned = !0; this.length > n;) this.shift();
            var p = typeof l !== "boolean" || l;
            return CC() && p
        };
        var e = b.slice(0).map(function(f) {
            return a(f)
        });
        sC.push.apply(sC, e);
        if (!xg(51)) {
            if (P(109)) {}
            jd(EC)
        }
    }
    var yC = function(a) {
        return w[E(19)].push(a)
    };

    function GC(a) {
        yC(a)
    };

    function HC() {
        var a, b = Sj(w.location.href);
        (a = b.hostname + b.pathname) && Sk("dl", encodeURIComponent(a));
        var c;
        var d = E(5);
        if (d) {
            var e = xg(7) ? 1 : 0,
                f = Gk(),
                g = f && f.fromContainerExecution ? 1 : 0,
                h = f && f.source || 0,
                l = E(6);
            c = d + ";" + l + ";" + g + ";" + h + ";" + e
        } else c = void 0;
        var n = c;
        n && Sk("tdp", n);
        var p = No(!0);
        p !== void 0 && Sk("frm", String(p))
    };
    var IC = cl(),
        JC = void 0;

    function KC(a) {
        return el(a, function(b) {
            return b.lb > 0 ? String(b.lb) : void 0
        })
    }

    function LC() {
        if (Zn() || nl) Sk("csp", function() {
            var a = KC(IC);
            fl(IC);
            return a
        }, !1), Sk("mde", function() {
            var a = KC(hl);
            fl(hl);
            return a
        }, !1), w.addEventListener("securitypolicyviolation", MC)
    }

    function MC(a) {
        if (a.disposition === "enforce") {
            Q(179);
            var b = ul(a.effectiveDirective);
            if (b) {
                var c;
                a: {
                    var d = a.blockedURI;
                    if (nl && d) {
                        var e = sl(b, d);
                        if (e) {
                            c = ql[b][e];
                            break a
                        }
                    }
                    c = void 0
                }
                var f = c;
                if (f) {
                    var g;
                    a: {
                        try {
                            var h = new URL(a.blockedURI),
                                l = h.pathname.indexOf(";");
                            g = l >= 0 ? h.origin + h.pathname.substring(0, l) : h.origin + h.pathname;
                            break a
                        } catch (y) {}
                        g = void 0
                    }
                    var n = g;
                    if (n) {
                        for (var p = m(f), q = p.next(); !q.done; q = p.next()) {
                            var r = q.value;
                            if (!r.qo) {
                                r.qo = !0;
                                var t = {
                                    eventId: r.eventId,
                                    priorityId: r.priorityId
                                };
                                if (Zn()) {
                                    var u =
                                        t,
                                        v = {
                                            type: 1,
                                            blockedUrl: n,
                                            endpoint: r.endpoint,
                                            violation: a.effectiveDirective
                                        };
                                    if (Zn()) {
                                        var x = fo("TAG_DIAGNOSTICS", {
                                            eventId: u == null ? void 0 : u.eventId,
                                            priorityId: u == null ? void 0 : u.priorityId
                                        });
                                        x.tagDiagnostics = v;
                                        Yn(x)
                                    }
                                }
                                NC(r.destinationId, r.endpoint)
                            }
                        }
                        tl(b, a.blockedURI)
                    }
                }
            }
        }
    }

    function NC(a, b) {
        gl(IC, a, b);
        Tk("csp", !0);
        Tk("mde", !0);
        b !== 61 && b !== 56 && JC === void 0 && (JC = w.setTimeout(function() {
            IC.lb > 0 && Xm(!1);
            JC = void 0
        }, 500))
    };

    function OC(a) {
        return function() {
            return w[a]
        }
    }
    var PC = {},
        QC = (PC[1] = OC("fetch"), PC[6] = OC("Map"), PC[2] = function() {
            return Math.random
        }, PC[8] = function() {
            return pa(Object, "assign")
        }, PC[9] = function() {
            return Object.entries
        }, PC[10] = function() {
            return Object.fromEntries
        }, PC[5] = OC("Promise"), PC[13] = OC("RegExp"), PC[3] = function() {
            return Rc.sendBeacon
        }, PC[7] = OC("Set"), PC[12] = function() {
            return String.prototype.endsWith
        }, PC[11] = function() {
            return String.prototype.startsWith
        }, PC[4] = OC("XMLHttpRequest"), PC);

    function RC() {
        for (var a = [], b = [], c = m(Object.keys(QC)), d = c.next(); !d.done; d = c.next()) {
            var e = d.value,
                f = QC[e]();
            if (typeof f !== "function") a.push(e);
            else {
                var g = Function.prototype.toString.call(f);
                Zb(g, "{ [native code] }") || Zb(g, "{\n    [native code]\n}") || b.push(e)
            }
        }
        a.length > 0 && Sk("jsm", a.join("~"));
        b.length > 0 && Sk("jsp", b.join("~"))
    };
    var SC = void 0;

    function TC() {
        P(236) && w.addEventListener("pageshow", function(a) {
            a && (Sk("bfc", function() {
                return SC ? "1" : "0"
            }), a.persisted ? (SC = !0, Tk("bfc", !0), Xm()) : SC = !1)
        })
    };

    function UC() {
        var a;
        var b = yk();
        if (b)
            if (b.canonicalContainerId) a = b.canonicalContainerId;
            else {
                var c, d = b.scriptContainerId || ((c = b.destinations) == null ? void 0 : c[0]);
                a = d ? "_" + d : void 0
            }
        else a = void 0;
        var e = a;
        e && Sk("pcid", e)
    };
    var VC = /^(https?:)?\/\//;

    function WC() {
        var a = Bk();
        if (a) {
            var b;
            a: {
                var c, d = (c = a.scriptElement) == null ? void 0 : c.src;
                if (d) {
                    var e;
                    try {
                        var f;
                        e = (f = xd()) == null ? void 0 : f.getEntriesByType("resource")
                    } catch (q) {}
                    if (e) {
                        for (var g = -1, h = m(e), l = h.next(); !l.done; l = h.next()) {
                            var n = l.value;
                            if (n.initiatorType === "script" && (g += 1, n.name.replace(VC, "") === d.replace(VC, ""))) {
                                b = g;
                                break a
                            }
                        }
                        Q(146)
                    } else Q(145)
                }
                b = void 0
            }
            var p = b;
            p !== void 0 && (a.canonicalContainerId && Sk("rtg", String(a.canonicalContainerId)), Sk("slo", String(p)), Sk("hlo", a.htmlLoadOrder || "-1"),
                Sk("lst", String(a.loadScriptType || "0")))
        } else Q(144)
    };

    function qD() {};
    var rD = function() {};
    rD.prototype.toString = function() {
        return "undefined"
    };
    var sD = new rD;
    var zD = {};

    function AD(a) {
        ll && (zD[a] = (zD[a] || 0) + 1)
    }

    function BD() {
        var a = [];
        zD[1] && a.push("1." + zD[1]);
        zD[2] && a.push("2." + zD[2]);
        zD[3] && a.push("3." + zD[3]);
        return a.length ? [
            ["odp", a.join("~")]
        ] : []
    };

    function CD() {
        (P(479) || P(405)) && E(5).indexOf("GTM-") !== 0 && (Cy("detect_link_click_events", function(a, b, c) {
            var d = c.options;
            return P(405) ? ((d == null ? void 0 : d.waitForTags) === !0 && AD(1), !0) : (d == null ? void 0 : d.waitForTags) !== !0
        }), Cy("detect_form_submit_events", function(a, b, c) {
            var d = c.options;
            return P(405) ? ((d == null ? void 0 : d.waitForTags) === !0 && AD(2), !0) : (d == null ? void 0 : d.waitForTags) !== !0
        }), Cy("detect_youtube_activity_events", function(a, b, c) {
            var d = c.options;
            return P(405) ? ((d == null ? void 0 : d.fixMissingApi) ===
                !0 && AD(3), !0) : (d == null ? void 0 : d.fixMissingApi) !== !0
        }));
        (P(479) || P(407)) && Bj && RA(wk(), function(a) {
            var b, c, d;
            b = a.entityId;
            c = a.securityGroups;
            d = a.originalEventData;
            var e = "__" + b,
                f = mA(e, 5) || !(!lg[e] || !lg[e][5]) || c.includes("cmpPartners");
            return P(407) ? (f || ll && MA(Number(d["gtm.uniqueEventId"]), b, "r"), !0) : f
        })
    };

    function DD(a, b) {
        function c(g) {
            var h = Sj(g),
                l = Mj(h, "protocol"),
                n = Mj(h, "host", !0),
                p = Mj(h, "port"),
                q = Mj(h, "path").toLowerCase().replace(/\/$/, "");
            if (l === void 0 || l === "http" && p === "80" || l === "https" && p === "443") l = "web", p = "default";
            return [l, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function ED(a) {
        return FD(a) ? 1 : 0
    }

    function FD(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && Array.isArray(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = Jd(a, {});
                Jd({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (ED(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return th(b, c);
            case "_css":
                var f;
                a: {
                    if (b) try {
                        for (var g = 0; g < oh.length; g++) {
                            var h = oh[g];
                            if (b[h] != null) {
                                f = b[h](c);
                                break a
                            }
                        }
                    } catch (l) {}
                    f = !1
                }
                return f;
            case "_ew":
                return ph(b, c);
            case "_eq":
                return uh(b, c);
            case "_ge":
                return vh(b, c);
            case "_gt":
                return xh(b, c);
            case "_lc":
                return qh(b, c);
            case "_le":
                return wh(b,
                    c);
            case "_lt":
                return yh(b, c);
            case "_re":
                return sh(b, c, a.ignore_case);
            case "_sw":
                return zh(b, c);
            case "_um":
                return DD(b, c)
        }
        return !1
    };
    var GD = function() {
        this.D = this.gppString = void 0
    };
    GD.prototype.reset = function() {
        this.D = this.gppString = void 0
    };
    var HD = new GD;
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    mu({
        Vt: 0,
        Ut: 1,
        Rt: 2,
        Mt: 3,
        St: 4,
        Nt: 5,
        Tt: 6,
        Pt: 7,
        Qt: 8,
        Lt: 9,
        Ot: 10,
        Wt: 11
    }).map(function(a) {
        return Number(a)
    });
    mu({
        Yt: 0,
        Zt: 1,
        Xt: 2
    }).map(function(a) {
        return Number(a)
    });
    var ID = function(a, b, c, d) {
        su.call(this);
        this.Td = b;
        this.Zc = c;
        this.bc = d;
        this.sb = new Map;
        this.Ud = 0;
        this.ma = new Map;
        this.Ta = new Map;
        this.V = void 0;
        this.J = a
    };
    xa(ID, su);
    ID.prototype.O = function() {
        delete this.D;
        this.sb.clear();
        this.ma.clear();
        this.Ta.clear();
        this.V && (ou(this.J, "message", this.V), delete this.V);
        delete this.J;
        delete this.bc;
        su.prototype.O.call(this)
    };
    var JD = function(a) {
            if (a.D) return a.D;
            a.Zc && a.Zc(a.J) ? a.D = a.J : a.D = Mo(a.J, a.Td);
            var b;
            return (b = a.D) != null ? b : null
        },
        LD = function(a, b, c) {
            if (JD(a))
                if (a.D === a.J) {
                    var d = a.sb.get(b);
                    d && d(a.D, c)
                } else {
                    var e = a.ma.get(b);
                    if (e && e.Tj) {
                        KD(a);
                        var f = ++a.Ud;
                        a.Ta.set(f, {
                            fi: e.fi,
                            hr: e.Wn(c),
                            persistent: b === "addEventListener"
                        });
                        a.D.postMessage(e.Tj(c, f), "*")
                    }
                }
        },
        KD = function(a) {
            a.V || (a.V = function(b) {
                try {
                    var c;
                    c = a.bc ? a.bc(b) : void 0;
                    if (c) {
                        var d = c.vs,
                            e = a.Ta.get(d);
                        if (e) {
                            e.persistent || a.Ta.delete(d);
                            var f;
                            (f = e.fi) == null || f.call(e,
                                e.hr, c.payload)
                        }
                    }
                } catch (g) {}
            }, nu(a.J, "message", a.V))
        };
    var MD = function(a, b) {
            var c = b.listener,
                d = (0, a.__gpp)("addEventListener", c);
            d && c(d, !0)
        },
        ND = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        OD = {
            Wn: function(a) {
                return a.listener
            },
            Tj: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, c
            },
            fi: function(a, b) {
                var c = b.__gppReturn;
                a(c.returnValue, c.success)
            }
        },
        PD = {
            Wn: function(a) {
                return a.listener
            },
            Tj: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            fi: function(a, b) {
                var c = b.__gppReturn,
                    d = c.returnValue.data;
                a == null || a(d, c.success)
            }
        };

    function QD(a) {
        var b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            vs: b.__gppReturn.callId
        }
    }
    var RD = function(a, b) {
        var c;
        c = (b === void 0 ? {} : b).timeoutMs;
        su.call(this);
        this.caller = new ID(a, "__gppLocator", function(d) {
            return typeof d.__gpp === "function"
        }, QD);
        this.caller.sb.set("addEventListener", MD);
        this.caller.ma.set("addEventListener", OD);
        this.caller.sb.set("removeEventListener", ND);
        this.caller.ma.set("removeEventListener", PD);
        this.timeoutMs = c != null ? c : 500
    };
    xa(RD, su);
    RD.prototype.O = function() {
        this.caller.dispose();
        su.prototype.O.call(this)
    };
    RD.prototype.addEventListener = function(a) {
        var b = this,
            c = Jo(function() {
                a(SD, !0)
            }),
            d = this.timeoutMs === -1 ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        LD(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    var h;
                    ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 || e.pingData.gppVersion === "1" || e.pingData.gppVersion === "1.0" ? (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 1,
                            gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                            applicableSections: [-1]
                        }
                    }) : Array.isArray(e.pingData.applicableSections) ? g = e : (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(g, f)
                } catch (l) {
                    if (e == null ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (n) {
                        a(TD, !0);
                        return
                    }
                    a(UD, !0)
                }
            }
        })
    };
    RD.prototype.removeEventListener = function(a) {
        LD(this.caller, "removeEventListener", {
            listener: function() {},
            listenerId: a
        })
    };
    var UD = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        SD = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        TD = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function VD(a) {
        var b;
        if (!(b = a.pingData.signalStatus === "ready")) {
            var c = a.pingData.applicableSections;
            b = !c || c.length === 1 && c[0] === -1
        }
        if (b) {
            HD.gppString = a.pingData.gppString;
            var d = a.pingData.applicableSections.join(",");
            HD.D = d
        }
    }

    function WD() {
        try {
            var a = new RD(w, {
                timeoutMs: -1
            });
            JD(a.caller) && a.addEventListener(VD)
        } catch (b) {}
    };

    function XD() {
        var a = [
                ["cv", E(1)],
                ["rv", E(14)],
                ["tc", jg.filter(function(c) {
                    return c
                }).length]
            ],
            b = yg(15);
        b && a.push(["x", b]);
        Vk() && a.push(["tag_exp", Vk()]);
        return a
    };
    var YD = 0,
        ZD = 0,
        $D = !1,
        aE = void 0,
        bE = Cg(63, 2E3);

    function cE() {
        if (P(468) && ll) {
            ZD++;
            aE = Tb();
            var a = w.jQuery;
            if (a && typeof a === "function") try {
                var b = a(A);
                (b.on || b.bind).call(b, "ajaxComplete", function() {
                    aE && Tb() < aE + bE && YD++
                })
            } catch (c) {}
        }
    }

    function dE(a) {
        var b = [];
        YD > 0 && b.push(["ajx", String(YD)]);
        ZD > 0 && b.push(["ajdc", String(ZD)]);
        a.me && (ZD = YD = 0);
        return b
    }

    function eE(a) {
        var b = [];
        $D && (b.push(["ifb", "1"]), a.me && ($D = !1));
        return b
    };
    var fE = {},
        gE = {};

    function hE(a) {
        var b = a.eventId,
            c = a.me,
            d = [],
            e = fE[b] || [];
        e.length && d.push(["hf", e.join(".")]);
        var f = gE[b] || [];
        f.length && d.push(["ht", f.join(".")]);
        c && (delete fE[b], delete gE[b]);
        return d
    };

    function iE() {
        return !1
    }

    function jE() {
        var a = {};
        return function(b, c, d) {}
    };

    function kE() {
        var a = lE;
        return function(b, c, d) {
            var e = d && d.event;
            mE(c);
            var f = ei(b) ? void 0 : 1,
                g = new nb;
            Lb(c, function(r, t) {
                var u = Xd(t, void 0, f);
                u === void 0 && t !== void 0 && Q(44);
                g.set(r, u)
            });
            a.Tb(Gg());
            var h = {
                Cn: Ug(b),
                eventId: e == null ? void 0 : e.id,
                priorityId: e !== void 0 ? e.priorityId : void 0,
                vg: e !== void 0 ? function(r) {
                    e.dd.vg(r)
                } : void 0,
                Rb: function() {
                    return b
                },
                log: function() {},
                nr: {
                    index: d == null ? void 0 : d.index,
                    type: d == null ? void 0 : d.type,
                    name: d == null ? void 0 : d.name
                },
                Ds: !!mA(b, 3),
                originalEventData: e == null ? void 0 : e.originalEventData
            };
            e && e.cachedModelValues && (h.cachedModelValues = {
                gtm: e.cachedModelValues.gtm,
                ecommerce: e.cachedModelValues.ecommerce
            });
            if (iE()) {
                var l = jE(),
                    n, p;
                h.zb = {
                    lk: [],
                    xg: {},
                    mc: function(r, t, u) {
                        t === 1 && (n = r);
                        t === 7 && (p = u);
                        l(r, t, u)
                    },
                    ei: yi()
                };
                h.log = function(r) {
                    var t = Qa.apply(1, arguments);
                    n && l(n, 4, {
                        level: r,
                        source: p,
                        message: t
                    })
                }
            }
            var q = wf(a, h, [b, g]);
            a.Tb();
            q instanceof Ua && (q.type === "return" ? q = q.data : q = void 0);
            return B(q, void 0, f)
        }
    }

    function mE(a) {
        var b = a.gtmOnSuccess,
            c = a.gtmOnFailure;
        Cb(b) && (a.gtmOnSuccess = function() {
            jd(b)
        });
        Cb(c) && (a.gtmOnFailure = function() {
            jd(c)
        })
    };

    function nE(a) {}
    nE.K = "internal.addAdsClickIds";

    function oE(a, b) {
        var c = this;
    }
    oE.publicName = "addConsentListener";
    var pE = !1;

    function qE(a) {
        for (var b = 0; b < a.length; ++b)
            if (pE) try {
                a[b]()
            } catch (c) {
                Q(77)
            } else a[b]()
    }

    function rE(a, b, c) {
        var d = this,
            e;
        return e
    }
    rE.K = "internal.addDataLayerEventListener";

    function sE(a, b, c) {}
    sE.publicName = "addDocumentEventListener";

    function tE(a, b, c, d) {}
    tE.publicName = "addElementEventListener";

    function uE(a) {
        return a.M.xb()
    };

    function vE(a) {}
    vE.publicName = "addEventCallback";

    function GE(a) {
        if (a.form) {
            var b;
            return ((b = a.form) == null ? 0 : b.tagName) ? a.form : A.getElementById(a.form)
        }
        return nd(a, ["form"], 100)
    };

    function KE(a) {}
    KE.K = "internal.addFormAbandonmentListener";

    function LE(a, b, c, d) {}
    LE.K = "internal.addFormData";
    var ME = {},
        NE = [],
        OE = {},
        PE = 0,
        QE = 0;

    function XE(a, b) {}
    XE.K = "internal.addFormInteractionListener";

    function dF(a, b) {}
    dF.K = "internal.addFormSubmitListener";

    function iF(a) {}
    iF.K = "internal.addGaSendListener";

    function jF(a) {
        if (!a) return {};
        var b = a.nr;
        return lA(b.type, b.index, b.name)
    }

    function kF(a) {
        return a ? {
            originatingEntity: jF(a)
        } : {}
    };

    function sF(a) {
        var b = qs.zones;
        return b ? b.getIsAllowedFn(xk(), a) : function() {
            return !0
        }
    }

    function tF() {
        var a = qs.zones;
        a && a.unregisterChild(xk())
    }

    function uF() {
        TA(wk(), function(a) {
            var b = a.originalEventData["gtm.uniqueEventId"],
                c = qs.zones;
            return c ? c.isActive(xk(), b) : !0
        });
        RA(wk(), function(a) {
            var b, c;
            b = a.entityId;
            c = a.securityGroups;
            return sF(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c)
        })
    };
    var vF = function(a, b) {
        this.tagId = a;
        this.canonicalId = b
    };

    function wF(a, b) {
        var c = this;
        return a
    }
    wF.K = "internal.loadGoogleTag";

    function xF(a) {
        return new Pd("", function(b) {
            var c = this.evaluate(b);
            if (c instanceof Pd) return new Pd("", function() {
                var d = Qa.apply(0, arguments),
                    e = this,
                    f = Jd(uE(this), null);
                f.eventId = a.eventId;
                f.priorityId = a.priorityId;
                f.originalEventData = a.originalEventData;
                var g = d.map(function(l) {
                        return e.evaluate(l)
                    }),
                    h = this.M.ub();
                h.he(f);
                return c.Sb.apply(c, [h].concat(Aa(g)))
            })
        })
    };

    function yF(a, b, c) {
        var d = this;
    }
    yF.K = "internal.addGoogleTagRestriction";
    var zF = {},
        AF = [];

    function HF(a, b) {}
    HF.K = "internal.addHistoryChangeListener";

    function IF(a, b, c) {}
    IF.publicName = "addWindowEventListener";

    function JF(a, b) {
        if (!Qh(a) || !Qh(b)) throw H(this.getName(), ["string", "string"], arguments);
        I(this, "access_globals", "write", a);
        I(this, "access_globals", "read", b);
        var c = a.split("."),
            d = b.split("."),
            e = w,
            f = [e, A],
            g = $b(e, c, f),
            h = $b(e, d, f);
        if (g === void 0 || h === void 0) return !1;
        g[c[c.length - 1]] = h[d[d.length - 1]];
        return !0
    }
    JF.publicName = "aliasInWindow";

    function KF(a, b, c) {}
    KF.K = "internal.appendRemoteConfigParameter";

    function LF(a) {
        var b;
        if (!Qh(a)) throw H(this.getName(), ["string", "...any"], arguments);
        I(this, "access_globals", "execute", a);
        for (var c = a.split("."), d = w, e = d[c[0]], f = 1; e && f < c.length; f++)
            if (d = e, e = e[c[f]], d === w || d === A) return;
        if (Gd(e) !== "function") return;
        for (var g = [], h = 1; h < arguments.length; h++) g.push(B(arguments[h], this.M, 2));
        var l = this.M.Dj()(e, d, g);
        b = Xd(l, this.M, 2);
        b === void 0 && l !== void 0 && Q(45);
        return b
    }
    LF.publicName = "callInWindow";

    function MF(a) {}
    MF.publicName = "callLater";

    function NF(a) {}
    NF.K = "callOnDomReady";

    function OF(a) {}
    OF.K = "callOnWindowLoad";

    function PF(a, b) {
        var c;
        return c
    }
    PF.K = "internal.computeGtmParameter";

    function QF(a, b) {
        var c = this;
    }
    QF.K = "internal.consentScheduleFirstTry";

    function RF(a, b) {
        var c = this;
    }
    RF.K = "internal.consentScheduleRetry";

    function SF(a) {
        var b;
        return b
    }
    SF.K = "internal.copyFromCrossContainerData";

    function TF(a, b) {
        var c;
        if (!Qh(a) || !Vh(b) && b !== null && !Lh(b)) throw H(this.getName(), ["string", "number|undefined"], arguments);
        I(this, "read_data_layer", a);
        c = (b || 2) !== 2 ? vt(a, 1) : xt(a, [w, A]);
        var d = Xd(c, this.M, ei(uE(this).Rb()) ? 2 : 1);
        d === void 0 && c !== void 0 && Q(45);
        return d
    }
    TF.publicName = "copyFromDataLayer";

    function UF(a) {
        var b = void 0;
        return b
    }
    UF.K = "internal.copyFromDataLayerCache";

    function VF(a) {
        var b;
        if (!Qh(a)) throw H(this.getName(), ["string"], arguments);
        I(this, "access_globals", "read", a);
        var c = a.split("."),
            d = $b(w, c, [w, A]);
        if (!d) return;
        var e = d[c[c.length - 1]];
        b = Xd(e, this.M, 2);
        b === void 0 && e !== void 0 && Q(45);
        return b
    }
    VF.publicName = "copyFromWindow";

    function WF(a) {
        var b = void 0;
        return Xd(b, this.M, 1)
    }
    WF.K = "internal.copyKeyFromWindow";
    var XF = function(a) {
        return a === km.ba.Ya && Cm[a] === jm.Na.Qe && !vo(K.m.X)
    };
    var YF = function() {
            return "0"
        },
        ZF = function(a) {
            if (typeof a !== "string") return "";
            var b = ["gclid", "dclid", "wbraid", "_gl"];
            P(102) && b.push("gbraid");
            return Tj(a, b, "0")
        };
    var $F = {},
        aG = {},
        bG = {},
        cG = {},
        dG = {},
        eG = {},
        fG = {},
        gG = {},
        hG = {},
        iG = {},
        jG = {},
        kG = {},
        lG = {},
        mG = {},
        nG = {},
        oG = {},
        pG = {},
        qG = {},
        rG = {},
        sG = {},
        tG = {},
        uG = {},
        vG = {},
        wG = {},
        xG = {},
        yG = {},
        zG = (yG[K.m.Oa] = ($F[2] = [XF], $F), yG[K.m.Vf] = (aG[2] = [XF], aG), yG[K.m.Nf] = (bG[2] = [XF], bG), yG[K.m.Rl] = (cG[2] = [XF], cG), yG[K.m.Sl] = (dG[2] = [XF], dG), yG[K.m.Tl] = (eG[2] = [XF], eG), yG[K.m.Ul] = (fG[2] = [XF], fG), yG[K.m.Vl] = (gG[2] = [XF], gG), yG[K.m.Kd] = (hG[2] = [XF], hG), yG[K.m.Wf] = (iG[2] = [XF], iG), yG[K.m.Xf] = (jG[2] = [XF], jG), yG[K.m.Yf] = (kG[2] = [XF], kG), yG[K.m.Zf] = (lG[2] = [XF], lG), yG[K.m.cg] = (mG[2] = [XF], mG), yG[K.m.dg] = (nG[2] = [XF], nG), yG[K.m.eg] = (oG[2] = [XF], oG), yG[K.m.fg] = (pG[2] = [XF], pG), yG[K.m.Ab] = (qG[1] = [XF], qG), yG[K.m.ud] = (rG[1] = [XF], rG), yG[K.m.zd] = (sG[1] = [XF], sG), yG[K.m.ye] = (tG[1] = [XF], tG), yG[K.m.wf] = (uG[1] = [function(a) {
            return P(102) && XF(a)
        }], uG), yG[K.m.Oc] = (vG[1] = [XF], vG), yG[K.m.za] = (wG[1] = [XF], wG), yG[K.m.Za] = (xG[1] = [XF], xG), yG),
        AG = {},
        BG = (AG[K.m.Ab] = YF, AG[K.m.ud] = YF, AG[K.m.zd] = YF, AG[K.m.ye] = YF, AG[K.m.wf] = YF, AG[K.m.Oc] = function(a) {
            if (!Id(a)) return {};
            var b = Jd(a,
                null);
            delete b.match_id;
            return b
        }, AG[K.m.za] = ZF, AG[K.m.Za] = ZF, AG),
        CG = {},
        DG = {},
        EG = (DG[S.C.Qa] = (CG[2] = [XF], CG), DG),
        FG = {};
    var GG = function(a, b, c, d) {
        this.D = a;
        this.O = b;
        this.T = c;
        this.V = d
    };
    GG.prototype.getValue = function(a) {
        a = a === void 0 ? km.ba.Yc : a;
        if (!this.O.some(function(b) {
                return b(a)
            })) return this.T.some(function(b) {
            return b(a)
        }) ? this.V(this.D) : this.D
    };
    GG.prototype.J = function() {
        return Gd(this.D) === "array" || Id(this.D) ? Jd(this.D, null) : this.D
    };
    var HG = function() {},
        IG = function(a, b) {
            this.conditions = a;
            this.D = b
        };
    IG.prototype.tb = function(a, b) {
        var c, d = ((c = this.conditions[a]) == null ? void 0 : c[2]) || [],
            e, f = ((e = this.conditions[a]) == null ? void 0 : e[1]) || [];
        return new GG(b, d, f, this.D[a] || HG)
    };
    var JG, KG;
    var LG, MG = !1;

    function NG() {
        MG = !0;
        xg(52) && (LG = productSettings, productSettings = void 0);
        LG = LG || {}
    }

    function OG(a) {
        MG || NG();
        return LG[a]
    };
    var PG = function(a, b, c) {
            this.eventName = b;
            this.F = c;
            this.D = {};
            this.isAborted = !1;
            this.target = a;
            this.metadata = {};
            for (var d = c.eventMetadata || {}, e = m(Object.keys(d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                U(this, g, d[g])
            }
        },
        Vr = function(a, b) {
            var c, d;
            return (c = a.D[b]) == null ? void 0 : (d = c.getValue) == null ? void 0 : d.call(c, T(a, S.C.sg))
        },
        W = function(a, b, c) {
            var d = a.D,
                e;
            c === void 0 ? e = void 0 : (JG != null || (JG = new IG(zG, BG)), e = JG.tb(b, c));
            d[b] = e
        };
    PG.prototype.mergeHitDataForKey = function(a, b) {
        var c, d, e;
        c = (d = this.D[a]) == null ? void 0 : (e = d.J) == null ? void 0 : e.call(d);
        if (!c) return W(this, a, b), !0;
        if (!Id(c)) return !1;
        W(this, a, pa(Object, "assign").call(Object, c, b));
        return !0
    };
    var QG = function(a, b) {
        b = b === void 0 ? {} : b;
        for (var c = m(Object.keys(a.D)), d = c.next(); !d.done; d = c.next()) {
            var e = d.value,
                f = void 0,
                g = void 0,
                h = void 0;
            b[e] = (f = a.D[e]) == null ? void 0 : (h = (g = f).J) == null ? void 0 : h.call(g)
        }
        return b
    };
    PG.prototype.copyToHitData = function(a, b, c) {
        var d = O(this.F, a);
        d === void 0 && (d = b);
        if (Db(d) && c !== void 0) try {
            d = c(d)
        } catch (e) {}
        d !== void 0 && W(this, a, d)
    };
    var T = function(a, b) {
            var c = a.metadata[b];
            if (b === S.C.sg) {
                var d;
                return c == null ? void 0 : (d = c.J) == null ? void 0 : d.call(c)
            }
            var e;
            return c == null ? void 0 : (e = c.getValue) == null ? void 0 : e.call(c, T(a, S.C.sg))
        },
        U = function(a, b, c) {
            var d = a.metadata,
                e;
            c === void 0 ? e = c : (KG != null || (KG = new IG(EG, FG)), e = KG.tb(b, c));
            d[b] = e
        },
        RG = function(a, b) {
            b = b === void 0 ? {} : b;
            for (var c = m(Object.keys(a.metadata)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value,
                    f = void 0,
                    g = void 0,
                    h = void 0;
                b[e] = (f = a.metadata[e]) == null ? void 0 : (h = (g = f).J) == null ? void 0 :
                    h.call(g)
            }
            return b
        },
        SG = function(a, b, c) {
            var d = OG(a.target.destinationId);
            return d && d[b] !== void 0 ? d[b] : c
        },
        TG = function(a) {
            for (var b = new PG(a.target, a.eventName, a.F), c = QG(a), d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
                var f = e.value;
                W(b, f, c[f])
            }
            for (var g = RG(a), h = m(Object.keys(g)), l = h.next(); !l.done; l = h.next()) {
                var n = l.value;
                U(b, n, g[n])
            }
            b.isAborted = a.isAborted;
            return b
        },
        UG = function(a) {
            var b = a.F,
                c = b.eventId,
                d = b.priorityId;
            return d ? c + "_" + d : String(c)
        };
    PG.prototype.accept = function() {
        var a = Qm(Lm.Z.Li, {}),
            b = UG(this),
            c = this.target.destinationId;
        a[b] || (a[b] = {});
        a[b][c] = wk();
        var d = Lm.Z.Li;
        if (Mm(d)) {
            var e;
            (e = Nm(d)) == null || e.notify()
        }
    };
    PG.prototype.canBeAccepted = function(a) {
        var b = Pm(Lm.Z.Li);
        if (!b) return !0;
        var c = b[UG(this)];
        if (!c) return !0;
        var d = c[a != null ? a : this.target.destinationId];
        return d === void 0 || d === wk()
    };

    function VG(a) {
        return {
            getDestinationId: function() {
                return a.target.destinationId
            },
            getEventName: function() {
                return a.eventName
            },
            setEventName: function(b) {
                a.eventName = b
            },
            getHitData: function(b) {
                return Vr(a, b)
            },
            setHitData: function(b, c) {
                W(a, b, c)
            },
            setHitDataIfNotDefined: function(b, c) {
                Vr(a, b) === void 0 && W(a, b, c)
            },
            copyToHitData: function(b, c) {
                a.copyToHitData(b, c)
            },
            getMetadata: function(b) {
                return T(a, b)
            },
            setMetadata: function(b, c) {
                U(a, b, c)
            },
            isAborted: function() {
                return a.isAborted
            },
            abort: function() {
                a.isAborted = !0
            },
            getFromEventContext: function(b) {
                return O(a.F, b)
            },
            wb: function() {
                return a
            },
            getHitKeys: function() {
                return Object.keys(a.D)
            },
            getMergedValues: function(b) {
                return a.F.getMergedValues(b, 3)
            },
            mergeHitDataForKey: function(b, c) {
                return Id(c) ? a.mergeHitDataForKey(b, c) : !1
            },
            accept: function() {
                a.accept()
            },
            canBeAccepted: function(b) {
                return a.canBeAccepted(b)
            }
        }
    };

    function WG(a, b) {
        var c;
        return c
    }
    WG.K = "internal.copyPreHit";

    function XG(a, b) {
        var c = null;
        return Xd(c, this.M, 2)
    }
    XG.publicName = "createArgumentsQueue";

    function YG(a) {
        return Xd(function(c) {
            var d = vA();
            if (typeof c === "function") d(function() {
                c(function(f, g, h) {
                    var l =
                        vA(),
                        n = l && l.getByName && l.getByName(f);
                    return (new w.gaplugins.Linker(n)).decorate(g, h)
                })
            });
            else if (Array.isArray(c)) {
                var e = String(c[0]).split(".");
                b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c)
            } else if (c === "isLoaded") return !!d.loaded
        }, this.M, 1)
    }
    YG.K = "internal.createGaCommandQueue";

    function ZG(a) {
        if (!Qh(a)) throw H(this.getName(), ["string"], arguments);
        I(this, "access_globals", "readwrite", a);
        var b = a.split("."),
            c = $b(w, b, [w, A]),
            d = b[b.length - 1];
        if (!c) throw Error("Path " + a + " does not exist.");
        var e = c[d];
        e === void 0 && (e = [], c[d] = e);
        return Xd(function() {
                if (!Cb(e.push)) throw Error("Object at " + a + " in window is not an array.");
                e.push.apply(e, Array.prototype.slice.call(arguments, 0))
            }, this.M,
            ei(uE(this).Rb()) ? 2 : 1)
    }
    ZG.publicName = "createQueue";

    function $G(a, b) {
        var c = null;
        if (!Qh(a) || !Rh(b)) throw H(this.getName(), ["string", "string|undefined"], arguments);
        try {
            var d = (b || "").split("").filter(function(e) {
                return "ig".indexOf(e) >= 0
            }).join("");
            c = new Ud(new RegExp(a, d))
        } catch (e) {}
        return c
    }
    $G.K = "internal.createRegex";

    function aH(a) {}
    aH.K = "internal.declareConsentState";

    function bH(a) {
        var b = "";
        return b
    }
    bH.K = "internal.decodeUrlHtmlEntities";

    function cH(a, b, c) {
        var d;
        return d
    }
    cH.K = "internal.decorateUrlWithGaCookies";

    function dH() {}
    dH.K = "internal.deferCustomEvents";

    function eH(a) {
        return P(423) || fH ? A.querySelector(a) : null
    }

    function gH(a) {
        return P(423) || fH ? A.querySelectorAll(a) : null
    }

    function hH(a, b) {
        if (P(423)) try {
            return a.closest(b)
        } catch (e) {
            return null
        } else {
            if (!fH) return null;
            if (Element.prototype.closest) try {
                return a.closest(b)
            } catch (e) {
                return null
            }
            var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
                d = a;
            if (!A.documentElement.contains(d)) return null;
            do {
                try {
                    if (c.call(d, b)) return d
                } catch (e) {
                    break
                }
                d = d.parentElement || d.parentNode
            } while (d !== null && d.nodeType ===
                1);
            return null
        }
    }
    var iH = !1;
    if (A.querySelectorAll) try {
        var jH = A.querySelectorAll(":root");
        jH && jH.length == 1 && jH[0] == A.documentElement && (iH = !0)
    } catch (a) {}
    var fH = iH;

    function kH() {
        var a = w.screen;
        return {
            width: a ? a.width : 0,
            height: a ? a.height : 0
        }
    }

    function lH(a) {
        if (A.hidden) return !0;
        var b = a.getBoundingClientRect();
        if (b.top === b.bottom || b.left === b.right || !w.getComputedStyle) return !0;
        var c = w.getComputedStyle(a, null);
        if (c.visibility === "hidden") return !0;
        for (var d = a, e = c; d;) {
            if (e.display === "none") return !0;
            var f = e.opacity,
                g = e.filter;
            if (g) {
                var h = g.indexOf("opacity(");
                h >= 0 && (g = g.substring(h + 8, g.indexOf(")", h)), g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)), f = String(Math.min(Number(g), Number(f))))
            }
            if (f !== void 0 && Number(f) <= 0) return !0;
            (d = d.parentElement) &&
            (e = w.getComputedStyle(d, null))
        }
        return !1
    }

    function qI(a) {
        var b;
        return b
    }
    qI.K = "internal.detectUserProvidedData";

    function vI(a, b) {
        return f
    }
    vI.K = "internal.enableAutoEventOnClick";

    function DI(a, b) {
        return p
    }
    DI.K = "internal.enableAutoEventOnElementVisibility";

    function EI() {}
    EI.K = "internal.enableAutoEventOnError";
    var FI = {},
        GI = [],
        HI = {},
        II = 0,
        JI = 0;

    function PI(a, b) {
        var c = this;
        return d
    }
    PI.K = "internal.enableAutoEventOnFormInteraction";

    function UI(a, b) {
        var c = this;
        return f
    }
    UI.K = "internal.enableAutoEventOnFormSubmit";

    function ZI() {
        var a = this;
    }
    ZI.K = "internal.enableAutoEventOnGaSend";
    var $I = {},
        aJ = [];

    function hJ(a, b) {
        var c = this;
        return f
    }
    hJ.K = "internal.enableAutoEventOnHistoryChange";
    var iJ = ["http://", "https://", "javascript:", "file://"];

    function mJ(a, b) {
        var c = this;
        return h
    }
    mJ.K = "internal.enableAutoEventOnLinkClick";
    var nJ, oJ;

    function zJ(a, b) {
        var c = this;
        return d
    }
    zJ.K = "internal.enableAutoEventOnScroll";

    function AJ(a) {
        return function() {
            if (a.limit && a.Wj >= a.limit) a.bi && w.clearInterval(a.bi);
            else {
                a.Wj++;
                var b = Tb();
                yC({
                    event: a.eventName,
                    "gtm.timerId": a.bi,
                    "gtm.timerEventNumber": a.Wj,
                    "gtm.timerInterval": a.interval,
                    "gtm.timerLimit": a.limit,
                    "gtm.timerStartTime": a.yo,
                    "gtm.timerCurrentTime": b,
                    "gtm.timerElapsedTime": b - a.yo,
                    "gtm.triggers": a.Ys
                })
            }
        }
    }

    function BJ(a, b) {
        return f
    }
    BJ.K = "internal.enableAutoEventOnTimer";
    var Kc = Ca(["data-gtm-yt-inspected-"]),
        DJ = ["www.youtube.com", "www.youtube-nocookie.com"],
        EJ, FJ = !1;

    function PJ(a, b) {
        var c = this;
        return e
    }
    PJ.K = "internal.enableAutoEventOnYouTubeActivity";
    FJ = !1;

    function QJ(a, b) {
        if (!Qh(a) || !Kh(b)) throw H(this.getName(), ["string", "Object|undefined"], arguments);
        var c = b ? B(b) : {},
            d = a,
            e = !1;
        return e
    }
    QJ.K = "internal.evaluateBooleanExpression";
    var RJ;

    function SJ(a) {
        var b = !1;
        return b
    }
    SJ.K = "internal.evaluateMatchingRules";

    function TJ(a) {
        var b = window,
            c = b.webkit;
        delete b.webkit;
        a(b.webkit);
        b.webkit = c
    }

    function UJ(a) {
        var b = {
            action: "gcl_setup"
        };
        if ("CWVWebViewMessage" in a.messageHandlers) return a.messageHandlers.CWVWebViewMessage.postMessage({
            command: "awb",
            payload: b
        }), !0;
        var c = a.messageHandlers.awb;
        return c ? (c.postMessage(b), !0) : !1
    };

    function VJ() {
        return ["ad_storage", "ad_user_data"]
    }

    function WJ(a) {
        if (P(38) && !Pm(Lm.Z.Rm) && "webkit" in window && window.webkit.messageHandlers) {
            var b = function() {
                try {
                    TJ(function(c) {
                        c && ("CWVWebViewMessage" in c.messageHandlers || "awb" in c.messageHandlers) && (Om(Lm.Z.Rm, function(d) {
                            d.gclid && or(d.gclid, 5, a)
                        }), UJ(c) || Q(178))
                    })
                } catch (c) {
                    Q(177)
                }
            };
            zm(function() {
                Kq(VJ()) ? b() : Am(b, VJ())
            }, VJ())
        }
    };
    var XJ = ["https://www.google.com", "https://www.youtube.com", "https://m.youtube.com"];

    function YJ(a) {
        return a.data.action !== "gcl_transfer" ? (Q(173), !0) : a.data.gadSource ? a.data.gclid ? !1 : (Q(181), !0) : (Q(180), !0)
    }

    function ZJ(a, b) {
        if (P(a)) {
            if (Pm(Lm.Z.Te)) return Q(176), Lm.Z.Te;
            if (Pm(Lm.Z.Um)) return Q(170), Lm.Z.Te;
            var c = Ho();
            if (!c) Q(171);
            else if (c.opener) {
                var d = function(g) {
                    if (!XJ.includes(g.origin)) Q(172);
                    else if (!YJ(g)) {
                        var h = {
                            gadSource: g.data.gadSource
                        };
                        P(229) && (h.gclid = g.data.gclid);
                        Om(Lm.Z.Te, h);
                        a === 200 && g.data.gclid && or(String(g.data.gclid), 6, b);
                        var l;
                        (l = g.stopImmediatePropagation) == null || l.call(g);
                        ou(c, "message", d)
                    }
                };
                if (nu(c, "message", d)) {
                    Om(Lm.Z.Um, !0);
                    for (var e = m(XJ), f = e.next(); !f.done; f = e.next()) c.opener.postMessage({
                            action: "gcl_setup"
                        },
                        f.value);
                    Q(174);
                    return Lm.Z.Te
                }
                Q(175)
            }
        }
    };

    function xK() {
        return Mu(7) && Mu(9) && Mu(10)
    };

    function CK(a) {
        if (P(10)) return;
        var b = bk() || !!dk(a.F);
        P(431) && (b = xg(50) || !!dk(a.F));
        if (b) return;
        Xy();
    };

    function HK() {
        var a;
        a = a === void 0 ? document : a;
        var b;
        return !((b = a.featurePolicy) == null || !b.allowedFeatures().includes("attribution-reporting"))
    };

    function OK(a) {
        U(a, S.C.Ia, !0);
        U(a, S.C.qb, Tb());
        U(a, S.C.mn, a.F.eventMetadata[S.C.Ia])
    };
    var fL = {};

    function hL(a) {
        var b = rB(!1);
        b && a.mergeHitDataForKey(K.m.Db, {
            gtb: b
        })
    };
    var iL = {
        Ma: {
            sk: 1,
            nn: 2,
            vn: 3,
            wn: 4,
            xn: 5,
            kn: 6
        }
    };
    iL.Ma[iL.Ma.sk] = "ADOBE_COMMERCE";
    iL.Ma[iL.Ma.nn] = "SQUARESPACE";
    iL.Ma[iL.Ma.vn] = "WOO_COMMERCE";
    iL.Ma[iL.Ma.wn] = "WOO_COMMERCE_LEGACY";
    iL.Ma[iL.Ma.xn] = "WORD_PRESS";
    iL.Ma[iL.Ma.kn] = "SHOPIFY";

    function jL(a) {
        var b = w;
        return Lj(b.escape(b.atob(a)))
    }

    function kL() {
        try {
            if (!P(243)) return [];
            var a = P(430);
            if (a) {
                var b = Pm(Lm.Z.Tm);
                if (Array.isArray(b)) return b
            }
            Op("4");
            var c = [],
                d;
            a: {
                try {
                    d = !!eH('script[data-requiremodule^="mage/"]');
                    break a
                } catch (z) {}
                d = !1
            }
            d && c.push(iL.Ma.sk);
            var e;
            a: {
                try {
                    var f = jL("YXNzZXRzLnNxdWFyZXNwYWNlLmNvbS8=");
                    e = f ? !!eH('script[src^="//' + f + '"]') : !1;
                    break a
                } catch (z) {}
                e = !1
            }
            e && c.push(iL.Ma.nn);
            var g;
            a: {
                if (P(425)) try {
                    var h = jL("c2hvcGlmeS5jb20="),
                        l = jL("c2hvcGlmeWNkbi5jb20=");
                    g = h && l ? !!eH('script[src*="cdn.' + h + '"],meta[property="og:image"][content*="cdn.' +
                        (h + '"],link[rel="preconnect"][href*="cdn.') + (h + '"],link[rel="preconnect"][href*="fonts.') + (l + '"],link[rel="preconnect"][href*="iterable-shopify"],link[rel="preconnect"][href*="v.') + (h + '"]')) : !1;
                    break a
                } catch (z) {}
                g = !1
            }
            g && c.push(iL.Ma.kn);
            var n;
            a: {
                try {
                    n = !!eH('script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]');
                    break a
                } catch (z) {}
                n = !1
            }
            n && c.push(iL.Ma.wn);
            var p;
            a: {
                try {
                    var q, r = ((q = A.location) == null ? void 0 : q.hostname) || "",
                        t, u = ((t = A.location) == null ? void 0 : t.origin) || "",
                        v = jL("LndvcmRwcmVzcy5jb20="),
                        x = jL("Ly9zLncub3Jn");
                    p = v && x ? Zb(r, v) || !!eH('[src^="' + u + '/wp-content"],meta[name="generator"][content^="WordPress "],link[rel="dns-prefetch"][href="' + (x + '"]')) : !1;
                    break a
                } catch (z) {}
                p = !1
            }
            p && c.push(iL.Ma.xn);
            var y;
            a: {
                try {
                    y = !!eH('[class*="woocommerce"],meta[name="generator"][content^="WooCommerce "]');
                    break a
                } catch (z) {}
                y = !1
            }
            y && c.push(iL.Ma.vn);
            Pp("4");
            wB && a && Om(Lm.Z.Tm, c);
            return c
        } catch (z) {}
        return []
    };

    function FL(a) {
        if (P(425) && T(a, S.C.mg)) {
            var b = Cg(67, 1500),
                c = a.mergeHitDataForKey,
                d = K.m.Db,
                e = {};
            c.call(a, d, e)
        }
    };
    var GL = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function HL(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function IL(a) {
        var b = a.google_tag_data,
            c;
        if (b != null && b.uach) {
            var d = b.uach,
                e = pa(Object, "assign").call(Object, {}, d);
            d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
            c = e
        } else c = null;
        return c
    }

    function JL(a) {
        var b, c;
        return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) != null ? c : null
    }

    function KL(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function LL(a) {
        if (!KL(a)) return null;
        var b = HL(a);
        if (b.uach_promise) return b.uach_promise;
        var c = a.navigator.userAgentData.getHighEntropyValues(GL).then(function(d) {
            b.uach != null || (b.uach = d);
            return d
        });
        return b.uach_promise = c
    };

    function RL(a, b) {
        b = b === void 0 ? !1 : b;
        var c = T(a, S.C.rg),
            d = SG(a, "custom_event_accept_rules", !1) && !b;
        if (c) {
            var e = c.indexOf(a.target.destinationId) >= 0,
                f = !0;
            T(a, S.C.rb) && (f = T(a, S.C.Ua) === wk());
            e && f ? U(a, S.C.ji, !0) : (U(a, S.C.ji, !1), d || (a.isAborted = !0));
            if (a.canBeAccepted()) {
                var g = vk().indexOf(a.target.destinationId) >= 0,
                    h = !1;
                if (!g) {
                    var l, n = (l = ok(a.target.destinationId)) == null ? void 0 : l.canonicalContainerId;
                    n && (h = wk() === n)
                }
                g || h ? T(a, S.C.ji) && a.accept() : a.isAborted = !0
            } else a.isAborted = !0
        }
    };
    var ZL = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
        $L = /^www.googleadservices.com$/;

    function aM(a) {
        a || (a = bM());
        return a.Zs ? !1 : a.Kr || a.Lr || a.Nr || a.Mr || a.Ze || a.Uh || a.wr || a.jc === "aw.ds" || P(235) && a.jc === "aw.dv" || a.Cr ? !0 : !1
    }

    function bM() {
        var a = {},
            b = mp(!0);
        a.Zs = !!b._up;
        var c = hr(),
            d = Gv();
        a.Kr = c.aw !== void 0;
        a.Lr = c.dc !== void 0;
        a.Nr = c.wbraid !== void 0;
        a.Mr = c.gbraid !== void 0;
        a.jc = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
        a.Ze = d.Ze;
        a.Uh = d.Uh;
        var e = A.referrer ? Mj(Sj(A.referrer), "host") : "";
        a.Cr = ZL.test(e);
        a.wr = $L.test(e);
        return a
    };

    function cM() {
        var a = w.__uspapi;
        if (Cb(a)) {
            var b = "";
            try {
                a("getUSPData", 1, function(c, d) {
                    if (d && c) {
                        var e = c.uspString;
                        e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e)
                    }
                })
            } catch (c) {}
            return b
        }
    };

    function fM(a) {
        nl && (en = !0, a.eventName === K.m.na ? ln(a.F, a.target.id) : (T(a, S.C.Lc) || (hn[a.target.id] = !0), HB(T(a, S.C.Ua))))
    };

    function kM(a, b) {
        return wq("gcl_dc", {
            value: {
                joinId: a,
                lastJoinedTimeMs: b
            },
            expires: b + 3E5
        }) === 0 ? !0 : !1
    };
    var nM = {
        aq: {
            it: "cd",
            Mo: "ce",
            jt: "cf",
            kt: "cpf",
            mt: "cu"
        }
    };

    function pM(a, b) {
        b = b === void 0 ? !0 : b;
        var c = Ab(ub.GTAG_EVENT_FEATURE_CHANNEL || []);
        c && (W(a, K.m.Rf, c), b && xb())
    };

    function CM(a) {};

    function YN(a, b, c, d) {}
    YN.K = "internal.executeEventProcessor";

    function ZN(a) {
        var b;
        return Xd(b, this.M, 1)
    }
    ZN.K = "internal.executeJavascriptString";

    function $N(a) {
        var b;
        return b
    };

    function aO(a) {
        var b = "";
        return b
    }
    aO.K = "internal.generateClientId";

    function bO(a) {
        var b = {};
        return Xd(b)
    }
    bO.K = "internal.getAdsCookieWritingOptions";

    function cO(a, b) {
        var c = !1;
        return c
    }
    cO.K = "internal.getAllowAdPersonalization";

    function dO() {
        var a;
        return a
    }
    dO.K = "internal.getAndResetEventUsage";

    function eO(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        return c
    }
    eO.K = "internal.getAuid";

    function fO() {
        var a = new nb;
        return a
    }
    fO.publicName = "getContainerVersion";

    function gO(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        return c
    }
    gO.publicName = "getCookieValues";

    function hO() {
        var a = "";
        return a
    }
    hO.K = "internal.getCorePlatformServicesParam";

    function iO() {
        return tn()
    }
    iO.K = "internal.getCountryCode";

    function jO() {
        var a = [];
        return Xd(a)
    }
    jO.K = "internal.getDestinationIds";

    function kO(a) {
        var b = new nb;
        return b
    }
    kO.K = "internal.getDeveloperIds";

    function lO(a) {
        var b;
        return b
    }
    lO.K = "internal.getEcsidCookieValue";

    function mO(a, b) {
        var c = null;
        return c
    }
    mO.K = "internal.getElementAttribute";

    function nO(a) {
        var b = null;
        return b
    }
    nO.K = "internal.getElementById";

    function oO(a) {
        var b = "";
        return b
    }
    oO.K = "internal.getElementInnerText";

    function pO(a) {
        var b = null;
        return b
    }
    pO.K = "internal.getElementParent";

    function qO(a) {
        var b = null;
        return b
    }
    qO.K = "internal.getElementPreviousSibling";

    function rO(a, b) {
        var c = null;
        return Xd(c)
    }
    rO.K = "internal.getElementProperty";

    function sO(a) {
        var b;
        return b
    }
    sO.K = "internal.getElementValue";

    function tO(a) {
        var b = 0;
        return b
    }
    tO.K = "internal.getElementVisibilityRatio";

    function uO(a) {
        var b = null;
        return b
    }
    uO.K = "internal.getElementsByCssSelector";

    function vO(a) {
        var b;
        if (!Qh(a)) throw H(this.getName(), ["string"], arguments);
        I(this, "read_event_data", a);
        var c;
        a: {
            var d = a,
                e = uE(this).originalEventData;
            if (e) {
                for (var f = e, g = {}, h = {}, l = {}, n = [], p = d.split("\\\\"), q = 0; q < p.length; q++) {
                    for (var r = p[q].split("\\."), t = 0; t < r.length; t++) {
                        for (var u = r[t].split("."), v = 0; v < u.length; v++) n.push(u[v]), v !== u.length - 1 && n.push(l);
                        t !== r.length - 1 && n.push(h)
                    }
                    q !== p.length - 1 && n.push(g)
                }
                for (var x = [], y = "", z = m(n), C = z.next(); !C.done; C =
                    z.next()) {
                    var D = C.value;
                    D === l ? (x.push(y), y = "") : y = D === g ? y + "\\" : D === h ? y + "." : y + D
                }
                y && x.push(y);
                for (var G = m(x), J = G.next(); !J.done; J = G.next()) {
                    if (f == null) {
                        c = void 0;
                        break a
                    }
                    f = f[J.value]
                }
                c = f
            } else c = void 0
        }
        b = Xd(c, this.M, 1);
        return b
    }
    vO.K = "internal.getEventData";

    function wO(a) {
        var b = null;
        return b
    }
    wO.K = "internal.getFirstElementByCssSelector";
    var xO = {};
    xO.disableUserDataWithoutCcd = P(223);

    function yO() {
        return Xd(xO)
    }
    yO.K = "internal.getFlags";

    function zO() {
        var a;
        return a
    }
    zO.K = "internal.getGsaExperimentId";

    function AO() {
        return new Ud(sD)
    }
    AO.K = "internal.getHtmlId";

    function BO(a) {
        var b;
        return b
    }
    BO.K = "internal.getIframingState";

    function CO(a, b) {
        var c = {};
        return Xd(c)
    }
    CO.K = "internal.getLinkerValueFromLocation";

    function DO() {
        var a = new nb;
        return a
    }
    DO.K = "internal.getPrivacyStrings";

    function EO(a, b) {
        var c;
        return c
    }
    EO.K = "internal.getProductSettingsParameter";

    function FO(a, b) {
        var c;
        return c
    }
    FO.publicName = "getQueryParameters";

    function GO(a, b) {
        var c;
        return c
    }
    GO.publicName = "getReferrerQueryParameters";

    function HO(a) {
        var b = "";
        if (!Rh(a)) throw H(this.getName(), ["string|undefined"], arguments);
        I(this, "get_referrer", a);
        b = Oj(Sj(A.referrer), a);
        return b
    }
    HO.publicName = "getReferrerUrl";

    function IO() {
        return un()
    }
    IO.K = "internal.getRegionCode";

    function JO(a, b) {
        var c;
        return c
    }
    JO.K = "internal.getRemoteConfigParameter";

    function KO(a, b) {
        var c = null;
        return c
    }
    KO.K = "internal.getScopedElementsByCssSelector";

    function LO() {
        var a = new nb;
        a.set("width", 0);
        a.set("height", 0);
        return a
    }
    LO.K = "internal.getScreenDimensions";

    function MO() {
        var a = "";
        return a
    }
    MO.K = "internal.getTopSameDomainUrl";

    function NO() {
        var a = "";
        return a
    }
    NO.K = "internal.getTopWindowUrl";

    function OO(a) {
        var b = "";
        if (!Rh(a)) throw H(this.getName(), ["string|undefined"], arguments);
        I(this, "get_url", a);
        b = Mj(Sj(w.location.href), a);
        return b
    }
    OO.publicName = "getUrl";

    function PO() {
        I(this, "get_user_agent");
        return Rc.userAgent
    }
    PO.K = "internal.getUserAgent";

    function QO() {
        var a;
        return a ? Xd(ML(a)) : a
    }
    QO.K = "internal.getUserAgentClientHints";

    function TO() {
        var a = w;
        return a.gaGlobal = a.gaGlobal || {}
    }

    function UO(a, b) {
        var c = TO();
        if (c.vid === void 0 || b && !c.from_cookie) c.vid = a, c.from_cookie = b
    };

    function vP(a) {
        (BK(a) || Xj()) && W(a, K.m.Xl, un() || tn());
        !BK(a) && Xj() && W(a, K.m.Ui, "::")
    }

    function wP(a) {
        Xj() && (BK(a) || xn() || W(a, K.m.El, !0))
    };

    function IQ(a) {
        a.copyToHitData(K.m.Oa);
        if (P(411)) {
            var b = O(a.F, K.m.Ec);
            b && (qt(b, function() {}), W(a, K.m.Ec, b))
        } else a.copyToHitData(K.m.Ec)
    };
    var MQ = function(a) {
        for (var b = {}, c = String(LQ.cookie).split(";"), d = 0; d < c.length; d++) {
            var e = c[d].split("="),
                f = e[0].trim();
            if (f && a(f)) {
                var g = e.slice(1).join("=").trim();
                g && (g = decodeURIComponent(g));
                var h = void 0,
                    l = void 0;
                ((h = b)[l = f] || (h[l] = [])).push(g)
            }
        }
        return b
    };
    var NQ = window,
        LQ = document,
        OQ = function(a) {
            var b = NQ._gaUserPrefs;
            if (b && b.ioo && b.ioo() || LQ.documentElement.hasAttribute("data-google-analytics-opt-out") || a && NQ["ga-disable-" + a] === !0) return !0;
            try {
                var c = NQ.external;
                if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0
            } catch (f) {}
            for (var d = MQ(function(f) {
                    return f === "AMP_TOKEN"
                }).AMP_TOKEN || [], e = 0; e < d.length; e++)
                if (d[e] == "$OPT_OUT") return !0;
            return LQ.getElementById("__gaOptOutExtension") ? !0 : !1
        };
    var SQ = "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(" ");

    function TQ() {
        var a = A.location,
            b, c = a == null ? void 0 : (b = a.search) == null ? void 0 : b.replace("?", ""),
            d;
        if (c) {
            for (var e = [], f = Kj(c, !0), g = m(SQ), h = g.next(); !h.done; h = g.next()) {
                var l = h.value,
                    n = f[l];
                if (n)
                    for (var p = 0; p < n.length; p++) {
                        var q = n[p];
                        q !== void 0 && e.push({
                            name: l,
                            value: q
                        })
                    }
            }
            d = e
        } else d = [];
        return d
    };

    function bR(a) {
        if (!P(411)) {
            Lb(a, function(c) {
                c.charAt(0) === "_" && delete a[c]
            });
            var b = a[K.m.Ec] || {};
            Lb(b, function(c) {
                c.charAt(0) === "_" && delete b[c]
            })
        }
    };

    function xR(a) {}

    function yR(a) {
        var b = function() {};
        return b
    }

    function zR(a, b) {}
    var AR = F.P.Tk,
        BR = F.P.Uk;

    function CR(a, b) {
        var c = uk();
        c && c.indexOf(b) > -1 && (a[S.C.rb] = !0)
    }

    function ER(a, b, c) {
        var d = this;
    }
    ER.K = "internal.gtagConfig";

    function FR(a, b, c) {
        var d = this;
    }
    FR.K = "internal.gtagDestinationConfig";

    function HR(a, b) {}
    HR.publicName = "gtagSet";

    function IR() {
        var a = {};
        return a
    };

    function JR(a) {}
    JR.K = "internal.initializeServiceWorker";

    function KR(a, b) {}
    KR.publicName = "injectHiddenIframe";
    var LR = function() {
        var a = 0;
        return function(b) {
            switch (b) {
                case 1:
                    a |= 1;
                    break;
                case 2:
                    a |= 2;
                    break;
                case 3:
                    a |= 4
            }
            return a
        }
    }();

    function MR(a, b, c, d, e) {}
    MR.K = "internal.injectHtml";
    var QR = {};
    var RR = function(a, b, c, d, e, f) {
        f ? e[f] ? (e[f][0].push(c), e[f][1].push(d)) : (e[f] = [
            [c],
            [d]
        ], cd(a, function() {
            for (var g = e[f][0], h = 0; h < g.length; h++) jd(g[h]);
            g.push = function(l) {
                jd(l);
                return 0
            }
        }, function() {
            for (var g = e[f][1], h = 0; h < g.length; h++) jd(g[h]);
            e[f] = null
        }, b)) : cd(a, c, d, b)
    };

    function SR(a, b, c, d) {
        if (!(Qh(a) && Nh(b) && Nh(c) && Rh(d))) throw H(this.getName(), ["string", "function|undefined", "function|undefined", "string|undefined"], arguments);
        I(this, "inject_script", a);
        var e = this.M;
        RR(a, void 0, function() {
            b && b.Sb(e)
        }, function() {
            c && c.Sb(e)
        }, QR, d);
    }
    var TR = {
            dl: 1,
            id: 1
        },
        UR = {};

    function VR(a, b, c, d) {
        var e = void 0,
            f = void 0;
        if (!Qh(a) && !Jh(a) || !Nh(b) || !Nh(c) || !Rh(d)) throw H(this.getName(), ["string|Object", "function|undefined", "function|undefined", "string|undefined"], arguments);
        if (Db(a)) f = a;
        else {
            e = B(a);
            var g = {},
                h;
            for (h in e)
                if (e.hasOwnProperty(h)) {
                    var l = e[h];
                    h = h.toLowerCase();
                    if (h === "src") f = String(l);
                    else if (Yb(h, "data-") || TR.hasOwnProperty(h)) g[h] = l
                }
            e = g;
            e.async = !0
        }
        if (!f) throw Error(this.getName() + ": script src attribute is required.");
        I(this, "inject_script", f);
        var n = this.M;
        RR(f, e, function() {
            b && b.Sb(n)
        }, function() {
            c && c.Sb(n)
        }, UR, d);
    }
    P(160) ? VR.publicName = "injectScript" : SR.publicName = "injectScript";
    VR.K = "internal.injectScript";

    function WR() {
        var a = !1;
        return a
    }
    WR.K = "internal.isAutoPiiEligible";

    function YR(a) {
        var b = !0;
        return b
    }
    YR.publicName = "isConsentGranted";

    function ZR(a) {
        var b = !1;
        return b
    }
    ZR.K = "internal.isDebugMode";

    function $R() {
        return wn()
    }
    $R.K = "internal.isDmaRegion";

    function aS() {
        return wB
    }
    aS.K = "internal.isDomReady";

    function bS(a) {
        var b = !1;
        return b
    }
    bS.K = "internal.isEntityInfrastructure";

    function cS(a) {
        var b = !1;
        return b
    }
    cS.K = "internal.isFeatureEnabled";

    function dS() {
        var a = !1;
        return a
    }
    dS.K = "internal.isFpfe";

    function eS() {
        var a = !1;
        return a
    }
    eS.K = "internal.isGcpConversion";

    function fS() {
        var a = !1;
        return a
    }
    fS.K = "internal.isLandingPage";

    function gS() {
        var a = !1;
        return a
    }
    gS.K = "internal.isOgt";

    function hS() {
        var a;
        return a
    }
    hS.K = "internal.isSafariPcmEligibleBrowser";

    function iS() {
        var a = ti(function(b) {
            uE(this).log("error", b)
        });
        a.publicName = "JSON";
        return a
    };

    function jS(a) {
        var b = void 0;
        if (!Qh(a)) throw H(this.getName(), ["string"], arguments);
        b = Sj(a);
        return Xd(b)
    }
    jS.K = "internal.legacyParseUrl";

    function kS() {
        return !1
    }
    var lS = {
        getItem: function(a) {
            var b = null;
            return b
        },
        setItem: function(a, b) {
            return !1
        },
        removeItem: function(a) {}
    };

    function mS() {
        try {
            I(this, "logging")
        } catch (d) {
            return
        }
        if (!console) return;
        for (var a = Array.prototype.slice.call(arguments, 0), b = 0; b < a.length; b++) a[b] = B(a[b], this.M);
        var c = uE(this);
        console.log.apply(console, a);
        jF(c);
    }
    mS.publicName = "logToConsole";

    function nS(a, b) {}
    nS.K = "internal.mergeRemoteConfig";

    function oS(a, b, c) {
        c = c === void 0 ? !0 : c;
        var d = [];
        return Xd(d)
    }
    oS.K = "internal.parseCookieValuesFromString";

    function pS(a) {
        var b = void 0;
        if (typeof a !== "string") return;
        a && Yb(a, "//") && (a = A.location.protocol + a);
        if (typeof URL === "function") {
            var c;
            a: {
                var d;
                try {
                    d = new URL(a)
                } catch (x) {
                    c = void 0;
                    break a
                }
                for (var e = {}, f = Array.from(d.searchParams), g = 0; g < f.length; g++) {
                    var h = f[g][0],
                        l = f[g][1];
                    e.hasOwnProperty(h) ? typeof e[h] === "string" ? e[h] = [e[h], l] : e[h].push(l) : e[h] = l
                }
                c = Xd({
                    href: d.href,
                    origin: d.origin,
                    protocol: d.protocol,
                    username: d.username,
                    password: d.password,
                    host: d.host,
                    hostname: d.hostname,
                    port: d.port,
                    pathname: d.pathname,
                    search: d.search,
                    searchParams: e,
                    hash: d.hash
                })
            }
            return c
        }
        var n;
        try {
            n = Sj(a)
        } catch (x) {
            return
        }
        if (!n.protocol || !n.host) return;
        var p = {};
        if (n.search)
            for (var q = n.search.replace("?", "").split("&"), r = 0; r < q.length; r++) {
                var t = q[r].split("="),
                    u = t[0],
                    v = Lj(t.splice(1).join("=")) || "";
                v = v.replace(/\+/g, " ");
                p.hasOwnProperty(u) ? typeof p[u] === "string" ? p[u] = [p[u], v] : p[u].push(v) : p[u] = v
            }
        n.searchParams = p;
        n.origin = n.protocol + "//" + n.host;
        n.username = "";
        n.password = "";
        b = Xd(n);
        return b
    }
    pS.publicName = "parseUrl";

    function qS(a) {}
    qS.K = "internal.processAsNewEvent";

    function rS(a, b, c) {
        var d;
        return d
    }
    rS.K = "internal.pushToDataLayer";

    function sS(a) {
        var b = Qa.apply(1, arguments),
            c = !1;
        return c
    }
    sS.publicName = "queryPermission";

    function tS(a) {
        var b = this;
    }
    tS.K = "internal.queueAdsTransmission";

    function uS(a) {
        var b = void 0;
        return b
    }
    uS.publicName = "readAnalyticsStorage";

    function vS() {
        var a = "";
        return a
    }
    vS.publicName = "readCharacterSet";

    function wS() {
        return E(19)
    }
    wS.K = "internal.readDataLayerName";

    function xS() {
        var a = "";
        return a
    }
    xS.publicName = "readTitle";

    function yS(a, b) {
        var c = this;
    }
    yS.K = "internal.registerCcdCallback";

    function zS(a, b) {
        return !0
    }
    zS.K = "internal.registerDestination";
    var AS = ["config", "event", "get", "set"];

    function BS(a, b, c) {}
    BS.K = "internal.registerGtagCommandListener";

    function CS(a, b) {
        var c = !1;
        return c
    }
    CS.K = "internal.removeDataLayerEventListener";

    function DS(a, b) {}
    DS.K = "internal.removeFormData";

    function ES() {}
    ES.publicName = "resetDataLayer";

    function FS(a, b, c) {
        var d = void 0;
        return d
    }
    FS.K = "internal.scrubUrlParams";

    function GS(a) {}
    GS.K = "internal.sendAdsHit";

    function HS(a, b, c, d) {}
    HS.K = "internal.sendGtagEvent";

    function IS(a, b, c) {}
    IS.publicName = "sendPixel";

    function JS(a, b) {}
    JS.K = "internal.setAnchorHref";

    function KS(a) {}
    KS.K = "internal.setContainerConsentDefaults";

    function LS(a, b, c, d) {
        var e = this;
        d = d === void 0 ? !0 : d;
        var f = !1;
        return f
    }
    LS.publicName = "setCookie";

    function MS(a) {}
    MS.K = "internal.setCorePlatformServices";

    function NS(a, b) {}
    NS.K = "internal.setDataLayerValue";

    function OS(a) {}
    OS.publicName = "setDefaultConsentState";

    function PS(a, b) {}
    PS.K = "internal.setDelegatedConsentType";

    function QS(a, b) {}
    QS.K = "internal.setFormAction";

    function RS(a, b, c) {
        c = c === void 0 ? !1 : c;
    }
    RS.K = "internal.setInCrossContainerData";

    function SS(a, b, c) {
        if (!Qh(a) || !Uh(c)) throw H(this.getName(), ["string", "any", "boolean|undefined"], arguments);
        I(this, "access_globals", "readwrite", a);
        var d = a.split("."),
            e = $b(w, d, [w, A]),
            f = d.pop();
        if (e && (e[String(f)] === void 0 || c)) return e[String(f)] = B(b, this.M, 2), !0;
        return !1
    }
    SS.publicName = "setInWindow";

    function TS(a, b, c) {}
    TS.K = "internal.setProductSettingsParameter";

    function US(a, b, c) {}
    US.K = "internal.setRemoteConfigParameter";

    function VS(a, b) {}
    VS.K = "internal.setTransmissionMode";

    function WS(a, b, c, d) {
        var e = this;
    }
    WS.publicName = "sha256";

    function XS(a, b, c) {}
    XS.K = "internal.sortRemoteConfigParameters";

    function YS(a) {}
    YS.K = "internal.storeAdsBraidLabels";

    function ZS(a, b) {
        var c = void 0;
        return c
    }
    ZS.K = "internal.subscribeToCrossContainerData";

    function $S(a) {}
    $S.K = "internal.taskSendAdsHits";
    var aT = {},
        bT = {};
    aT.getItem = function(a) {
        var b = null;
        return b
    };
    aT.setItem = function(a, b) {};
    aT.removeItem = function(a) {};
    aT.clear = function() {};
    aT.publicName = "templateStorage";
    aT.resetForTest = function() {
        for (var a = m(Object.keys(bT)), b = a.next(); !b.done; b = a.next()) delete bT[b.value]
    };

    function cT(a, b) {
        var c = !1;
        return c
    }
    cT.K = "internal.testRegex";

    function dT(a) {
        var b;
        return b
    };

    function eT(a, b) {}
    eT.K = "internal.trackUsage";

    function fT(a, b) {
        var c;
        return c
    }
    fT.K = "internal.unsubscribeFromCrossContainerData";

    function gT(a) {}
    gT.publicName = "updateConsentState";

    function hT(a) {
        var b = !1;
        return b
    }
    hT.K = "internal.userDataNeedsEncryption";
    var iT;

    function jT(a, b, c) {
        iT = iT || new Hi;
        iT.add(a, b, c)
    }

    function kT(a, b) {
        var c = iT = iT || new Hi;
        if (c.D.hasOwnProperty(a)) throw Error("Attempting to add a private function which already exists: " + a + ".");
        if (c.contains(a)) throw Error("Attempting to add a private function with an existing API name: " + a + ".");
        c.D[a] = Cb(b) ? Yh(a, b) : Zh(a, b)
    }

    function lT() {
        return function(a) {
            var b;
            var c = iT;
            if (c.contains(a)) b = c.get(a, this);
            else {
                var d;
                if (d = c.D.hasOwnProperty(a)) {
                    var e = this.M.xb();
                    if (e) {
                        var f = !1,
                            g = e.Rb();
                        if (g) {
                            ei(g) || (f = !0);
                        }
                        d = f
                    } else d = !0
                }
                if (d) {
                    var h = c.D.hasOwnProperty(a) ? c.D[a] : void 0;
                    b = h
                } else throw Error(a + " is not a valid API name.");
            }
            return b
        }
    };

    function mT() {
        var a = function(c) {
                return void kT(c.K, c)
            },
            b = function(c) {
                return void jT(c.publicName, c)
            };
        b(oE);
        b(vE);
        b(JF);
        b(LF);
        b(MF);
        b(TF);
        b(VF);
        b(XG);
        b(iS());
        b(ZG);
        b(fO);
        b(gO);
        b(FO);
        b(GO);
        b(HO);
        b(OO);
        b(HR);
        b(KR);
        b(YR);
        b(mS);
        b(pS);
        b(sS);
        b(uS);
        b(vS);
        b(xS);
        b(IS);
        b(LS);
        b(OS);
        b(SS);
        b(WS);
        b(aT);
        b(gT);
        jT("Math", ci());
        jT("Object", Fi);
        jT("TestHelper", Ji());
        jT("assertApi", $h);
        jT("assertThat", ai);
        jT("decodeUri", fi);
        jT("decodeUriComponent", gi);
        jT("encodeUri", hi);
        jT("encodeUriComponent", ii);
        jT("fail", ni);
        jT("generateRandom",
            qi);
        jT("getTimestamp", ri);
        jT("getTimestampMillis", ri);
        jT("getType", si);
        jT("makeInteger", ui);
        jT("makeNumber", vi);
        jT("makeString", wi);
        jT("makeTableMap", xi);
        jT("mock", Ai);
        jT("mockObject", Ei);
        jT("fromBase64", $N, !("atob" in w));
        jT("localStorage", lS, !kS());
        jT("toBase64", dT, !("btoa" in w));
        a(nE);
        a(rE);
        a(LE);
        a(XE);
        a(dF);
        a(iF);
        a(yF);
        a(HF);
        a(KF);
        a(NF);
        a(OF);
        a(PF);
        a(QF);
        a(RF);
        a(SF);
        a(UF);
        a(WF);
        a(WG);
        a(YG);
        a($G);
        a(aH);
        a(bH);
        a(cH);
        a(dH);
        a(qI);
        a(vI);
        a(DI);
        a(EI);
        a(PI);
        a(UI);
        a(ZI);
        a(hJ);
        a(mJ);
        a(zJ);
        a(BJ);
        a(PJ);
        a(QJ);
        a(SJ);
        a(YN);
        a(ZN);
        a(aO);
        a(bO);
        a(cO);
        a(dO);
        a(eO);
        a(hO);
        a(iO);
        a(jO);
        a(kO);
        a(lO);
        a(mO);
        a(nO);
        a(oO);
        a(pO);
        a(qO);
        a(rO);
        a(sO);
        a(tO);
        a(uO);
        a(vO);
        a(wO);
        a(yO);
        a(zO);
        a(AO);
        a(BO);
        a(CO);
        a(DO);
        a(EO);
        a(IO);
        a(JO);
        a(KO);
        a(LO);
        a(MO);
        a(NO);
        a(QO);
        a(ER);
        a(FR);
        a(JR);
        a(MR);
        a(VR);
        a(WR);
        a(ZR);
        a($R);
        a(aS);
        a(bS);
        a(cS);
        a(dS);
        a(eS);
        a(fS);
        a(gS);
        a(hS);
        a(jS);
        a(wF);
        a(nS);
        a(oS);
        a(qS);
        a(rS);
        a(tS);
        a(wS);
        a(yS);
        a(zS);
        a(BS);
        a(CS);
        a(DS);
        a(FS);
        a(GS);
        a(HS);
        a(JS);
        a(KS);
        a(MS);
        a(NS);
        a(PS);
        a(QS);
        a(RS);
        a(TS);
        a(US);
        a(VS);
        a(XS);
        a(YS);
        a(ZS);
        a($S);
        a(cT);
        a(eT);
        a(fT);
        a(hT);
        kT("internal.IframingStateSchema", IR());
        kT("internal.quickHash", pi);
        P(160) ? b(VR) : b(SR);
        return lT()
    };
    var lE;

    function nT() {
        var a = data.sandboxed_scripts,
            b = data.security_groups,
            c = data.runtime || [],
            d = data.runtime_lines;
        lE = new uf;
        oT();
        fg = kE();
        var e = lE,
            f = mT(),
            g = new Qd("require", f);
        g.Wa();
        e.D.D.set("require", g);
        jb.set("require", g);
        for (var h = 0; h < c.length; h++) {
            var l = c[h];
            if (!Array.isArray(l) || l.length < 3) {
                if (l.length === 0) continue;
                break
            }
            d && d[h] && d[h].length && Eg(l, d[h]);
            try {
                lE.execute(l)
            } catch (q) {}
        }
        if (a && a.length)
            for (var n = 0; n < a.length; n++) {
                var p = a[n].replace(/^_*/, "");
                Fj[p] = ["sandboxedScripts"]
            }
        pT(b)
    }

    function oT() {
        lE.kd(function(a, b, c) {
            qs.SANDBOXED_JS_SEMAPHORE = qs.SANDBOXED_JS_SEMAPHORE || 0;
            qs.SANDBOXED_JS_SEMAPHORE++;
            try {
                return a.apply(b, c)
            } finally {
                qs.SANDBOXED_JS_SEMAPHORE--
            }
        })
    }

    function pT(a) {
        a && Lb(a, function(b, c) {
            for (var d = 0; d < c.length; d++) {
                var e = c[d].replace(/^_*/, "");
                Fj[e] = Fj[e] || [];
                Fj[e].push(b)
            }
        })
    };

    function qT(a) {
        NB(Ys("developer_id." + a, !0), 0, {})
    };
    var rT = Array.isArray;

    function sT(a, b) {
        return Jd(a, b || null)
    }

    function X(a) {
        return window.encodeURIComponent(a)
    }

    function tT(a, b, c) {
        gd(a, b, c)
    }

    function uT(a) {
        var b = ["veinteractive.com", "ve-interactive.cn"];
        if (!a) return !1;
        var c = Mj(Sj(a), "host");
        if (!c) return !1;
        for (var d = 0; b && d < b.length; d++) {
            var e = b[d] && b[d].toLowerCase();
            if (e) {
                var f = c.length - e.length;
                f > 0 && e.charAt(0) !== "." && (f--, e = "." + e);
                if (f >= 0 && c.indexOf(e, f) === f) return !0
            }
        }
        return !1
    }

    function vT(a, b, c) {
        for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
        return e ? d : null
    }

    function wT(a, b) {
        var c = {};
        if (a)
            for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
        if (b) {
            var e = vT(b, "parameter", "parameterValue");
            e && (c = sT(e, c))
        }
        return c
    }

    function xT(a, b, c) {
        return a === void 0 || a === c ? b : a
    }

    function yT(a, b, c) {
        return cd(a, b, c, void 0)
    }

    function zT(a, b) {
        return vt(a, b || 2)
    }

    function AT(a, b) {
        w[a] = b
    }

    function BT(a, b, c) {
        var d = w;
        b && (d[a] === void 0 || c && !d[a]) && (d[a] = b);
        return d[a]
    }
    var CT = {},
        DT = M.N;
    var Y = {
        securityGroups: {}
    };

    Y.securityGroups.access_globals = ["google"],
        function() {
            function a(b, c, d) {
                var e = {
                    key: d,
                    read: !1,
                    write: !1,
                    execute: !1
                };
                switch (c) {
                    case "read":
                        e.read = !0;
                        break;
                    case "write":
                        e.write = !0;
                        break;
                    case "readwrite":
                        e.read = e.write = !0;
                        break;
                    case "execute":
                        e.execute = !0;
                        break;
                    default:
                        throw Error("Invalid " + b + " request " + c);
                }
                return e
            }(function(b) {
                Y.__access_globals = b;
                Y.__access_globals.H = "access_globals";
                Y.__access_globals.isVendorTemplate = !0;
                Y.__access_globals.priorityOverride = 0;
                Y.__access_globals.isInfrastructure = !1;
                Y.__access_globals["5"] = !1
            })(function(b) {
                for (var c = b.vtp_keys || [], d = b.vtp_createPermissionError, e = [], f = [], g = [], h = 0; h < c.length; h++) {
                    var l = c[h],
                        n = l.key;
                    l.read && e.push(n);
                    l.write && f.push(n);
                    l.execute && g.push(n)
                }
                return {
                    assert: function(p, q, r) {
                        if (!Db(r)) throw d(p, {}, "Key must be a string.");
                        if (q === "read") {
                            if (e.indexOf(r) > -1) return
                        } else if (q === "write") {
                            if (f.indexOf(r) > -1) return
                        } else if (q === "readwrite") {
                            if (f.indexOf(r) > -1 && e.indexOf(r) > -1) return
                        } else if (q === "execute") {
                            if (g.indexOf(r) > -1) return
                        } else throw d(p, {}, "Operation must be either 'read', 'write', or 'execute', was " + q);
                        throw d(p, {}, "Prohibited " + q + " on global variable: " + r + ".");
                    },
                    W: a
                }
            })
        }();
    Y.securityGroups.get_referrer = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Y.__get_referrer = b;
                Y.__get_referrer.H = "get_referrer";
                Y.__get_referrer.isVendorTemplate = !0;
                Y.__get_referrer.priorityOverride = 0;
                Y.__get_referrer.isInfrastructure = !1;
                Y.__get_referrer["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"),
                    b.vtp_query && c.push("query"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!Db(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!Db(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " +
                                    h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    W: a
                }
            })
        }();
    Y.securityGroups.read_event_data = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Y.__read_event_data = b;
                Y.__read_event_data.H = "read_event_data";
                Y.__read_event_data.isVendorTemplate = !0;
                Y.__read_event_data.priorityOverride = 0;
                Y.__read_event_data.isInfrastructure = !1;
                Y.__read_event_data["5"] = !1
            })(function(b) {
                var c = b.vtp_eventDataAccess,
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (g != null && !Db(g)) throw e(f, {
                            key: g
                        }, "Key must be a string.");
                        if (c !== "any") {
                            try {
                                if (c ===
                                    "specific" && g != null && nh(g, d)) return
                            } catch (h) {
                                throw e(f, {
                                    key: g
                                }, "Invalid key filter.");
                            }
                            throw e(f, {
                                key: g
                            }, "Prohibited read from event data.");
                        }
                    },
                    W: a
                }
            })
        }();

    Y.securityGroups.read_data_layer = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Y.__read_data_layer = b;
                Y.__read_data_layer.H = "read_data_layer";
                Y.__read_data_layer.isVendorTemplate = !0;
                Y.__read_data_layer.priorityOverride = 0;
                Y.__read_data_layer.isInfrastructure = !1;
                Y.__read_data_layer["5"] = !1
            })(function(b) {
                var c = b.vtp_allowedKeys || "specific",
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (!Db(g)) throw e(f, {}, "Keys must be strings.");
                        if (c !== "any") {
                            try {
                                if (nh(g,
                                        d)) return
                            } catch (h) {
                                throw e(f, {}, "Invalid key filter.");
                            }
                            throw e(f, {}, "Prohibited read from data layer variable: " + g + ".");
                        }
                    },
                    W: a
                }
            })
        }();








    Y.securityGroups.get_url = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Y.__get_url = b;
                Y.__get_url.H = "get_url";
                Y.__get_url.isVendorTemplate = !0;
                Y.__get_url.priorityOverride = 0;
                Y.__get_url.isInfrastructure = !1;
                Y.__get_url["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"), b.vtp_query && c.push("query"), b.vtp_fragment &&
                    c.push("fragment"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!Db(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!Db(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " + h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    W: a
                }
            })
        }();

    Y.securityGroups.inject_script = ["google"],
        function() {
            function a(b, c) {
                return {
                    url: c
                }
            }(function(b) {
                Y.__inject_script = b;
                Y.__inject_script.H = "inject_script";
                Y.__inject_script.isVendorTemplate = !0;
                Y.__inject_script.priorityOverride = 0;
                Y.__inject_script.isInfrastructure = !1;
                Y.__inject_script["5"] = !1
            })(function(b) {
                var c = b.vtp_urls || [],
                    d = b.vtp_createPermissionError;
                return {
                    assert: function(e, f) {
                        if (!Db(f)) throw d(e, {}, "Script URL must be a string.");
                        try {
                            if (Fh(Sj(f), c)) return
                        } catch (g) {
                            throw d(e, {}, "Invalid script URL filter.");
                        }
                        throw d(e, {}, "Prohibited script URL: " + f);
                    },
                    W: a
                }
            })
        }();




    Y.securityGroups.logging = ["google"],
        function() {
            function a() {
                return {}
            }(function(b) {
                Y.__logging = b;
                Y.__logging.H = "logging";
                Y.__logging.isVendorTemplate = !0;
                Y.__logging.priorityOverride = 0;
                Y.__logging.isInfrastructure = !1;
                Y.__logging["5"] = !1
            })(function(b) {
                var c = b.vtp_environments || "debug",
                    d = b.vtp_createPermissionError;
                return {
                    assert: function(e) {
                        var f;
                        if (f = c !== "all" && !0) {
                            var g = !1;
                            f = !g
                        }
                        if (f) throw d(e, {}, "Logging is not enabled in all environments");
                    },
                    W: a
                }
            })
        }();





    var ET = {},
        ts = {
            dataLayer: wt,
            callback: function(a) {
                ET.hasOwnProperty(a) && Cb(ET[a]) && ET[a]();
                delete ET[a]
            },
            bootstrap: 0
        };

    function FT() {
        ss();
        Dk();
        Zz();
        Wb(Fj, Y.securityGroups);
        var a = zk(Ak()),
            b, c = a == null ? void 0 : (b = a.context) == null ? void 0 : b.source;
        eo(c, a == null ? void 0 : a.parent);
        c !== 2 && c !== 4 && c !== 3 || Q(142);
        rg = {
            Vq: Lg
        }
    }

    function GT() {
        var a = E(60);
        a && a && (fL[a] = !0)
    }

    function qn() {
        try {
            if (xg(47) || !Mk()) {
                wj();
                if (P(109)) {}
                hb[6] = !0;
                var a = rs("debugGroupId", function() {
                    return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
                });
                mo(a);
                zs();
                WD();
                Fu();
                vB();
                if (Ek()) {
                    E(5);
                    tF();
                    SA().removeExternalRestrictions(wk());
                } else {
                    os();
                    pg();
                    lg = Y;
                    mg = ED;
                    By();
                    nT();
                    FT();
                    CD();
                    on || (nn = sn(), nn["0"] && Qm(Lm.Z.Oe, JSON.stringify(nn)));
                    Do();
                    FC();
                    BB();
                    uB();
                    ll && (Ft(St), w.setInterval(Rt, 864E5), Ft(XD), Ft(KA), Ft(Nx), Ft(Vt), Ft(hE), Ft(QA), zD = {}, Ft(BD), ll && (P(468) && Ft(dE), P(478) && Ft(eE)));
                    nl && (bn(), Qs(), HC(), WC(), UC(), Sk("bt", String(xg(47) ? 2 : xg(50) ? 1 : 0)), Sk("ct", String(xg(47) ? 0 : xg(50) ? 1 : 3)), LC(), TC(), RC(), Cw());
                    qD();
                    mn(1);
                    uF();
                    ts.bootstrap = Tb();
                    xg(51) && EC();
                    P(109) && iy();
                    typeof w.name === "string" && Yb(w.name, "web-pixel-sandbox-CUSTOM") && yd() ? qT("dMDg0Yz") : w.Shopify && (qT("dN2ZkMj"), yd() && qT("dNTU0Yz"));
                    GT()
                }
            }
        } catch (b) {
            mn(5), Ot()
        }
    }
    (function(a) {
        function b() {
            n = A.documentElement.getAttribute("data-tag-assistant-present");
            Rn(n) && (l = h.gm)
        }

        function c() {
            l && Uc ? g(l) : a()
        }
        if (!w[E(37)]) {
            var d = !1;
            if (A.referrer) {
                var e = Sj(A.referrer);
                d = Oj(e, "host") === E(38)
            }
            if (!d) {
                var f = Rp(E(39));
                d = !(!f.length || !f[0].length)
            }
            d && (w[E(37)] = !0, cd(E(40)))
        }
        var g = function(u) {
                var v = "GTM",
                    x = "GTM";
                Bj && (v = "OGT", x = "GTAG");
                var y = E(23),
                    z = w[y];
                z || (z = [], w[y] = z, cd("https://" + E(3) + "/debug/bootstrap?id=" + E(5) + "&src=" + x + "&cond=" + String(u) + "&gtm=" + Xk()));
                var C = {
                    messageType: "CONTAINER_STARTING",
                    data: {
                        scriptSource: Uc,
                        containerProduct: v,
                        debug: !1,
                        id: E(5),
                        targetRef: {
                            ctid: E(5),
                            isDestination: tk(),
                            canonicalId: E(6)
                        },
                        aliases: xk(),
                        destinations: uk()
                    }
                };
                C.data.resume = function() {
                    a()
                };
                xg(2) && (C.data.initialPublish = !0);
                z.push(C)
            },
            h = {
                hq: 1,
                Bm: 2,
                Wm: 3,
                Nk: 4,
                gm: 5
            };
        h[h.hq] = "GTM_DEBUG_LEGACY_PARAM";
        h[h.Bm] = "GTM_DEBUG_PARAM";
        h[h.Wm] = "REFERRER";
        h[h.Nk] = "COOKIE";
        h[h.gm] = "EXTENSION_PARAM";
        var l = void 0,
            n = void 0,
            p = Mj(w.location, "query", !1, void 0, "gtm_debug");
        Rn(p) && (l = h.Bm);
        if (!l && A.referrer) {
            var q = Sj(A.referrer);
            Oj(q,
                "host") === E(24) && (l = h.Wm)
        }
        if (!l) {
            var r = Rp("__TAG_ASSISTANT");
            r.length && r[0].length && (l = h.Nk)
        }
        l || b();
        if (!l && Qn(n)) {
            var t = !1;
            hd(A, "TADebugSignal", function() {
                t || (t = !0, b(), c())
            }, !1);
            w.setTimeout(function() {
                t || (t = !0, b(), c())
            }, 200)
        } else c()
    })(function() {
        !xg(47) || sn()["0"] ? qn() : pn()
    });

})()